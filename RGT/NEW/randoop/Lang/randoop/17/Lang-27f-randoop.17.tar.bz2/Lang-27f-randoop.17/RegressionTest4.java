import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "EIHPOS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("urrent.jar");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/0.0-1.0:/usr/lib/java");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/0.0-1.0:/usr/lib/java", strArray2, strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/0.0-1.0:/usr/lib/java" + "'", str5.equals("/Users/sophie/0.0-1.0:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("jAVA vIRTUAL mACHINE sPECIFICATION", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mAC os x", "ava");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(" ", "J v  HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJo", "1.7.0717-b15.1-.71..71b100--bb10g.177.7:1.7.0717-b15.1-.71..710.w-0k15b1.7g..05-1g..05-10--b-00.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str3.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-1.Oracle Corporation0.0-1.Oracl", "/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("urrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja", 31, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "mac os x                ", 100, 100);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-b11                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11                " + "'", str1.equals("24.80-b11                "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "/users/sophie/documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/users/sophie/documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                 1.7.0_80                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JmAC/s/x////////////////////////////////////////mAC/s/x////////////////////////////////////////////", "mac os x                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe", "", 0, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe" + "'", str4.equals("mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "Jr", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("J v  HotSpot(TM) 6-Bit Server VM################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J v  HotSpot(TM) 6-Bit Server VM################" + "'", str1.equals("J v  HotSpot(TM) 6-Bit Server VM################"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification", 212, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                          Java Platform API Specification                                                                                           " + "'", str3.equals("                                                                                          Java Platform API Specification                                                                                           "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("er", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r" + "'", str2.equals("r"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "                                ");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        int[] intArray2 = new int[] { '4', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("dea", "java Platform API Specif");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str2.equals("0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("USERSaSOPHIEaLIBRARYaJAVAaEXTENSIONS:aLIBRARYaJAVAaJAVAVIRTUALMACHINESaJDK1.7.0_80.JDKaCONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("ORACLE CORPORATION", "TTP://JV");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("EIHPOS", "EIHPOS", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b11" + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b11"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aamixed modeaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) 32, (double) 2776);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2776.0d + "'", double3 == 2776.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi!", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.0-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                                EN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3", 67, 122);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("URRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "URRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA" + "'", str2.equals("URRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RNDOOP.PL_10404_1560228757/TRGET/CLSSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRMEWORK/LIB/TEST_GENERTION/GENERTION/RNDOOP-CURRENT.JRURRENT.JA"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION", "                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(67, (int) '4', (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str1.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("sun.lwawt.macosx.CPrinterJobracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/users/sophie/documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/users/sophie/documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/0.0-1.0:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/0.0-1.0:/usr/lib/java" + "'", str1.equals("/Users/sophie/0.0-1.0:/usr/lib/java"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", 2310, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.14.3", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        double[] doubleArray4 = new double[] { 100L, (short) -1, (-1L), (byte) 100 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mac os x                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ", (java.lang.CharSequence) "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.Oracle");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2719 + "'", int2 == 2719);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie/Documents0.0-1.ion/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents0.0-1.ion/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents0.0-1.ion/randoop-current.jar"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 14);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 14.0f + "'", float2 == 14.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Mac OS X", "SOPHIE", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "10.14.3", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "Java Platform API Specification");
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                                                                                               Oracle Corporation", strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray9, strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/", strArray4, strArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Mac OS X" + "'", str5.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "http://java.oracle.com/" + "'", str17.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java Platform API Specification" + "'", str18.equals("Java Platform API Specification"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.3", 52, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine S10.14.3Java Virtual Machine Sp" + "'", str3.equals("Java Virtual Machine S10.14.3Java Virtual Machine Sp"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Sun.lwawt.macosx.CPrinterJo", "JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("JmAC/s/x////////////////////////////////////////mAC/s/x////////////////////////////////////////////", "raj.tnerru", 1629);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "EN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3" + "'", str1.equals("eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                       ", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph", (int) (short) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.Oracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java Platform API Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specif" + "'", str1.equals("java platform api specif"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("EIHPOS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EIHPOS" + "'", str1.equals("EIHPOS"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aamixed modeaa", 97, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aamixed modeaa" + "'", str3.equals("aamixed modeaa"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double[] doubleArray2 = new double[] { 0.0f, (-1.0f) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "10.14.3", (int) (byte) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "Java Platform API Specification");
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                                                                                               Oracle Corporation", strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/", strArray5, strArray10);
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                ", strArray5);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "J v  HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Mac OS X" + "'", str6.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "http://java.oracle.com/" + "'", str18.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Mac OS X" + "'", str21.equals("Mac OS X"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                en/Users/sophie/0.0-1.0:/usr/lib/java4.3", "oaC-rs-x----------------------------------------");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oaC-rs-x----------------------------------------" + "'", str2.equals("oaC-rs-x----------------------------------------"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                             sophie                                             ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        long[] longArray6 = new long[] { (short) 100, (byte) -1, 10L, (byte) 100, 7, 28 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "TTP://JV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javaon Platform API JavatSpecification Platform API JavapoSpecification Platform API CoSpecification Javacle Platform API OSpecification" + "'", str2.equals("Javaon Platform API JavatSpecification Platform API JavapoSpecification Platform API CoSpecification Javacle Platform API OSpecification"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("java platform api specif", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                en/Users/sophie/0.0-1.0:/usr/lib/java4.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("wawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"r\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 35, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "sUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "1.7.0_80-b15", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("en", "URRENT.JA", "wawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.Oracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        char[] charArray11 = new char[] { ' ', '4', '#', '#', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ava", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("urrent.ja");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents0.0-1.ion/randoop-current.jar", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("H", "Java Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "H" + "'", str2.equals("H"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Jr");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", "mac os x                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str2.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("mACosx", "Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph", "mac os x                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757", "!", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31L, (float) 24, (float) 67);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("#########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################ttp://jv", "SOPHIE", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ttp://jav", "/Users/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://jav" + "'", str2.equals("ttp://jav"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/users/sophie/documents0.0-1.ion/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                  HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 2776, 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "    USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str4.equals("    USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sUN.LWAWT.MACOSX.cpRINTERjO");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                             sophie                                              ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(67, 24, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.awt.CGraphicsEnvironment", "Jr", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("MacOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        short[] shortArray0 = new short[] {};
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("oaC-rs-x----------------------------------------", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mACosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mACosx", (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0a.a0a-a1a.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a.a0a-a1a." + "'", str1.equals("0a.a0a-a1a."));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sophie", 96, "h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiehhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh" + "'", str3.equals("sophiehhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("dea");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dea" + "'", str1.equals("dea"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "/", (int) (short) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "USERSaSOPHIEaLIBRARYaJAVAaEXTENSIONS:aLIBRARYaJAVAaJAVAVIRTUALMACHINESaJDK1.7.0_80.JDKaCONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str7.equals("USERSaSOPHIEaLIBRARYaJAVAaEXTENSIONS:aLIBRARYaJAVAaJAVAVIRTUALMACHINESaJDK1.7.0_80.JDKaCONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                Java Platform API Specification  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("X SO caM", "1.7.0_80-b15", "                \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caM" + "'", str3.equals("X SO caM"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 163);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                                                                               ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("NOITAROPROC ELCARO                                                                                                                                                               ", "                                                       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/users/sophie/documents0.0-1.ion/randoop-current.ja", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("urrent.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "urrent.j" + "'", str1.equals("urrent.j"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", "Oracle Corporatio");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("us", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7578220651_001_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java(TM) SE Runtime Environment", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java Virtual Machine Specification                                                               ", (java.lang.CharSequence) "0.0-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, 1.0f, (float) 24);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", "0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", "eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str2.equals("\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("-un.lw4wt.24.0-1.CPrinterJ0br4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-1.Or4.le8C0rp0r4ti0n0.0-", "USERSaSOPHIEaLIBRARYaJAVAaEXTENSIONS:aLIBRARYaJAVAaJAVAVIRTUALMACHINESaJDK1.7.0_80.JDKaCONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("J v  HotSpot(TM) 64-Bit Server VM", " E");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J v  HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("J v  HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r ndoop.pl_10404_1560228757");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r" + "'", str1.equals("r"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("java platform api specif", "urrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jrurrent.ja", 170);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM" + "'", str2.equals("JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("TTP://JV", 0, "                                                                                 1.7.0_80                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TTP://JV" + "'", str3.equals("TTP://JV"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "24.80-b11                ", "H", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.", "MacOSX");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("URRENT.JA                                                                                        ", "OracleCorporation", "                ///////////////////////////////////////////////////////////////////                 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Platform API Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specif" + "'", str1.equals("Java Platform API Specif"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 2801.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2801.0f + "'", float2 == 2801.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.Oracle Corporation0.0-1.Oracl");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mac os x                ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.ja", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0a.a0a-a1a.", "                \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 " + "'", str2.equals("                \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("TTP://JV                                                                                            ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                ...", (int) (short) 1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/", "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("s", "JavaPlatformAPISpecification", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Librar0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("tionacle Corpora                                                                                                                                                               Or", 26, 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                                                          ..." + "'", str3.equals("...                                                                          ..."));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                             sophie                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                             SOPHIE                                              " + "'", str1.equals("                                             SOPHIE                                              "));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "MacOSX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("urrent.ja                                                                                        ", "sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JmAC os x                                        vmAC os x                                         HotSpot(TM) 64-Bit Server VM", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0a.a0a-a1a.", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a.a0a-a1a." + "'", str2.equals("0a.a0a-a1a."));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("Java Platform API Specification", strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0" + "'", str4.equals("51.0"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java(TM) SE Runtime Environment", "sun....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/users/sophie/documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/users/sophie/documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "noitaroproC elcarO                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun....", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun...." + "'", str2.equals("sun...."));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        char[] charArray13 = new char[] { ' ', ' ', '#', '4', ' ' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "urrent.jars/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ttp://jav", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny("", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.Oracle", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny("X SO caM", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_r ndoop.pl_10404_1560228757", (int) (short) -1, "ttp://jv                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_r ndoop.pl_10404_1560228757" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_r ndoop.pl_10404_1560228757"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "24.80-b11                ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "24.80-b11                " + "'", charSequence2.equals("24.80-b11                "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                             SOPHIE                                              ", "mac os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/", "mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("E", "/Libr ry/J v /J v Virtu lM chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Libr ry/J v /J v Virtu lM chines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Libr ry/J v /J v Virtu lM chines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sophiesophiesophiesophiesophiesophiesophiesophiesoph", "sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesoph" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesoph"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "10.14.3", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "Java Platform API Specification");
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                                                                                               Oracle Corporation", strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray9, strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/", strArray4, strArray9);
        java.lang.Class<?> wildcardClass18 = strArray4.getClass();
        java.lang.Class<?> wildcardClass19 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Mac OS X" + "'", str5.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "http://java.oracle.com/" + "'", str17.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" E");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", "x86_64", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "                                                                                                                                                               Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Librar0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("-1.Oracle Corporation0.0-1.Oracl...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, (double) 100, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" ", ":", 1629, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                en/Users/sophie/0.0-1.0:/usr/lib/java4.", "0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 163, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.oracle corporation0.0-1.", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                 1.7.0_80                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophments/defectsj/framework/lib/test_generation/generation/randoop-current.jar", "10.14.3                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophments/defectsj/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophments/defectsj/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        int[] intArray2 = new int[] { '4', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" E");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E" + "'", str1.equals("E"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 14, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.HTTP://JAVA.ORACLE.COM/", "-1.Oracle Corporation0.0-1.Oracl", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ttp://jav", "", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ttp://jav" + "'", str5.equals("ttp://jav"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TTP://JV                                                                                            ", "raj.tnerru", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7.0_8", "mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0.0-1.Oracle Corporation0.0-...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("NOITAROPROC ELCARO                                                                                                                                                               ", "################################", 2799);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/users/sophie/documents0.0-1.ion/randoop-current.jar", 122);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents0.0-1.ion/randoop-current.jar                                                                      " + "'", str2.equals("/users/sophie/documents0.0-1.ion/randoop-current.jar                                                                      "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0-1.", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0-1." + "'", str3.equals("0.0-1."));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        char[] charArray9 = new char[] { ' ', ' ', '#', '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "urrent.jars/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.http://jv.orcle.com/", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "Java Virtual Machine S10.14.3Java Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1955 + "'", int2 == 1955);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun....", "O4racle4 4C4orporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0.0-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0-1.0" + "'", str1.equals("0.0-1.0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                 1.7.0_80                                                                                 ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ttp://jv");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("                                en/Users/sophie/0.0-1.0:/usr/lib/java4.3", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttp://jv" + "'", str3.equals("ttp://jv"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ttp://jv" + "'", str4.equals("ttp://jv"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("10.14.3                                                                                                                                                                                                             ", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                             sophie                                              ", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                          Java Platform API Specification                                                                                           ", "aamixed modeaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "        ORACLE CORPORATION         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("mAC os x                                        ", "EIHPOS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EIHPOS" + "'", str2.equals("EIHPOS"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("X SO caM", 1, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("urrent.ja", "                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", 28, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "urrent.ja                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon" + "'", str4.equals("urrent.ja                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Virtual Machine S10.14.3Java Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0a.a0a-a1a.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("oaC-rs-x----------------------------------------", 28, 2310);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--------------------" + "'", str3.equals("--------------------"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                                                                                                                                                               Oracle Corporation", "                                                                                 1.7.0_80                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.14.310.14.310.14.3" + "'", str3.equals("10.14.310.14.310.14.310.14.310.14.310.14.310.14.3"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Java Platform API Specification");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("                                en/Users/sophie/0.0-1.0:/usr/lib/java4.3", (java.lang.Object[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph" + "'", str5.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph" + "'", str6.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("################################", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("--------------------");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "--------------------" + "'", str1.equals("--------------------"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.ja", "Oc Ct", "-1.Oracle Corporation0.0-1.Oracl...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/Users/sophie/Do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja" + "'", str3.equals("/Users/sophie/Do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/Users/sophie/Do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b11", "24.80-b11                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ":");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 100, 163);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.", 80, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:", "us", 2719);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(11, 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.Oracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("raj.tnerru");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerru" + "'", str1.equals("raj.tnerru"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("TTP://JV                                                                                            ", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "///////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("raj.tnerru");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerru" + "'", str1.equals("raj.tnerru"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0-1.0", 122, "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0.0-1.0" + "'", str3.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0.0-1.0"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "urrent.jars/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aamixed modeaa", "", "ttp://jv");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                ///////////////////////////////////////////////////////////////////                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "///////////////////////////////////////////////////////////////////" + "'", str1.equals("///////////////////////////////////////////////////////////////////"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("JmAC/s/x////////////////////////////////////////mAC/s/x////////////////////////////////////////////");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("URRENT.JA", "", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "URRENT.JA" + "'", str3.equals("URRENT.JA"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_r ndoop.pl_10404_1560228757");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                               ORACLE CORPORATION", (java.lang.CharSequence) "0.0-1.oracle ...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 176 + "'", int2 == 176);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0a.a0a-a1a.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A.A0A-A1A." + "'", str1.equals("0A.A0A-A1A."));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("raj.tnerru", "                  HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "oaC-rs-x----------------------------------------");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                Java Platform API Specification  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                JAVA PLATFORM API SPECIFICATION  " + "'", str1.equals("                                                JAVA PLATFORM API SPECIFICATION  "));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("raj.tnerru", "                                ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("X SO caM", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(6L, (long) 176, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/24.80-b11", "s", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "################################", (int) (short) 10, 0);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                ///////////////////////////////////////////////////////////////////                 ", (int) '#', 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", "0.0-1.oracle ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                  Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  Java Virtual Machine Specification" + "'", str1.equals("                  Java Virtual Machine Specification"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 81L, 67.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 81.0f + "'", float3 == 81.0f);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("O4racle4 4C4orporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"O4ra\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aamixed modeaa", "                                EN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "EN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mac os x", (int) (byte) 100, 176);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                en/Users/sophie/0.0-1.0:/usr/lib/java4.", "0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", 122);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/users/sophie/documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/users/sophie/documents/defectsj/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_100_1560228757/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_100_1560228757/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "JmAC/s/x////////////////////////////////////////mAC/s/x////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 16, (double) 52, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(" E", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " E" + "'", str2.equals(" E"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "                                             SOPHIE                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolkit", "eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Oracle Corporatio", "0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.http://java.oracle.com/dea");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("--------------------", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "--------------------" + "'", str2.equals("--------------------"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/", "mAC os x                ", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                JAVA PLATFORM API SPECIFICATION  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                java platform api specification  " + "'", str1.equals("                                                java platform api specification  "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "sun....");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java Platform API Specification" + "'", charSequence2.equals("Java Platform API Specification"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("wawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0.0-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("wawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str1.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "J v  HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                             sophie                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                                       ", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7578220651_001_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrin", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("java platform api specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIF" + "'", str1.equals("JAVA PLATFORM API SPECIF"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesop", "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(2776);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents0.0-1.ion/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                ///////////////////////////////////////////////////////////////////                 ", "Java Virtual Machine Specification", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Jr", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jr" + "'", str2.equals("Jr"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str2.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 26, 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 16, (float) 81, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporatio" + "'", str1.equals("oracle corporatio"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/", "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/library/java/javavirtualmachines/jdk", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk" + "'", str2.equals("/library/java/javavirtualmachines/jdk"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(":", "mAC os x                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophments/defectsj/framework/lib/test_generation/generation/randoop-current.jar", 1629, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "_1" + "'", str3.equals("_1"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.oRACLE cORPORATION0.0-1.", "mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("################################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("h", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1." + "'", str2.equals("0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1.OracleCorporation0.0-1."));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) -1, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                  HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  HotSpot(TM) 64-Bit Server V" + "'", str1.equals("                  HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM", "                                             SOPHIE                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("J v  HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J V  HOTSPOT(TM) 6-BIT SERVER VM" + "'", str1.equals("J V  HOTSPOT(TM) 6-BIT SERVER VM"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("J V  HOTSPOT(TM) 6-BIT SERVER VM", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", "\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("mac os x", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Sun.lwawt.macosx.CPrinterJo", "java platform api specif");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("TTP://JV                                                                                            ", "                                                java platform api specification  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                                               Oracle Corporation", "r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        float[] floatArray2 = new float[] { 24L, 10 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 24.0f + "'", float3 == 24.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("tionacle Corpora                                                                                                                                                               Or", "                                                java platform api specification  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/jstcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7578220651_001_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("oaC-rs-x----------------------------------------", "/Users/sophie/Documents0.0-1.ion/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C-rs-x" + "'", str2.equals("C-rs-x"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:", "10.14.3");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                 ", "0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ttp://jav", "", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 81, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 81");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "        ORACLE CORPORATION         ", (java.lang.CharSequence) "urrent.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        char[] charArray12 = new char[] { ' ', ' ', '#', '4', ' ' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "urrent.jars/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51.0", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ttp://jav", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny("                  HotSpot(TM) 64-Bit Server V", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("sun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("urrent.ja                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecification" + "'", str1.equals("JavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecification"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/", "us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sophiehhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/Users/sophie/Do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/users/sophie/do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja" + "'", str1.equals("/users/sophie/do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/users/sophie/do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "--------------------");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                  HotSpot(TM) 64-Bit Server VM", "mAC os x                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("                  HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.0-1.oracle ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("JavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecification" + "'", str1.equals("JavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecificationurrent.jarJavaVirtualMachineSpecification"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.0-1.oracle ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0-1.oracle ...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        int[] intArray2 = new int[] { '4', 0 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/users/sophie/do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/users/sophie/do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/users/sophie/do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja" + "'", str1.equals("/users/sophie/do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/users/sophie/do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.CPrinterJobracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJobracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("JavaPlatformAPISpecification", "################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Libr ry/J v /J v Virtu lM chines/jdk1.7.0_80.jdk/Contents/Home/jre", "ttp://jav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                  Java Virtual Machine Specification", 97, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavaJ" + "'", str2.equals("tionatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavaJ"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("eN/USERS/SOPHIE/0.0-1.0:/USR/LIB/JAVA4.3", "", 81);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("EIHPOS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"EIHPOS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                  HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                  HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("HotSpot(TM) 64-Bit Server VM444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", "    USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie" + "'", str2.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.Object[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0.0-1.");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "10.14.3", (int) (byte) 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "Java Platform API Specification");
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                                                                                               Oracle Corporation", strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.com/", strArray5, strArray10);
        int int19 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                ", strArray5);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Mac OS X" + "'", str6.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "http://java.oracle.com/" + "'", str18.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Mac OS X" + "'", str20.equals("Mac OS X"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("10.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.", "                                                                                                                                                               ORACLE CORPORATION", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 2719);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2719 + "'", int3 == 2719);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                ///////////////////////////////////////////////////////////////////                 ", "java platform api specif", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mac os x                ", 1629, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("oracle corporatio", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporatio" + "'", str2.equals("oracle corporatio"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 176, (double) 4, (double) 3L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", "r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie" + "'", str2.equals("0.0-1.\n\n\n\n/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "JavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecificationJvHotSpot(TM)64-BitServerVMJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0.0-1.Oracle Corporation0.0-...", "0.0-1.oracle ...", "Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) ' ', 32, 81);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "java Platform API Specif", (java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(27, 28, 163);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/soph", 176, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0a.a0a-a1a.", "mac os x ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("java platform api specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaplatformapispecif" + "'", str1.equals("javaplatformapispecif"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM", "-1.Oracle Corporation0.0-1.Oracl...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM" + "'", str2.equals("JMAC OS X                                        VMAC OS X                                         HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("    USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (float) 2799);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2799.0f + "'", float2 == 2799.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0717-b15.1-.71..71b100--bb10g.177.7:1.7.0717-b15.1-.71..710.w-0k15b1.7g..05-1g..05-10--b-00.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Javaon Platform API JavatSpecification Platform API JavapoSpecification Platform API CoSpecification Javacle Platform API OSpecification", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javaon Platform API JavatSpecification Platform API JavapoSpecification Platform API CoSpecification Javacle Platform API OSpecification" + "'", str2.equals("Javaon Platform API JavatSpecification Platform API JavapoSpecification Platform API CoSpecification Javacle Platform API OSpecification"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("tionatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavationJvHotSpot(TM)64-BitServerVMJatformAPISpecificaPlavaJ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("E", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                          Java Platform API Specification                                                                                           ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API SpecificationJ v  HotSpot(TM) 64-Bit Server VMJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "...                                                                          ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                                                                               ORACLE CORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                               ORACLE CORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.http://jv.orcle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.0-1.Orcle Corportion0.http://jv.orcle.com/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "urrent.jars/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe", "                                                                                          Java Platform API Specification                                                                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe" + "'", str2.equals("mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Librar0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 28, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Librar0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("/Librar0.0-1.\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("urrent.ja                                                                                        ", "Sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "userssophielibraryjavaextensions:libraryjavaextensions:networklibraryjavaextensions:systemlibraryjavaextensions:usrlibjava:" + "'", str1.equals("userssophielibraryjavaextensions:libraryjavaextensions:networklibraryjavaextensions:systemlibraryjavaextensions:usrlibjava:"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java HotSpot(TM) 64-Bit Server VM", 0, "    USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                  HotSpot(TM) 64-Bit Server V", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                                                                               ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                               ORACLE CORPORATION" + "'", str1.equals("                                                                                                                                                               ORACLE CORPORATION"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("urrent.j");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sUN.LWAWT.MACOSX.cpRINTERjO", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("urrent.ja                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "urrent.ja                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon" + "'", str2.equals("urrent.ja                                                                                                                                                               OSpecification API Platform Javacle CoSpecification API Platform JavapoSpecification API Platform JavatSpecification API Platform Javaon"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  HotSpot(TM) 64-Bit Server VM", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("O4racle4 4C4orporation", (double) 177.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 177.0d + "'", double2 == 177.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2801, 6, 81);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2801 + "'", int3 == 2801);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                  HotSpot(TM) 64-Bit Server VM", "", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!0.0-1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("7.1", 0, "mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.1" + "'", str3.equals("7.1"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ttp://jv                                            ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        long[] longArray2 = new long[] { 100, 100L };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("J V  HOTSPOT(TM) 6-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J V  HOTSPOT(TM) 6-BIT SERVER VM" + "'", str1.equals("J V  HOTSPOT(TM) 6-BIT SERVER VM"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, (int) 'a', 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { ' ', '4', '#', '#', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                                                                               Oracle Corporation", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("sun.awt.CGraphicsEnvironment", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        char[] charArray8 = new char[] { ' ', '4', '#', '#', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################ttp://jv", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_100_1560228757/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.lwawt.macosx.CPrinterJob", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("C-rs-x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"C-rs-x\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:", (double) 81L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.0d + "'", double2 == 81.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("java Platform API Specif", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Platform API Specif" + "'", str2.equals("java Platform API Specif"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("JAVA PLATFORM API SPECIF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.HTTP://JAVA.ORACLE.COM/", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        long[] longArray2 = new long[] { 100, 100L };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", "/Users/sophie/Documents0.0-1.ion/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("JmAC os x                                        vmAC os x                                         HotSpot(TM) 64-Bit Server VM", "", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java platform api specif", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java platform api specif" + "'", str2.equals("java platform api specif"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specificationurrent.jarJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.0-1.ORACLE CORPORATION0.HTTP://JAVA.ORACLE.COM/", (long) 177);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 177L + "'", long2 == 177L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("10.14.3                                                                                                                                                                                                             ", "Java Virtual Machine S10.14.3Java Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mACosx", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("v", "sophiesophiesophiesophiesophiesophiesophiesophiesop");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", ":", 2719);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  Java Platform API Specification  ", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  Java Platform API Specification  " + "'", str3.equals("  Java Platform API Specification  "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 100, (byte) -1, (byte) 100, (byte) 10, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, (double) 2719, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/Users/sophie/Do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja", "                ///////////////////////////////////////////////////////////////////                 ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/Users/sophie/Do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja" + "'", str3.equals("/Users/sophie/Do1umenrs/defe1rsj/rmp/run_randoop.pl_100_1560228757/rarger/1lasses:/Users/sophie/Do1umenrs/defe1rsj/framework/lib/resr_generarion/generarion/randoop-1urrenr.ja"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("urrent.ja", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("0.0-1.0", strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("noitaroproC elcarO                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarO                                  " + "'", str1.equals("noitaroproC elcarO                                  "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("J v  HotSpot(TM) 64-Bit Server VM");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "24.80-b11                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe" + "'", str1.equals("mp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defeURRENT.JA/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr/Users/sophie/Documents/defe"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", "0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.0-1.Oracle Corporation0.http://java.oracle.com/dea");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10404_1560228757/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("mixed mode", "URRENT.JA", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("H", 176, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################################################################################################################################################H" + "'", str3.equals("###############################################################################################################################################################################H"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "10.14.3", (int) (byte) 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("OracleCorporation", strArray5, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("urrent.jar");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/0.0-1.0:/usr/lib/java");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/0.0-1.0:/usr/lib/java", strArray12, strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie", strArray5, strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "OracleCorporation" + "'", str8.equals("OracleCorporation"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mac OS X" + "'", str9.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Users/sophie/0.0-1.0:/usr/lib/java" + "'", str15.equals("/Users/sophie/0.0-1.0:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "urrent.jar" + "'", str17.equals("urrent.jar"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie" + "'", str18.equals("0.0-1./Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10404_1560228757/Users/sophie"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "                                ...", "mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                mac os x                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', 212, 163);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 212 + "'", int3 == 212);
    }
}

