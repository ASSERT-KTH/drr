import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "0");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jav", 34, "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.jav" + "'", str3.equals("10.14.310.14.310.14.310.14.310.jav"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a0a100a100", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ixed mode", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-141040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-141040" + "'", str1.equals("-141040"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("-1 0 1 1 10 10", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1 0 1 1 10 10" + "'", str6.equals("-1 0 1 1 10 10"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "51B-08_0.7.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/users/sophie", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                          /users/sophie                                          " + "'", str2.equals("                                          /users/sophie                                          "));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1 . 7", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0" + "'", str2.equals("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 52, 25);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("AA", (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...E Runtime EdJava(TM) SE Ru...", (java.lang.CharSequence) "                              J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("M");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M" + "'", str1.equals("M"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################" + "'", str2.equals("###################################"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0 100.0 1.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("51B-08_0.7.", "c OS XaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51B-08_0.7." + "'", str2.equals("51B-08_0.7."));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                            ixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "35a1a1a34", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1.equals(10.0f));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("44444444444444444444444444444444444", (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444444444E34d + "'", double2 == 4.444444444444444E34d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("###########################################################################################ixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("3.41.01", "\n         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0#10.0#100.0#1.0#0.0", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                1.7                                                 ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0.9", 10, 6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("oraclecorporation", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("##!iheihpos", "                              1.7                                                 ", "35a1a1a34");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##!iheihpos" + "'", str3.equals("##!iheihpos"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, 1L, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0000000000", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444x86_644444444444444", "                              1.7                                                 ", 1, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4                              1.7                                                 444x86_644444444444444" + "'", str4.equals("4                              1.7                                                 444x86_644444444444444"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0410497");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0410497" + "'", str1.equals("0410497"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "0000000000                                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                              1.7                                                 ", "ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", 3, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 " + "'", str4.equals("   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0 100 52 -1 100", 7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("a44                                                                                                    ", "                                                                                             3.41.01", "          ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a44                                                                                                    " + "'", str4.equals("a44                                                                                                    "));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava(TM) SE Runtime Environment", "JavaHotSpot(TM)64-BitServerVMBitServerVM", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 3, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        java.lang.Class<?> wildcardClass11 = charArray7.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.010.0100.01.00.", (java.lang.CharSequence) "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, ".7.0_80-B15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str3.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str6.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("##!iheihpos", "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10" + "'", str2.equals("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtim", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim" + "'", str2.equals("Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                  US", (int) (short) -1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100", "", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java(TM) SE Runtim", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Ru" + "'", str2.equals("Java(TM) SE Ru"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   " + "'", str1.equals("   "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                 7.1                                                ", (int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                7.1                                               " + "'", str3.equals("                                                7.1                                               "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                  US", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie/Users/sophie/Documents/defec", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 100, 959);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "##############x86_64###############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                     noitacificepS IPA mroftalP avaJ", "a44                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                  0 100 52 -1 100", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("52 100 97 3 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.awt.CGraphicsE", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...", (java.lang.CharSequence) "1 . 7", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "10.14.310.14.310.14.310.14.310.jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.", (java.lang.CharSequence) "10.0a1.0a100.0a97.0a0.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 66 + "'", int3 == 66);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.310.14.310.14.310.14.310.jav", 2, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.jav" + "'", str3.equals("10.14.310.14.310.14.310.14.310.jav"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, ":", (int) '4', (int) (short) 0);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ixed mod", strArray6, strArray11);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "1 . 7", 7, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ixed mod" + "'", str17.equals("ixed mod"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("51B-08_0.7.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51B-08_0.7." + "'", str1.equals("51B-08_0.7."));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1 . 7", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence) "-1.0 100.0 1.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...", (java.lang.CharSequence) "-1.010.0100.01.00.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1.0#.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#.0#1.0#1.0#10.0" + "'", str1.equals("-1.0#.0#1.0#1.0#10.0"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 10, 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1.0#10.0#100.0#1.0#0.0", (int) '4');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", strArray4, strArray8);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "\n                                                                                                   ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0" + "'", str11.equals("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0a1.0a100.0a97.0a0.0", (double) 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        char[] charArray6 = new char[] { ' ', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!1.71.7", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.6" + "'", str4.equals("1.6"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod" + "'", str3.equals("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 0, 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("##!iheihpos", "3.41.01");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4444444444444444444444444", "                                          /users/sophie                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444" + "'", str2.equals("4444444444444444444444444"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0a1.0a1                                                                                          ", "1004041004100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", ":", "jav");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str3.equals("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1004041004100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100404100410" + "'", str1.equals("100404100410"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, 52.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", "Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod" + "'", str2.equals("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(66, (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100 97 6 100 1                  ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("d", "Java(TM) SE Runtime Environment", 217);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "en", (int) (short) -1, 959);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "100#0#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.0a1.0a100.0a97.0a0.0", (java.lang.CharSequence) "1.60.9", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("en", (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass8 = javaVersion7.getClass();
        java.lang.reflect.Type[] typeArray9 = new java.lang.reflect.Type[] { wildcardClass4, wildcardClass6, wildcardClass8 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(typeArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) typeArray9, "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(typeArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str10.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion" + "'", str12.equals("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("UTF-8", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int[] intArray5 = new int[] { '4', (byte) 100, 'a', 3, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', 34, (int) (short) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52 100 97 3 10" + "'", str7.equals("52 100 97 3 10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "52a100a97a3a10" + "'", str13.equals("52a100a97a3a10"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("A44                                                                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A44                                                                                                    " + "'", str2.equals("A44                                                                                                    "));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4.4444444E34f, (double) (short) 10, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.444444406226121E34d + "'", double3 == 4.444444406226121E34d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                              J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(49L, 0L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "1.4", 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0#1.0#100.0#97.0#0.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 52, 25);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) (short) 0, (float) 49);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JavaVirtualMachineSpecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_80-b15");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, ":", (int) '4', (int) (short) 0);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("1.7", strArray3, strArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (int) (byte) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.7" + "'", str15.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sunawtCGraphicsEnvironment" + "'", str16.equals("sunawtCGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                7.1                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.9", "4444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0 + "'", number1.equals(0));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1004041004100", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004041004100" + "'", str3.equals("1004041004100"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4', (int) ' ', 0);
        try {
            float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(".0#1.0#", "d");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.uw..CGnuGhrcsEnnrntnmen.", (java.lang.CharSequence) "###################################", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.14.3", "jAVAhOTsPOT(tm)64-bITsERVERvm", "7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################" + "'", str1.equals("###################################"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "a44");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " 44", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("35A1A1A34");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "###########################################################################################ixed mod", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(":", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", (java.lang.CharSequence) "1.7.0_80", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsE" + "'", str1.equals("Sun.awt.CGraphicsE"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80", 49, 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle CorporationOr-1.0410.04100.0", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#!iheihpos", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1 0 1 1 10 10", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 0 1 1 10 10" + "'", str2.equals("-1 0 1 1 10 10"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n         ", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0410.04100.041.040.0" + "'", str11.equals("-1.0410.04100.041.040.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str14.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "ixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0#1.0#100.0#97.0#0.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "          ", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("ophie/Users/sophie", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle CorporationOr-1.0410.04100.0", (int) (byte) 0, "vREVREsTIb-a6)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOr-1.0410.04100.0" + "'", str3.equals("Oracle CorporationOr-1.0410.04100.0"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("10.0", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0" + "'", str2.equals("10.0"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                1.7                                                 ", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, ".7.0_80-B15");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1.0410.04100.041.040.0");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0000000000");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                          /users/sophie                                          ", "J", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aa4", (java.lang.CharSequence) "oraclecorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...E Runtime EdJava(TM) SE Ru...", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "52 100 97 3 10", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 0, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1a10a0" + "'", str17.equals("-1a10a0"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                                                                            ixed mod", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                            ixed mod" + "'", charSequence2.equals("                                                                                            ixed mod"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80", "J", 32, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J" + "'", str4.equals("J"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 1, "jAVAhOTsPOT(tm)64-bITsERVERvm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j" + "'", str3.equals("j"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray3, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "                      100a0a100a100");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "en" + "'", str6.equals("en"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "\n         ", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "\n         " + "'", charSequence2.equals("\n         "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "UTF-8", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ophie/Users/sophie", "2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100404100410", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "10.14.3", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100404100410" + "'", str4.equals("100404100410"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime E", 18, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1 . 7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ixed mod", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) (byte) -1, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#!iheihpos", 31, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", "24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod" + "'", str2.equals("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime E", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1004041004100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004041004100" + "'", str1.equals("1004041004100"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(".7.0_80-b15#########################################", "sophiehi!##", "ixed mod", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".7.0_80-b15#########################################" + "'", str4.equals(".7.0_80-b15#########################################"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("52a100a97a3a10", "0410497");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52a100a97a3a10" + "'", str2.equals("52a100a97a3a10"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1d + "'", double1.equals(1.1d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                1.7                                                 ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0000000000", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("51B-08_0.7.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#", 0, "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/users/sophie", (int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = null;
        try {
            boolean boolean5 = javaVersion2.atLeast(javaVersion4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                7.1                                               ", "hi!##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.041.04100.0497.040.0", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str12.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + (-1.0f) + "'", float14 == (-1.0f));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("35A1A1A34", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0410497");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 410497.0d + "'", double1.equals(410497.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " 44", (java.lang.CharSequence) "\n                                                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("2.0a97.0a1.0                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2.0a97.0a1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 100, (int) (byte) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracle CorporationOr-1.0410.04100.0", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a0a100a100", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                                                                                            ixed mod", (int) (short) 1, 34);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://java.oracle.com/", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("jAVAhOTsPOT(tm)64-bITsERVERvm", "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVAhOTsPOT(tm)64-bITsERVERvm" + "'", str3.equals("jAVAhOTsPOT(tm)64-bITsERVERvm"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", ".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mod" + "'", str2.equals("ixed mod"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("35a1a1a34", "jejejejejejejejejejejejejejejejejejejejejejejejeje", "Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35a1a1a34" + "'", str3.equals("35a1a1a34"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ophie/Users/sophie", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Users/sophie" + "'", str2.equals("ophie/Users/sophie"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                               sophie/Users/sophie/Documents/defec                               ", "                                                                                                                                                                                                                         ", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                               " + "'", str3.equals("                               sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                               "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aa4", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              aa4               " + "'", str2.equals("              aa4               "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.041.04100.0497.040.0", (int) (byte) 100, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "                              1.7                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("\n         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n         " + "'", str1.equals("\n         "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Ru", (java.lang.CharSequence) "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "0410497");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(":", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":                                                                                                                                                                                                                        " + "'", str2.equals(":                                                                                                                                                                                                                        "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "1.7");
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "hi!");
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray5, strArray16);
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray25, "hi!");
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray25, "aa");
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.stripAll(strArray33, "hi!");
        java.lang.String str39 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray35, "", (int) (short) 100, (-1));
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray29, strArray35);
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray35, 'a');
        int int43 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray35);
        java.lang.String[] strArray45 = org.apache.commons.lang3.StringUtils.stripAll(strArray35, "sun.uw..CGnuGhrcsEnnrntnmen.");
        java.lang.String[] strArray46 = org.apache.commons.lang3.StringUtils.stripAll(strArray45);
        boolean boolean47 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence[]) strArray46);
        java.lang.String str48 = org.apache.commons.lang3.StringUtils.replaceEach("sophie/Users/sophie/Documents/defec", strArray16, strArray46);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!1.71.7" + "'", str9.equals("hi!1.71.7"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str18.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "44444444444444444444444444444444444" + "'", str40.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "aa" + "'", str42.equals("aa"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 217 + "'", int43 == 217);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "sophie/Users/sophie/Documents/defec" + "'", str48.equals("sophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, (int) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("35a1a1a34", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35a1a1a34" + "'", str2.equals("35a1a1a34"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#################################################1.2", 31, "2.0 97.0 1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################1.2" + "'", str3.equals("#################################################1.2"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("##!iheihpos", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##!iheihpos" + "'", str2.equals("##!iheihpos"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "jAVAhOTsPOT(tm)64-bITsERVERvm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "sun.uw..CGnuGhrcsEnnrntnmen.", "jAVAhOTsPOT(t)64-bITsERVERv");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24.80-b11                                                                                           ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", (java.lang.CharSequence) "-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("35a1a1a34");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35a1a1a34" + "'", str1.equals("35a1a1a34"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                     noitacificepS IPA mroftalP avaJ", 66, "-1 0 1 1 10 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                     noitacificepS IPA mroftalP avaJ" + "'", str3.equals("                                                                     noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.jav", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "35a1a1a34", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.9", "ava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100 97 6 100 1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Environment", (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "vREVREsTIb-a6)t(TOPsTOhAVAj", (java.lang.CharSequence) "java(tm) se runtime e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("35a1a1a34", "35a1a1a34");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "d");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/fol" + "'", str2.equals("/var/fol"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("AA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AA" + "'", str1.equals("AA"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "-1.0#.0#1.0#1.0#10.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("-1.0410.04100.041.040.0", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0410.04100.041.040.0" + "'", str2.equals("-1.0410.04100.041.040.0"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E" + "'", str2.equals("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) ' ', (double) '#', 1.1d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("       ...", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (-1), 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6.0f, 4.444444444444444E34d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str2.equals(" Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11                                                                                           ", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a44" + "'", str12.equals("a44"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("x86_64", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                    ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 2, (long) 'a', (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("d", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Ru", (double) 28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.0d + "'", double2 == 28.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("jev", "/var/fol");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jev" + "'", str2.equals("jev"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-141040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-141040" + "'", str1.equals("-141040"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##############x86_64###############", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0000000000", "java(tm) se runtime e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000" + "'", str2.equals("0000000000"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machine specification" + "'", str1.equals("java virtual machine specification"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", (java.lang.CharSequence) "0410497", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10.0f, (double) 31.0f, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/users/sophi", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-141040", (java.lang.CharSequence) "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("java virtual machine specification", (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0#.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "d", (java.lang.CharSequence) "-1 0 1 1 10 10", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 6, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.041.04100.0497.040.0" + "'", str9.equals("10.041.04100.0497.040.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str11.equals("10.0a1.0a100.0a97.0a0.0"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 18, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-141040" + "'", str9.equals("-141040"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "...");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aa");
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "", (int) (short) 100, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray9, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, 'a');
        int int23 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray15);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "sun.uw..CGnuGhrcsEnnrntnmen.");
        int int26 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aa" + "'", str22.equals("aa"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 217 + "'", int23 == 217);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randooppl_538_5627845", (java.lang.CharSequence) "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#!iheihpos", "aa", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#!iheihpos" + "'", str3.equals("#!iheihpos"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randooppl_538_5627845", (java.lang.CharSequence) "1.60.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ", 32, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   " + "'", str3.equals("24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   "));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(6.0f, 217.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("###########################################################################################ixed mode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################################################################################ixed mode" + "'", str2.equals("###########################################################################################ixed mode"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0a1.0a1", (java.lang.CharSequence) "2.0a97.0a1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("51.0", "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.60.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.60.9" + "'", str1.equals("1.60.9"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str1.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.CPrinterJob", 1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1.0410.04100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-141040" + "'", str15.equals("-141040"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444" + "'", str1.equals("sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                1.7                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jav" + "'", str1.equals("jav"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str2.equals("ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("100#0#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#0#100#100" + "'", str1.equals("100#0#100#100"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                                                                                                                         ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0a1.0a100.0a97.0a0.0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4", "10.041.04100.0497.040.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("aa");
        java.lang.CharSequence charSequence7 = null;
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence7, (java.lang.CharSequence[]) strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0", strArray6, strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n         ", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a10a0" + "'", str13.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\n         " + "'", str14.equals("\n         "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str11.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "   ", 959);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(".7.0_80-b15", "", "-1.04100.041.041.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0" + "'", str3.equals("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100 97 6 100 1                  ", 0, "sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 97 6 100 1                  " + "'", str3.equals("100 97 6 100 1                  "));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 8, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52 100 97 3 10", "-1.010.0100.01.00.", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-1.010.0100.01.00.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.010.0100.01.00." + "'", str2.equals("-1.010.0100.01.00."));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("ixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ixed mode" + "'", str1.equals("ixed mode"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str12.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str14.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.04100.041.041.0410.0" + "'", str16.equals("-1.04100.041.041.0410.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str18.equals("-1.0a100.0a1.0a1.0a10.0"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("   ", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.CPrinterJob", "-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ":s", (java.lang.CharSequence) "35A1A1A34", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "S", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("\n", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!##", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("aa", strArray1, strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa" + "'", str4.equals("aa"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".7.0_80-b15" + "'", str4.equals(".7.0_80-b15"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.0a1.0a100.0a97.0a0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str1.equals("10.0a1.0a100.0a97.0a0.0"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.0#1.0#100.0#97.0#0.0", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, 0.0d, (double) 31.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod" + "'", str2.equals("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.3", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', (int) '4', (int) ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(49L, (long) 10, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "AA", (java.lang.CharSequence) "100404100410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444", " ", 959);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray4, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", 8, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ophie/Documents/defects4j/tmp/ru" + "'", str3.equals("ophie/Documents/defects4j/tmp/ru"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ixed mod" + "'", str1.equals("ixed mod"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mac OS X", (java.lang.CharSequence) "Java(TM) SE Ru");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("a 4", (long) 72);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("###########################################################################################ixed mod", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8                             ", 32, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8                             " + "'", str3.equals("UTF-8                             "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 66, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "...", "#!iheihpos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre" + "'", str3.equals("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                            1.7.0_80-b15                                            ", "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("d", "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "d" + "'", str2.equals("d"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", "sophiehi!##", "1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100404100410", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str11.equals("-1.0 100.0 1.0 1.0 10.0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Mac OS X", 52, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                            ixed mod", "                               sophie/Users/sophie/Documents/defec                               ", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                            ixed mod" + "'", str3.equals("                                                                                            ixed mod"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "###########################################################################################ixed mod", (int) (byte) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("###########################################################################################ixed mod", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################################################################################ixed mod" + "'", str2.equals("###########################################################################################ixed mod"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "###########################################################################################ixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("J", (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!##", (java.lang.CharSequence) "\n         ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray7);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray7);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa4" + "'", str11.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa4" + "'", str14.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#!iheihpos", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", "       ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((-1L), (long) (-1), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = null;
        try {
            boolean boolean7 = javaVersion3.atLeast(javaVersion6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                            ixed mod", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("2.0 97.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2.0 97.0 1.0" + "'", str1.equals("2.0 97.0 1.0"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "J", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("#!iheihpos", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "JavaVirtualMachineSpecification", 103);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ".7.0_80-b15", (java.lang.CharSequence) "jAVAhOTsPOT(tm)64-bITsERVERvm", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(217L, (long) (byte) 10, 72L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 217L + "'", long3 == 217L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.uw..CGnuGhrcsEnnrntnmen.", 28, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ntnmen." + "'", str3.equals("...ntnmen."));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 31.0f, (double) 72L, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 72.0d + "'", double3 == 72.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 0, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.010.0100.01.00.0", "-1.");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1004041004100", (java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#!iheihpos", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos" + "'", str2.equals("#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        try {
            long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#!iheihpos", (java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsE", (java.lang.CharSequence) "aa4", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.0a1.0a1", (java.lang.CharSequence) "Java(TM) SE Ru", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                 7.1                                                ", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100" + "'", str2.equals("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0a10a97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str12.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0410.04100.041.040.0" + "'", str14.equals("-1.0410.04100.041.040.0"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.1" + "'", str6.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1a10a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1A10A0" + "'", str1.equals("-1A10A0"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(52.0f, 6.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                    ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                 7.1                                                ", (int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "J", (java.lang.CharSequence) "Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\n         ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                 7.1", 97, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("oracle CorporationOr-1.0410.04100.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                      100a0a100a100", (int) (byte) 10, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      100a0a100a100" + "'", str3.equals("                      100a0a100a100"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.", (int) (byte) 100, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", 32, "##!iheihpos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec" + "'", str3.equals("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1", "aa4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/users/sophie", "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                            ixed mod", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                            ixed mod" + "'", str3.equals("                                                                                            ixed mod"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) '#', (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405", "a44", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', (int) (byte) 100, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                      100a0a100a100", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ophie/Users/sophie", "1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ophie/Users/sophie", 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444x86_644444444444444", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444x86_644444444444444" + "'", str2.equals("4444444444444x86_644444444444444"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...E Runtime EdJava(TM) SE Ru...", 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(".7.0_80-b15#########################################", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15#########################################" + "'", str2.equals(".7.0_80-b15#########################################"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aa");
        java.lang.CharSequence charSequence5 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence5, (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0", strArray4, strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a10a0" + "'", str11.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("          ", ".0#1.0#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aa");
        java.lang.CharSequence charSequence3 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence3, (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0", strArray2, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass11 = strArray10.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a0" + "'", str9.equals("-1a10a0"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str2.equals("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.041.04100.0497.040.0", (java.lang.CharSequence) "-1.0#.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                1.7                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                1.7                                                " + "'", str1.equals("                                                1.7                                                "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "-1.010.0100.01.00.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                     noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 72L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", "                                                1.7                                                 ", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str3.equals(" 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11                                                                                           ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                                                                                           " + "'", str2.equals("24.80-b11                                                                                           "));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                  US", (java.lang.CharSequence) "                               sophie/Users/sophie/Documents/defec                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "  ", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                              1.7                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                               1.7                                                  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 6, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1004041004100" + "'", str11.equals("1004041004100"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jAVAhOTsPOT(t)64-bITsERVERv", (java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server VM                                  ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 " + "'", str1.equals("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                               sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                               ", 0, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("J", "j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J" + "'", str2.equals("J"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#!iheihpos", (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion", (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ":");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US", "", "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }
}

