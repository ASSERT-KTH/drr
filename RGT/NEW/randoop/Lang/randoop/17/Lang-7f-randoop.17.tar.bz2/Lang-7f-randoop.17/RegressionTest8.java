import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             class org.apache.commons.lang3.javaversionclass org.apache.commons.lang3.javaversion" + "'", str1.equals("             class org.apache.commons.lang3.javaversionclass org.apache.commons.lang3.javaversion"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", (java.lang.CharSequence) "#################################################1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-1a0a1a1a10a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a0a1a1a10a10" + "'", str1.equals("-1a0a1a1a10a10"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "c OS X", (java.lang.CharSequence) "52a100a97a3a10", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("51.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-141004100404104100", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "                                                                                                    ", 959);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("S", "4", "0000000000                                                                                       ", 72);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "S" + "'", str4.equals("S"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             51.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", (java.lang.CharSequence) "                        1.6                         ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 10 + "'", short14 == (short) 10);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                  library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre                   ", "-1a10a0", 2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, 52.0f, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "jav", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1004041004100", "52a100a97a3a10", "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004041004100" + "'", str3.equals("1004041004100"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass7 = javaVersion6.getClass();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        java.lang.String str10 = javaVersion6.toString();
        boolean boolean11 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#!iheihpos");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("S:");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.6");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 97 6 100 1" + "'", str8.equals("100 97 6 100 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "d" + "'", str1.equals("d"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "5.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 7, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str12.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str14.equals("-1.0a100.0a1.0a1.0a10.0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("A44                                                                                                    ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        float[] floatArray2 = new float[] { 50, 1 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-1a10a0", "Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10a0" + "'", str2.equals("-1a10a0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "...ntnmen.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                             -1a10a0                                             ", (int) (short) 1, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             51.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             -1a10a0                                             " + "'", str3.equals("                                             -1a10a0                                             "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 103, 78);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime E", "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("5.1", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.1" + "'", str2.equals("5.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec", (java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str3.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str4.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ".1", (java.lang.CharSequence) "sophie", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str1.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0410497", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04..." + "'", str2.equals("04..."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("M", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                             0 100 52 -1 100", "-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                             0 100 52 -1 100" + "'", str2.equals("                                                             0 100 52 -1 100"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100#97#6#100#1", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                      100a0a100a100", "\naaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 959, 21.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0000000000                                                                                       ", "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52...", 32, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("100 97 6 100 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 97 6 100 " + "'", str1.equals("100 97 6 100 "));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1", (java.lang.CharSequence) "                           2.0a97.0a1.0                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "jejejejejejejejejejejejejejejejejejejejejejejejeje");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "-1.1.1.1..-1.1.1.1..-1.1.1.1..-1.1.1.1..-1.1.1.ixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java HotSpot(TM) 64-Bit Server VM is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100" + "'", str1.equals("100"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', (int) (byte) 1, (int) (short) -1);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3.41.01", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a444 444#4a" + "'", str16.equals("a444 444#4a"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                   ", (int) (byte) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        short[] shortArray6 = new short[] { (short) -1, (short) 0, (byte) 1, (short) 1, (byte) 10, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1 1 10 10" + "'", str8.equals("-1 0 1 1 10 10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1#0#1#1#10#10" + "'", str13.equals("-1#0#1#1#10#10"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.041.04100.0497.040.0" + "'", str9.equals("10.041.04100.0497.040.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str11.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.041.04100.0497.040.0" + "'", str13.equals("10.041.04100.0497.040.0"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0410497", "10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410497" + "'", str2.equals("0410497"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1A10A0", (java.lang.CharSequence) "5.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.0#1.0#100.0#97.0#0.0", (java.lang.CharSequence) "100a10a100a-1a-1a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", (java.lang.CharSequence) "                                          /users/sophie                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(":s", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":s" + "'", str2.equals(":s"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1.0410.04100.041.040.0", 0, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1.0#100.0#1.0#1.0#10.0", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str3.equals("-1.0#100.0#1.0#1.0#10.0"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "S:", (java.lang.CharSequence) "0.0#10.0#97.0#52.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", charArray9);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray9);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                        1.6                         ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aa4" + "'", str16.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "a#4" + "'", str21.equals("a#4"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", (java.lang.CharSequence) "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1 . 7", ":", "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 . 7" + "'", str3.equals("1 . 7"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "#########################################################################");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: #########################################################################");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0#1.0#100.0#97.0#0.0", "                                                                                             3.41.01", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        int[] intArray5 = new int[] { '4', (byte) 100, 'a', 3, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', 34, (int) (short) 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 69, 50);
        int int18 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52 100 97 3 10" + "'", str7.equals("52 100 97 3 10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "jev", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7", "-1.0#10.0#100.0#1.0#0.0", "ixed mo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xe7" + "'", str3.equals("xe7"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100#97#6#100#1", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#97..." + "'", str2.equals("100#97..."));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 100, "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod-1." + "'", str3.equals("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod-1."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        int[] intArray5 = new int[] { '4', (byte) 100, 'a', 3, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', 34, (int) (short) 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52 100 97 3 10" + "'", str7.equals("52 100 97 3 10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 103, (long) 23, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 103L + "'", long3 == 103L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.0#1.0#100.0#97.0#0.0", (int) (byte) 10, "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0#1.0#100.0#97.0#0.0" + "'", str3.equals("10.0#1.0#100.0#97.0#0.0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ens/jdk1#7#0_80#jdk/contents/home/jre", (java.lang.CharSequence) "a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray11 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4', (int) (byte) 1, (int) (short) -1);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a10a0", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophie/Users/sophie/Documents/defec", charArray11);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray11, ' ', 103, 0);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", (java.lang.CharSequence) "                        1.6                         ", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("xe7", "-1.0410.04100.041.040.0", 66, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "xe7-1.0410.04100.041.040.0" + "'", str4.equals("xe7-1.0410.04100.041.040.0"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100a0a100a100", (java.lang.CharSequence) "/                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec" + "'", str1.equals("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(21.0f, (float) 94, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", "100", "1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.041.7.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0" + "'", str3.equals("-1.041.7.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 100, (int) (byte) -1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', 34, (int) (byte) 10);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                1.7                                                 ", charArray10);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray10);
        int int25 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1.0410.04100.041.040.0", charArray10);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", charArray10);
        int int27 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oraclecorporation", charArray10);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jejejejejejejejejejejejejejejejejejejejejejejejeje", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa4" + "'", str14.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":s", "ens/jdk1#7#0_80#jdk/contents/home/jre", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("org.apache.commons.lang3.JavaVersion org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class class");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.lang3.javaversion org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class class" + "'", str1.equals("org.apache.commons.lang3.javaversion org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class class"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.041.04100.0497.040.0", charArray7);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, (double) 6.0f, (double) 2L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mod" + "'", str2.equals("ixed mod"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo", (int) (byte) 0, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ixed moixed moixed moi..." + "'", str3.equals("ixed moixed moixed moi..."));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        float[] floatArray5 = new float[] { 0, 10L, 97L, '4', (short) 100 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a10.0a97.0a52.0a100.0" + "'", str9.equals("0.0a10.0a97.0a52.0a100.0"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                               sophie/Users/sophie/Documents/defec                               ", 66, "Java(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               sophie/Users/sophie/Documents/defec                               " + "'", str3.equals("                               sophie/Users/sophie/Documents/defec                               "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "org.apache.commons.lang3.javaversion org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class class", (java.lang.CharSequence) "#!iheihpos");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("A44                                                                                                    ", "1.7");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                  Java(TM) SE Runtime Environment", " a4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 69, 13);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "utf-8SUN.UW..cgNUgHRCSeNNRNTNMEN.", (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 31, (-1));
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str12.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str1.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444" + "'", str2.equals("4444444444444444444444444"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("##############x86_64###############", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############x86_64###############" + "'", str2.equals("##############x86_64###############"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fJava Virtual Machine Specificatio", (java.lang.CharSequence) "-1a0a1a1a10a10", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("3.41.01", 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/" + "'", str3.equals("/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena", (java.lang.CharSequence) "5.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1.", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ophie/Users/sophie", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Users/sophie" + "'", str2.equals("ophie/Users/sophie"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jav", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", (int) (short) 1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jav" + "'", str4.equals("jav"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("52 100 97 3 10", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  52 100 97 3 10  " + "'", str2.equals("  52 100 97 3 10  "));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(2L, (long) (short) 1, 103L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 103L + "'", long3 == 103L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ixed moixed moixed mo", (java.lang.CharSequence) "S:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "xe7", (java.lang.CharSequence) "je");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sophiehi!##", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiehi!##" + "'", str2.equals("sophiehi!##"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena", "a44                               ", "04...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-b11", (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ixed moixed moixed moi...", "  52 100 97 3 10  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Ru", "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ru" + "'", str3.equals("Java(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ru"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle CorporationOr-1.0410.04100.0", 3, 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cle CorporationOr-1.0410.04100.0" + "'", str3.equals("cle CorporationOr-1.0410.04100.0"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.uw..CGnuGhrcsEnnrntnmen.", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(3.0d, (double) 217, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 217.0d + "'", double3 == 217.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophi", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.010.0100.01.00.", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a44" + "'", str12.equals("a44"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 959, (float) 4, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 959.0f + "'", float3 == 959.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("\n         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", 28L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100 97 6 100 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 103, (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", (java.lang.CharSequence) "Aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#################################################1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":S", "2.0a97.0a1.0", 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S" + "'", str3.equals(":S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100 97 6 100 ", 217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aa4enaa4enaa4enaa4en...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AA4ENAA4ENAA4ENAA4EN..." + "'", str1.equals("AA4ENAA4ENAA4ENAA4EN..."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aa4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 103, (double) 78, (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 103.0d + "'", double3 == 103.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80", "org.apache.commons.lang3.javaversion org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class class");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80" + "'", str2.equals("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("JAVA(TM) SE RUNTIM");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1#0#1#1#10#10", (java.lang.CharSequence) "100.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Ru", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "aa");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "hi!");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "", (int) (short) 100, (-1));
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray8, strArray14);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, ' ', (int) (short) 100, (int) (byte) 1);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "d mod");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "44444444444444444444444444444444444" + "'", str19.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "d modd mod" + "'", str26.equals("d modd mod"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.", (java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444", 69);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen.", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4                              1.7                                                 444x86_644444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4                              1.7                                                 444x86_644444444444444" + "'", str1.equals("4                              1.7                                                 444x86_644444444444444"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 959, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                1.7                                                 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version", "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", (int) (short) 10, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa4enaa4enaa4enaa4enaa4" + "'", str3.equals("aa4enaa4enaa4enaa4enaa4"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0410.04100.041.040.0" + "'", str9.equals("-1.0410.04100.041.040.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(103.0d, 100.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) 'a', (int) (short) 10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a97a6a100a1" + "'", str14.equals("100a97a6a100a1"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str1.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("java(tm) se runtime e", "1 . 7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0#10.0#97.0#52.0#100.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                              1.7                                                 ", ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("hi!1.71.7", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 80");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ".1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "cle CorporationOr-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("oracle CorporationOr-1.0410.04100.0", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "ava(TM) SE Runtime Environment", (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Platform API Specification", "", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Jdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/vdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ldesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/tdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/fdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/rdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/mdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Sdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/edesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/fdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/tdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ndesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Jdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/vdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ldesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/tdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/fdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/rdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/mdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Sdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/edesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/fdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/tdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ndesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "  4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "0410497", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 217L, (double) 35.0f, (double) 49);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 217.0d + "'", double3 == 217.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aa4enaa4enaa4enaa4en...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java(TM) SE Ru");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Ru\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        char[] charArray6 = new char[] { ' ', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!1.71.7", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oraclecorporation", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", 959);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str2.equals(" 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...E Runtime EdJava(TM) SE Ru...", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "2.0a97.0a1.0                                                                                        ", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str1.equals("Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 66, (long) '#', (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sunawtCGraphicsEnvironment", (java.lang.CharSequence) " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4ixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.0", "java(tm) se runtime e", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("xe7-1.0410.04100.041.040.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: xe7-1.0410.04100.041.040.0 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "1.7.0_80", (int) (byte) 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("-141004100404104100", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-141004100404104100" + "'", str6.equals("-141004100404104100"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100a10a10...", "ixed moixed moixed moi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a10a10..." + "'", str2.equals("100a10a10..."));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 0, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", "0.0a10.0a97.0a52.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                              1.7                                                 ", (java.lang.CharSequence) "aa4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randooppl_538_5627845", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaa" + "'", str2.equals("aaaaaa"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 0, 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 97, (int) (short) 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ixed mod", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ixedamod" + "'", str3.equals("ixedamod"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sophie/Users/sophie/Documents/defec", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie/Users/sophie/Documents/defec" + "'", str2.equals("sophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                         ", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                                                                                                                                                                                                         " + "'", str7.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1.0#100.0#1.0#1.0#10.0", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.04100.041.041.0410.0" + "'", str3.equals("-1.04100.041.041.0410.0"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "435a1a1a3444", (java.lang.CharSequence) "###############################", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        int[] intArray5 = new int[] { '4', (byte) 100, 'a', 3, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52 100 97 3 10" + "'", str7.equals("52 100 97 3 10"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 78, (long) 3, 959L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 959L + "'", long3 == 959L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', (int) ' ', 18);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "                                                                                  0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                  0 100 52 -1 100" + "'", charSequence2.equals("                                                                                  0 100 52 -1 100"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n         ", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (byte) 10, (int) (short) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-141040" + "'", str12.equals("-141040"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("5.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.15.1", "d mod", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, (int) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        short[] shortArray6 = new short[] { (short) -1, (short) 0, (byte) 1, (short) 1, (byte) 10, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 14, 217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1 1 10 10" + "'", str8.equals("-1 0 1 1 10 10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0a1a1a10a10" + "'", str11.equals("-1a0a1a1a10a10"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...                                                                        ...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("##############x86_64###############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############x86_64###############" + "'", str1.equals("##############x86_64###############"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("7.1", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jav", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", (int) (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 10, 3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                  Java(TM) SE Runtime Environment", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        org.apache.commons.lang3.StringUtils[][] stringUtilsArray0 = new org.apache.commons.lang3.StringUtils[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray0);
        org.junit.Assert.assertNotNull(stringUtilsArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                  library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre                   ", ".7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!1.61.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!1.61.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sunawtCGraphicsEnvironment", "2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunawtCGraphicsEnvironment" + "'", str2.equals("sunawtCGraphicsEnvironment"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!##", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################################################################hi!##" + "'", str3.equals("###############################################################################################hi!##"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "D", (java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 31, 2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0 100.0 1.0 1.0 10.0", "", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) (short) 10, 9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "jev");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "jev" + "'", charSequence2.equals("jev"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 49, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0.0a10.0a97.0a52.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0A10.0A97.0A52.0A100.0" + "'", str1.equals("0.0A10.0A97.0A52.0A100.0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE", "cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 959, 3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "-1#10#0");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                              1.7                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen.", "/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen." + "'", str2.equals("                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen."));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("################################", "/users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java(TM) SE Ru", "aaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Ru" + "'", str2.equals("Java(TM) SE Ru"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "sophiehi!##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "uTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########" + "'", str2.equals("########"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "J", (java.lang.CharSequence) "1.60.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1004041004100", "2.0a97.0a1.0", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10.14.3", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "########", (java.lang.CharSequence) "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "########" + "'", charSequence2.equals("########"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0 100 52 -1 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0 100 52 -1 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation", 13, 143);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation" + "'", str3.equals("ationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##!iheihpos", "                                                                                                    ", 72);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "##!iheihpos" + "'", str5.equals("##!iheihpos"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("52a100a97a3a10", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52a100a97a3a10" + "'", str3.equals("52a100a97a3a10"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.60.9", (java.lang.CharSequence) "                                                             0 100 52 -1 100", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "...E Runtime EdJava(TM) SE Ru...");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaa" + "'", str1.equals("aaaaa"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\naaaaaaaaaaaaaaaaaaaaaaaa", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             51.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1#0#1#1#10#10", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/fol/var/fol", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str11.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str13.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str15.equals("-1.0#100.0#1.0#1.0#10.0"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("51B-08_0.7.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 8, 0);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(".7.0_80-b15#########################################", "2.0 97.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15#########################################" + "'", str2.equals(".7.0_80-b15#########################################"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("A44                                                                                                    ", (float) 8L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC" + "'", str2.equals("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Aasun.lwawt.macosx.CPrinterJobAa", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("je");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"je\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "jav", 2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#97...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) (byte) 1, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "a#4", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("35a1a1a34");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35a1a1a34" + "'", str1.equals("35a1a1a34"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str2.equals("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "-1 0 1 1 10 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"lib\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "ophie/Documents/defects4j/tmp/ru");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("D", "0.0A10.0A97.0A52.0A100.0", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0000000000", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000" + "'", str2.equals("0000000000"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                      100a0a100a100", (java.lang.CharSequence) ".7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("S", "2.0a97.0a1.0");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "435a1a1a3444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/var/fol/var/fol");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophi" + "'", str1.equals("/users/sophi"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        int[] intArray4 = new int[] { (short) -1, (short) 100, 1, 18 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 100, (int) (byte) 10);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "en", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sophi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":                                                                                                                                                                                                                        ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_800#10.0                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "vaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", 97, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(35.0f, 31.0f, (float) 99);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 99.0f + "'", float3 == 99.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVAhOTsPOT(tm)64-bITsERVERvm", "10.0a1.0a1", 5);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "jAVAhOTsPOT(tm)64-bITsERVERvm" + "'", str5.equals("jAVAhOTsPOT(tm)64-bITsERVERvm"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/", "100a10a100a-1a-1a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/" + "'", str2.equals("/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ixed moixed moixed moi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IXED MOIXED MOIXED MOI..." + "'", str1.equals("IXED MOIXED MOIXED MOI..."));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaa", (java.lang.CharSequence) "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("###############################", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) -1, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/" + "'", str1.equals("/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("  52 100 97 3 10  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  52 100 97 3 10  " + "'", str2.equals("  52 100 97 3 10  "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        char[] charArray7 = new char[] { ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!1.71.7", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100#0#100#100", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444444", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".7.0_80-b15#########################################", charArray7);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray7);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a10a100a-1a-1a", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa4" + "'", str11.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                             3.41.01", "###############################", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ru", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100.0", (java.lang.CharSequence) ":s", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        int[] intArray3 = new int[] { 0, (byte) 10, 'a' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', (int) ' ', (int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1.0#10.0#100.0#1.0#0.0", (int) '4');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("-1a10a0", strArray5, strArray11);
        java.lang.CharSequence charSequence13 = null;
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence13, (java.lang.CharSequence[]) strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", strArray5, strArray16);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a10a0" + "'", str12.equals("-1a10a0"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str18.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", (double) 143);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 143.0d + "'", double2 == 143.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00" + "'", str2.equals("-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("SUN.UW..CGNUGHRCSENNRNTNMEN.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                             0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/users/sophi");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 8, (-1));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA(TM) SE RUNTIM", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) 'a', (int) (short) 10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.0a1.0a1", "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod-1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a1.0a" + "'", str2.equals("a1.0a"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) 'a', (int) (short) -1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004041004100" + "'", str14.equals("1004041004100"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "...ntnmen.", (java.lang.CharSequence) "#################################################1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DESRODNE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/" + "'", str1.equals("DESRODNE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0410497");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 410497 + "'", int1 == 410497);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#########################################################################", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0#100.0#1.0#1.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        int[] intArray5 = new int[] { '4', (byte) 100, 'a', 3, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', 34, (int) (short) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 217, 8);
        java.lang.Class<?> wildcardClass16 = intArray5.getClass();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52 100 97 3 10" + "'", str7.equals("52 100 97 3 10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "###############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java(tm) se runtime e");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1", "   ", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1   1" + "'", str3.equals("1   1"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", "  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        java.lang.Class<?> wildcardClass9 = doubleArray3.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2.0a97.0a1.0" + "'", str11.equals("2.0a97.0a1.0"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sophiehi!##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str5 = javaVersion1.toString();
        boolean boolean6 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                 7.1                                                ", "10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100", "jejejejejejejejejejejejejejejejejejejejejejejejeje");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7, (float) 21, 31.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaa", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ":s", (java.lang.CharSequence) "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray9);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0a100.0a1.0a1.0a10.0", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Aa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aa4" + "'", str16.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 0, 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int18 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int20 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0410497");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0410497" + "'", str1.equals("0410497"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0000000000", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0000000000" + "'", str3.equals("0000000000"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("d mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: d mod is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ophie/Users/sophie", "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime E", " 44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime E" + "'", str2.equals("Java(TM) SE Runtime E"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFEC" + "'", str1.equals("SOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFEC"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("UTF-8                             ", "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8                             " + "'", str3.equals("UTF-8                             "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa" + "'", str2.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        char[] charArray8 = new char[] { ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!1.71.7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100#0#100#100", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                1.7                                                 ", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                  0 100 52 -1 100", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("5.1", "-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5.1-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("5.1-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a44                                                                                                    ", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", 78);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "jav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Mac OS X", "/users/sophie", 410497, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "M/users/sophie" + "'", str4.equals("M/users/sophie"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                 7.1                                                ", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 7.1                                                " + "'", str2.equals("                                                 7.1                                                "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray0 = new org.apache.commons.lang3.SystemUtils[] {};
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray1 = new org.apache.commons.lang3.SystemUtils[] {};
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray2 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray0, systemUtilsArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray2);
        org.junit.Assert.assertNotNull(systemUtilsArray0);
        org.junit.Assert.assertNotNull(systemUtilsArray1);
        org.junit.Assert.assertNotNull(systemUtilsArray2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                         " + "'", str1.equals("                                                                         "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n                                                                                                   ", "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed", ".0#1.0#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111" + "'", str3.equals("\n111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                  Java(TM) SE Runtime Environment", (java.lang.CharSequence) "a44       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1, "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Jdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/vdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ldesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/tdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/fdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/rdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/mdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Sdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/pdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/edesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/fdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/adesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/tdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/idesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/odesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ndesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 100, (int) (byte) -1);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 34, (int) (byte) 10);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                1.7                                                 ", charArray9);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray9);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1.0410.04100.041.040.0", charArray9);
        int int25 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", charArray9);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str1.equals("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "Java(TM) SE Runtime E");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100404100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100404100410" + "'", str1.equals("100404100410"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                   ", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!1.61.6", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("  52 100 97 3 10  ", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.310.14.310.14.310.14.310.jav", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                             3.41.01", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1.0#100.0#1.0#1.0#10.0", 410497);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str2.equals("-1.0#100.0#1.0#1.0#10.0"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        char[] charArray9 = new char[] { 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray9);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray9);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S2.0a97.0a1.0:S", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "aa4" + "'", str16.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "5.1-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 100.0 1.0 1.0 10.0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("-1.0 100.0 1.0 1.0 10.0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 18, 0L, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, "52 100 97 3 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 143, 4.0d, (double) 959);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ophie/Documents/defects4j/tmp/ru", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  52 100 97 3 10  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52 100 97 3 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("########", (long) 217);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 217L + "'", long2 == 217L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            " + "'", str2.equals("            "));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi!##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!##" + "'", str1.equals("hi!##"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a44", (java.lang.CharSequence) "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "                                                1.7                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 100, (int) 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80" + "'", str6.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "Java(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ruxed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modJava(TM) SE Ru");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre", "0a10a97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10a97" + "'", str2.equals("0a10a97"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-B11                                                                                           ", (java.lang.CharSequence) "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                  0 100 52 -1 100", "###########################################################################################ixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 100 52 -1 100" + "'", str2.equals("0 100 52 -1 100"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100 97 6 100 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" + "'", str2.equals("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion", "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        float[] floatArray5 = new float[] { 0, 10L, 97L, '4', (short) 100 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0 10.0 97.0 52.0 100.0" + "'", str9.equals("0.0 10.0 97.0 52.0 100.0"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                           2.0a97.0a1.0                           ", "class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1 0 1 1 10 10", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########" + "'", str1.equals("########"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1004041004100" + "'", str11.equals("1004041004100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100#0#100#100" + "'", str15.equals("100#0#100#100"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 100 + "'", short16 == (short) 100);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 0, (int) (byte) 0);
        float float18 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str13.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 100.0f + "'", float18 == 100.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaa" + "'", str1.equals("Aaaaaa"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(103.0d, (double) 14, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "j", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a44       ", (java.lang.CharSequence) "SOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFECJAVAAPLATFORMAAPIASPECIFICATIONSOPHIE/USERS/SOPHIE/DOCUMENTS/DEFEC");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "...aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  ", 143, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "5.1-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444", "  4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                 7.1                                                ", "a444 444#4a", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11                                                                                           ", (int) (short) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100#97...", "                                                                  Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8                             ", "2.0a97.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod-1.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1a10a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a01a1-" + "'", str1.equals("0a01a1-"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0 100 52 -1 100", "-1.0#10.0#100.0#1.0#0.0", 34);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) ".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100a97a6a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                7.1                                               ", "SUN.UW..CGNUGHRCSENNRNTNMEN.", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                7.1                                               " + "'", str3.equals("                                                7.1                                               "));
    }
}

