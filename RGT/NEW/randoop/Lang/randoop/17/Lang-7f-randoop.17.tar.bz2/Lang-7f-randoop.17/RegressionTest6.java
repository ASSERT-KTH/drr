import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0 100 52 -1 100", "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "-1 0 1 1 10 10");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0 100 52 -1 100" + "'", str5.equals("0 100 52 -1 100"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mac OS X");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed" + "'", str2.equals("mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                     noitacificepS IPA mroftalP avaJ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7", "vREVREsTIb-a6)t(TOPsTOhAVAj", "10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aa", "   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", (int) '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-1.04100.041.041.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0410.04100.041.040.0" + "'", str1.equals("-1.0410.04100.041.040.0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "4444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.0#10.0#97.0#52.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        char[] charArray8 = new char[] { 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray8);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray8);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aa4" + "'", str12.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aa4" + "'", str15.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 35 + "'", int18 == 35);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11                                                                                           " + "'", str1.equals("24.80-b11                                                                                           "));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("jejejejejejejejejejejejejejejejejejejejejejejejeje");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(78, (int) (byte) 1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78 + "'", int3 == 78);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ixed moixed moixed mo");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4444444444444x86_644444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1a0a1a1a10a10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "-1.0410.04100.041.040.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ixed mo", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1.0#.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#.0#1.0#1.0#10.0" + "'", str1.equals("-1.0#.0#1.0#1.0#10.0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-b11");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                              J");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 100, (int) (byte) -1);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                  0 100 52 -1 100", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                             0 100 52 -1 100" + "'", str2.equals("                                                             0 100 52 -1 100"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("jAVAhOTsPOT(tm)64-bITsERVERvm", 49, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...VERvm" + "'", str3.equals("...VERvm"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.010.0100.01.00.0");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 100, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 34, (int) (byte) 10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                1.7                                                 ", charArray5);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 6, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "jav");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/users/sophie", 32, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java(TM) SE Ru", (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.0#100.0#1.0#1.0#10.0", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1A10A0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa4" + "'", str10.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4ixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0000000000                                                                                       ", "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", 10, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       " + "'", str4.equals("0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ophie/Documents/defects4j/tmp/ru", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC" + "'", str2.equals("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.6");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.6f + "'", float1 == 1.6f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtim", 52, "-1.010.0100.01.00.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00" + "'", str3.equals("-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("M", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00", "                                          /users/sophie                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00" + "'", str2.equals("-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(12, 2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("vREVREsTIb-a6)t(TOPsTOhAVAj", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vREVREsTIb-a6)t(TOPsTOhAVAj" + "'", str2.equals("vREVREsTIb-a6)t(TOPsTOhAVAj"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.uw..CGnuGhrcsEnnrntnmen.", "UTF-8", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTF-8sun.uw..CGnuGhrcsEnnrntnmen." + "'", str4.equals("UTF-8sun.uw..CGnuGhrcsEnnrntnmen."));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0A100.0A1.0A1.0A10.0" + "'", str1.equals("-1.0A100.0A1.0A1.0A10.0"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" Runt\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("-141040");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-141040" + "'", str1.equals("-141040"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        char[] charArray5 = new char[] { ' ', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " a4" + "'", str10.equals(" a4"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre", "en", 0, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ens/jdk1#7#0_80#jdk/contents/home/jre" + "'", str4.equals("ens/jdk1#7#0_80#jdk/contents/home/jre"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1.0410.04100.041.040.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                     noitacificepS IPA mroftalP avaJ", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 12, (double) 959, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.0410.04100.041.040.0", "mixed mode");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0410.04100.041.040.0" + "'", str4.equals("-1.0410.04100.041.040.0"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100404100410", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#97#6#100#1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                            ixed mod", (java.lang.CharSequence) ".7.0_80-b15", 78);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100#0#100#", "Aa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hi!" + "'", charSequence2.equals("hi!"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 49, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("2.0a97.0a1.0", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.0a97.0a1.0" + "'", str2.equals("2.0a97.0a1.0"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aa4", (java.lang.CharSequence) "                                                1.7                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                7.1                                               ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b11                                                                                           ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 217, (float) 18, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ixed mo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ixed mo\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(217, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", 7, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", (long) 72);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "\n         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                   " + "'", str1.equals("                                   "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "3.41.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("vREVREsTIb-a6)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 35, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ":s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("2.0 97.0 1.0", "1.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "ophie/Users/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 143 + "'", int2 == 143);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/users/sophi", "java(tm) se runtime e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophi" + "'", str2.equals("/users/sophi"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " a4", (java.lang.CharSequence) "ixed mo", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("#################################################1.2", "Java(TM) SE Runtim", "\n", 99);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#################################################1.2" + "'", str4.equals("#################################################1.2"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444444", 66, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenenene44444444444444444444444444444444444" + "'", str3.equals("enenenenenenenenenenenenenenene44444444444444444444444444444444444"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Sun.awt.CGraphicsE", (java.lang.CharSequence) "100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                 7.1                                                ", "-1.0A100.0A1.0A1.0A10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 7.1                                                " + "'", str2.equals("                                                 7.1                                                "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "a44       ", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sophie", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophie" + "'", str2.equals("sophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("oraclecorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclecorporation" + "'", str1.equals("oraclecorporation"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("52a100a97a3a10", "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52a100a97a3a10" + "'", str2.equals("52a100a97a3a10"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ".7.0_80-b15#########################################", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                                                                                                                         ", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                      ..." + "'", str2.equals("                                                                      ..."));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", "", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.010.0100.01.00.0", (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.3", 959, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1.3" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1.3"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str6 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        java.lang.String str9 = javaVersion7.toString();
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean11 = javaVersion7.atLeast(javaVersion10);
        boolean boolean12 = javaVersion5.atLeast(javaVersion7);
        java.lang.String str13 = javaVersion7.toString();
        boolean boolean14 = javaVersion2.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7" + "'", str6.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7" + "'", str13.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444444", "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0a1.0a1", "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1.equals(4));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.1.1.1..-1.1.1.1..-1.1.1.1..-1.1.1.1..-1.1.1.ixed mod" + "'", str2.equals("-1.1.1.1..-1.1.1.1..-1.1.1.1..-1.1.1.1..-1.1.1.ixed mod"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 31, 49);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2.0a97.0a1.0                                                                                        ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "/");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.041.04100.0497.040.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1a10a0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                      100a0a100a100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(".7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4enaa4enaa4enaa4en..." + "'", str2.equals("aa4enaa4enaa4enaa4en..."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", "aa4enaa4enaa4enaa4en...", "Oracle Corporation");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.14.310.14.310.14.310.14.310.jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ", (java.lang.CharSequence) "100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1.0#10.0#100.0#1.0#0.0", 34, "444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444-1.0#10.0#100.0#1.0#0.0444444" + "'", str3.equals("44444-1.0#10.0#100.0#1.0#0.0444444"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils4 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray5 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3, stringUtils4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray5);
        org.junit.Assert.assertNotNull(stringUtilsArray5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle CorporationOr-1.0410.04100.0", "", 31);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oracle CorporationOr-1.0410.04100.0" + "'", str7.equals("Oracle CorporationOr-1.0410.04100.0"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                    ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 0, (float) 78, (float) 217L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        short[] shortArray4 = new short[] { (byte) 1, (byte) 100, (byte) 0, (short) -1 };
        short[] shortArray9 = new short[] { (byte) 1, (byte) 100, (byte) 0, (short) -1 };
        short[] shortArray14 = new short[] { (byte) 1, (byte) 100, (byte) 0, (short) -1 };
        short[] shortArray19 = new short[] { (byte) 1, (byte) 100, (byte) 0, (short) -1 };
        short[][] shortArray20 = new short[][] { shortArray4, shortArray9, shortArray14, shortArray19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(shortArray20);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.uw..CGnuGhrcsEnnrntnmen.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.uw..CGnuGhrcsEnnrntnmen." + "'", str2.equals("sun.uw..CGnuGhrcsEnnrntnmen."));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "A44                                                                                                    ", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 103 + "'", int9 == 103);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JavaVirtualMachineSpecification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 72, "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0" + "'", str3.equals("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "0410497");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444x86_644444444444444", "0410497");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.CPrinterJob", 1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str7.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100#0#100#100", (java.lang.CharSequence) "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4                              1.7                                                 444x86_644444444444444", "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed" + "'", str2.equals("mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "java virtual machine specification", (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.0#1.0#100.0#97.0#0.0" + "'", str15.equals("10.0#1.0#100.0#97.0#0.0"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(18.0f, 0.0f, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.0a1.0a1", "JavaHotSpot(TM)64-BitServerVMBitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a1.0a1" + "'", str2.equals("10.0a1.0a1"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/var/fol", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/fol/var/fol" + "'", str2.equals("/var/fol/var/fol"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaa", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("##################################################-1.##################################################", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "hi!");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "aa");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray3, strArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str14.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "51B-08_0.7.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim", (int) (short) 100, 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100", "                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "ixed mod", ".7.0_80-b15#########################################");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("M", 34, "                                                                     noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M                                 " + "'", str3.equals("M                                 "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("       ...", "#!iheihpos", " a4", 217);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       ..." + "'", str4.equals("       ..."));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str1.equals("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java(TM) SE Ru", (java.lang.CharSequence) "a44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', (int) '#', 72);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 2, 3);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0#1.0#100.0#97.0#0.0" + "'", str11.equals("10.0#1.0#100.0#97.0#0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100.0" + "'", str15.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-141040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        char[] charArray5 = new char[] { ' ', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "  4" + "'", str10.equals("  4"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444x86_644444444444444", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "hi!");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "aa");
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "hi!");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "", (int) (short) 100, (-1));
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray11, strArray17);
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray27, "hi!");
        int int30 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray29);
        java.lang.String[] strArray34 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String str38 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray34, ":", (int) '4', (int) (short) 0);
        int int39 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray34);
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ixed mod", strArray29, strArray34);
        java.lang.String str41 = org.apache.commons.lang3.StringUtils.replaceEach(".0#1.0#", strArray11, strArray29);
        boolean boolean42 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.6", (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray43 = new java.lang.String[] {};
        java.lang.String[] strArray44 = org.apache.commons.lang3.StringUtils.stripAll(strArray43);
        java.lang.String str45 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray11, strArray43);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "44444444444444444444444444444444444" + "'", str22.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ixed mod" + "'", str40.equals("ixed mod"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + ".0#1.0#" + "'", str41.equals(".0#1.0#"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "x86_64" + "'", str45.equals("x86_64"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(23, 100, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("enenenenenenenenenenenenenenene44444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" 44", "                                                                                  0 100 52 -1 100", "J");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 44" + "'", str3.equals(" 44"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0", "1004041004100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.60.9", "JavaHotSpot(TM)64-BitServerVMBitServerVM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 143, (float) 2L, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100a0a100a100", (java.lang.CharSequence) "51.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj", (int) ' ', 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(".0#1.0#52a100a97a3a10", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        char[] charArray6 = new char[] { ' ', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "2.0 97.0 1.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 2, (int) (byte) -1);
        try {
            long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                1.7                                                 ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "2.0 97.0 1.0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("100a0a100a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a0a100a100" + "'", str1.equals("100a0a100a100"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("c OS XaM", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", "/Users/sophie", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str4.equals("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ophie/Users/sophie", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Users/sophie" + "'", str2.equals("ophie/Users/sophie"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("jAVAhOTsPOT(tm)64-bITsERVERvm", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "", (int) (short) 100, (-1));
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "hi!");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "1.7");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray14);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "1.6");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!1.71.7" + "'", str18.equals("hi!1.71.7"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!1.61.6" + "'", str22.equals("hi!1.61.6"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100a10a100a-1a-1a", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a10a100a-1a-1a" + "'", str2.equals("100a10a100a-1a-1a"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\n         ", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n         " + "'", str3.equals("\n         "));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "enenenenenenenenenenenenenenene44444444444444444444444444444444444", (java.lang.CharSequence) "7.1", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        char[] charArray5 = new char[] { ' ', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "3.41.01", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8, (double) 217.0f, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 217.0d + "'", double3 == 217.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion", "JAVA(TM) SE RUNTIM", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("c OS XaM", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS X" + "'", str2.equals("c OS X"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", charSequence1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                   ", "class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion", ":S", 73);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                   " + "'", str4.equals("                                   "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4ixed mod", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "d mod" + "'", str2.equals("d mod"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", (java.lang.CharSequence) "                                                7.1                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.awt.CGraphicsEnvironment", "ixed moixed moixed mo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4444444444444x86_644444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1a10a0" + "'", str15.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("jev");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("mixedmode");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "Oracle Corporation");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                              J", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              J" + "'", str2.equals("                              J"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "3.41.01", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1.010.0100.01.00.", (java.lang.CharSequence) "1.60.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "              aa4               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre", "4444444444444444444444444", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 7.1" + "'", str1.equals("                                                                                                 7.1"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "...", (java.lang.CharSequence) "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "##!iheihpos", (java.lang.CharSequence) "                                            1.7.0_80-b15                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100 97 6 100 1", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str1.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.9", "Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str2.equals("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        float[] floatArray2 = new float[] { (byte) 100, (short) 100 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", (java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 143, (double) 1L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 143.0d + "'", double3 == 143.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 10, (int) (short) 0);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(".7.0_80-B15", 78, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444.7.0_80-B154444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444.7.0_80-B154444444444444444444444444444444444"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "AA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100a10a100a-1a-1a", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a10a10..." + "'", str2.equals("100a10a10..."));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 94, (double) 28, 7.1d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 94.0d + "'", double3 == 94.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a44       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) '#', (int) (short) 1);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 10, (int) (short) 10);
        short short19 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 10 + "'", short14 == (short) 10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 18, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#97#6#100#1" + "'", str12.equals("100#97#6#100#1"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                1.7                                                 ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", (int) ' ', 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" 44", "sun.uw..CGnuGhrcsEnnrntnmen.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1", (java.lang.CharSequence) "\n         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) 'a', (int) (short) 10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100#97#6#100#1" + "'", str13.equals("100#97#6#100#1"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.041.04100.0497.040.0", (java.lang.CharSequence) "                                             -1a10a0                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/var/fol/var/fol", "100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/fol/var/fol" + "'", str2.equals("/var/fol/var/fol"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "444444444444444444444444444444444.7.0_80-B154444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 444444444444444444444444444444444.7.0_80-B154444444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) (byte) 1, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a100a100", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsE", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "jev", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                            ixed mod", ".7.0_80-b15#########################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            ixed mod" + "'", str2.equals("                                                                                            ixed mod"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray11 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4', (int) (byte) 1, (int) (short) -1);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ixed mode", charArray11);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("J", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J" + "'", str3.equals("J"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "jAVAhOTsPOT(t)64-bITsERVERv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 3, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#0#100#100" + "'", str12.equals("100#0#100#100"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("US", 103, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "a 4", "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100a10a100a-1a-1a0", ".0#1.0#", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##############x86_64###############", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "AA");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                      ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "a44       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "100.0#100.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0a100.0a1.0a1.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0a100.0a1.0a1.0a10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                1.7                                                 ", 959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0#10.0#100.0#1.0#0.0", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aa", (int) (byte) 10, 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0" + "'", str2.equals("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1004041004100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 0, 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1a10a0" + "'", str18.equals("-1a10a0"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                 7.1                                                ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("uTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("oracle corporation", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation" + "'", str2.equals("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":s", "1004041004100", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1.3", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.041.04100.0497.040.0" + "'", str9.equals("10.041.04100.0497.040.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str11.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a 4", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a44" + "'", str3.equals("a44"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("a44                                                                                                    ", (int) (byte) 0, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a44                               " + "'", str3.equals("a44                               "));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j" + "'", str1.equals("j"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaa", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                     noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str6 = javaVersion5.toString();
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.6" + "'", str6.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.6" + "'", str7.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("a44       ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a44       " + "'", str2.equals("a44       "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405", ".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jejejejejejejejejejejejejejejejejejejejejejejejeje", 0, "1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jejejejejejejejejejejejejejejejejejejejejejejejeje" + "'", str3.equals("jejejejejejejejejejejejejejejejejejejejejejejejeje"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100a10a100a-1a-1a", 25, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) (byte) 1, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3.41.01", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                              1.7                                                 ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!##", "jAVA hOTsPOT(tm) 64-bIT sERVER vm", "J");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100#0#100#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) 7.1f, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str12.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 100.0f + "'", float14 == 100.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("###########################################################################################ixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("  4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sophie/Users/sophie/Documents/defec");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie/Users/sophie/Documents/defec\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie", ".0#1.0#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0410497");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.jav", (java.lang.CharSequence) "jAVAhOTsPOT(t)64-bITsERVERv");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10.0a1.0a1                                                                                          ", (java.lang.CharSequence) "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1.0#.0#1.0#1.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1.0#.0#1.0#1.0#10.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 959, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 959 + "'", int3 == 959);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(".1", 28, "7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.17.17.17.17.17.17.17.17.17" + "'", str3.equals("7.17.17.17.17.17.17.17.17.17"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 44", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 " + "'", str2.equals("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100#97#6#100#1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("...ntnmen.", "", "mixed mode");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion", "-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("       ...", (float) 49L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 49.0f + "'", float2 == 49.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0000000000                                                                                       ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "java virtual machine specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4ixed mod", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          4ixed mod" + "'", str2.equals("                          4ixed mod"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', (int) (byte) 10, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 18 + "'", int7 == 18);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#4" + "'", str10.equals("a#4"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 18, (int) (byte) -1);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "##############x86_64###############");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("en", "je");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ":s");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405", "                                                1.7                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("##############x86_64###############", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############x86_64###############" + "'", str3.equals("##############x86_64###############"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 3, (int) (byte) -1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed", "a 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed" + "'", str2.equals("mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ixed mo", (java.lang.CharSequence) "1.7.0_80", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "M                                 ", "1.4");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.310.14.310.14.310.14.310.jav", "", "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.310.14.310.14.310.jav" + "'", str3.equals("10.14.310.14.310.14.310.14.310.jav"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                1.7                                                 ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 0, 3);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0410.04100.0" + "'", str12.equals("-1.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("UTF-8", "                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100", "0.0#10.0#97.0#52.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100" + "'", str2.equals("100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2.0a97.0a1.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "java(tm) se runtime e", (java.lang.CharSequence) "4444444444444x86_644444444444444", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "-141004100404104100", (int) 'a', 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100a10a10...", 35, 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "Java(TM) SE Runtime E");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n         ", (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/USERS/SOPHIE", "Java Virtual Machine Specificatio", (int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPJava Virtual Machine SpecificatioHIE" + "'", str4.equals("/USERS/SOPJava Virtual Machine SpecificatioHIE"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode" + "'", str2.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("M                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", (java.lang.CharSequence) "/users/sophi", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                            1.7.0_80-b15                                            ", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            1.7.0_80-b15                                            " + "'", str3.equals("                                            1.7.0_80-b15                                            "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP avaJ" + "'", str1.equals("noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "       ...", (java.lang.CharSequence) ".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 32, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str14.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str16.equals("-1.0a100.0a1.0a1.0a10.0"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "       ...", (java.lang.CharSequence) "...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                            1.7.0_80-b15                                            ", (java.lang.CharSequence) "#########################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 32, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0000000000                                                                                       ", "                                                                                                    ", 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.Class<?> wildcardClass12 = byteArray1.getClass();
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 97 6 100 1" + "'", str8.equals("100 97 6 100 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a97a6a100a1" + "'", str11.equals("100a97a6a100a1"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "aa");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray4, strArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1.0410.04100.041.040.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str15.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00" + "'", str1.equals("-1.010.0100.01.00Java(TM) SE Runtim-1.010.0100.01.00"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                             0 100 52 -1 100", "hi!1.71.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                             0 100 52 -1 100" + "'", str2.equals("                                                             0 100 52 -1 100"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aa", (java.lang.CharSequence) "24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-1.0a100.0a1.0a1.0a10.0", "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str2.equals("-1.0a100.0a1.0a1.0a10.0"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0410497", "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410497" + "'", str2.equals("0410497"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(78, (int) '#', 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78 + "'", int3 == 78);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", ".7.0_80-b15#########################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str2.equals("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 23, 103.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("UTF-8", "  ", 2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", strArray1, strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str6.equals("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(":S", "   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("7.1", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", (java.lang.CharSequence) "10.14.3", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.0a1.0a1                                                                                          ", "Java Virtual Machine Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          " + "'", str3.equals("10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          "));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(72.0d, 0.0d, (double) 217.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 217.0d + "'", double3 == 217.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", "UTF-8                             ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "jAVAhOTsPOT(t)64-bITsERVERv");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 72, 2.0f, 49.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                             0 100 52 -1 100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "/USERS/SOPJava Virtual Machine SpecificatioHIE");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                     noitacificepS IPA mroftalP avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 6, 217);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", charSequence1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) (byte) 1, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1a10a0", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.6", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str3.equals("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#########################################################################", "...VERvm", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 35, 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "100#0#100#", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-1.0#.0#1.0#1.0#10.0", (int) (short) 100, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#.0#1.0#1.0#10.0" + "'", str3.equals("-1.0#.0#1.0#1.0#10.0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "j", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                               sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                               ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("J", "35A1A1A34", "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(78, 99, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1#10#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ixed mode", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ixed mode" + "'", str3.equals("ixed mode"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", (int) (byte) 0, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "enenenenenenenenenenenenenenene44444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7.0_80-b15" + "'", str1.equals(".7.0_80-b15"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', (int) 'a', (int) (short) 10);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray5, '#', 12, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (-1), 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                               sophie/Users/sophie/Documents/defec                               ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed" + "'", str2.equals("mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracle corporation", "                                                                                                  US");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sunawtCGraphicsEnvironment", (java.lang.CharSequence) "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004041004100" + "'", str10.equals("1004041004100"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(23, 72, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 72 + "'", int3 == 72);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 103, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 103.0f + "'", float3 == 103.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4", 52, 78);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                                                        ..." + "'", str3.equals("...                                                                        ..."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("uTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8-FTu" + "'", str1.equals("8-FTu"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("...                                                                        ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", "c OS XaM", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("          ", strArray5, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str6.equals("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 . 7" + "'", str10.equals("1 . 7"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       " + "'", str1.equals("0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       "));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                               sophie/Users/sophie/Documents/defec                               ", "mixed mode", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               sophie/Users/sophie/Documents/defec                               " + "'", str3.equals("                               sophie/Users/sophie/Documents/defec                               "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          ", (java.lang.CharSequence) "  4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("35a1a1a34", 12, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "435a1a1a3444" + "'", str3.equals("435a1a1a3444"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a#4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a#4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", "10.0a1.0a1                                                                                          ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/" + "'", str3.equals("/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" 44", (-1), 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 103, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.041.04100.0497.040.0" + "'", str9.equals("10.041.04100.0497.040.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str11.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", 97);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-1.010.0100.01.00.");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1 . 7", (java.lang.CharSequence) "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2081 + "'", int2 == 2081);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.60.9", (java.lang.CharSequence) "10.0a1.0a1                                                                                          ", 959);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ixed moixed moixed mo", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo" + "'", str2.equals("ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre", "UTF-8sun.uw..CGnuGhrcsEnnrntnmen.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j" + "'", str2.equals("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, (int) 'a', 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 7.1f, (double) 'a', (double) 103.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 103.0d + "'", double3 == 103.0d);
    }
}

