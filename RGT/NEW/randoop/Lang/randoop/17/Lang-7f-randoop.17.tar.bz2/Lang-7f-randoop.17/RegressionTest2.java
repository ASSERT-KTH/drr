import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ixed mod", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod" + "'", str2.equals("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, (float) 35L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("en", "7.1", "-1#10#0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "d", 2, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1 0 1 1 10 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 0 1 1 10 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        try {
            float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UTF-8", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jev", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jev" + "'", str2.equals("jev"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Virtual Machine Specification", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", (int) (byte) 1, "sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("51.0", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("JavaHotSpot(TM)64-BitServerVM", "2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str2.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("ava(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava(TM) SE Runtime Environment" + "'", str2.equals("ava(TM) SE Runtime Environment"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1a10a0", (java.lang.CharSequence) "  ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("100a0a100a100", "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("###########################################################################################ixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###########################################################################################ixed mod" + "'", str1.equals("###########################################################################################ixed mod"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "Java(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtime E", "d", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E" + "'", str3.equals("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", (java.lang.CharSequence) "AA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "java virtual machine specification", "-1a10a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", 34, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("US", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", "M");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                  US" + "'", str1.equals("                                                                                                  US"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1.010.0100.01.00.0", "100", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.041.04100.0497.040.0", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.041.04100.0497.040.0" + "'", str2.equals("10.041.04100.0497.040.0"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.0f, (double) (short) 1, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51B-08_0.7.", (long) 49);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "Sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 49, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.041.04100.0497.040.0" + "'", str10.equals("10.041.04100.0497.040.0"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "Mac OS X", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 7.1" + "'", str1.equals("                                                                                                 7.1"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) ":s", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str1.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", (java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "vREVREsTIb-46)t(TOPsTOhAVAj" + "'", charSequence2.equals("vREVREsTIb-46)t(TOPsTOhAVAj"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("vREVREsTIb-46)t(TOPsTOhAVAj", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vREVREsTIb-a6)t(TOPsTOhAVAj" + "'", str3.equals("vREVREsTIb-a6)t(TOPsTOhAVAj"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", (int) (short) 1, "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4d + "'", double1 == 1.4d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 49, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "       ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                  US", 3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                  US" + "'", str3.equals("                                                                                                  US"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("http://java.oracle.com/", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine Specification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("en", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1 0 1 1 10 10", 3, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 0 1 1 10 10" + "'", str3.equals("-1 0 1 1 10 10"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.awt.CGraphicsE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 97, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophiehi!##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##!iheihpos" + "'", str1.equals("##!iheihpos"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "1 . 7");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "-1.010.0100.01.00.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.010.0100.01.00.0" + "'", str2.equals("-1.010.0100.01.00.0"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0000000000                                                                                       ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000                                                                                       " + "'", str2.equals("0000000000                                                                                       "));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime E", "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, (long) (short) 10, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ava(TM) SE Runtime Environment", (java.lang.CharSequence) "##!iheihpos");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ixed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("java virtual machine specification", (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("100.0", "                                                                                                    ", "vREVREsTIb-a6)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_64", (int) '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############x86_64###############" + "'", str3.equals("##############x86_64###############"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...", (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "-1.0410.04100.0", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVAhOTsPOT(t)64-bITsERVERv", "       ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7.1", "sophie/Users/sophie/Documents/defec", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                  US" + "'", str1.equals("                                                                                                  US"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jAVA hOTsPOT(tm) 64-bIT sERVER vm", (int) (short) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str3.equals("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("###########################################################################################ixed mod", 97, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(".7.0_80-b15#########################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4", (java.lang.CharSequence) "/Users/sophie", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aa");
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "", (int) (short) 100, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray9, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, 'a');
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.CPrinterJob", 1);
        int int28 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray27);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray27);
        try {
            java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.3", strArray15, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aa" + "'", str22.equals("aa"));
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(strArray29);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sophie/Users/sophie/Documents/defec", "                                            1.7.0_80-b15                                            ", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie/Users/sophie/Documents/defec" + "'", str3.equals("sophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1.0 100.0 1.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE", "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("JavaHotSpot(TM)64-BitServerVM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(".7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-b15" + "'", str2.equals(".7.0_80-b15"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion" + "'", str2.equals("clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/users/sophie", "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "52 100 97 3 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(tm) se runtime e" + "'", str1.equals("java(tm) se runtime e"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-1.0#10.0#100.0#1.0#0.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str2.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "vREVREsTIb-a6)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.6", "ixed mod");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", (java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.CPrinterJob", 1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "-1.0 100.0 1.0 1.0 10.0");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, (int) '#', 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34, (float) 1L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (byte) 10, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.CPrinterJob", 1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (short) 0, (float) 31);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0#10.0#100.0#1.0#0.0", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.7f, (double) (short) 1, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 31, (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(".7.0_80-b15#########################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7.0_80-b15#########################################" + "'", str1.equals(".7.0_80-b15#########################################"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("0", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aa");
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "", (int) (short) 100, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray9, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, 'a');
        int int23 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray15);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "sun.uw..CGnuGhrcsEnnrntnmen.");
        try {
            java.lang.String str29 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aa" + "'", str22.equals("aa"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 217 + "'", int23 == 217);
        org.junit.Assert.assertNotNull(strArray25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', (int) '4', (int) ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime E", "4", "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime E" + "'", str3.equals("Java(TM) SE Runtime E"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', (-1), 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corporation", "-1.0410.04100.041.040.0", "###########################################################################################ixed mode");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.0410.04100.041.040.0", "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "  ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("vREVREsTIb-46)t(TOPsTOhAVAj", (int) (short) 10, "Java(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vREVREsTIb-46)t(TOPsTOhAVAj" + "'", str3.equals("vREVREsTIb-46)t(TOPsTOhAVAj"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("jAVAhOTsPOT(t)64-bITsERVERv", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVAhOTsPOT(t)64-bITsERVERv" + "'", str2.equals("jAVAhOTsPOT(t)64-bITsERVERv"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str2.equals("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "35a1a1a34");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 18, 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", "0000000000", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/users/sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".0#1.0#", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "##!iheihpos", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1#10#0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) 0, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (java.lang.CharSequence) "                                                                                                                                                                                                                         ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 18, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sophiehi!##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", 34.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "-1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1.0410.04100.0", (int) (byte) 0, "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0410.04100.0" + "'", str3.equals("-1.0410.04100.0"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java(TM) SE Runtime Environment", 0, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtim" + "'", str3.equals("Java(TM) SE Runtim"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 100, 100);
        java.lang.Class<?> wildcardClass6 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10.041.04100.0497.040.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.041.04100.0497.040.0" + "'", str2.equals("10.041.04100.0497.040.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("52 100 97 3 10");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0 100.0 1.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7.0_80-B15" + "'", str1.equals(".7.0_80-B15"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str2.equals(" 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime E" + "'", str1.equals("Java(TM) SE Runtime E"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("2.0a97.0a1.0                                                                                        ", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.0a97.0a1.0                                                                                        " + "'", str2.equals("2.0a97.0a1.0                                                                                        "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.awt.CGraphicsEnvironment", "                                                                                                    ", "-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34, (float) 1, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 100, "0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" + "'", str3.equals("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Users/sophie", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "\n", (java.lang.CharSequence) "Sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) '4', 217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "hi!1.71.7", "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) 97, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1.0#100.0#1.0#1.0#10.0", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aa");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence4, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0", strArray3, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence[]) strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a10a0" + "'", str10.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0#1.0#100.0#97.0#0.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7", 49, 217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(":s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":s" + "'", str1.equals(":s"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                                                                         ", (-1), "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                         " + "'", str3.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 3, (int) (byte) -1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a0a100a100" + "'", str13.equals("100a0a100a100"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", "/USERS/SOPHIE");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0a1.0a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("jAVAhOTsPOT(t)64-bITsERVERv", 0, 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVAhOTsPOT(t)64-bITsERVERv" + "'", str3.equals("jAVAhOTsPOT(t)64-bITsERVERv"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##############x86_64###############", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int[] intArray5 = new int[] { '4', (byte) 100, 'a', 3, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', 1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52 100 97 3 10" + "'", str7.equals("52 100 97 3 10"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", 0, 217);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("jAVAhOTsPOT(t)64-bITsERVERv", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "aa4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVAhOTsPOT(t)64-bITsERVERv" + "'", str3.equals("jAVAhOTsPOT(t)64-bITsERVERv"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ixed mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ixed mod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100a0a100a100", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      100a0a100a100" + "'", str2.equals("                      100a0a100a100"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsE", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion" + "'", charSequence2.equals("clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Oracle CorporationOr-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOr-1.0410.04100.0" + "'", str1.equals("Oracle CorporationOr-1.0410.04100.0"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aa");
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "", (int) (short) 100, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray9, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, 'a');
        int int23 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray15);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray15);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aa" + "'", str22.equals("aa"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 217 + "'", int23 == 217);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "       ...", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "51B-08_0.7.", "1.7", 25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(" ", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/" + "'", str2.equals("/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long[] longArray1 = new long[] { 32 };
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ava(TM) SE Runtime Environment", "", (int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "AA", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + (-1.0f) + "'", number1.equals((-1.0f)));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophie", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str10.equals("10.0a1.0a100.0a97.0a0.0"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(".7.0_80-b15#########################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                1.7                                                 ", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              1.7                                                 " + "'", str2.equals("                              1.7                                                 "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "Java(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("2.0 97.0 1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "                                                 7.1                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        java.lang.reflect.Type[] typeArray7 = new java.lang.reflect.Type[] { wildcardClass4, wildcardClass6 };
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass12 = strArray11.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass14 = javaVersion13.getClass();
        java.lang.reflect.Type[] typeArray15 = new java.lang.reflect.Type[] { wildcardClass12, wildcardClass14 };
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass20 = strArray19.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass22 = javaVersion21.getClass();
        java.lang.reflect.Type[] typeArray23 = new java.lang.reflect.Type[] { wildcardClass20, wildcardClass22 };
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass28 = strArray27.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass30 = javaVersion29.getClass();
        java.lang.reflect.Type[] typeArray31 = new java.lang.reflect.Type[] { wildcardClass28, wildcardClass30 };
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass36 = strArray35.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass38 = javaVersion37.getClass();
        java.lang.reflect.Type[] typeArray39 = new java.lang.reflect.Type[] { wildcardClass36, wildcardClass38 };
        java.lang.String[] strArray43 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        java.lang.Class<?> wildcardClass44 = strArray43.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion45 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass46 = javaVersion45.getClass();
        java.lang.reflect.Type[] typeArray47 = new java.lang.reflect.Type[] { wildcardClass44, wildcardClass46 };
        java.lang.reflect.Type[][] typeArray48 = new java.lang.reflect.Type[][] { typeArray7, typeArray15, typeArray23, typeArray31, typeArray39, typeArray47 };
        java.lang.String str49 = org.apache.commons.lang3.StringUtils.join(typeArray48);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(typeArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(typeArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(typeArray23);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(typeArray31);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(typeArray39);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + javaVersion45 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion45.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(typeArray47);
        org.junit.Assert.assertNotNull(typeArray48);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                1.7                                                 ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7d + "'", double1 == 1.7d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                    ", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1a10a0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("24.80-b11", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ".0#1.0#", (java.lang.CharSequence) "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1a10a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a10a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        char[] charArray4 = new char[] { ' ', '4' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("2.0a97.0a1.0                                                                                        ", 49, "jAVAhOTsPOT(t)64-bITsERVERv");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0a97.0a1.0                                                                                        " + "'", str3.equals("2.0a97.0a1.0                                                                                        "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.60.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.60.9" + "'", str1.equals("1.60.9"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 72 + "'", int1 == 72);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0000000000                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0000000000" + "'", str1.equals("0000000000"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("##############x86_64###############", "sophie", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############x86_64###############" + "'", str3.equals("##############x86_64###############"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("3.41.01", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                             3.41.01" + "'", str3.equals("                                                                                             3.41.01"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!1.71.7", "AA", "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!1.71.7" + "'", str3.equals("hi!1.71.7"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.60.9", 72, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.60.9" + "'", str3.equals("1.60.9"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", "35a1a1a34");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Aa", "Sun.awt.CGraphicsE");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aa" + "'", str3.equals("Aa"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "3.41.01", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("          ", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtime Environment", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0000000000", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("en");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 2, "-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str3.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#', 217, 1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100a0a100a100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 217, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', (int) (byte) 10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0#1.0#100.0#97.0#0.0" + "'", str11.equals("10.0#1.0#100.0#97.0#0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 72, 217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 72");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("d", "Java(TM) SE Runtime Environment", 217);
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "hi!");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence[]) strArray12);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("sophiehi!##", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "                                                                                  0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.0#1.0#100.0#97.0#0.0", (java.lang.CharSequence) "       ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                              1.7                                                 ", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aa");
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "", (int) (short) 100, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray9, strArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, 'a');
        int int23 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray15);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "sun.uw..CGnuGhrcsEnnrntnmen.");
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray25);
        try {
            java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, 'a', (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aa" + "'", str22.equals("aa"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 217 + "'", int23 == 217);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray26);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("3.41.01", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3.41.01" + "'", str3.equals("3.41.01"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/users/sophi", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "52 100 97 3 10", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.6", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long[] longArray0 = new long[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        try {
            long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", "10.041.04100.0497.040.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str2.equals("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 100, 0);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) (byte) 0, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1 . 7", "-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 . 7" + "'", str2.equals("1 . 7"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "10.0a1.0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime E", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ixed mod", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mod" + "'", str2.equals("ixed mod"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("jAVA hOTsPOT(tm) 64-bIT sERVER vm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA hOTsPOT(tm) 64-bIT sERVER vm\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java HotSpot(TM) 64-Bit Server VM", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J" + "'", str2.equals("J"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!1.71.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa" + "'", str1.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("jav");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 31, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-1a10a0", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             -1a10a0                                             " + "'", str2.equals("                                             -1a10a0                                             "));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 8, (double) 4.4444444E34f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "44444444444444444444444444444444444", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 6, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", "-1 0 1 1 10 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 0 1 1 10 10" + "'", str2.equals("-1 0 1 1 10 10"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" ", "0 100 52 -1 100", "-1a10a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                             3.41.01", (java.lang.CharSequence) "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(49, 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0410.04100.041.040.0" + "'", str1.equals("-1.0410.04100.041.040.0"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", (int) (byte) 0, " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-1.0#100.0#1.0#1.0#10.0", (java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", "                                                                                             3.41.01", 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        try {
            float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", (int) (byte) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("  ", "0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.LWCToolkit", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 34, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "M", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie" + "'", str6.equals("/Users/sophie"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0000000000", "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("noitacificepS IPA mroftalP avaJ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     noitacificepS IPA mroftalP avaJ" + "'", str2.equals("                                                                     noitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (byte) 1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2L, 100.0f, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtime E", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime E" + "'", str3.equals("Java(TM) SE Runtime E"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "-1 0 1 1 10 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E" + "'", str1.equals("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str11.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str13.equals("-1.0 100.0 1.0 1.0 10.0"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("51.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "100", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.awt.CGraphicsEnvironment", "Sun.awt.CGraphicsE", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod" + "'", str1.equals("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                             -1a10a0                                             ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                             -1a10a0                                             " + "'", charSequence2.equals("                                             -1a10a0                                             "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aa4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10" + "'", str3.equals("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-8", "                                                1.7                                                 ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J" + "'", str1.equals("J"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("3.41.01", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("c OS XaM", "1.60.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS XaM" + "'", str2.equals("c OS XaM"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa", ".0#1.0#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                             3.41.01", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             3.41.01" + "'", str2.equals("                                                                                             3.41.01"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec", (java.lang.CharSequence) "Java(TM) SE Runtim", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "jev");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "http://java.oracle.com/", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "d", (int) ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.0#1.0#100.0#97.0#0.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("jev");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "je" + "'", str1.equals("je"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sun.awt.CGraphicsEnvironment", "0410497", "###########################################################################################ixed mod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecification" + "'", str1.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str1.equals("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", "0410497", "vREVREsTIb-46)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod" + "'", str3.equals("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1.0#10.0#100.0#1.0#0.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "1.2");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.2");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4", (java.lang.CharSequence) "vREVREsTIb-a6)t(TOPsTOhAVAj", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                                 7.1", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aa");
        java.lang.CharSequence charSequence5 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence5, (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0", strArray4, strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51B-08_0.7.", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a10a0" + "'", str11.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.uw..CGnuGhrcsEnnrntnmen.", (java.lang.CharSequence) "###########################################################################################ixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0#10.0#100.0#1.0#0.0", (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime E");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Jav\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1.", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 1, "Sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10.0a1.0a1", "                              1.7                                                 ", ".0#1.0#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a1.0a1" + "'", str3.equals("10.0a1.0a1"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("##!iheihpos", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##!iheihpos" + "'", str2.equals("##!iheihpos"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0000000000                                                                                       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "       ...", charSequence1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "  ", 18, 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.14.3", (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sophie/Users/sophie/Documents/defec", 72, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444" + "'", str3.equals("sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) ".7.0_80-b15#########################################", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "35a1a1a34", "-1.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7, (float) (byte) 1, (float) 217L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 100, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "3.41.01", "51B-08_0.7.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", "JavaHotSpot(TM)64-BitServerVM", "100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str3.equals("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100" + "'", str1.equals("100"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 100, (byte) -1, (byte) -1, (byte) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100a10a100a-1a-1a0" + "'", str8.equals("100a10a100a-1a-1a0"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec" + "'", str3.equals("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("3.41.01", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("S", "0000000000                                                                                       ", "44444444444444444444444444444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Oracle CorporationOr-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "je");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_64", 32, "4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444x86_644444444444444" + "'", str3.equals("4444444444444x86_644444444444444"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "52 100 97 3 10", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray3, strArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "en" + "'", str6.equals("en"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", (java.lang.CharSequence) "a44", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("\n");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ixed mode", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.0a1.0a1", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a1.0a1                                                                                          " + "'", str2.equals("10.0a1.0a1                                                                                          "));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte[] byteArray3 = new byte[] { (byte) 10 };
        byte[][] byteArray4 = new byte[][] { byteArray1, byteArray3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray4);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "1.60.9", "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".7.0_80-b15", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("vREVREsTIb-46)t(TOPsTOhAVAj", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "10.0", "2.0a97.0a1.0", 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10.0a1.0a1", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0 100.0 1.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0", (int) ' ', 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }
}

