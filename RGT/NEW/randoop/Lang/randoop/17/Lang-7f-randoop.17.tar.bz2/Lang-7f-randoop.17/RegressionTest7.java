import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("52 100 97 3 10", "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" + "'", str2.equals("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        double[] doubleArray3 = new double[] { 2.0f, 10L, 52.0f };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', (int) 'a', 5);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", 7, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                           2.0a97.0a1.0                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                           2.0a97.0a1.0                           " + "'", str1.equals("                           2.0a97.0a1.0                           "));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.jav", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "44444-1.0#10.0#100.0#1.0#0.0444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4444444444444x86_644444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "D" + "'", str1.equals("D"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str3.equals("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\naaaaaaaaaaaaaaaaaaaaaaaa", 78, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...aaaaaaa" + "'", str3.equals("...aaaaaaa"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0A100.0A1.0A1.0A10.0", "hi!1.61.6", "/var/fol/var/fol");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ", "1.7.0_80", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_800#10.0                                                                 " + "'", str4.equals("1.7.0_800#10.0                                                                 "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 25);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sophie/Users/sophie/Documents/defec", 12, 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("35a1a1a34", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("51.0", 959, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             51.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             51.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("4444444", 72, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11                                                                                           " + "'", str1.equals("24.80-b11                                                                                           "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(":", "S", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        int[] intArray3 = new int[] { 0, (byte) 10, 'a' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0#10#97" + "'", str6.equals("0#10#97"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.60.9", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.60.9" + "'", str2.equals("1.60.9"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Sun.awt.CGraphicsE", "UTF-8sun.uw..CGnuGhrcsEnnrntnmen.", "aa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 0, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', 78, 959);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 78");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "2.0 97.0 1.0", (java.lang.CharSequence) "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15#########################################", "-1A10A0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "2.0a97.0a1.0                                                                                        ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-141040", charSequence1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 32, (int) '4');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim", "10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          ", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "2.0 97.0 1.0", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("7.17.17.17.17.17.17.17.17.17", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass5 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.9" + "'", str4.equals("0.9"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa", "en");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa" + "'", str3.equals("aa"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0" + "'", str2.equals("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 99, 69);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "                               sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                                                                                                                                                                                                                                                                                       sophie/Users/sophie/Documents/defec                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str2.equals("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "clss org.pche.commons.lng3.JvVersionclss org.pche.commons.lng3.JvVersion", (java.lang.CharSequence) "35A1A1A34");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) -1, (int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "-141004100404104100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.0a1.0a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0a1.0a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophiehi!##", "100#0#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                   ", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "hi!");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "A44                                                                                                    ", (java.lang.CharSequence[]) strArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.041.04100.0497.040.0", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 103 + "'", int10 == 103);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "0.9", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aa");
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "", (int) (short) 100, (-1));
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray9, strArray15);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "24.80-b11");
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0", "a44", 52);
        int int28 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", (java.lang.CharSequence[]) strArray27);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray27);
        try {
            java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("##!iheihpos", strArray9, strArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "44444444444444444444444444444444444" + "'", str20.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 99 + "'", int28 == 99);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("jejejejejejejejejejejejejejejejejejejejejejejejeje", 9, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jejejejejejejejejejejejejejejejejejejejejejejejeje" + "'", str3.equals("jejejejejejejejejejejejejejejejejejejejejejejejeje"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oracle corporation", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle corporation" + "'", str3.equals("oracle corporation"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100a97a6a100a1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("################################", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                              J");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0a1.0a1", "10.0a1.0a100.0a97.0a0.0", (int) (byte) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "100a10a100a-1a-1a0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a1.0a1" + "'", str5.equals("10.0a1.0a1"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...ntnmen.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("#################################################1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################1.2" + "'", str1.equals("#################################################1.2"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) (byte) 1, (int) (short) -1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3.41.01", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "2.0a97.0a1.0                                                                                        ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("  4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("c OS X", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS Xc OS X" + "'", str2.equals("c OS Xc OS X"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7." + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7."));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), 52.0d, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1.010.0100.01.00.0", "52 100 97 3 10");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("/var/fol/var/fol", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/var/fol/var/fol" + "'", str7.equals("/var/fol/var/fol"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/USERS/SOPJava Virtual Machine SpecificatioHIE", "100a10a100a-1a-1a0", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPJava Virtual Machine SpecificatioHIE" + "'", str3.equals("/USERS/SOPJava Virtual Machine SpecificatioHIE"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(":                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.awt.CGraphicsE", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsE" + "'", str3.equals("sun.awt.CGraphicsE"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("aaaaaaaaaa", "/                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aa");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence4, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0", strArray3, strArray8);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "-1.010.0100.01.00.0", (int) (byte) 10);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1.0#10.0#100.0#1.0#0.0", (int) '4');
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray19, "");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("-1a10a0", strArray15, strArray21);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray8, strArray15);
        java.lang.Class<?> wildcardClass24 = strArray8.getClass();
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, ".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a10a0" + "'", str10.equals("-1a10a0"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1a10a0" + "'", str22.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str23.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(strArray27);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "0000000000");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE", (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi!", 4, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE", "cl ss org. p che.commons.l ng0.J v Versioncl ss org. p che.commons.l ng0.J v Version");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 31, (int) (byte) -1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 97 6 100 1" + "'", str8.equals("100 97 6 100 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100 97 6 100 1" + "'", str11.equals("100 97 6 100 1"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#################################################1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################1.2" + "'", str1.equals("#################################################1.2"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("2.0 97.0 1.0");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixedmode", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "   ", (java.lang.CharSequence) "#########################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.lang3.JavaVersion org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class class" + "'", str2.equals("org.apache.commons.lang3.JavaVersion org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class class"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 18, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray5, '4', 52, 28);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#97#6#100#1" + "'", str12.equals("100#97#6#100#1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1#10#0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "100#97#6#100#1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100 97 6 100 1                  ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 18, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 97 6 100 1" + "'", str12.equals("100 97 6 100 1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwwt.mcosx.LWCToolkit", "10049746410041");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" + "'", str2.equals("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100", "                                                                     noitacificepS IPA mroftalP avaJ", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Sun.awt.CGraphicsE", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        long[] longArray6 = new long[] { 99, 34, 6, 143, (short) 1, 6 };
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str12.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str14.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a44       ", "uTF-8");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", strArray5, strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0" + "'", str9.equals("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_80-b15");
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVMBitServerVM", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ixed mode", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 32, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str14.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 100.0f + "'", float15 == 100.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 2, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("51.0", "                                                                     noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":s");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.010.0100.01.00.0", 5, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ophie/Users/sophie", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa4" + "'", str10.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aa4enaa4enaa4enaa4en...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("c OS Xc OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS Xc OS X" + "'", str1.equals("c OS Xc OS X"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2.0#97.0#1.0" + "'", str11.equals("2.0#97.0#1.0"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8, (double) 35, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.6", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        1.6                         " + "'", str2.equals("                        1.6                         "));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("UTF-8sun.uw..CGnuGhrcsEnnrntnmen.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8SUN.UW..cgNUgHRCSeNNRNTNMEN." + "'", str1.equals("utf-8SUN.UW..cgNUgHRCSeNNRNTNMEN."));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(18.0f, (float) 4, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC" + "'", str2.equals("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1.equals(100));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("...", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sophiehi!##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophiehi!##" + "'", str1.equals("sophiehi!##"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "hi!");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa", (java.lang.CharSequence[]) strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 21, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5.1" + "'", str1.equals("5.1"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("##############x86_64###############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############x86_64###############" + "'", str1.equals("##############x86_64###############"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "http://java.oracle.com/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0 100 52 -1 100", (java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1#0#1#1#10#10", (java.lang.CharSequence) "100a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Sun.awt.CGraphicsE", ":                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.2", "24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("M", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "oraclecorporation", (java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "oraclecorporation" + "'", charSequence2.equals("oraclecorporation"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.CPrinterJob", 1);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "hi!");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "", (int) (short) 100, (-1));
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray22, "hi!");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray22, "1.7");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray22);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray14, strArray22);
        int int29 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray14);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, ' ', (int) (byte) 10, 3);
        try {
            java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", strArray7, strArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!1.71.7" + "'", str26.equals("hi!1.71.7"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC" + "'", str1.equals("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, 49L, (long) 99);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8, (float) 100L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str2.equals("a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a10a0", (java.lang.CharSequence) "ixed moixed moixed mo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(".1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".1" + "'", str1.equals(".1"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.uw..CGnuGhrcsEnnrntnmen.", "-1.010.0100.01.00.", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444444444", "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100a97a6a100a1", "http://java.oracle.com/", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("2.0#97.0#1.0", "              aa4               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/fol/var/fol", "#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                  0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                  0 100 52 -1 100" + "'", str1.equals("                                                                                  0 100 52 -1 100"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...VERvm", "  ", "Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...VERvm" + "'", str3.equals("...VERvm"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM) SE Runtime Environment", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  Java(TM) SE Runtime Environment" + "'", str2.equals("                                                                  Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                1.7                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                1.7                                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        float[] floatArray1 = new float[] { 31 };
        float[] floatArray3 = new float[] { 31 };
        float[] floatArray5 = new float[] { 31 };
        float[] floatArray7 = new float[] { 31 };
        float[] floatArray9 = new float[] { 31 };
        float[] floatArray11 = new float[] { 31 };
        float[][] floatArray12 = new float[][] { floatArray1, floatArray3, floatArray5, floatArray7, floatArray9, floatArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray12);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.010.0100.01.00.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.010.0100.01.00.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100a10a100a-1a-1a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/", "0#10#97", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/" + "'", str3.equals("/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "                           2.0a97.0a1.0                           ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, (long) 25, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 25L + "'", long3 == 25L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ", "#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclecorporation" + "'", str1.equals("oraclecorporation"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "1 . 7", "10.041.04100.0497.040.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str3.equals("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("24.80-b11                                                                                           ", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                                                                                           " + "'", str2.equals("24.80-b11                                                                                           "));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                                                                                                                                         ", "0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "xed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", "0000000000                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "/users/sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie/Users/sophie/Documents/defec" + "'", str1.equals("Sophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                1.7                                                 ", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                1.7                                                 " + "'", str2.equals("                                                1.7                                                 "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/0#10#97/", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE RuntimJava(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oraclecorporation", (java.lang.CharSequence) "3.41.01", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 97 6 100 1" + "'", str8.equals("100 97 6 100 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        float[] floatArray1 = new float[] { (byte) 1 };
        float[][] floatArray2 = new float[][] { floatArray1 };
        float[] floatArray4 = new float[] { (byte) 1 };
        float[][] floatArray5 = new float[][] { floatArray4 };
        float[] floatArray7 = new float[] { (byte) 1 };
        float[][] floatArray8 = new float[][] { floatArray7 };
        float[] floatArray10 = new float[] { (byte) 1 };
        float[][] floatArray11 = new float[][] { floatArray10 };
        float[] floatArray13 = new float[] { (byte) 1 };
        float[][] floatArray14 = new float[][] { floatArray13 };
        float[][][] floatArray15 = new float[][][] { floatArray2, floatArray5, floatArray8, floatArray11, floatArray14 };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray15);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(35.0d, (double) 8.0f, (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100", (java.lang.CharSequence) "10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-1.0410.04100.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0-1a10a0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1", (java.lang.CharSequence) "jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("35a1a1a34", "Java Virtual Machine Specification", 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35a1a1a34" + "'", str3.equals("35a1a1a34"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.04100.041.041.0410.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.04100.041.041.0410.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("###########################################################################################ixed mod", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                           ixed mod" + "'", str3.equals("                                                                                           ixed mod"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, (int) (short) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 18, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#97#6#100#1" + "'", str12.equals("100#97#6#100#1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-141040" + "'", str9.equals("-141040"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#10#0" + "'", str11.equals("-1#10#0"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, (int) (byte) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", 78);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0410.04100.0" + "'", str1.equals("-1.0410.04100.0"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                 7.1                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 7.1                                                " + "'", str1.equals("                                                 7.1                                                "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(217.0f, (float) 66, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("...aaaaaaa", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...aaaaaaa" + "'", str2.equals("...aaaaaaa"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hi!1.71.7", (java.lang.CharSequence) "jejejejejejejejejejejejejejejejejejejejejejejejeje");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("52 100 97 3 10", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52..." + "'", str2.equals("52..."));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                      100a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) (short) 100, (int) ' ');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                  Java(TM) SE Runtime Environment", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str12.equals("-1.0#100.0#1.0#1.0#10.0"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.uw..CGnuGhrcsEnnrntnmen.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.UW..CGNUGHRCSENNRNTNMEN." + "'", str1.equals("SUN.UW..CGNUGHRCSENNRNTNMEN."));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(28.0d, 0.0d, (double) 23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mixed mode", 78, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0", "a44", 52);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", ' ');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a44       ", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a44       " + "'", str10.equals("a44       "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0 100.0 1.0 1.0 10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...E Runtime EdJava(TM) SE Ru...", (int) '#', 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!1.61.6", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str7 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("35a1a1a34", "1 . 7");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aa4", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java(tm) se runtime e");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "              aa4               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0", "                                                                                  0 100 52 -1 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0" + "'", str2.equals("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Ru");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "100#97#6#100#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Aa");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Aa" + "'", str4.equals("Aa"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { 'a', '4' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1a0a1a1a10a10", "                                                                         ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass13 = intArray3.getClass();
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        short[] shortArray5 = new short[] { (short) 0, (byte) 1, (short) 0, (short) 0, (byte) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) '#', (int) (short) 1);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 10 + "'", short14 == (short) 10);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0a1a0a0a10" + "'", str17.equals("0a1a0a0a10"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a', 78, 21);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ixed mod", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod                                                                                       ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVMBitServerVM", (java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-141040" + "'", str9.equals("-141040"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "ophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                1.7                                                ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 94);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 103, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre                   " + "'", str3.equals("                  library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre                   "));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j", "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j" + "'", str2.equals("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " a4", charSequence1, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena" + "'", str1.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/", (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi!");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophi", (java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                             3.41.01", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                                                                             3.41.01" + "'", str7.equals("                                                                                             3.41.01"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("UTF-8", "                                                1.7                                                 ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Oracle Corporation", (int) (short) 10, (int) (short) 1);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                         ", 'a');
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8sun.uw..CGnuGhrcsEnnrntnmen.", strArray4, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen." + "'", str15.equals("                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen."));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "5.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0#100.0#1.0#1.0#10.0");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 100, 6);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str2.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode" + "'", str2.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-b15");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 78, 5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, (float) 1L, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ophie/Users/sophie" + "'", str1.equals("ophie/Users/sophie"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        float[] floatArray2 = new float[] { (byte) 100, (short) 100 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "S", (java.lang.CharSequence) "/users/sophi");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "S" + "'", charSequence2.equals("S"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0#10#97", 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n                                                                                                   ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a#4" + "'", str11.equals("a#4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0a10a97", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', (int) (byte) 1, (int) (short) -1);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "3.41.01", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', 52, 12);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                     noitacificepS IPA mroftalP avaJ", charArray10);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "52a100a97a3a10", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 69 + "'", int21 == 69);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                   ", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1.0410.04100.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(":S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S:" + "'", str1.equals("S:"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", (java.lang.CharSequence) "...                                                                        ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', (int) '4', 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "A44                                                                                                    ", (java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##########", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        short[] shortArray6 = new short[] { (short) -1, (short) 0, (byte) 1, (short) 1, (byte) 10, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 97, 8);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1 1 10 10" + "'", str8.equals("-1 0 1 1 10 10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " 44", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa4" + "'", str10.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "aa4" + "'", str14.equals("aa4"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0A01A1-", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0A01A1-" + "'", str2.equals("0A01A1-"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", (int) (byte) 10, "/users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec" + "'", str3.equals("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.0#1.0#100.0#97.0#0.0", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j" + "'", str1.equals("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/j"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', 0, 2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.0a1.0a1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", "Mac OS X", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.uw..CGnuGhrcsEnnrntnmen.", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.uw..CGnuGhrcsEnnrntnmen." + "'", str2.equals("sun.uw..CGnuGhrcsEnnrntnmen."));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "mod modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed ixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 73, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 73");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          Java Virtual Machine Specification10.0a1.0a1                                                                                          ", "-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "hi!##", "100#0#100#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence) "52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", ' ');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sophiehi!##", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("sophie/Users/sophie/Documents/defec", '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("java virtual machine specification", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 59 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100404100410", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100404100410" + "'", str2.equals("100404100410"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                                   ", 959, (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                      100a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                         sun.uw..CGnuGhrcsEnnrntnmen.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.9", 69, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                      ...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 143, (int) (byte) -1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                  0 100 52 -1 100", (java.lang.CharSequence) "2.0 97.0 1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10049746410041");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation" + "'", str1.equals("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporation"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_800#10.0                                                                 ", "ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                          /users/sophie                                          ", "100 97 6 100 1                  ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2.0 97.0 1.0" + "'", str11.equals("2.0 97.0 1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 97.0d + "'", double12 == 97.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                             0 100 52 -1 100", "...aaaaaaa", 959);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                             0 100 52 -1 100" + "'", str3.equals("                                                             0 100 52 -1 100"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", charArray6);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa4" + "'", str10.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aa4" + "'", str12.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a 4" + "'", str16.equals("a 4"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("utf-8SUN.UW..cgNUgHRCSeNNRNTNMEN.", 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444", " ", 959);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 959, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                 7.1", "M                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                            1.7.0_80-b15                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                1.7                                                 ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("d", "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sophiehi!##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophiehi!##" + "'", str1.equals("sophiehi!##"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                                                                                                                                                         ", "M                                 ", "/var/fol");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444", "Sun.awt.CGraphicsE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.lwawt.macosx.LWCToolkit", "S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixedmode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "0.9", (java.lang.CharSequence) ".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.9" + "'", charSequence2.equals("0.9"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", "-1.0#10.0#100.0#1.0#0.0", 9);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n                                                                                                   ", (int) (byte) 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, (float) 'a', (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0, 78);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("AA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AA" + "'", str1.equals("AA"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.041.04100.0497.040.0", "4444444444444x86_644444444444444", (int) (short) 100);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "hi!");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "aa");
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "hi!");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray19, "", (int) (short) 100, (-1));
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray13, strArray19);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "24.80-b11");
        try {
            java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("java(tm) se runtime e", strArray4, strArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "44444444444444444444444444444444444" + "'", str24.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray26);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10.0a1.0a1                                                                                          ", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        " + "'", str2.equals("                                                                        "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(99, 23, 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str12.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str15.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str17.equals("-1.0a100.0a1.0a1.0a10.0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":S", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa4" + "'", str10.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa4" + "'", str13.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ava(TM) SE Runtime Environment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randooppl_538_5627845", (java.lang.CharSequence) "1.60.9", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("24.80-b11                                                                                           ", "edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11                                                                                           " + "'", str3.equals("24.80-b11                                                                                           "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', 5, (int) (short) -1);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a0a100a100", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jejejejejejejejejejejejejejejejejejejejejejejejeje", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1.0410.04100.041.040.0", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444444444444444444444444", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        float[] floatArray2 = new float[] { (byte) 100, (short) 100 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100.0#100.0" + "'", str5.equals("100.0#100.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("c OS Xc OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"c OS Xc OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#########################################################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" 44", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode", "#################################################1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode" + "'", str2.equals("/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11                                                                                           " + "'", str1.equals("24.80-B11                                                                                           "));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed moixed mo", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", (int) (short) 10, 959);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "org.apache.commons.lang3.JavaVersion org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class class");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1A10A0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specificatio", 72, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fJava Virtual Machine Specificatio" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fJava Virtual Machine Specificatio"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Virtual Machine Specificatio", "100#97#6#100#1", "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatio" + "'", str3.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100", 52, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100" + "'", str3.equals("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        char[] charArray5 = new char[] { 'a', '4' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", charArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 73, 2);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aa4" + "'", str9.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aa4" + "'", str12.equals("aa4"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "JavaVirtualMachineSpecification", (java.lang.CharSequence) "hi!1.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0000000000                                                                                       ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0000000000                                                                                       " + "'", str2.equals("0000000000                                                                                       "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a10a100a-1a-1a", "100a10a100a-1a-1a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0#10.0#100.0#1.0#0.0", 97, 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7.17.17.17.17.17.17.17.17.17", "0000000000", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vaVersion" + "'", str2.equals("vaVersion"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("435a1a1a3444", "1004041004100", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean8 = javaVersion3.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.1" + "'", str6.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        char[] charArray6 = new char[] { 'a', '4' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aa4" + "'", str10.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#0#1#1#10#10", 1, 78);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                                                                                                                         ", 7, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                         " + "'", str3.equals("                                                                                                                                                                                                                         "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("jejejejejejejejejejejejejejejejejejejejejejejejeje");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jejejejejejejejejejejejejejejejejejejejejejejejeje" + "'", str1.equals("jejejejejejejejejejejejejejejejejejejejejejejejeje"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/USERS/SOPJava Virtual Machine SpecificatioHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPJava Virtual Machine SpecificatioHIE" + "'", str1.equals("/USERS/SOPJava Virtual Machine SpecificatioHIE"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################" + "'", str1.equals("###################################"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                         ", (java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                          /users/sophie                                          ", "###########################################################################################ixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                          /users/sophie                                          " + "'", str2.equals("                                          /users/sophie                                          "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("jejejejejejejejejejejejejejejejejejejejejejejejeje", "-1.0#.0#1.0#1.0#10.0");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "52a100a97a3a10", (java.lang.CharSequence[]) strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("                                 Java HotSpot(TM) 64-Bit Server VM                                  ", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ".7.0_80-b15" + "'", str7.equals(".7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                 Java HotSpot(TM) 64-Bit Server VM                                  " + "'", str13.equals("                                 Java HotSpot(TM) 64-Bit Server VM                                  "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("...E Runtime EdJava(TM) SE Ru...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...E Runtime EdJava(TM) SE Ru..." + "'", str1.equals("...E Runtime EdJava(TM) SE Ru..."));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVMBitServerVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 69, 35);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", (int) ' ', "Aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aasun.lwawt.macosx.CPrinterJobAa" + "'", str3.equals("Aasun.lwawt.macosx.CPrinterJobAa"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", "0.0#10.0#97.0#52.0#100.0", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2.0a97.0a1.0" + "'", str1.equals("2.0a97.0a1.0"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        char[] charArray8 = new char[] { 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".0#1.0#", charArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", charArray8);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray8);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "2.0a97.0a1.0                                                                                        ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aa4" + "'", str12.equals("aa4"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aa4" + "'", str15.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("enenenenenenenenenenenenenenene44444444444444444444444444444444444", "", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "d mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100a0a100a100", "UTF-8                             ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("a44       ", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a44       " + "'", str2.equals("a44       "));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre" + "'", str2.equals("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0000000000                                                                                       ", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 31, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################" + "'", str3.equals("###############################"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1.0a100.0a1.0a1.0a10.0", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!##", "", 7);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "M", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("a44                                                                                                    ", "", 49);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("24.80-B11                                                                                           ", "US", "\naaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-B11                                                                                           " + "'", str4.equals("24.80-B11                                                                                           "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".0#1.0#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0#1.0#" + "'", str1.equals(".0#1.0#"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1L), (float) '#', (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 72, (int) '#');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                               sophie/Users/sophie/Documents/defec                               ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##############x86_64###############", 959);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("jejejejejejejejejejejejejejejejejejejejejejejejeje", "-1.0#.0#1.0#1.0#10.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "52a100a97a3a10", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!1.71.7", "JAVA(TM) SE RUNTIM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!1.71.7" + "'", str2.equals("hi!1.71.7"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "a 4", (java.lang.CharSequence) "ophie/Documents/defects4j/tmp/ru");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0000000000                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0000000000                                                                                       " + "'", str1.equals("0000000000                                                                                       "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", "a 4", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1a10a0", "mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a10a0" + "'", str2.equals("-1a10a0"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("52...", "1004041004100", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52..." + "'", str3.equals("52..."));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.041.04100.0497.040.0", (java.lang.CharSequence) "24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("oraclecorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclecorporation" + "'", str1.equals("oraclecorporation"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtim", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtim" + "'", str3.equals("Java(TM) SE Runtim"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        long[] longArray5 = new long[] { 100L, 97, 6, (short) 100, 1L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray5, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 97 6 100 1" + "'", str8.equals("100 97 6 100 1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10049746410041" + "'", str10.equals("10049746410041"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion", (java.lang.CharSequence) "c OS Xc OS X", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 5, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 8, (long) 8, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "100.0#100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0410497", 78, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#!iheihpos", "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (byte) 1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100a10a10...", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-141040" + "'", str9.equals("-141040"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String[] strArray7 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "hi!");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "aa");
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "hi!");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "", (int) (short) 100, (-1));
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray11, strArray17);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, 'a');
        int int25 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray17);
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "sun.uw..CGnuGhrcsEnnrntnmen.");
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.stripAll(strArray27);
        boolean boolean29 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ".7.0_80-B15", (java.lang.CharSequence[]) strArray28);
        boolean boolean30 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", (java.lang.CharSequence[]) strArray28);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "44444444444444444444444444444444444" + "'", str22.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "aa" + "'", str24.equals("aa"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 217 + "'", int25 == 217);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JavaVirtualMachineSpecification", "Java(TM) SE Runtime Environment", 94);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        short[] shortArray6 = new short[] { (short) -1, (short) 0, (byte) 1, (short) 1, (byte) 10, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 0, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1 1 10 10" + "'", str8.equals("-1 0 1 1 10 10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 0 1 1 10 10" + "'", str11.equals("-1 0 1 1 10 10"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ":", (int) '4', (int) (short) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "                                                                  Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                   Java(TM) SE Runtime Environment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(32.0d, (double) 97L, 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "M", (java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("jev", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100.0#100.0", (java.lang.CharSequence) "10.0a1.0a100.0a97.0a0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  ", "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1 0 1 1 10 10", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 21, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str12.equals("-1.0a100.0a1.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0a100.0a1.0a1.0a10.0" + "'", str14.equals("-1.0a100.0a1.0a1.0a10.0"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "0.9");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.", "10.14.3");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 100, (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "enenenenenenenenenenenenenenene44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/", "ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-141040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                           ixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-1A10A0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

