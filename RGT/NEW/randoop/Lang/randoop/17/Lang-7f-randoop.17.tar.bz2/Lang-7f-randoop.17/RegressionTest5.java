import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aa4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4" + "'", str1.equals("aa4"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str2.equals("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!##" + "'", str1.equals("hi!##"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", 25);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1.04100.041.041.0410.0", (java.lang.CharSequence) "UTF-8                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                     noitacificepS IPA mroftalP avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                      noitacificepS IPA mroftalP avaJ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0", " 44");
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "aa");
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "hi!");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, "", (int) (short) 100, (-1));
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray12, strArray18);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "24.80-b11");
        try {
            java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/users/sophi", strArray3, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "44444444444444444444444444444444444" + "'", str23.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray25);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4", "ixed mod", 52, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4ixed mod" + "'", str4.equals("4ixed mod"));
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test011");
//        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserHome();
//        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getUserDir();
//        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
//        java.io.File file3 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
//        java.io.File[] fileArray4 = new java.io.File[] { file0, file1, file2, file3 };
//        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(fileArray4);
//        org.junit.Assert.assertNotNull(file0);
//        org.junit.Assert.assertNotNull(file1);
//        org.junit.Assert.assertNotNull(file2);
//        org.junit.Assert.assertNotNull(file3);
//        org.junit.Assert.assertNotNull(fileArray4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str5.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 97, ".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80" + "'", str3.equals("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                         ", "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java(tm) se runtime e", 12, "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java(tm) se runtime e" + "'", str3.equals("java(tm) se runtime e"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7", 959, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("   ", "Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ophie/Documents/defects4j/tmp/ru", "                              J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("JavaHotSpot(TM)64-BitServerVMBitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVMBitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVMBitServerVM"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aa", 0, "-1.0a100.0a1.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa" + "'", str3.equals("aa"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "7.1", "jav");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                      100a0a100a100");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "##########" + "'", str5.equals("##########"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mixedmode", (java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("###########################################################################################ixed mode", "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0#10.0#100.0#1.0#0.0", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) '4', (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(".0#1.0#", "52a100a97a3a10", (int) ' ', 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".0#1.0#52a100a97a3a10" + "'", str4.equals(".0#1.0#52a100a97a3a10"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtim", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("2.0 97.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2.0 97.0 1.0" + "'", str1.equals("2.0 97.0 1.0"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100", (java.lang.CharSequence) "c OS XaM", 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("###################################", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################" + "'", str3.equals("###################################"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("2.0a97.0a1.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.0a97.0a1.0" + "'", str2.equals("2.0a97.0a1.0"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.0#10.0#100.0#1.0#0.0", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str4.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Sun.awt.CGraphicsE", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str1.equals("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, (int) '#', 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "2.0a97.0a1.0", (java.lang.CharSequence) "                                                                                                                                                                                                                         ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, (int) (byte) 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray10 = new char[] { 'a', '4', ' ', '4', '#', 'a' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', (int) (byte) 1, (int) (short) -1);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.0", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                               sophie/Users/sophie/Documents/defec                               ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sophie", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Aa");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "2.0a97.0a1.0", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "0 100 52 -1 100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("###########################################################################################ixed mode", "-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mode" + "'", str2.equals("ixed mode"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2.0a97.0a1.0                                                                                        ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', (int) (short) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1 0 1 1 10 10", (int) '#', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                              1.7                                                 ", (java.lang.CharSequence) "2.0 97.0 1.0", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78 + "'", int3 == 78);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Aa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aa" + "'", str2.equals("Aa"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("###########################################################################################ixed mod", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################################################################################ixed mod" + "'", str2.equals("###########################################################################################ixed mod"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j" + "'", str1.equals("j"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("Library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("M", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str3.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod" + "'", charSequence2.equals("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b15", 78, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "http://java.oracle.com/");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                  0 100 52 -1 100", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0000000000                                                                                       ", "                                                                     noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("J", "1.60.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J" + "'", str2.equals("J"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1d + "'", double1 == 1.1d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (byte) 10, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/users/sophie", 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str1.equals("Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0" + "'", str2.equals("-1.04100.041.041.0410.0.-1.04100.041.041.0410.07-1.04100.041.041.0410.0.-1.04100.041.041.0410.00-1.04100.041.041.0410.0_-1.04100.041.041.0410.08-1.04100.041.041.0410.00-1.04100.041.041.0410.0--1.04100.041.041.0410.0b-1.04100.041.041.0410.01-1.04100.041.041.0410.05-1.04100.041.041.0410.0"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.0a1.0a1                                                                                          ", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0a1.0a1                                                                                          " + "'", str5.equals("10.0a1.0a1                                                                                          "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0#10.0#100.0#1.0#0.0", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                1.7                                                 ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str5.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.14.3", (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-1A10A0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a10a0" + "'", str1.equals("-1a10a0"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ixed mod", "100#0#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mod" + "'", str2.equals("ixed mod"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 7.1" + "'", str1.equals("                                                                                                 7.1"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                              1.7                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              1.7                                                 " + "'", str1.equals("                              1.7                                                 "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "vREVREsTIb-46)t(TOPsTOhAVAj", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 0, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        try {
            long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 1, 32, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("J", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", "#!iheihpos");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", "\n", (int) (short) 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1.010.0100.01.00.0", "-1.");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", 34, (int) (short) 10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) ":", 959);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAA52 100 97 3 10AAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 21, (float) ' ', 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        float[] floatArray5 = new float[] { 0, 10L, 97L, '4', (short) 100 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100#0#100#100", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#100#" + "'", str2.equals("100#0#100#"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("   ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '#', 52, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Sun.awt.CGraphicsE", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                  US");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("a44", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a44       " + "'", str3.equals("a44       "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) ' ', (float) ' ', (float) 103);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 103.0f + "'", float3 == 103.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(":s", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":s" + "'", str2.equals(":s"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str11.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str13.equals("-1.0#100.0#1.0#1.0#10.0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("444444444444444444444444444444444444444444444444444444444444444444444444", "a44       ", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("a44       ", 0, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a44       " + "'", str3.equals("a44       "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ".7.0_80-b15", (java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) 6L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/var/fol", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "                                                                                                    ", "CLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSIONCLASS ORG.APACHE.COMMONS.LANG3.JAVAVERSION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str3.equals("/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(".7.0_80-b15#########################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("M");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M" + "'", str1.equals("M"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, 0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.0410.04100.0", "24.80-b11                                                                                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0410.04100.0" + "'", str2.equals("-1.0410.04100.0"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.Comparable<java.lang.String>[] strComparableArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strComparableArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jav", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "aa");
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "hi!");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "", (int) (short) 100, (-1));
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray10, strArray16);
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.stripAll(strArray26, "hi!");
        int int29 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray28);
        java.lang.String[] strArray33 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String str37 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray33, ":", (int) '4', (int) (short) 0);
        int int38 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray33);
        java.lang.String str39 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ixed mod", strArray28, strArray33);
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEach(".0#1.0#", strArray10, strArray28);
        boolean boolean41 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.6", (java.lang.CharSequence[]) strArray10);
        java.lang.String str45 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a', (int) '4', 2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "44444444444444444444444444444444444" + "'", str21.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "ixed mod" + "'", str39.equals("ixed mod"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + ".0#1.0#" + "'", str40.equals(".0#1.0#"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "3.41.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa51B-08_0.7.", 100, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randooppl_538_5627845");
        java.lang.String[] strArray8 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "aa");
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "hi!");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, "", (int) (short) 100, (-1));
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray12, strArray18);
        java.lang.String[] strArray28 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.stripAll(strArray28, "hi!");
        int int31 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray30);
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "                                                1.7                                                 ", 0);
        java.lang.String str39 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray35, ":", (int) '4', (int) (short) 0);
        int int40 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray35);
        java.lang.String str41 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ixed mod", strArray30, strArray35);
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.replaceEach(".0#1.0#", strArray12, strArray30);
        int int43 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        try {
            java.lang.String str44 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.4", strArray2, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "44444444444444444444444444444444444" + "'", str23.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ixed mod" + "'", str41.equals("ixed mod"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + ".0#1.0#" + "'", str42.equals(".0#1.0#"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0a100.0a1.0a1.0a10.0", "jAVAhOTsPOT(t)64-bITsERVERv");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        float[] floatArray5 = new float[] { 0, 10L, 97L, '4', (short) 100 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0#10.0#97.0#52.0#100.0" + "'", str8.equals("0.0#10.0#97.0#52.0#100.0"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", 959);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...ntnmen.", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                 7.1", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 32, 0);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', (int) (short) 0, 49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ixed mo" + "'", str1.equals("ixed mo"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("A44                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a44                                                                                                    " + "'", str1.equals("a44                                                                                                    "));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1.equals((-1.0f)));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificatio" + "'", str1.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                                                                         ", (java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 217 + "'", int2 == 217);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("44444444444444444444444444444444444", 8, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                            ixed mod");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                            ixed mod\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str1.equals("class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1.0#100.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str1.equals("-1.0#100.0#1.0#1.0#10.0"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##!iheihpos", "hi!", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/users/sophi", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str1.equals("library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("35a1a1a34");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35a1a1a34" + "'", str1.equals("35a1a1a34"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 18, (double) 35.0f, (double) 6.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4", "0410497");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0410497" + "'", str2.equals("0410497"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion" + "'", str1.equals("class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                     noitacificepS IPA mroftalP avaJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("S", "10.14.3", (int) (short) -1, 217);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.3" + "'", str4.equals("10.14.3"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("       ...", "sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolkit", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str2.equals("sun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str1.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#", 959);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80-b15.7.0_80", "100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sophiehi!##", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1" + "'", str1.equals("7.1"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".1" + "'", str1.equals(".1"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed mode", "100#0#100#100", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JavaVirtualMachineSpecification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:           ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("a44                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a44\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("35A1A1A34");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35a1a1a34" + "'", str1.equals("35a1a1a34"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("j", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.uw..CGnuGhrcsEnnrntnmen.", 103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103 + "'", int2 == 103);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mac OS X", (java.lang.CharSequence) "100 97 6 100 1                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "mixedmode", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) 97, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.0a1.0a1", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a1.0a1" + "'", str2.equals("10.0a1.0a1"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defecJava Platform API Specificationsophie/Users/sophie/Documents/defec", 52, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0a100.0a1.0a1.0a10.0", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0a1.0a1", charArray7);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 10, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa4" + "'", str11.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0 100.0 1.0 1.0 10.0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "35a1a1a34");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("24.80-b11                                                                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b11                                                                                           \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jejejejejejejejejejejejejejejejejejejejejejejejeje", (int) (byte) 10, "hi!##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jejejejejejejejejejejejejejejejejejejejejejejejeje" + "'", str3.equals("jejejejejejejejejejejejejejejejejejejejejejejejeje"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine Specification", "ophie/Documents/defects4j/tmp/ru");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Documents/defects4j/tmp/ru" + "'", str2.equals("ophie/Documents/defects4j/tmp/ru"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("US");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray4, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "             class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "en" + "'", str7.equals("en"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4                              1.7                                                 444x86_644444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4                              1.7                                                 444x86_644444444444444" + "'", str1.equals("4                              1.7                                                 444x86_644444444444444"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100#0#100#100", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100" + "'", str2.equals("100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100100#0#100#100"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100#0#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "/");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ".7.0_80-B15", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10.0a1.0a1                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a1.0a1                                                                                          " + "'", str1.equals("10.0a1.0a1                                                                                          "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1.0410.04100.041.040.0", "10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava(TM) SE Runtime Environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.3", "   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", 959);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion", (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defecJavaaPlatformaAPIaSpecificationsophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC" + "'", str1.equals("SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a44                                                                                                    ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1.0 100.0 1.0 1.0 10.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 3, (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', (int) '#', 34);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', (int) '#', 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100a0a100a100" + "'", str20.equals("100a0a100a100"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("35A1A1A34", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100#0#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#0#100#100" + "'", str1.equals("100#0#100#100"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("ophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime EdJava(TM) SE Runtime E", (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 52, 31);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) '4', 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-141040" + "'", str9.equals("-141040"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion[] javaVersionArray1 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray2 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(javaVersionArray2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(javaVersionArray1);
        org.junit.Assert.assertNotNull(javaVersionArray2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, 10.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "100#0#100#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ", "Java(TM) SE Runtim", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("UTF-8", "sun.lwwt.mcosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "#################################################1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("je", "                                                7.1                                               ", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1 . 7" + "'", str3.equals("1 . 7"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("2.0a97.0a1.0", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           2.0a97.0a1.0                           " + "'", str2.equals("                           2.0a97.0a1.0                           "));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 12, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str3.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str5 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion4.atLeast(javaVersion6);
        boolean boolean8 = javaVersion2.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        short[] shortArray6 = new short[] { (short) -1, (short) 0, (byte) 1, (short) 1, (byte) 10, (byte) 10 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', 66, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 66");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1 1 10 10" + "'", str8.equals("-1 0 1 1 10 10"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                   ", "-1.0410.04100.041.040.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                1.7                                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7f + "'", float1.equals(1.7f));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER v" + "'", str1.equals("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER v"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jev", "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "2.0 97.0 1.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0a1.0a1", "###########################################################################################ixed mod", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":                                                                                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a44       ", "100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a44       " + "'", str2.equals("a44       "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java(TM) SE Runtim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA(TM) SE RUNTIM" + "'", str1.equals("JAVA(TM) SE RUNTIM"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a44                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11                                                                                           ", ".7.0_80-b15#########################################", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1.", 103, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################################-1.##################################################" + "'", str3.equals("##################################################-1.##################################################"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                              1.7                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                              1.7                                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jejejejejejejejejejejejejejejejejejejejejejejejeje", "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jejejejejejejejejejejejejejejejejejejejejejejejeje" + "'", str2.equals("jejejejejejejejejejejejejejejejejejejejejejejejeje"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos", 97, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos" + "'", str3.equals("#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos#!iheihpos"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("je");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"je\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " 44", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("vREVREsTIb-46)t(TOPsTOhAVAj");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0 100 52 -1 100", " 44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 100 52 -1 100" + "'", str2.equals("0 100 52 -1 100"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uTF-8" + "'", str1.equals("uTF-8"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100#0#100#100", "-1#10#0", "###########################################################################################ixed mode");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aa4", 959);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4', 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2.0 97.0 1.0" + "'", str11.equals("2.0 97.0 1.0"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.4", "Java(TM) SE Runtim");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment" + "'", str2.equals(" Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("vREVREsTIb-a6)t(TOPsTOhAVAj", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vREVREsTIb-a6)t(TOPsTOhAVAj" + "'", str2.equals("vREVREsTIb-a6)t(TOPsTOhAVAj"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("###########################################################################################ixed mode", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0a1.0a1", (java.lang.CharSequence) "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10" + "'", str3.equals("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 31, 2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 21, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\n", 25, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\naaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("\naaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        short[] shortArray6 = new short[] { (short) -1, (byte) 100, (short) 100, (byte) 0, (short) 10, (short) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 0, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-141004100404104100" + "'", str12.equals("-141004100404104100"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                1.7                                                 ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', (int) '#', 78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "#!iheihpos", 72);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1.04100.041.041.0410.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.04100.041.041.0410.0" + "'", str2.equals("-1.04100.041.041.0410.0"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.1", "ixed mode", "1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("JAVA(TM) SE RUNTIM", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA(TM) SE RUNTIM" + "'", str2.equals("JAVA(TM) SE RUNTIM"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "je");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                             -1a10a0                                             ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             -1a10a0                                             " + "'", str2.equals("                                             -1a10a0                                             "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1 0 1 1 10 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 0 1 1 10 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "                                                1.7                                                ", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, 31.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1 0 1 1 10 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sunawtCGraphicsEnvironment", (java.lang.CharSequence) "AA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str10.equals("-1.0 100.0 1.0 1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#!iheihpos", (int) (byte) 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava(TM) SE Runtime Environment");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "                                   ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "jAVAhOTsPOT(tm)64-bITsERVERvm", (int) ' ', 32);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.0#1.0#100.0#97.0#0.0", "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi!##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0 100.0 1.0 1.0 10.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JAVA(TM) SE RUNTIM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Aa");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "2.0a97.0a1.0", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "52 100 97 3 10", 32, 31);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ".0#1.0#52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str1.equals("-1.0#10.0#100.0#1.0#0.0"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        int[] intArray3 = new int[] { (-1), (short) 10, (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 10, (int) (short) 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 0, 0);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (int) (byte) 0, 78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1a10a0" + "'", str5.equals("-1a10a0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#0" + "'", str7.equals("-1#10#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "", 97);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "oracle CorporationOr-1.0410.04100.0");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "  ", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "a44                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mixedmode", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1A10A0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0A01A1-" + "'", str1.equals("0A01A1-"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 78, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/                                                                             " + "'", str3.equals("/                                                                             "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "sophie/Users/sophie/Documents/defec");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ".0#1.0#", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Sun.awt.CGraphicsE", 97, 103);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4" + "'", str2.equals("a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100404100410", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVMBitServerVM", (java.lang.CharSequence) "10.0#1.0#100.0#97.0#0.0", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444" + "'", str2.equals("4444444"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jejejejejejejejejejejejejejejejejejejejejejejejeje", ".0#1.0#52a100a97a3a10");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("                                   ", "oracle CorporationOr-1.0410.04100.0");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java Platform API Specification" + "'", str7.equals("Java Platform API Specification"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("sun.lwawt.macosx.LWCToolkit", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("-1#10#0", "                                                 7.1                                                ", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...", "/users/sophi");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("ixed mo", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        double[] doubleArray3 = new double[] { 2, 97, 1.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) (byte) 10, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2.0a97.0a1.0" + "'", str10.equals("2.0a97.0a1.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        int[] intArray5 = new int[] { 28, 100, '#', 12, 73 };
        int[] intArray11 = new int[] { 28, 100, '#', 12, 73 };
        int[] intArray17 = new int[] { 28, 100, '#', 12, 73 };
        int[] intArray23 = new int[] { 28, 100, '#', 12, 73 };
        int[][] intArray24 = new int[][] { intArray5, intArray11, intArray17, intArray23 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(intArray24);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 49, 28);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod", "ava(TM) SE Runtime Environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod" + "'", str3.equals("-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, (float) 72, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Virtual Machine Specificatio", (java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                  US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                  US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", "/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "je", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1.04100.041.041.0410.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0a1.0a100.0a97.0a0.0", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("java(tm) se runtime e");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("J", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("   ava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment7                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str11.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0 100.0 1.0 1.0 10.0" + "'", str13.equals("-1.0 100.0 1.0 1.0 10.0"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 28, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sophiehi!##", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 7.1", "\n         ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        char[] charArray4 = new char[] { ' ', '4' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51B-08_0.7.", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 100, (int) (short) -1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ', 25, 78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1.0410.04100.041.040.0", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 56");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.0#1.0#100.0#97.0#0.0", "class [ljava.lang.string;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/t/class org.apache.commons.lang3.javaversion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0#1.0#100.0#97.0#0.0" + "'", str2.equals("10.0#1.0#100.0#97.0#0.0"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, 52L, (long) 99);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java(TM) SE Ru");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java(TM) SE Ru is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.0", "-1 0 1 1 10 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0" + "'", str2.equals("10.0"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "\naaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JavaVirtualMachineSpecification", (java.lang.CharSequence) "...E Runtime EdJava(TM) SE Ru...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24.80-b11", 100, "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena" + "'", str3.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", "", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/###########################################################################################ixed modevar###########################################################################################ixed mode/###########################################################################################ixed modefolders###########################################################################################ixed mode/###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode/###########################################################################################ixed mode6###########################################################################################ixed modev###########################################################################################ixed mode597###########################################################################################ixed modezmn###########################################################################################ixed mode4###########################################################################################ixed mode_###########################################################################################ixed modev###########################################################################################ixed mode31###########################################################################################ixed modecq###########################################################################################ixed mode2###########################################################################################ixed moden###########################################################################################ixed mode2###########################################################################################ixed modex###########################################################################################ixed mode1###########################################################################################ixed moden###########################################################################################ixed mode4###########################################################################################ixed modefc###########################################################################################ixed mode0000###########################################################################################ixed modegn###########################################################################################ixed mode/###########################################################################################ixed modeT###########################################################################################ixed mode/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 3, (int) (byte) -1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100a1052a3a97a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("3.41.01", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.41.01" + "'", str2.equals("3.41.01"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444a44       444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", "Mac OS X", 72);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode" + "'", str3.equals("/Users/sophie/Documents/defects4Mac OS Xoop.pl_51318_1560278405ixed mode"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environmentava(TM) SE Runtime Environment", (java.lang.CharSequence) "jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11ixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed modixed mod                                                                   ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime E", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime E" + "'", str2.equals("Java(TM) SE Runtime E"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4", "SOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFECjAVAApLATFORMAapiAsPECIFICATIONSOPHIE/uSERS/SOPHIE/dOCUMENTS/DEFEC");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aa4"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 7.1" + "'", str1.equals("                                                                                                 7.1"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("52 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 11.7.0_80-b1552 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10" + "'", str3.equals("52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0a100.0a1.0a1.0a10.0", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.0a1.0a1", charArray7);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa4" + "'", str11.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100a10a100a-1a-1a0", "100 97 6 100 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a10a100a-1a-1a" + "'", str2.equals("100a10a100a-1a-1a"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "aa");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                             3.41.01");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.6", "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52.0f, (double) 73, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                  0 100 52 -1 100", "", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0A01A1-", "                                                                                                  US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                      100a0a100a100", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      100a0a100a100" + "'", str3.equals("                      100a0a100a100"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) 72, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444", "library/java/javavirtualmachines/jdk1#7#0_80#jdk/contents/home/jre");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach(".1", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".1" + "'", str4.equals(".1"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        int[] intArray4 = new int[] { '#', (short) 1, 1, 34 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "35a1a1a34" + "'", str6.equals("35a1a1a34"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("jev", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jev" + "'", str2.equals("jev"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion" + "'", str1.equals("class [Ljava.lang.String;/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.3", "aaaaaaaaaaaaaaaaaaa52 100 97 3 10aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("vREVREsTIb-46)t(TOPsTOhAVAj", "52a100a97a3a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vREVREsTIb-46)t(TOPsTOhAVAj" + "'", str2.equals("vREVREsTIb-46)t(TOPsTOhAVAj"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405ixed mode", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        float[] floatArray5 = new float[] { (-1), (short) 100, (byte) 1, (short) 1, 10L };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', (int) (short) 1, (int) (short) 0);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0#100.0#1.0#1.0#10.0" + "'", str8.equals("-1.0#100.0#1.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + (-1.0f) + "'", float14 == (-1.0f));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        int[] intArray4 = new int[] { '#', (short) 1, 1, 34 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "35a1a1a34" + "'", str6.equals("35a1a1a34"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "100a10a100a-1a-1a0", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1.0#.0#1.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#.0#1.0#1.0#10.0" + "'", str1.equals("-1.0#.0#1.0#1.0#10.0"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 73, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################################################################" + "'", str3.equals("#########################################################################"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100", "52 100 97 3 10", "ixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###################################################################jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "java virtual machine specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split(".7.0_80-b15", 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence[]) strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "http://java.oracle.com/" + "'", str7.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10" + "'", str13.equals("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.Class<?> wildcardClass5 = byteArray1.getClass();
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-1.0#10.0#100.0#1.0#0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", "-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.01.00.0-1.010.0100.0ixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) '4', 959L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ixed mo", "", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ixed moixed moixed mo" + "'", str3.equals("ixed moixed moixed mo"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 0, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2.0a97.0a1.0" + "'", str1.equals("2.0a97.0a1.0"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35, (float) 21, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("edom dexi5048720651_81315_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "1 . 7", "10.0a1.0a1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("52a100a97a3a10", (-1), '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52a100a97a3a10" + "'", str3.equals("52a100a97a3a10"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                         " + "'", str2.equals("                                                                         "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(":s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":S" + "'", str1.equals(":S"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("24.80-b11", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        double[] doubleArray5 = new double[] { 10, (short) 1, 100.0f, 'a', 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 2, 3);
        java.lang.Class<?> wildcardClass16 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a1.0a100.0a97.0a0.0" + "'", str7.equals("10.0a1.0a100.0a97.0a0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0#1.0#100.0#97.0#0.0" + "'", str11.equals("10.0#1.0#100.0#97.0#0.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100.0" + "'", str15.equals("100.0"));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1004041004100" + "'", str11.equals("1004041004100"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a0a100a100" + "'", str14.equals("100a0a100a100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100a0a100a100" + "'", str16.equals("100a0a100a100"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                7.1                                               ", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                7.1                                               " + "'", str2.equals("                                                7.1                                               "));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                           2.0a97.0a1.0                           ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "2.0a97.0a1.0                                                                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 ", "jev", "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 " + "'", str3.equals("2.0a97.0a1.0                       -1.0#100.0#1.0#1.0#10.0                                                                 "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0#.0#1.0#1.0#10.0", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, 0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0", " 44");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence4, (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                            ixed mod", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                                                                            ixed mod" + "'", str9.equals("                                                                                            ixed mod"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) 10, 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        try {
            long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.9");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 32, (int) (byte) 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "d" + "'", str5.equals("d"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0A01A1-", "ophie/Documents/defects4j/tmp/ru");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "1.7.0_80-b15");
        java.lang.Class<?> wildcardClass7 = strArray4.getClass();
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVMBitServerVM", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "aa");
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "", "" };
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray21, "hi!");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, "", (int) (short) 100, (-1));
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("44444444444444444444444444444444444", strArray17, strArray23);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray23);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena", strArray4, strArray23);
        int int31 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "44444444444444444444444444444444444" + "'", str28.equals("44444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena" + "'", str30.equals("aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4en24.80-b11aa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4enaa4ena"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                             -1a10a0                                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sunawtCGraphicsEnvironment", ".7.0_80-b15#########################################", "\naaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        double[] doubleArray5 = new double[] { (-1.0d), (short) 10, 100L, 1.0f, 0.0d };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 31, 7);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0#10.0#100.0#1.0#0.0" + "'", str7.equals("-1.0#10.0#100.0#1.0#0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.jav", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0.0#10.0#97.0#52.0#100.0", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jejejejejejejejejejejejejejejejejejejejejejejejeje", "M", 217);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) 10, 72);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                           2.0a97.0a1.0                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                           2.0a97.0a1.0                           " + "'", str1.equals("                           2.0a97.0a1.0                           "));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                             3.41.01", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                             3.41.01" + "'", str3.equals("                                                                                             3.41.01"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "oracle CorporationOr-1.0410.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########", "library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", (int) '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                              J", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        char[] charArray7 = new char[] { 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/users/sophie", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0a100.0a1.0a1.0a10.0", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randooppl_538_5627845", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aa4" + "'", str11.equals("aa4"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ophie/Users/sophie", 959);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Users/sophie" + "'", str2.equals("ophie/Users/sophie"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51318_1560278405/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) ' ', 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("2.0a97.0a1.0", "100#0#100#100", "52a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a11.7.0_80-b1552a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0a97.0a1.0" + "'", str3.equals("2.0a97.0a1.0"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.Number[] numberArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        short[] shortArray4 = new short[] { (short) 100, (short) 0, (short) 100, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) 'a', (int) (short) -1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100a10a100a-1a-1a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.041.04100.0497.040.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.041.04100.0497.040.0" + "'", str1.equals("10.041.04100.0497.040.0"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("ixed mode", "100#0#100#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mode" + "'", str2.equals("ixed mode"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn_v31cq2n2x1nfc0000gn/T/", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 100 97 3 1052 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "ava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.0", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0" + "'", str3.equals("10.0"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/                                                                             ", "", "sophie/Users/sophie/Documents/defec4444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/                                                                             " + "'", str3.equals("/                                                                             "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("jev");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a100a97a3a1052a10", 12, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }
}

