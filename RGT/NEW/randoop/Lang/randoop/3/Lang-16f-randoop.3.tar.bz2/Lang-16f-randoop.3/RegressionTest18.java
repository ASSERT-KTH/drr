import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test01");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 23, 0.0d, (double) 9.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test02");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#############", "java(TM)SERuntimeEnvironmen1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15Java(TM)SERuntimeEnvironmen1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15Java(TM)SERuntimeEnvironmen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test03");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("javahotspot(tm)64-bitservervjavahotspot(tm)64-bitservervjavahotspot(tm)64-bitservervjavahotspot(...", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test04");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "        51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User                 51.0/UseH/User         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test05");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94285_1560208945", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation Oracle Corporation ", 15, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test06");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("6_68x", "!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i!ih!ih!i!i");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test07");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test08");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre 10.14.3 10.14.3 10.14.3 10.14.3", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "re 10.14.3 10.14.3 10.14.3 10.14.3" + "'", str2.equals("re 10.14.3 10.14.3 10.14.3 10.14.3"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test09");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "       p    h    O0", (java.lang.CharSequence) " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test10");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironme");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironme" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironme"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test11");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("raclhi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!hi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!Chi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!rphi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!rathi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!hi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RACLHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!HI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!cHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!RPHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!RATHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!HI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!N" + "'", str1.equals("RACLHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!HI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!cHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!RPHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!RATHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!HI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!/uSERS/SOPHIEHI!N"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test12");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("    0Ohp", "hi!i!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    0Ohp" + "'", str2.equals("    0Ohp"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test13");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aa                            5498020651_58249_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa                            5498020651_58249_LP.POODNAR_NUR/PMT/J4STCEFED/STNEMUCOd/EIHPOS/SRESu/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test14");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("NOITAROPROc ELCARo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROc ELCARo" + "'", str1.equals("NOITAROPROc ELCARo"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test15");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-BIT SERVER VM                                                           JAVA HOTSPOT(TM) 6", (java.lang.CharSequence) "x86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_6", 316);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test16");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aAAAAAAAAAAAAAA", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test17");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SUN.LWAWT.MACOSX.LWCTOOLKITaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa####################################################################################################a", "b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.42");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test18");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " NOITAROPROc ELCARo ", (java.lang.CharSequence) "j#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervj#v#hotspot(tm)64-bitservervrporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation0Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test19");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "CLE.COM/X86_64A.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVAX86_64HTTP://J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test20");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server V");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" NOITAROPROc ELCARo0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1181");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test21");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("...                                          h                         ...", "x86_6", "                                                                                                                                                                                                                                                                               24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                          h                         ..." + "'", str3.equals("...                                          h                         ..."));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test22");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("u");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "U" + "'", str1.equals("U"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test23");
        char[] charArray7 = new char[] { 'a', ' ', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "6_68x", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "p    h    O0-Bit Server x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 64 Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test24");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Waw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cpwaw.ac.cp", "/var...", "CLE.COM/X86_64A.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVACLE.COM/X86_64HTTP://JA.ORAVAX86_64HTTP://J");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcp" + "'", str3.equals("WEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcpwEwCEcCcp"));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test25");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94285_1560208945", (java.lang.CharSequence) "                                                                                                    1.71.81.21.8                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test26");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str7 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = javaVersion8.atLeast(javaVersion11);
        java.lang.String str15 = javaVersion8.toString();
        boolean boolean16 = javaVersion3.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        boolean boolean23 = javaVersion17.atLeast(javaVersion20);
        java.lang.String str24 = javaVersion17.toString();
        java.lang.String str25 = javaVersion17.toString();
        java.lang.String str26 = javaVersion17.toString();
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean29 = javaVersion27.atLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion31 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean32 = javaVersion30.atLeast(javaVersion31);
        boolean boolean33 = javaVersion27.atLeast(javaVersion30);
        java.lang.String str34 = javaVersion27.toString();
        boolean boolean35 = javaVersion17.atLeast(javaVersion27);
        boolean boolean36 = javaVersion3.atLeast(javaVersion27);
        org.apache.commons.lang3.JavaVersion javaVersion37 = null;
        try {
            boolean boolean38 = javaVersion27.atLeast(javaVersion37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.2" + "'", str15.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.2" + "'", str24.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1.2" + "'", str25.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1.2" + "'", str26.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion31 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion31.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1.2" + "'", str34.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test27");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444401.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94285_1560208945                           0-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B1RACLE cORPORATION 4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "85_156020895                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test28");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test29");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test30");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("j4v4(tm) se runtime environme");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"j4v4(tm) se runtime environme\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test31");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("#################################################################################################################################################################################################################################################################", "ACLEcORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################################################################################################################################################################################" + "'", str2.equals("#################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test32");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test33");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ndoop.pl_94285_1560208945                            ", ' ');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test34");
        double[] doubleArray4 = new double[] { 10.0f, 100, 100, '#' };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test35");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("java(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmenjava(tm) se runtime environmen", '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_6", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "x86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_6" + "'", str5.equals("x86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_64clecmx86_6"));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test36");
        short[] shortArray1 = new short[] { (byte) 1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test37");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("HI!I!HI!HI!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test38");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 22, (double) 9.0f, (double) 24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.0d + "'", double3 == 24.0d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test39");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "x 86 _ 64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test40");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa####################################################################################################", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test41");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "       1.2                  ", charSequence1, 258);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test42");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "HI!HI!HI!", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.Class<?> wildcardClass6 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str5.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test43");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "8-FTU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test44");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hhhhhh##################################################################################################################################0Oracle Corporation ###############################################################################################################", "!ih!ih!ihNOITAROPROc ELCARo0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################################################################################################################################0Oracle Corporation ###############################################################################################################" + "'", str2.equals("##################################################################################################################################0Oracle Corporation ###############################################################################################################"));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test45");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "Java Platform API Specificationhi!hi!hi!", 542);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test46");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("java HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server Vjava HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server v" + "'", str1.equals("java hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server vjava hotspot(tm) 64-bit server v"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test47");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x" + "'", str2.equals("6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x1.     6_68x"));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test48");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86_6x86");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test49");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test50");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test51");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "rF-44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test52");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("        51.0/useh/user         ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test53");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test54");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("            1.21.21.6              ", "x86_64            x86_64            x86_64            x86_64            x86_64            x86_64", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test55");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 215);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test56");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_94285_1560208945                           ", (java.lang.CharSequence) "a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a51.0a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test57");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 26, (long) 22, (long) 99);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 99L + "'", long3 == 99L);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test58");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "######################################################################################################################################################### /", (java.lang.CharSequence) "51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/U...cle.com/x8...51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/UseH/User51.0/Us", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test59");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "users/sophie/documents/defects4j/tmp/run_randoop.pl_94285_1560208945                            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test60");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "        aaaaaaaaaaaaaaa        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test61");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Il/:", "com/x86_64http://java.oracle.com/x86_64http://java.oracle.com/x86_64http://java.oracle.com/x86_64http://java.oracle.com/x86_64http://java.oracle.com/x86_64http://java.oracle.com/x86_64StoH avaJ", "Oraclhi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!hi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!Chi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!rphi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!rathi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!hi!/Users/sophiehi!/Users/sophiehi!/Users/sophiehi!n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Isc/" + "'", str3.equals("Isc/"));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test62");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("J4v4(TM) S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J4v4(TM) S" + "'", str1.equals("J4v4(TM) S"));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test63");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("I!HI!HI!", "0Oracle Corporation ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server V");
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', 79, 15);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.Class<?> wildcardClass12 = strArray5.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server VJava HotSpot(TM) 64-Bit Server V", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "I!HI!HI!" + "'", str11.equals("I!HI!HI!"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test64");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "...                                          h                         ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test65");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ORACLE CORPORATION 444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test66");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" noitaroproc elcaro0                                                                               ", "ro.avaj//:ptthhi!hi!hi!...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1560208945...85_1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test67");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-FTU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-FTU" + "'", str1.equals("-FTU"));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test68");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("##################################0O    h    p      ", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################################0O    h    p      " + "'", str2.equals("##################################0O    h    p      "));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test69");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("J", "Mac OS24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test70");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 76, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test71");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("UTF-8", 281);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                          UTF-8                                                                                                                                          " + "'", str2.equals("                                                                                                                                          UTF-8                                                                                                                                          "));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test72");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test73");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("http://j4http://j.orvVrevrex86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64StoH.orvcle.com/x86_64Jvcle.com/x86_6", "1.7.S_8S-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j4http://j.orvVrevrex86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64StoH.orvcle.com/x86_64Jvcle.com/x86_6" + "'", str2.equals("http://j4http://j.orvVrevrex86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64http://j.orvcle.com/x86_64StoH.orvcle.com/x86_64Jvcle.com/x86_6"));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test74");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "###############################################", 258);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test75");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("v REVREX86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64sTOh AVAj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vREVREX86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64sTOhAVAj" + "'", str1.equals("vREVREX86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64HTTP://JAVA.ORACLE.COM/X86_64sTOhAVAj"));
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test76");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!hi!hi!", (java.lang.CharSequence) "-bIT sERVER vm4jAVA hOTsPOT(tm) 6", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test77");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java HotSpot(TM) 64-Bit Server VM", "               0RACLE cORPORAION ", "!ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i                     !ih!ih!i!i");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test78");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 53L, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test79");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!h", 279);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!h                                                                                                                                                                                                                                                                                   " + "'", str2.equals("hi!h                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test80");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(" ", "ORACLE CORPORATION 444444444444444444444444444444444444444444444444444444", 39);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test81");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("H");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "          ");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                  /Library/J", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test82");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                     ", 28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test83");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "noitaroproC elcarO                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test84");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("           oracle ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"           oracle \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test85");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("          Java(TM) SE Runtime Environmen1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_\n                                                                                                                                                  !IH!IH!IH", "###############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          Java(TM) SE Runtime Environmen1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_\n                                                                                                                                                  !IH!IH!IH" + "'", str2.equals("          Java(TM) SE Runtime Environmen1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_\n                                                                                                                                                  !IH!IH!IH"));
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test86");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 640Oracle Corporation http0Oracle Corporation ://0Oracle Corporation java0Oracle Corporation .0Oracle Corporation oracle0Oracle Corporation .0Oracle Corporation com0Oracle Corporation /0Oracle Corporation x0Oracle Corporation 860Oracle Corporation _0Oracle Corporation 64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test87");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-bIT sERVER vm4jAVA hOTsPOT(tm) 6", (java.lang.CharSequence) "1.21.21.6", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test88");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre 10.14.3 10.14.3 10.14.3 10.14.3", "class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test89");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence) "...85_156020895                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test90");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java HotSpot(TM) 64-Bit Server VJava HotSpotHI!HI!HI!Java HotSpot(TM) 64-Bit Server VJava HotSpot                                   Java HotSpot(TM) 64-Bit Server VJava HotSpotHI!HI!HI!Java HotSpot(TM) 64-Bit Server VJava HotSpot                                   Java HotSpot(TM) 64-Bit Server VJava HotSpotHI!HI!HI!Java HotSpot(TM) 64-Bit Server VJava HotSpot                                   Java HotSpot(TM) 64-Bit Server VJava HotSpotHI!HI!HI!Java HotSpot(TM) 64-Bit Server VJava HotSpot                                   Java HotSpot(TM) 64-Bit Server VJava HotSpotHI!HI!HI!Java HotSpot(TM) 64-Bit Server VJava HotSpot");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest18.test91");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 4300);
        org.junit.Assert.assertNotNull(strArray3);
    }
}

