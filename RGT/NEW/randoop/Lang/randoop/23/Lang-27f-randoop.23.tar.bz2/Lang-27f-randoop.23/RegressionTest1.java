import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Sophie", "i!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sophie" + "'", str3.equals("Sophie"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "http://java.oracle.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("US", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/\n", (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray4, strArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', 100, 0);
        java.lang.String[] strArray21 = new java.lang.String[] { "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM", "\n", "/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/", "  Sophie  ", "sun.awt.CGraphicsEnvironment" };
        boolean boolean22 = org.apache.commons.lang3.StringUtils.startsWithAny("sun.lwawt.macosx.CPrinterJob", strArray21);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray21);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("Java HotSpot(TM) 64-Bit Server VM", strArray7, strArray21);
        int int25 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Sun.awt.CGraphicsEnvironment", strArray21);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Java Virtual Machine Specification" + "'", str10.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment" + "'", str23.equals("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str24.equals("Java HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("java platforUSjava platf");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Sophie", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sophie" + "'", str2.equals("Sophie"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Virtual Machine SpecificationJava Virtual Ma1.7", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Ma1.7" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Ma1.7"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Double double0 = org.apache.commons.lang3.math.NumberUtils.DOUBLE_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-1.0d) + "'", double0.equals((-1.0d)));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, 1.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.awt.CGraphicsEnvironment", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "x86_64");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/" + "'", str8.equals("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, (int) (short) 10, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\n/", "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n/" + "'", str2.equals("\n/"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specification", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("d", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                d                                                " + "'", str2.equals("                                                d                                                "));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "24.80-b11", (int) ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "Hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (byte) -1, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("i!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_4;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, (int) ' ', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 26, (float) (-1), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 26.0f + "'", float3 == 26.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("b", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("sophie", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("M");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", 9, "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!1.7hi!" + "'", str3.equals("hi!1.7hi!"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("\n/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("mixed mode", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("java platforUSjava platfor");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(":", (int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("http://java.oracle.", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80                                            ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80                                            " + "'", str2.equals("1.7.0_80                                            "));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/\n", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/", "Hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/" + "'", str2.equals("/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                          ", "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("\n", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "46_68X", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str1.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Integer int0 = org.apache.commons.lang3.math.NumberUtils.INTEGER_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0.equals((-1)));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                          sun.lwawt.macosx.LWCToolkit                                                          ", "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) (byte) -1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("441.7.0_80", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                                    ", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_ZERO;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0.equals((byte) 0));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hi!1.7hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_PATH;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str0.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80", "Oracle Corporation", 52, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80Oracle Corporation" + "'", str4.equals("1.7.0_80Oracle Corporation"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("//////////", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/de" + "'", str2.equals("/Users/sophie/Documents/de"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 10, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sophie", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        int int0 = org.apache.commons.lang3.SystemUtils.JAVA_VERSION_INT;
//        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 170 + "'", int0 == 170);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", "1.7.0_80-b15", (int) (short) 10);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("Oracle Corporation", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) (short) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477", "/var/folders/          v/          v597zmn          v31cq2n2          1n          fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Platform API Specification", "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/", "/var/folders/          v/          v597zmn          v31cq2n2          1n          fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob", "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                          sun.lwawt.macosx.LWCToolkit                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("//////////", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////" + "'", str2.equals("//////////"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("          ", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("441.7.0_80", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, ":");
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "441.7.0_80" + "'", str8.equals("441.7.0_80"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM", "hi!", "US");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.LWCToolkit", "//////////", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("441.7.0_80", (int) ' ', "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "441.7.0_80sun.lwawt.macosx.LWCTo" + "'", str3.equals("441.7.0_80sun.lwawt.macosx.LWCTo"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/var/folders/          v/          v597zmn          v31cq2n2          1n          fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_CLASS_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "51.0" + "'", str0.equals("51.0"));
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificationa" + "'", str1.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                                                          sun.lwawt.macosx.LWCToolkit                                                          ", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "441.7.0_80", "M");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("java platforUSjava platf", "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specificationa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80                                            ", "b");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("Sun.awt.CGraphicsEnvironment", (java.lang.Object[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80                                            " + "'", str4.equals("1.7.0_80                                            "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n/", 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.7f, (float) 52, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 12, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("15", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/var/folders/          v/          v597zmn          v31cq2n2          1n          fc0000gn/T/", 31, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 97, "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("441.7.0_80sun.lwawt.macosx.LWCTo", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                          sun.lwawt.macosx.LWCToolkit                                                          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 143 + "'", int1 == 143);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0, (float) 0L, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Hi!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("  Sophie  ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("UTF-8", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("//////////", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80Oracle Corporation", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80Oracle Corporation" + "'", str2.equals("1.7.0_80Oracle Corporation"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM", "b");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray2, strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', 100, 0);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specification");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, ":");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/\n", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment" + "'", str2.equals("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("b");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hi!1.7hi!", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("X86_64", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80                                            ", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("b", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("Java Virtual Machine Specification", "//////////", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Virtual Machine SpecificationJava Virtual Ma1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Ma1.7" + "'", str1.equals("Java Virtual Machine SpecificationJava Virtual Ma1.7"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 97.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "441.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "46_68X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 0, (float) 100, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "java platforUSjava platf");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("441.7.0_80sun.lwawt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "441.7.0_80sun.lwawt.macosx.LWCTo" + "'", str1.equals("441.7.0_80sun.lwawt.macosx.LWCTo"));
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 12, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, 100.0d, (double) 13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":", "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mixed mode", "Oracle Corporation");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(143, (int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 143 + "'", int3 == 143);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java platform api specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) 'a', 143);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                    ", "24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.3", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("441.7.0_80", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, ":");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("java platforUSjava platfor", strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "x86_64");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("441.7.0_80sun.lwawt.macosx.LWCTo", strArray7, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/" + "'", str12.equals("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/" + "'", str14.equals("/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("441.7.0_80", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "en", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("mixed mode", "UTF-8", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode" + "'", str3.equals("mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/", (int) (short) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/" + "'", str3.equals("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Sun.awt.CGraphicsEnvironment", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("i!", "441.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "441.7.0_80" + "'", str2.equals("441.7.0_80"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "d");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, 0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", 52, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolkit", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("http://java.oracle.", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle." + "'", str2.equals("http://java.oracle."));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("http://java.oracle.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://java.oracle.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Virtual Machine Specification", "/Users/sophie", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Oracle Corporation", 0, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("M");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80                                            ", 170, "Sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            " + "'", str3.equals("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i!", "hi!1.7hi!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i!", "hi!1.7hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.CPrinterJob", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str7.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80Oracle Corporation", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80Oracle Corporation" + "'", str2.equals("1.7.0_80Oracle Corporation"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, (double) 97, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("          ", "Oracle Corporation", "441.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '#', (float) (short) 10, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", "//////////");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/de", "java platforUSjava platfor");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("en", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM", "  Sophie  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM" + "'", str2.equals("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "441.7.0_80sun.lwawt.macosx.LWCTo", "/Users/sophie/Documents/de");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("441.7.0_80", "http://java.oracle.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "441.7.0_80" + "'", str2.equals("441.7.0_80"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("\n/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n/" + "'", str2.equals("\n/"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/\n", 0, "SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/\n" + "'", str3.equals("/\n"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) 30, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specification", "java platforUSjava platf", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("24.80-b11", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.80-b11" + "'", str4.equals("24.80-b11"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode", "                                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("i!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!" + "'", str2.equals("i!"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                    ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("\n/", "15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("b", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 100, (long) 13, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment", "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10.14.3", "Sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8mixed mode" + "'", str2.equals("UTF-8mixed mode"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Hi!", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("i!", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "441.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                    ", "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ", (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/va\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("java platform api specification", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java platform api specification" + "'", str2.equals("java platform api specification"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "d", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/" + "'", str3.equals("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "441.7.0_80", "441.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("i!", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java HotSpot(TM) 64-Bit Server VM", "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "24.80-b11", (int) ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("sun.lwawt.macosx.CPrinterJob", strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.Long long0 = org.apache.commons.lang3.math.NumberUtils.LONG_ZERO;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0.equals(0L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str0.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "java platforUSjava platfor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("46_68X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                d                                                ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("46_68X", "/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("          ", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("java platforUSjava platf", "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java platforUSjava platf" + "'", str2.equals("java platforUSjava platf"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, (double) 9, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "1.7", "/Users/sophie", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/moc.elcaro.avaj//:ptth", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str2.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                          sun.lwawt.macosx.LWCToolkit                                                          ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                          sun.lwawt.macosx.LWCToolkit                                                          ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!1.7hi!", "15", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!M.7hi!" + "'", str3.equals("hi!M.7hi!"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("java platforUSjava platf", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java Virtual Machine Specification", "51.0", (int) ' ', 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine Specificati51.0" + "'", str4.equals("Java Virtual Machine Specificati51.0"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', (int) 'a', 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!1.7hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("441.7.0_80sun.lwawt.macosx.LWCTo", "Java(TM) SE Runtime Environment", "10.14.3", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "441.7.0_80sun.lwawt.macosx.LWCTo" + "'", str4.equals("441.7.0_80sun.lwawt.macosx.LWCTo"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("//////////", "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("java platforUSjava platfor", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                    ", "mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 97L, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "//////////");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_64", "", 143);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X86_64" + "'", str4.equals("X86_64"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "hi!", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Ushi!jar" + "'", str3.equals("/Ushi!jar"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "15" + "'", str1.equals("15"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("java platform api specification", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java platform api specification" + "'", str2.equals("java platform api specification"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!1.7hi!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 0, (long) 52, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("10.14.3", "mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/", "hi!M.7hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/" + "'", str2.equals("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment", "sun.lwawt.macosx.LWCToolkit", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment" + "'", str3.equals("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ", "X86_64", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Sun.awt.CGraphicsEnvironment", "1.7.0_80                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("java platforUSjava platf", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "//////////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie", "                                                d                                                ", (int) '4');
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("hi!M.7hi!", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("15", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL" + "'", str1.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode" + "'", str2.equals("mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80Oracle Corporation", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_1;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                    ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("java platforUSjava platfor");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 15, 0.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 15.0f + "'", float3 == 15.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("java platform api specification", "sun.lwawt.macosx.LWCToolkit", "                                                          sun.lwawt.macosx.LWCToolkit                                                          ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java platform api specification" + "'", str4.equals("java platform api specification"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("java platforUSjava platf", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("Hi!", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("x86_64", "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477", "15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 588 + "'", int1 == 588);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("b", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("hi!1.7hi!", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                                    " + "'", str5.equals("                                                    "));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("b", "                                                d                                                ", "                                                    ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("java platforUSjava platf", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("java platforUSjava platfor", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("en", 143, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("UTF-8mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8mixed mode" + "'", str1.equals("UTF-8mixed mode"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "46_68X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                          ", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          " + "'", str3.equals("                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("b", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specification", (int) 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "b" + "'", str5.equals("b"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "\n/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n/" + "'", str2.equals("\n/"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("", "X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", "UTF-8mixed mode", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sph8" + "'", str3.equals("sph8"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("java platforUSjava platf");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platforUSjava platf" + "'", str1.equals("java platforUSjava platf"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("sun.awt.CGraphicsEnvironment", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477", "          ", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("b", "");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("46_68X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray2, strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 170, 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java Virtual Machine Specification" + "'", str8.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                                    " + "'", str9.equals("                                                    "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                                                d                                                ", "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80Oracle Corporation", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80Oracl" + "'", str2.equals("1.7.0_80Oracl"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "46_68X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                          ", "hi!1.7hi!", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("  Sophie  ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("http://java.oracle.com/", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("46_68X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                    ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray3, strArray6);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!", "sun.lwawt.macosx.CPrinterJob", (int) (short) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray6, strArray13);
        java.lang.Class<?> wildcardClass15 = strArray6.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java Virtual Machine Specification" + "'", str9.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str14.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/var/folders/          v/          v597zmn          v31cq2n2          1n          fc0000gn/T/", "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sph8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sph8" + "'", str1.equals("Sph8"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/MOC.ELCARO.AVAJ//:PTTH" + "'", str1.equals("/MOC.ELCARO.AVAJ//:PTTH"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Hi!", "\n/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("http://java.oracle.com/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cle.com/a.oravahttp://j" + "'", str2.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3.0f, (double) (short) 1, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Ushi!jar", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 143, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("X86_64", "baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.CPrinterJob", "                                                d                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "441.7.0_80sun.lwawt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/MOC.ELCARO.AVAJ//:PTTH");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("cle.com/a.oravahttp://j", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sph8", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sph8      " + "'", str2.equals("sph8      "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Ushi!jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Ushi!jar" + "'", str1.equals("/Ushi!jar"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("en", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            " + "'", str3.equals("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Hi!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!" + "'", str2.equals("Hi!"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10.14.3", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                    10.14.3                                                                    " + "'", str2.equals("                                                                    10.14.3                                                                    "));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                          sun.lwawt.macosx.LWCToolkit                                                          ", (int) (byte) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("//////////");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "//////////" + "'", str1.equals("//////////"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                          ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("java platform api specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va platform api " + "'", str2.equals("va platform api "));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8", 6, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aUTF-8" + "'", str3.equals("aUTF-8"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi!M.7hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "/var/folders/          v/          v597zmn          v31cq2n2          1n          fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mixed mode", "", "Sph8");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), 3L, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Virtual Machine Specificati51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificati51.0" + "'", str1.equals("Java Virtual Machine Specificati51.0"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/var/folders/v/v597zmnv31cq2n21nfc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80                                            " + "'", str1.equals("1.7.0_80                                            "));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie", 0, "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Sph8", "d", "/MOC.ELCARO.AVAJ//:PTTH");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sph8" + "'", str3.equals("Sph8"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(15.0f, (float) 97L, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 15.0f + "'", float3 == 15.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!M.7hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!M.7hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Sophie", "                                                          sun.lwawt.macosx.LWCToolkit                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sophie" + "'", str2.equals("Sophie"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Java(TM) SE Runtime Environment", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "441.7.0_80sun.lwawt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("cle.com/a.oravahttp://j", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cle.com/a.oravahttp://j" + "'", str2.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                    ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE." + "'", str1.equals("HTTP://JAVA.ORACLE."));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specificationa", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificationa" + "'", str2.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10992_1560229477" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10992_1560229477"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80                                            ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80                                            " + "'", str2.equals("1.7.0_80                                            "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 143, (long) (short) 1, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Java Platform API Specification", "hi!M.7hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("b", "Java Virtual Machine Specificationa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users//Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                                                    10.14.3                                                                    ", "/moc.elcaro.avaj//:ptth", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("          ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java Virtual Machine Specificationa", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificationa" + "'", str2.equals("Java Virtual Machine Specificationa"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed modeUTF-8mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1495 + "'", int1 == 1495);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Java HotSpot(TM) 64-Bit Server VM", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "\n/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 22 + "'", int2 == 22);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("X86_64aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java Virtual Machine SpecificationJava Virtual Ma1.7", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Ma1.7" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Ma1.7"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment" + "'", str3.equals("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/  Sophie  sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!M.7hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!M.7hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aUTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "sun.lwawt.macosx.CPrinterJob", (int) '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "24.80-b11", 100, 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Oracle Corporation", 52);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Sophie", strArray4, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Sophie" + "'", str15.equals("Sophie"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/MOC.ELCARO.AVAJ//:PTTH");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/MOC.ELCARO.AVAJ//:PTTH\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                                                    ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "1.7.0_80                                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("java platform api specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specification" + "'", str1.equals("java platform api specification"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Mac OS X", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Documents/de", "/var/folders/av/av597zmnav31cq2n2a1nafc0000gn/T/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSoph1.7.0_80                                            ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10992_1560229477", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, (long) 6, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aUTF-8", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.7f, (double) 'a', (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/de");
        org.junit.Assert.assertNotNull(strArray1);
    }
}

