import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        java.lang.StringBuffer stringBuffer2 = strBuilder1.toStringBuffer();
        java.lang.StringBuffer stringBuffer3 = strBuilder1.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteAll(strMatcher14);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.append((java.lang.Object) (-1));
        boolean boolean30 = strBuilder25.equalsIgnoreCase(strBuilder27);
        char[] charArray33 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer36.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher37);
        int int41 = strBuilder27.indexOf(strMatcher37, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder19.deleteAll(strMatcher37);
        int int44 = strBuilder9.indexOf(strMatcher37, (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder1.deleteFirst(strMatcher37);
        java.io.Writer writer46 = strBuilder1.asWriter();
        org.junit.Assert.assertNotNull(stringBuffer2);
        org.junit.Assert.assertNotNull(stringBuffer3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(writer46);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.deleteAll(strMatcher4);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append(strBuilder6);
        boolean boolean9 = strBuilder7.contains("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.append((java.lang.Object) (-1));
        boolean boolean21 = strBuilder16.equalsIgnoreCase(strBuilder18);
        char[] charArray22 = strBuilder16.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder7.insert(0, charArray22);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder23.clear();
        java.lang.StringBuffer stringBuffer25 = strBuilder23.toStringBuffer();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(stringBuffer25);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append((java.lang.Object) (-1));
        boolean boolean10 = strBuilder5.equalsIgnoreCase(strBuilder7);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder5.append((int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher16 = strTokenizer15.getIgnoredMatcher();
        int int17 = strBuilder5.indexOf(strMatcher16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer20.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder5.replaceFirst(strMatcher21, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder5.append(".00aaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder5.insert(12, (-1));
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strMatcher16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setEmptyTokenAsNull(false);
        char[] charArray11 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer3.reset(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher13 = strTokenizer3.getTrimmerMatcher();
        java.lang.String[] strArray14 = strTokenizer3.getTokenArray();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strMatcher13);
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("h#!4", '#', '4');
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.apache.commons.lang.text.StrBuilder strBuilder2 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder2.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteAll(strMatcher5);
        int int8 = strBuilder6.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.append((float) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.ensureCapacity((int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strBuilder12.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer13.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("-10", strMatcher14);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strMatcher14);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        int int5 = strBuilder1.lastIndexOf(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setLength((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.appendPadding(12, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strBuilder7.asTokenizer();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strTokenizer11);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((double) (short) 1);
        boolean boolean7 = strBuilder3.contains('#');
        int int8 = strBuilder3.length();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder3.replaceAll('a', '1');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.append((float) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append('#');
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher19, strMatcher20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer21.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass24 = strTokenizer21.getClass();
        java.lang.Object obj25 = strTokenizer21.clone();
        java.lang.Class<?> wildcardClass26 = strTokenizer21.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setEmptyTokenAsNull(false);
        char[] charArray38 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer30.reset(charArray38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer21.reset(charArray38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray38);
        char[] charArray42 = strBuilder15.getChars(charArray38);
        char[] charArray43 = strBuilder13.getChars(charArray38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray43);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray42);
        org.junit.Assert.assertNotNull(charArray43);
        org.junit.Assert.assertNotNull(strTokenizer44);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setEmptyTokenAsNull(false);
        char[] charArray11 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer3.reset(charArray11);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher14, strMatcher15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass19 = strTokenizer16.getClass();
        java.lang.Object obj20 = strTokenizer16.clone();
        org.apache.commons.lang.text.StrMatcher strMatcher21 = strTokenizer16.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray11, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(strMatcher21);
        org.junit.Assert.assertNotNull(strTokenizer23);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder4.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.append("-11.0");
        boolean boolean10 = strBuilder8.contains('1');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        int int5 = strBuilder1.lastIndexOf(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceAll("hi!", "hi!");
        java.lang.String str9 = strBuilder1.getNullText();
        java.lang.String str10 = strBuilder1.getNullText();
        java.lang.String str12 = strBuilder1.rightString((int) 'a');
        java.io.Writer writer13 = strBuilder1.asWriter();
        char[] charArray14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder1.append(charArray14);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
        org.junit.Assert.assertNotNull(writer13);
        org.junit.Assert.assertNotNull(strBuilder15);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setCharAt((int) (byte) 1, '#');
        java.lang.String str8 = strBuilder7.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append('4');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append((double) (short) 1);
        boolean boolean20 = strBuilder16.contains('#');
        char[] charArray21 = strBuilder16.toCharArray();
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher22);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder11.insert((int) (short) 0, (java.lang.Object) strTokenizer23);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendWithSeparators(objArray26, "");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder25.deleteAll("-");
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher34);
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoredMatcher(strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher42 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher41, strMatcher42);
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass46 = strTokenizer43.getClass();
        java.lang.Object obj47 = strTokenizer43.clone();
        java.lang.Class<?> wildcardClass48 = strTokenizer43.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher50, strMatcher51);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer52.setEmptyTokenAsNull(false);
        char[] charArray60 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer52.reset(charArray60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer43.reset(charArray60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer39.reset(charArray60);
        try {
            strBuilder30.getChars((int) (byte) 1, 7, charArray60, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(charArray60);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertNotNull(strTokenizer64);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append((java.lang.Object) (-1));
        boolean boolean10 = strBuilder5.equalsIgnoreCase(strBuilder7);
        char[] charArray13 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer16.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher17);
        int int21 = strBuilder7.indexOf(strMatcher17, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strBuilder23.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.deleteAll('#');
        boolean boolean29 = strBuilder7.equalsIgnoreCase(strBuilder28);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strBuilder31.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder31.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.setCharAt((int) (byte) 1, '#');
        java.lang.String str38 = strBuilder37.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder37.append('4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder37.replaceFirst("", "100.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444445");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder7.append(strBuilder37);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.deleteAll(strMatcher49);
        int int52 = strBuilder50.lastIndexOf('a');
        org.apache.commons.lang.text.StrBuilder strBuilder54 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder54.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder54.appendFixedWidthPadLeft(5, 100, '4');
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher63 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher62, strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass67 = strTokenizer64.getClass();
        java.lang.Object obj68 = strTokenizer64.clone();
        java.lang.Class<?> wildcardClass69 = strTokenizer64.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher71 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher71, strMatcher72);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer73.setEmptyTokenAsNull(false);
        char[] charArray81 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer73.reset(charArray81);
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = strTokenizer64.reset(charArray81);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer(charArray81, '#');
        char[] charArray86 = strBuilder60.getChars(charArray81);
        org.apache.commons.lang.text.StrBuilder strBuilder87 = strBuilder50.append(charArray86);
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder37.append(charArray86);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(charArray81);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertNotNull(strTokenizer83);
        org.junit.Assert.assertNotNull(charArray86);
        org.junit.Assert.assertNotNull(strBuilder87);
        org.junit.Assert.assertNotNull(strBuilder88);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.deleteAll(strMatcher4);
        java.io.Reader reader6 = strBuilder5.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.setNewLineText("-1");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder10.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = strBuilder16.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.append("hi!");
        boolean boolean20 = strBuilder14.equals(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder5.appendFixedWidthPadLeft((java.lang.Object) strBuilder16, (int) 'a', '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strBuilder5.asTokenizer();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strTokenizer17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer24);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher2, strMatcher3);
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer4.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass7 = strTokenizer4.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher8 = strTokenizer4.getTrimmerMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = new org.apache.commons.lang.text.StrTokenizer(".00aaaaaaa", strMatcher8);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strMatcher8);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setCharAt((int) (byte) 1, '#');
        java.lang.String str8 = strBuilder7.getNullText();
        int int11 = strBuilder7.lastIndexOf("-", (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder7.setNullText("-1");
        int int15 = strBuilder13.indexOf('-');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder13.replaceFirst(".00aaaaaaa", "Tokenizer[not tokenized yet]h#!4");
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("4444445100");
        try {
            java.lang.Object obj2 = strTokenizer1.previous();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("-10", '#', '-');
        java.lang.String str4 = strTokenizer3.previousToken();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((double) (short) 1);
        boolean boolean7 = strBuilder3.contains('#');
        int int8 = strBuilder3.length();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder3.replaceAll('a', '1');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder3.append((float) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder3.appendFixedWidthPadRight(100, 12, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.deleteFirst('4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        java.util.List list26 = strTokenizer25.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.appendWithSeparators((java.util.Collection) list26, "-1");
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder3.insert((int) (short) 100, (java.lang.Object) strBuilder28);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 100");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((double) (short) 1);
        boolean boolean7 = strBuilder3.contains('#');
        char[] charArray8 = strBuilder3.toCharArray();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer(charArray8, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray8);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strTokenizer11);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder1.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder6.clear();
        int int10 = strBuilder6.indexOf("44#a ", 6);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder12.appendFixedWidthPadLeft(5, 100, '4');
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass25 = strTokenizer22.getClass();
        java.lang.Object obj26 = strTokenizer22.clone();
        java.lang.Class<?> wildcardClass27 = strTokenizer22.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher29, strMatcher30);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.setEmptyTokenAsNull(false);
        char[] charArray39 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer31.reset(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer22.reset(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray39, '#');
        char[] charArray44 = strBuilder18.getChars(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer(charArray44, '4', '4');
        char[] charArray48 = strBuilder6.getChars(charArray44);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(charArray44);
        org.junit.Assert.assertNotNull(charArray48);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setCharAt((int) (byte) 1, '#');
        int int10 = strBuilder7.indexOf('#', 10);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder7.replaceAll(".00aaaaaaa", "h#!4");
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.appendNewLine();
        java.lang.Object obj4 = null;
        boolean boolean5 = strBuilder3.equals(obj4);
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("1", '0');
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.deleteAll(strMatcher4);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append(strBuilder6);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder5.appendFixedWidthPadLeft(100, (int) (short) 1, '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer17.getIgnoredMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher18, strMatcher19);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder5.replaceAll(strMatcher19, "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.clear();
        int int26 = strBuilder23.indexOf("hi!", 0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder4.appendNull();
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strBuilder7.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append("hi!");
        boolean boolean11 = strBuilder5.equals(strBuilder7);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder13.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder16.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        java.lang.StringBuffer stringBuffer22 = strBuilder21.toStringBuffer();
        java.lang.StringBuffer stringBuffer23 = strBuilder21.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder17.append(stringBuffer23);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder5.append(stringBuffer23, 0, (int) (short) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.deleteAll('1');
        boolean boolean31 = strBuilder29.contains("hi!");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(stringBuffer22);
        org.junit.Assert.assertNotNull(stringBuffer23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass6 = strTokenizer3.getClass();
        java.lang.Object obj7 = strTokenizer3.clone();
        java.lang.Class<?> wildcardClass8 = strTokenizer3.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher10, strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setEmptyTokenAsNull(false);
        char[] charArray20 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer12.reset(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer3.reset(charArray20);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.reset("");
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer22.setDelimiterString("h#!4");
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer26);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteAll('#');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((java.lang.Object) (-1));
        int int12 = strBuilder8.lastIndexOf(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder8.replaceAll("hi!", "hi!");
        java.lang.String str16 = strBuilder8.getNullText();
        java.lang.String str17 = strBuilder8.getNullText();
        int int18 = strBuilder8.capacity();
        boolean boolean19 = strBuilder6.equals(strBuilder8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strBuilder8.asTokenizer();
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strTokenizer20);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((double) (short) 1);
        boolean boolean7 = strBuilder3.contains('#');
        char[] charArray8 = strBuilder3.toCharArray();
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher10, strMatcher11);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append((java.lang.Object) (-1));
        boolean boolean23 = strBuilder18.equalsIgnoreCase(strBuilder20);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder18.append((int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher29 = strTokenizer28.getIgnoredMatcher();
        int int30 = strBuilder18.indexOf(strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer12.setQuoteMatcher(strMatcher29);
        int int32 = strBuilder3.lastIndexOf(strMatcher29);
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder3.append((int) '1');
        char[] charArray37 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer40.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray37, strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher41);
        boolean boolean44 = strBuilder3.contains(strMatcher41);
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher47 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher46, strMatcher47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer48.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass51 = strTokenizer48.getClass();
        java.lang.Object obj52 = strTokenizer48.clone();
        java.lang.Class<?> wildcardClass53 = strTokenizer48.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher54 = strTokenizer48.getIgnoredMatcher();
        boolean boolean55 = strTokenizer48.isIgnoreEmptyTokens();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder57.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder57.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder63.append((java.lang.Object) (-1));
        boolean boolean66 = strBuilder61.equalsIgnoreCase(strBuilder63);
        char[] charArray67 = strBuilder61.toCharArray();
        char[] charArray69 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher73 = strTokenizer72.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer(charArray69, strMatcher73);
        char[] charArray76 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher80 = strTokenizer79.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer(charArray76, strMatcher80);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer(charArray67, strMatcher73, strMatcher80);
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = strTokenizer48.setIgnoredMatcher(strMatcher80);
        int int84 = strBuilder3.lastIndexOf(strMatcher80);
        int int87 = strBuilder3.lastIndexOf("-", (int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder90 = strBuilder3.replaceAll('4', '0');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strMatcher29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(strMatcher54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(charArray67);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(strMatcher73);
        org.junit.Assert.assertNotNull(charArray76);
        org.junit.Assert.assertNotNull(strMatcher80);
        org.junit.Assert.assertNotNull(strTokenizer83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(strBuilder90);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((double) (short) 1);
        boolean boolean7 = strBuilder3.contains('#');
        int int8 = strBuilder3.length();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder3.replaceAll('a', '1');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteAll(strMatcher16);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append(strBuilder18);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.append("");
        int int23 = strBuilder21.lastIndexOf("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder();
        int int27 = strBuilder24.indexOf('4', 0);
        boolean boolean28 = strBuilder21.equals(strBuilder24);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder21.append((long) 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        java.util.List list32 = strTokenizer31.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.appendWithSeparators((java.util.Collection) list32, "-");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder11.appendWithSeparators((java.util.Collection) list32, "-10");
        int int38 = strBuilder11.indexOf("-");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder11.appendNull();
        int int41 = strBuilder11.lastIndexOf('4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder11.append("4444445100");
        java.lang.StringBuffer stringBuffer44 = strBuilder43.toStringBuffer();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(stringBuffer44);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", '1');
        org.apache.commons.lang.text.StrMatcher strMatcher3 = strTokenizer2.getTrimmerMatcher();
        boolean boolean4 = strTokenizer2.hasPrevious();
        boolean boolean5 = strTokenizer2.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(strMatcher3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        char[] charArray1 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append((java.lang.Object) (-1));
        boolean boolean12 = strBuilder7.equalsIgnoreCase(strBuilder9);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder7.append((int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer17.getIgnoredMatcher();
        int int19 = strBuilder7.indexOf(strMatcher18);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((java.lang.Object) (-1));
        int int25 = strBuilder21.lastIndexOf(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder21.replaceAll("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder21.appendFixedWidthPadRight((int) '#', 10, '4');
        char[] charArray34 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer37.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher38);
        int int40 = strBuilder32.indexOf(strMatcher38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray1, strMatcher18, strMatcher38);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        java.util.List list43 = strTokenizer42.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer42.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = new org.apache.commons.lang.text.StrTokenizer("-1", strMatcher18, strMatcher44);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder47.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder47.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder53.append((java.lang.Object) (-1));
        boolean boolean56 = strBuilder51.equalsIgnoreCase(strBuilder53);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder51.append((int) (short) 10);
        boolean boolean60 = strBuilder58.contains(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder58.appendFixedWidthPadRight(2, 12, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder66 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder66.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder66.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder72 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder72.append((java.lang.Object) (-1));
        boolean boolean75 = strBuilder70.equalsIgnoreCase(strBuilder72);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder70.append((int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer80.getIgnoredMatcher();
        int int82 = strBuilder70.indexOf(strMatcher81);
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer85.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder70.replaceFirst(strMatcher86, "hi!");
        boolean boolean89 = strBuilder58.contains(strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strTokenizer45.setDelimiterMatcher(strMatcher86);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertNotNull(strMatcher81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(strTokenizer90);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.deleteAll(strMatcher4);
        org.apache.commons.lang.text.StrBuilder strBuilder6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append(strBuilder6);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.deleteAll(strMatcher14);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.append((java.lang.Object) (-1));
        boolean boolean30 = strBuilder25.equalsIgnoreCase(strBuilder27);
        char[] charArray33 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer36.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray33, strMatcher37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher37);
        int int41 = strBuilder27.indexOf(strMatcher37, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder19.deleteAll(strMatcher37);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.append((java.lang.Object) (-1));
        int int48 = strBuilder44.lastIndexOf(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder44.replaceAll("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder44.appendFixedWidthPadRight((int) '#', 10, '4');
        char[] charArray57 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher61 = strTokenizer60.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer(charArray57, strMatcher61);
        int int63 = strBuilder55.indexOf(strMatcher61);
        java.lang.Object obj64 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder55.append(obj64);
        boolean boolean66 = strBuilder42.equalsIgnoreCase(strBuilder55);
        java.lang.StringBuffer stringBuffer67 = strBuilder42.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder7.append((java.lang.Object) strBuilder42);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder68.replaceFirst('4', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder71.deleteFirst("-1");
        java.lang.String str75 = strBuilder71.rightString((int) 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertNotNull(strMatcher61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(stringBuffer67);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "-1" + "'", str75.equals("-1"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("-10");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setCharAt((int) (byte) 1, '#');
        java.lang.String str8 = strBuilder7.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append('4');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append((double) (short) 1);
        boolean boolean20 = strBuilder16.contains('#');
        char[] charArray21 = strBuilder16.toCharArray();
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher22);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = strTokenizer23.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder11.insert((int) (short) 0, (java.lang.Object) strTokenizer23);
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.appendWithSeparators(objArray26, "");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder25.deleteAll("-");
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder25.setCharAt((int) (byte) 10, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        java.lang.StringBuffer stringBuffer36 = strBuilder35.toStringBuffer();
        java.lang.StringBuffer stringBuffer37 = strBuilder35.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder39.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder39.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder45.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder47.deleteAll(strMatcher48);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.append(strBuilder50);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder49.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder55.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder55.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder61.append((java.lang.Object) (-1));
        boolean boolean64 = strBuilder59.equalsIgnoreCase(strBuilder61);
        char[] charArray67 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher71 = strTokenizer70.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer(charArray67, strMatcher71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher71);
        int int75 = strBuilder61.indexOf(strMatcher71, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder53.deleteAll(strMatcher71);
        int int78 = strBuilder43.indexOf(strMatcher71, (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder35.deleteFirst(strMatcher71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher83 = strTokenizer82.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder84 = strBuilder35.deleteFirst(strMatcher83);
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder84.append((double) 12);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder25.appendFixedWidthPadLeft((java.lang.Object) strBuilder86, 0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder25.deleteAll(' ');
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strMatcher24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(stringBuffer36);
        org.junit.Assert.assertNotNull(stringBuffer37);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(charArray67);
        org.junit.Assert.assertNotNull(strMatcher71);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strMatcher83);
        org.junit.Assert.assertNotNull(strBuilder84);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteAll(strMatcher6);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append(strBuilder8);
        boolean boolean11 = strBuilder9.contains("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append((java.lang.Object) (-1));
        boolean boolean23 = strBuilder18.equalsIgnoreCase(strBuilder20);
        char[] charArray24 = strBuilder18.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder9.insert(0, charArray24);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray24, '4', ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.deleteAll(strMatcher33);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder34.append(strBuilder35);
        boolean boolean38 = strBuilder36.contains("");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder41.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder47.append((java.lang.Object) (-1));
        boolean boolean50 = strBuilder45.equalsIgnoreCase(strBuilder47);
        char[] charArray51 = strBuilder45.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder36.insert(0, charArray51);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher54);
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.setIgnoredMatcher(strMatcher56);
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer55.getQuoteMatcher();
        int int59 = strBuilder52.lastIndexOf(strMatcher58);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder52.append((long) 5);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder52.insert(2, (float) (short) 10);
        java.lang.Object[] objArray65 = new java.lang.Object[] { strTokenizer28, 2 };
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder1.appendWithSeparators(objArray65, "");
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher69);
        org.apache.commons.lang.text.StrMatcher strMatcher71 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer70.setIgnoredMatcher(strMatcher71);
        org.apache.commons.lang.text.StrMatcher strMatcher73 = strTokenizer70.getQuoteMatcher();
        int int75 = strBuilder1.lastIndexOf(strMatcher73, (int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder77 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder79 = strBuilder77.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder79.append((double) (short) 1);
        boolean boolean83 = strBuilder79.contains('#');
        char[] charArray84 = strBuilder79.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder1.append((java.lang.Object) strBuilder79);
        java.util.Iterator iterator86 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder79.appendWithSeparators(iterator86, "");
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(charArray51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strMatcher73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strBuilder79);
        org.junit.Assert.assertNotNull(strBuilder81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(charArray84);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strBuilder88);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append((java.lang.Object) (-1));
        boolean boolean10 = strBuilder5.equalsIgnoreCase(strBuilder7);
        char[] charArray13 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher17 = strTokenizer16.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray13, strMatcher17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher17);
        int int21 = strBuilder7.indexOf(strMatcher17, 1);
        java.lang.String str23 = strBuilder7.leftString((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder7.appendFixedWidthPadRight(2, (int) (byte) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder7.append(0L);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strMatcher17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-1" + "'", str23.equals("-1"));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteAll('#');
        int int9 = strBuilder4.lastIndexOf(' ', (int) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder4.replaceAll("hi!", "-");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.deleteAll(strMatcher17);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.append(strBuilder19);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append((java.lang.Object) (-1));
        boolean boolean33 = strBuilder28.equalsIgnoreCase(strBuilder30);
        char[] charArray36 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer39.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = new org.apache.commons.lang.text.StrTokenizer(charArray36, strMatcher40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher40);
        int int44 = strBuilder30.indexOf(strMatcher40, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder22.deleteAll(strMatcher40);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder45.appendFixedWidthPadLeft(7, 6, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.append((double) 100L);
        org.apache.commons.lang.text.StrMatcher strMatcher53 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher53, strMatcher54);
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass58 = strTokenizer55.getClass();
        java.lang.Object obj59 = strTokenizer55.clone();
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer55.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder51.deleteAll(strMatcher60);
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder4.append(strBuilder51);
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder62);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadLeft(5, 100, '4');
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher9, strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer11.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass14 = strTokenizer11.getClass();
        java.lang.Object obj15 = strTokenizer11.clone();
        java.lang.Class<?> wildcardClass16 = strTokenizer11.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher18, strMatcher19);
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setEmptyTokenAsNull(false);
        char[] charArray28 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer20.reset(charArray28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer11.reset(charArray28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray28, '#');
        char[] charArray33 = strBuilder7.getChars(charArray28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray33, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoredChar('0');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer37);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append("");
        java.lang.String str6 = strBuilder3.midString((int) '1', 1);
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder3.append(4);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher3 = strTokenizer2.getIgnoredMatcher();
        java.util.List list4 = strTokenizer2.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer2.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher8, strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass13 = strTokenizer10.getClass();
        java.lang.Object obj14 = strTokenizer10.clone();
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer10.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.append((double) (short) 1);
        char char23 = strBuilder19.charAt(1);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.append((double) (short) 1);
        boolean boolean31 = strBuilder27.contains('#');
        char[] charArray32 = strBuilder27.toCharArray();
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher34, strMatcher35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder38.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.append((java.lang.Object) (-1));
        boolean boolean47 = strBuilder42.equalsIgnoreCase(strBuilder44);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder42.append((int) (short) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer52.getIgnoredMatcher();
        int int54 = strBuilder42.indexOf(strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer36.setQuoteMatcher(strMatcher53);
        int int56 = strBuilder27.lastIndexOf(strMatcher53);
        int int58 = strBuilder19.indexOf(strMatcher53, (int) '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer10.setDelimiterMatcher(strMatcher53);
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer59.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer2.setDelimiterMatcher(strMatcher60);
        boolean boolean62 = strTokenizer61.hasNext();
        boolean boolean63 = strTokenizer61.hasNext();
        org.junit.Assert.assertNotNull(strMatcher3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + char23 + "' != '" + '1' + "'", char23 == '1');
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setCharAt((int) (byte) 1, '#');
        java.lang.String str8 = strBuilder7.getNullText();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.append('4');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher16 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteAll(strMatcher16);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append(strBuilder18);
        boolean boolean21 = strBuilder19.contains("");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder24.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append((java.lang.Object) (-1));
        boolean boolean33 = strBuilder28.equalsIgnoreCase(strBuilder30);
        char[] charArray34 = strBuilder28.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder19.insert(0, charArray34);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder10.insert((int) (byte) 1, charArray34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher40 = strTokenizer39.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        java.util.List list42 = strTokenizer41.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer41.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray34, strMatcher40, strMatcher43);
        org.apache.commons.lang.text.StrMatcher strMatcher45 = strTokenizer44.getDelimiterMatcher();
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(charArray34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strMatcher40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strMatcher45);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strBuilder1.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder1.append("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.setCharAt((int) (byte) 1, '#');
        java.lang.String str8 = strBuilder7.getNullText();
        int int11 = strBuilder7.lastIndexOf("-", (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder7.deleteFirst("#");
        boolean boolean15 = strBuilder13.startsWith("1");
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1);
        org.apache.commons.lang.text.StrMatcher strMatcher3 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setIgnoredMatcher(strMatcher3);
        org.apache.commons.lang.text.StrMatcher strMatcher5 = strTokenizer2.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer2.setQuoteChar('#');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.deleteAll(strMatcher12);
        java.io.Reader reader14 = strBuilder13.asReader();
        java.lang.String str15 = strBuilder13.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        java.lang.StringBuffer stringBuffer18 = strBuilder17.toStringBuffer();
        java.lang.StringBuffer stringBuffer19 = strBuilder17.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.deleteAll(strMatcher30);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.append(strBuilder32);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder37.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.append((java.lang.Object) (-1));
        boolean boolean46 = strBuilder41.equalsIgnoreCase(strBuilder43);
        char[] charArray49 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher53 = strTokenizer52.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray49, strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher53);
        int int57 = strBuilder43.indexOf(strMatcher53, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder35.deleteAll(strMatcher53);
        int int60 = strBuilder25.indexOf(strMatcher53, (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder17.deleteFirst(strMatcher53);
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder17.appendPadding((int) '#', '#');
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) '#', (int) (short) 0, '-');
        org.apache.commons.lang.text.StrBuilder strBuilder69 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder69.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder73 = strBuilder71.append((double) (short) 1);
        org.apache.commons.lang.text.StrMatcher strMatcher75 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher75, strMatcher76);
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = strTokenizer77.setEmptyTokenAsNull(false);
        java.lang.Class<?> wildcardClass80 = strTokenizer77.getClass();
        java.lang.Object obj81 = strTokenizer77.clone();
        java.lang.Class<?> wildcardClass82 = strTokenizer77.getClass();
        org.apache.commons.lang.text.StrMatcher strMatcher84 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher85 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher84, strMatcher85);
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = strTokenizer86.setEmptyTokenAsNull(false);
        char[] charArray94 = new char[] { '4', '4', '#', 'a', ' ' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer95 = strTokenizer86.reset(charArray94);
        org.apache.commons.lang.text.StrTokenizer strTokenizer96 = strTokenizer77.reset(charArray94);
        org.apache.commons.lang.text.StrBuilder strBuilder97 = strBuilder71.append(charArray94);
        org.apache.commons.lang.text.StrBuilder strBuilder98 = strBuilder67.append(charArray94);
        org.apache.commons.lang.text.StrTokenizer strTokenizer99 = strTokenizer2.reset(charArray94);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strMatcher5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(reader14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(stringBuffer18);
        org.junit.Assert.assertNotNull(stringBuffer19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strMatcher53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder73);
        org.junit.Assert.assertNotNull(strTokenizer79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(obj81);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(strTokenizer88);
        org.junit.Assert.assertNotNull(charArray94);
        org.junit.Assert.assertNotNull(strTokenizer95);
        org.junit.Assert.assertNotNull(strTokenizer96);
        org.junit.Assert.assertNotNull(strBuilder97);
        org.junit.Assert.assertNotNull(strBuilder98);
        org.junit.Assert.assertNotNull(strTokenizer99);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append((double) (short) 1);
        boolean boolean7 = strBuilder3.contains('#');
        char[] charArray8 = strBuilder3.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder3.replaceAll(' ', '#');
        java.lang.String str13 = strBuilder3.rightString((int) '1');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-11.0" + "'", str13.equals("-11.0"));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((java.lang.Object) (-1));
        int int5 = strBuilder1.lastIndexOf(' ');
        java.lang.Class<?> wildcardClass6 = strBuilder1.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteAll(strMatcher11);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.append(strBuilder13);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.setNewLineText("");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.append((java.lang.Object) (-1));
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder18.setNullText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.append((java.lang.Object) (-1));
        boolean boolean27 = strBuilder22.equalsIgnoreCase(strBuilder24);
        char[] charArray30 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher34 = strTokenizer33.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer(charArray30, strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher34);
        int int38 = strBuilder24.indexOf(strMatcher34, 1);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder16.deleteAll(strMatcher34);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.append((java.lang.Object) (-1));
        int int45 = strBuilder41.lastIndexOf(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder41.replaceAll("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder41.appendFixedWidthPadRight((int) '#', 10, '4');
        char[] charArray54 = new char[] { '#' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("hi!", '4');
        org.apache.commons.lang.text.StrMatcher strMatcher58 = strTokenizer57.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer(charArray54, strMatcher58);
        int int60 = strBuilder52.indexOf(strMatcher58);
        java.lang.Object obj61 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder52.append(obj61);
        boolean boolean63 = strBuilder39.equalsIgnoreCase(strBuilder52);
        java.lang.StringBuffer stringBuffer64 = strBuilder39.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder1.append(stringBuffer64);
        int int66 = strBuilder65.size();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertNotNull(strMatcher34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strMatcher58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(stringBuffer64);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 4 + "'", int66 == 4);
    }
}

