import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "EIHPOS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 0L, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Platform API Specification", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (short) -1, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/t", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ne", (java.lang.CharSequence) "//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, (double) 79, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ", (int) (byte) 0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ" + "'", str3.equals("noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("444", "un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("EN", "Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "EN" + "'", str3.equals("EN"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", "UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!" + "'", str3.equals("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("SUN.LWAWT.MACOSX.CPRINTERJOB", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str2.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "24.80-b11");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence[]) strArray7);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Platform API Specification                                                                                                    SE Runtime Environment", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_64" + "'", str2.equals("_64"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "class [Ljava.lang.String;", (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "class [Ljava.lang.String;" + "'", charSequence2.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Ur/", (java.lang.CharSequence) "eihpos");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444", (java.lang.CharSequence) ".Java(TM) SE Runtime Environment", 79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "snna:atasaeosxaLWeToo:bit", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(79L, (long) (byte) -1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 79L + "'", long3 == 79L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("noitaroproC elcarO", "1.4", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.3", "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "Java Platform API Specification                                                                                                    SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.2", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "ne");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "///////////////////////////////////" + "'", str2.equals("///////////////////////////////////"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "EIHPOS", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "//users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/javasophie///lib/endorsed" + "'", str1.equals("//users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/javasophie///lib/endorsed"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence) "UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     " + "'", str2.equals("                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("class [Ljava.lang.String;", "NENENENENEN/Users/sophieNENENENENEN", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;" + "'", str4.equals("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("ne", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("24.80-b11", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("//");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "//" + "'", str1.equals("//"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("UTF-8", "ava Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarO" + "'", str1.equals("noitaroproC elcarO"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ", "4444444444444444444444444444444444444444444444444", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.CharSequence) "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", "/Users/sophie/Documents/defects4j/t");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Documents/defects4j/t", (java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("http://java.oracle.com/", "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserDir();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Documents/defects4j/t", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tDocuments/defects4j/tDocuments/defects4j/t" + "'", str2.equals("Documents/defects4j/tDocuments/defects4j/tDocuments/defects4j/t"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "                                                                        SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) 31.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mAC os x", "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 31);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                        SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 0L, (float) 49);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "x so cam", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/U...", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "///////////////////////////////////", (java.lang.CharSequence) "\n", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie", "4444444444", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie" + "'", str3.equals("/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("#######...", "///////////////////////////////////", "Java Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######..." + "'", str3.equals("#######..."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 67L, (float) (short) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava Virtual Machine SpecificationJ", "sun.awt.CGraphicsEnvironment1.2");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", (java.lang.CharSequence) "UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVASOPHIE//", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVASOPHIE//" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVASOPHIE//"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("MAC os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC os " + "'", str1.equals("MAC os "));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                    ", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Ur/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/...", "sun.awt.CGraphicsEnvironment", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/..." + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/..."));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "_64", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8" + "'", str1.equals("utf-8"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "NENENENENEN/Users/sophieNENENENENEN", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1.2", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("eihpos", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos" + "'", str2.equals("eihpos"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "racle.com/", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "noitaroproC elcarO", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "24.80-B11", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed mode", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Ur/", "10.14.3", "x86_64", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Ur/" + "'", str4.equals("/Ur/"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "jAVA pLATFORM api sPECIFICATION", "4444444444444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("un.lwawt.macosx.LWCToolkit", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkit" + "'", str2.equals("un.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.2", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "\n", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("x86_64", "                                                                                                     SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.2");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine SpecificationJ", (int) '4', "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine SpecificationJJava Virtual Mach" + "'", str3.equals("Java Virtual Machine SpecificationJJava Virtual Mach"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ".");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.CGraphicsEnvironment1.2");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, ":");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("jAVA pLATFORM api sPECIFICATION", strArray3, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 11");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 67 + "'", int7 == 67);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "Mac OS X", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java(TM) SE Runtime Environment", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.0f, 52.0d, (double) 24);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24.80-B11", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-B11" + "'", str3.equals("24.80-B11"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ne");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Documents/defects4j/t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1.2", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        char[] charArray5 = new char[] { '4', ' ', ' ' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "//", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("//");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("NENENENENEN/Users/sophieNENENENENEN", "1.7.0                                                                                                     SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NENENENENEN/Users/sophieNENENENENEN" + "'", str2.equals("NENENENENEN/Users/sophieNENENENENEN"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//", (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-B11", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(67L, (long) 12, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!http://java.oracle.com/hi!http://java.oracle.com/hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sophie" + "'", charSequence2.equals("sophie"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/t");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mac os x", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os x" + "'", str2.equals("mac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os x"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("un.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.LWCToolkit" + "'", str2.equals("un.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONJ" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATIONJ"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.LWCToolkit", 79);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit                                                    " + "'", str2.equals("sun.lwawt.macosx.LWCToolkit                                                    "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.CPRINTERJOB", "1.7.0_80", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x so cam", 79, "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam" + "'", str3.equals("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "./Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/s", (int) 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mac os x", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mac os x", "http://java.oracle.com/");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "hi!", 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION" + "'", str1.equals("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "eihpos", (java.lang.CharSequence) "//");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("snna:atasaeosxaLWeToo:bit", "ava Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "snna:atasaeosxaLWeToo:bit" + "'", str2.equals("snna:atasaeosxaLWeToo:bit"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str1.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/USERS/SOPHIE", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("snna:atasaeosxaLWeToo:bit", "_64", "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "snna:atasaeosxaLWeToo:bit" + "'", str3.equals("snna:atasaeosxaLWeToo:bit"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                                                                                                     SE Runtime Environment", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java Virtual Machine Specification", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(".Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".Java(TM) SE Runtime Environment" + "'", str1.equals(".Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LWAWT.MACOSX.CPRINTERJOB", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUNWAWTAOSXPRINTEROB" + "'", str3.equals("SUNWAWTAOSXPRINTEROB"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATIONJ", (java.lang.CharSequence) "MAC os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("MAC os ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC os " + "'", str2.equals("MAC os "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.LWCToolkit                                                    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java Virtual Machine SpecificationJava Virtual Ma1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str2.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JAVA VIRTUAL MACHINE SPECIFICATIONJ", "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONJ" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATIONJ"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "11b-08.42" + "'", str1.equals("11b-08.42"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "L" + "'", str2.equals("L"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, (float) (-1L), 49.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java(TM) SE Runtime Environment", (int) (byte) -1, 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "t" + "'", str3.equals("t"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (short) -1, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "_64", (java.lang.CharSequence) "Java Virtual Machine SpecificationJ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("snna:atasaeosxaLWeToo:bit", "x so cam");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "snna:atasaeosxaLWeToo:bit" + "'", str2.equals("snna:atasaeosxaLWeToo:bit"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) -1, (byte) 0, (byte) -1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih//aeihposaavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/e8-FTU!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih//aeihposaavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/e8-FTU!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih" + "'", str1.equals("!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih//aeihposaavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/e8-FTU!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih//aeihposaavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/e8-FTU!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB", (java.lang.CharSequence) "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                    ", charSequence1, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, 0L, 8L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sophie", "//" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/" + "'", str8.equals("/"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Sun.lwawt.macosx.LWCToolkit", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "iun/lwawt/macosx/oWvtoolkit" + "'", str3.equals("iun/lwawt/macosx/oWvtoolkit"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Sun.lwawt.macosx.LWCToolkit", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("##########");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "##########" + "'", str5.equals("##########"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so ca" + "'", str2.equals("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so ca"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "./Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/s", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATIONJ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java HotSpot(TM) 64-Bit Server VM", "", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.2", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!" + "'", str1.equals("Hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 10, (float) 8, 49.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.awt.CGraphicsEnvironment1.2", ".Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment1.2" + "'", str2.equals("sun.awt.CGraphicsEnvironment1.2"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "NE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Platform API Specification                                                                                                    SE Runtime Environment", "Java Platform API Specification                                                                                                    SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Ma1.2", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os x", (int) (short) 1, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac os xmac os xmac os ..." + "'", str3.equals("mac os xmac os xmac os ..."));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOPHIE", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(".");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "." + "'", str1.equals("."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JAVA VIRTUAL MACHINE SPECIFICATIONJ", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONJ" + "'", str3.equals("JAVA VIRTUAL MACHINE SPECIFICATIONJ"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "//", (java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//" + "'", str2.equals("UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0                                                                                                     SE Runtime Environment", charSequence1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Documents/defects4j/t", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(1L, 0L, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, 10.0f, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("ava Virtual Machine SpecificationJ", "Documents/defects4j/t", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJ" + "'", str3.equals("ava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJ"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mixed mod", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mod" + "'", str2.equals("mixed mod"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.awt.CGraphicsEnvironment1.2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed" + "'", str2.equals("//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B1" + "'", str1.equals("24.80-B1"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "24.80-B11");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "noitaroproC elcarO", (java.lang.CharSequence) "eihpos");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("utf-8", "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8" + "'", str2.equals("utf-8"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("//", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////////////////////////////////////////////////" + "'", str2.equals("//////////////////////////////////////////////////////"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "t", (java.lang.CharSequence) "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("///////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "///////////////////////////////////" + "'", str1.equals("///////////////////////////////////"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolkit", "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so ca");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/", "                                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("mac os xmac os xmac os ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "USmixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mo", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sun.lwawt.macosx.LWCToolkit", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaSun.lwawt.macosx.LWCToolkit" + "'", str3.equals("aaaaaSun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "USmixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mo", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit                                                    ", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 76 + "'", int2 == 76);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "//users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/javasophie///lib/endorsed", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                                    ", "mac os xmac os xmac os ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80-b15", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b" + "'", str2.equals("1.7.0_80-b"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle Corporation", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("x86_64");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444" + "'", str1.equals("4444444444"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "MAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ":", (java.lang.CharSequence) "snna:atasaeosxaLWeToo:bit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "MAC os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC os x", "MV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJMV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, (int) '#', 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/U...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/U..." + "'", str1.equals("/U..."));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;", "24.80-B1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;" + "'", str2.equals("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ne", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "NENENENENEN/Users/sophieNENENENENEN", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "11b-08.42", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "Java Platform API Specification                                                                                                    SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean7 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("racle.com/", "EN", "/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "racle.com/" + "'", str4.equals("racle.com/"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUNWAWTAOSXPRINTEROB", 31, "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaSUNWAWTAOSXPRINTEROBnoitar" + "'", str3.equals("noitaSUNWAWTAOSXPRINTEROBnoitar"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ", "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Virtual Machine Specification", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specif" + "'", str2.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("444", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine SpecificationJ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("_64", "mixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_64" + "'", str2.equals("_64"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) -1, "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) (short) 1, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("_64", "eihpos", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "_64" + "'", str3.equals("_64"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 100, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("444", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444" + "'", str2.equals("444"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sophie", "//" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/" + "'", str8.equals("/"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//" + "'", str9.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "t", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "t" + "'", charSequence2.equals("t"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "//", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long[] longArray6 = new long[] { (byte) 1, (byte) -1, 67L, 52L, (short) 0, 'a' };
        long[] longArray13 = new long[] { (byte) 1, (byte) -1, 67L, 52L, (short) 0, 'a' };
        long[] longArray20 = new long[] { (byte) 1, (byte) -1, 67L, 52L, (short) 0, 'a' };
        long[] longArray27 = new long[] { (byte) 1, (byte) -1, 67L, 52L, (short) 0, 'a' };
        long[] longArray34 = new long[] { (byte) 1, (byte) -1, 67L, 52L, (short) 0, 'a' };
        long[] longArray41 = new long[] { (byte) 1, (byte) -1, 67L, 52L, (short) 0, 'a' };
        long[][] longArray42 = new long[][] { longArray6, longArray13, longArray20, longArray27, longArray34, longArray41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(longArray42);
        java.lang.String str45 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) longArray42, "1.7.0_80-b15");
        java.lang.String str49 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) longArray42, ' ', 76, 27);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertNotNull(longArray42);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("4444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "51.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(".", "class [Ljava.lang.String;", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "." + "'", str5.equals("."));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("JavaPlatformAPISpecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("USmixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mo", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USmixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mo" + "'", str2.equals("USmixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mo"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "t", (java.lang.CharSequence) "mp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/...", (java.lang.CharSequence) "/U...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/..." + "'", charSequence2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/..."));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed" + "'", str2.equals("ophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt.cgraphicsenvironment", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih//aeihposaavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/e8-FTU!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih//aeihposaavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/e8-FTU!ih/moc.elcaro.avaj//:ptth!ih/moc.elcaro.avaj//:ptth!ih", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, 0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Documents/defects4j/t", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j/t4/Users/sophie/Documents/defects" + "'", str2.equals("j/t4/Users/sophie/Documents/defects"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "//////////////////////////////////////////////////////", (java.lang.CharSequence) "NENENENENEN/Users/sophieNENENENENEN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                        SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                        SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("                                                                        SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "x86_64", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#U#sers#/#sophie#/#L#ibrary#/#J#ava#/#E#xtensions#:/#L#ibrary#/#J#ava#/#E#xtensions#:/#N#etwork#/#L#ibrary#/#J#ava#/#E#xtensions#:/#S#ystem#/#L#ibrary#/#J#ava#/#E#xtensions#:/#usr#/#lib#/#java#:." + "'", str3.equals("/#U#sers#/#sophie#/#L#ibrary#/#J#ava#/#E#xtensions#:/#L#ibrary#/#J#ava#/#E#xtensions#:/#N#etwork#/#L#ibrary#/#J#ava#/#E#xtensions#:/#S#ystem#/#L#ibrary#/#J#ava#/#E#xtensions#:/#usr#/#lib#/#java#:."));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//", "EN", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("//", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//  " + "'", str2.equals("//  "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str1.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("L", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "L" + "'", str2.equals("L"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;" + "'", str1.equals("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "hi!", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.awt.CGraphicsEnvironment1.2", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment1.2" + "'", str3.equals("sun.awt.CGraphicsEnvironment1.2"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/#U#sers#/#sophie#/#L#ibrary#/#J#ava#/#E#xtensions#:/#L#ibrary#/#J#ava#/#E#xtensions#:/#N#etwork#/#L#ibrary#/#J#ava#/#E#xtensions#:/#S#ystem#/#L#ibrary#/#J#ava#/#E#xtensions#:/#usr#/#lib#/#java#:.", "Java Virtual Machine SpecificationJJava Virtual Mach", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/#U#sers#/#sophie#/#L#ibrary#/#J#ava#/#E#xtensions#:/#L#ibrary#/#J#ava#/#E#xtensions#:/#N#etwork#/#L#ibrary#/#J#ava#/#E#xtensions#:/#S#ystem#/#L#ibrary#/#J#ava#/#E#xtensions#:/#usr#/#lib#/#java#:." + "'", str3.equals("/#U#sers#/#sophie#/#L#ibrary#/#J#ava#/#E#xtensions#:/#L#ibrary#/#J#ava#/#E#xtensions#:/#N#etwork#/#L#ibrary#/#J#ava#/#E#xtensions#:/#S#ystem#/#L#ibrary#/#J#ava#/#E#xtensions#:/#usr#/#lib#/#java#:."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0", "Hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", (int) (byte) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "//");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "51.0" + "'", str5.equals("51.0"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/U...", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U..." + "'", str2.equals("U..."));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.2", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MAC os ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("USmixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mo", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", 8);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("SUNWAWTAOSXPRINTEROB", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUNWAWTAOSXPRINTEROB" + "'", str2.equals("SUNWAWTAOSXPRINTEROB"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;", (int) (short) 1, "        /Users/sophie SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;" + "'", str3.equals("NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so ca");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                     SE Runtime Environment", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Ur/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            Mac OS X" + "'", str2.equals("                                                                                            Mac OS X"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513", "mac os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Virtual Machine Specif", "sun.lwawt.macosx.LWCToolkit                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specif" + "'", str2.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUNWAWTAOSXPRINTEROB", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                        SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                            Mac OS X", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 76, (float) 'a', 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52, 0.0d, (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specification", (int) 'a', "                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                    ophiesophiesophiesophiesophiesophiesophiesoJava Virtual Machine Specification" + "'", str3.equals("                    ophiesophiesophiesophiesophiesophiesophiesoJava Virtual Machine Specification"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "_64", (java.lang.CharSequence) "Java Virtual Machine SpecificationJJava Virtual Mach");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("//  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                    ophiesophiesophiesophiesophiesophiesophiesoJava Virtual Machine Specification", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    ophiesophiesophiesophiesophiesophiesophiesoJava Virtual Machine Specification" + "'", str2.equals("                    ophiesophiesophiesophiesophiesophiesophiesoJava Virtual Machine Specification"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 31, "4444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so ca");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.0f, (double) 4, (double) 49.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("EIHPOS", "ava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJDocuments/defects4j/tava Virtual Machine SpecificationJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EIHPOS" + "'", str2.equals("EIHPOS"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("NENENENENEN/Users/sophieNENENENENEN", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513" + "'", str2.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96236_1560211513"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 79L, (float) 3, (float) 79L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 79.0f + "'", float3 == 79.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Documents/defects4j/tDocuments/defects4j/tDocuments/defects4j/t");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        char[] charArray5 = new char[] { '4', 'a', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mac os x", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie" + "'", str1.equals("/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("24.80-B11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVASOPHIE//", "24.80-b11########################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVASOPHIE//" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVASOPHIE//"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("MAC os ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC os " + "'", str1.equals("MAC os "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444444444444444444444", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "##########", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("EN", "noitacificepS enihcaM lautriV avaJ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "ophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mac os xmac os xmac os ...", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { 'a', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "SUN.LWAWT.MACOSX.CPRINTERJOB", "Documents/defects4j/t");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "ophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.7.0                                                                                                     SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("snna:atasaeosxaLWeToo:bit", "10.14.3", 9);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification                                                                                                    SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "NENENENENEN/Users/sophieNENENENENEN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Documents/defects4j/tDocuments/defects4j/tDocuments/defects4j/t", "mAC os x", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/Tfolders/_v/6v597zmn4_v31cq2nx so cam\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVMJavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4444444444", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513", 0, 4);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment1.2", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.2", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Ur/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ava Virtual Machine SpecificationJ", (int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "L", (java.lang.CharSequence) "Java Platform API Specification                                                                                                    SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "snna:atasaeosxaLWeToo:bit", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Ur/", (java.lang.CharSequence) "mac os xmac os xmac os ...", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        char[] charArray5 = new char[] { '4', ' ', ' ' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "./Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/s", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Sun.lwawt.macosx.LWCToolkit", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "it" + "'", str2.equals("it"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "L", (java.lang.CharSequence) "//////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corporation", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATIONJ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.2" + "'", charSequence2.equals("1.2"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie///lib/endorsed", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("un.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"un.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkitun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.14.3", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.1.3" + "'", str2.equals("10.1.3"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie", "noitaSUNWAWTAOSXPRINTEROBnoitar", "mac os xmac os xmac os ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce" + "'", str3.equals("/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce4444444444/ ses/saphce"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "mixed mod", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATIONjAVA pLATFORM api sPECIFICATION", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "NE", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "NENENENENEN/Users/sophieNENENENENENclass [Ljava.lang.String;", (java.lang.CharSequence) "                                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("snna:atasaeosxaLWeToo:bit", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str2.equals("ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 76, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 76");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        long[] longArray4 = new long[] { 100, 0L, 0, (byte) -1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96236_1560211513", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasophie//");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                    ophiesophiesophiesophiesophiesophiesophiesoJava Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("##########");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.2", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("##########", strArray4, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(strArray4);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "24.80-B11", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "##########" + "'", str5.equals("##########"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "##########" + "'", str10.equals("##########"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "##########" + "'", str11.equals("##########"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################################Oracle Corporation#########################################" + "'", str3.equals("#########################################Oracle Corporation#########################################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATIONJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("SUN.AWT.CGRAPHICSENVIRONMENT", (int) (short) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0, (double) 5, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("MAC os x", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x" + "'", str3.equals("MAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreMAC os x"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie", (int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophi" + "'", str3.equals("Users/sophi"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("x86_64", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!UTF-8e/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaasophiea//hi!http://java.oracle.com/hi!http://java.oracle.com/hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie4444444444/Users/sophie", 79.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 79.0f + "'", float2 == 79.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("//////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "//////////////////////////////////////////////////////" + "'", str1.equals("//////////////////////////////////////////////////////"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaSun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_8", (java.lang.CharSequence) "./Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/s", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;Cclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;sclass [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mac os x", "noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ444noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", (java.lang.CharSequence) "                    ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3, (float) 31L, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "        /Users/sophie SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 44 + "'", int1 == 44);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

