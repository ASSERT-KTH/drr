import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(" noitacificeps ipa mroftalp avaJ", "1.7.0_801.7.0_801.7.0_801...", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("!1.7.0_80-b15ih                 ", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame", "j ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("en", (int) (byte) 100, "tnemnorivnescihpargc.twa.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc." + "'", str3.equals("tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc."));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwhwt.mhcosx.LWCToolkit", "aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java platform api specification ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("444444444444/         4444444444444", "/Us...", "/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_962_1560211758/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARAVAPLATFORMAPISPECIFICATIONEN    AAAAAAAAAAAAAAAAAA", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444444444444/         4444444444444" + "'", str4.equals("444444444444/         4444444444444"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/         ", "", "4444444444444444444444444444444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/users/sophie", "Mac OS X                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("#", "EN    AAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Doc/Users/sophie/Docu", "                                      sunlwhwtmhcosxLWCToolkit                                      ", 1, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/                                      sunlwhwtmhcosxLWCToolkit                                      sers/sophie/Doc/Users/sophie/Docu" + "'", str4.equals("/                                      sunlwhwtmhcosxLWCToolkit                                      sers/sophie/Doc/Users/sophie/Docu"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, 1.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaa24.80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/usjava virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("TF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Up Up", "Mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed mode" + "'", str2.equals("Mixed mode"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("###########################################    ne    ############################################", (int) (short) 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##..." + "'", str2.equals("##..."));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/", "44444444444444444444444444444444444", "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("pU pUroftalP avaJnoitacificepS IPA mroftalP avaJ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pU pUroftalP avaJnoitacificepS IPA mroftalP avaJ" + "'", str2.equals("pU pUroftalP avaJnoitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/" + "'", str2.equals("gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/gn/T/"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("kit1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "mixeda amode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(216, 44, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("!1.7.0_80-b15ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444" + "'", str2.equals("                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, 52.0f, 6.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758" + "'", str2.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle Corporation                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        float[] floatArray1 = new float[] { 0.0f };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "hi", (java.lang.CharSequence) "Up UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp Up");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwhwt.mhcosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "ORAnnn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "noitacificepSIPAmroftalPavaraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8571120651_42469_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "java virtual machine specif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("!1.7.0_80-b15ih                 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!1.7.0_80-b15ih                 " + "'", str2.equals("!1.7.0_80-b15ih                 "));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "sophie                          44444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24", 22, "j ja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j jaj jaj 24j jaj jaj " + "'", str3.equals("j jaj jaj 24j jaj jaj "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HOTSPOT(TMEHOTSPOT(TM)", 217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 217 + "'", int2 == 217);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("java virtual machine specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "emnorivnEsci...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("javavhotspot(tm)var-bitvservervvm", (int) 'a', 84);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "javavhotspot(tm)var-bitvservervvm" + "'", str3.equals("javavhotspot(tm)var-bitvservervvm"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("kit1", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        char[] charArray11 = new char[] { '4', '#', '#', ' ', '#', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 ", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "avaJ mroftalP IPA noitacificepS", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/", (int) (byte) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 55, (double) 1L, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 55.0d + "'", double3 == 55.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Doc/Users/sophie/Docu", "tform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Doc/Users/sophie/Docu" + "'", str2.equals("/Users/sophie/Doc/Users/sophie/Docu"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.8", "/Us...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "E", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        long[] longArray3 = new long[] { (byte) 100, (short) 1, 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "HOTSPOT(TM) 6a-B");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15i");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758Ui7ip/8p-bU5/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.8     ", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8     " + "'", str2.equals("1.8     "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment... platform api sp", (java.lang.CharSequence) "!1.7.0_80-b15ih");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java(TM)SERuntimeEnvironment... platform api sp" + "'", charSequence2.equals("Java(TM)SERuntimeEnvironment... platform api sp"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "_96424_1560211758/trgt/clsss:/usrs/sophi/documts/dfcorclcorportio", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".7", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".7", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str6.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str7.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "######################", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        char[] charArray11 = new char[] { '4', '#', '#', ' ', '#', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "5", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mvvrevresvtib-rav)mt(topstohvavaj", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Gn/T/" + "'", str1.equals("Gn/T/"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "eihpos/sresU/", (java.lang.CharSequence) "/usjava virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac", 216);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "1.7.0_801.7.0_801.7.0_801.7.0_80", 28);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("    en    aaaaaaaaaaaaaaaaaa", strArray2, strArray10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "    en    aaaaaaaaaaaaaaaaaa" + "'", str12.equals("    en    aaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mac OS X" + "'", str13.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("B11", "CLSS ORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSS ORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSS [lJV.LNG.oBJECT;CLSS [lJV.LNG.oBJECT;CLSS [lJV.LNG.oBJECT;CLSS [lJV.LNG.oBJECT;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "x86_64" + "'", charSequence2.equals("x86_64"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "1.7.0_80", (int) (short) 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecification");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "CLSS ORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSS ORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSS [lJV.LNG.oBJECT;CLSS [lJV.LNG.oBJECT;CLSS [lJV.LNG.oBJECT;CLSS [lJV.LNG.oBJECT;", 47, 6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophi", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophi" + "'", str12.equals("/Users/sophi"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        short[] shortArray1 = new short[] { (byte) 1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU/" + "'", str1.equals("eihpos/sresU/"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("tnemnorivnEscihparGC.twa.nus", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                              Mac OS X                                              ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API SpecificationJava PlatforUp UpJava Platform API SpecificationJava PlatforUp UpJaen", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava PlatforUp UpJava Platform API SpecificationJava PlatforUp UpJaen" + "'", str2.equals("Java Platform API SpecificationJava PlatforUp UpJava Platform API SpecificationJava PlatforUp UpJaen"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ ", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc.", 27, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc." + "'", str3.equals("tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc."));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(".", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        char[] charArray11 = new char[] { '4', '#', '#', ' ', '#', ' ' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " ", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "###########################################    ne    ############################################", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixeda", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 47 + "'", int15 == 47);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Gn/T/", (int) (byte) 10, "j jasun.lwhwt.mhcosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Gn/T/j jas" + "'", str3.equals("Gn/T/j jas"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", 8, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                             0.9", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "java platform api specification java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac platform api specification java platform api specification java platform api specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "t/usjava virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual macc.twa.nus", (java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkithttp://j", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwhwt.mhcosx.LWCToolkit     ", (int) (short) 0, 3277);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwhwt.mhcosx.LWCToolkit     " + "'", str3.equals("sun.lwhwt.mhcosx.LWCToolkit     "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("!sun . lwhwt . mhcosx . lwctoolkitih", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!sun . lwhwt . mhcosx . lwctoolkitih" + "'", str2.equals("!sun . lwhwt . mhcosx . lwctoolkitih"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Us...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Oracle Corporation                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 noitaroproC elcarO" + "'", str1.equals("                 noitaroproC elcarO"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Mac OS X                                              ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X                                              " + "'", str2.equals("Mac OS X                                              "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "...    ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("j ja", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j ja" + "'", str2.equals("j ja"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM)SERuntimeEnvironment... platform api sp", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("    en    aaaaaaaaaaaaaaaaaa", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8L, 0.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80", "tnemnorivnEemitnuRES)MT(avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 5);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 5 + "'", short3 == (short) 5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".", (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("mixeda amode");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaa24.80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaa24.80" + "'", str1.equals("aaaaa24.80"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "UTF-8", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(217L, (long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 217L + "'", long3 == 217L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("NOITACIFICEPS IPA MROFTALP AVAJ", 168, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                     ", "3.41.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     " + "'", str2.equals("                                     "));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarava Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ", "noitacificepsipamroftalpavaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarava Platform API Specification" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarava Platform API Specification"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("avaJ mroftalP IPA noitacificepS", "http://java.oracle.com/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Gn/T/", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac", "\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7", "\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac" + "'", str3.equals("java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Doc/Users/sophie/Docu", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(" noitacificeps ipa mroftalp avaJ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " noitacificeps ipa mroftalp avaJ" + "'", str2.equals(" noitacificeps ipa mroftalp avaJ"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "TF-8", (java.lang.CharSequence) "##...", 216);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "noitacificepsipamroftalpavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 5, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "_1424_1 100..._96424..._96");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "         ", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "latf", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/        ", (java.lang.CharSequence) ";TCEJBo.GNL.VJl[ SSLC;TCEJBo.GNL.VJl[ SSLC;TCEJBo.GNL.VJl[ SSLC;TCEJBo.GNL.VJl[ SSLCSLITuREBMUn.HTM.3GNL.SNOMMOC.EHCP.GRO SSLCSLITuREBMUn.HTM.3GNL.SNOMMOC.EHCP.GRO SSLC");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1 100", (int) '4', 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "1 100");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-b15");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwhwt.mhcosx.LWCTool...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "!1.7.0_80-b15ih" + "'", str12.equals("!1.7.0_80-b15ih"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "!#ih" + "'", str14.equals("!#ih"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "!sun.lwhwt.mhcosx.LWCTool...ih" + "'", str16.equals("!sun.lwhwt.mhcosx.LWCTool...ih"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######################", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1 100", (int) '4', 0);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "1 100");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray10);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#", "UTF-8");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758", strArray10, strArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationenaaaaaaaaaaaaaaaaaa", 48, 31);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "                            /Users/sophie/Docum#ts/defects4j/tmp/run_randoop.pl_96424_1560211758" + "'", str15.equals("                            /Users/sophie/Docum#ts/defects4j/tmp/run_randoop.pl_96424_1560211758"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("  ne", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("HOTSPOT(TMEHOTSPOT(TM)");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HOTSPOT(TMEHOTSPOT(TM)\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ".!1.7.0_80-b15ih                 1 100..._96424_1", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "tnemnorivnescihpargc.twa.nus", (java.lang.CharSequence) "                                      sunlwhwtmhcosxLWCToolkit                                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7", 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("    en    aaaaaaaaaaaaaaaaaa", strArray4, strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " noitacificeps ipa mroftalp avaJ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "    en    aaaaaaaaaaaaaaaaaa" + "'", str7.equals("    en    aaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) (short) 100, (int) (short) -1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) '4', 35);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "mixed# #mode" + "'", str13.equals("mixed# #mode"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "sun.lwawt.macosx.LWCToolkit", (int) (byte) 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Users/sophie1 100/Users/sophie/", strArray4, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IHjava hotspot(tm) 64-bit server vm!1.7.0_80-B15IH", 10, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Users/sophie1 100/Users/sophie/" + "'", str7.equals("Users/sophie1 100/Users/sophie/"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "  ne/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/                                      sunlwhwtmhcosxLWCToolkit                                      sers/sophie/Doc/Users/sophie/Docu");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun . lwhwt . mhcosx . lwctoolkit", "4444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.6", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "edomdexiMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) " noitacificeps ipa mroftalp avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(" noitacificeps ipa mroftalp avaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " NOITACIFICEPS IPA MROFTALP AVAJ" + "'", str1.equals(" NOITACIFICEPS IPA MROFTALP AVAJ"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("44444444444444444444444444444444", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("!1.7.0_80-b15ih", (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ie1 100/Users/sophie/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ie1 100/Users/sophie/" + "'", str1.equals("ie1 100/Users/sophie/"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkit", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode444444444444444444gn/T/mixed mode");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("E", ".!1.7.0_80-b15ih                 1 100..._96424_1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E" + "'", str2.equals("E"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "###################################", (java.lang.CharSequence) "pU pUroftalP avaJnoitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("..._96424_1560211758/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_gener...", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(" noitacificeps ipa mroftalp avaJ", "..._96424_1 100..._96424_1", "                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444                                                                                                                                                                                                   4444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " noitacificeps ipa mroftalp avaJ" + "'", str3.equals(" noitacificeps ipa mroftalp avaJ"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 24, (double) 213, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 213.0d + "'", double3 == 213.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac", 84);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac" + "'", str2.equals("java virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual mac"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Librbry/Jbvb/JbvbVirtublMbchines/jdk1.7.0_80.jdk/Contents/Home/jre", 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("eihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/" + "'", str2.equals("eihpos/sresU/"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("atform api specification java platform api specification java platform api specification Oracle Corp", "mvvrevresvtib-rav)mt(topstohvavaj");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(".7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7" + "'", str1.equals(".7"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444", (java.lang.CharSequence) "Java Ho...", 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96424_1560211758                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                ", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("j jaj jaj 24j jaj jaj ", (-1), "                                 Java Platform API Specification                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j jaj jaj 24j jaj jaj " + "'", str3.equals("j jaj jaj 24j jaj jaj "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;" + "'", str1.equals("clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironment", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironment" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        long[] longArray5 = new long[] { 26L, 48, 5L, 28, (-1) };
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.3", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ng.Object;");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.1ng.Object;.3" + "'", str4.equals("10.1ng.Object;.3"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwhwt.mhcosx.lwctoolkit1", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1 100", (int) '4', 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "1 100");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(strArray4);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("java platform api specification", "1.7", (int) '4');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, "hi!", 22, (int) (byte) -1);
        java.lang.String[] strArray25 = null;
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("ne", strArray20, strArray25);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ", strArray4, strArray25);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "!ih" + "'", str13.equals("!ih"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ne" + "'", str26.equals("ne"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               " + "'", str27.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               "));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " noitacificeps ipa mroftalp avaj", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", charSequence2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Us...", " Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification Java Virtual Machine Specification ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "class org.apache.commons.lang3.math.NumberUtilsclass org.apache.commons.lang3.math.NumberUtilsclass [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie1 100/Users/sophie/", "24.80-B11");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 83 + "'", int3 == 83);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("class org.apache.commons.lang3.math.NumberUtilsclass org.apache.commons.lang3.math.NumberUtilsclass [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.math.NumberUtilsclass org.apache.commons.lang3.math.NumberUtilsclass [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object" + "'", str1.equals("class org.apache.commons.lang3.math.NumberUtilsclass org.apache.commons.lang3.math.NumberUtilsclass [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 216, 10L, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 216L + "'", long3 == 216L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "!#ih", (java.lang.CharSequence) "CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mvvrevresvtib-rav)mt(topstohvavaj", "/Users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "    en    aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("!#ih", "                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!#ih" + "'", str2.equals("!#ih"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "aaaaaaaaaaaaaahttaaaaaaaaaaaaaaa", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "tnemnorivnEscihparGC.twa.nusaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GN/t/" + "'", str1.equals("GN/t/"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "5", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;", (java.lang.CharSequence) "tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "tnemnorivnEemitnuRES)MT(avaJ", (java.lang.CharSequence) "GN/t/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Mac OS X", " noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ noitacificepS enihcaM lautriV avaJ ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.1ng.Object;.3", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("444444444444444444gn/t/", "!#ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444gn/t/" + "'", str2.equals("444444444444444444gn/t/"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "                             0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.8                       ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.6", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6                         " + "'", str2.equals("1.6                         "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) 10L, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Users/sophie1 100/Users/sophie/", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                    1.7.0_80", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    1.7.0_80" + "'", str2.equals("                    1.7.0_80"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Gn/T/", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 6a-BIT SERVER VM", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("..._96424_1560211758/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_gener...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) -1, (byte) -1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 10 + "'", byte10 == (byte) 10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("noitacificepSIPAmroftalPavaraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8571120651_42469_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecification" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecification"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444", "/Users/sophie/Doc/Users/sophie/Docu", "UTF-", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444" + "'", str4.equals("4444444444444444444444"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7", (int) (short) 1, "3.41.01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 6, 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 27, (float) 47);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 47.0f + "'", float3 == 47.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("44444444444444444444444Enaaa444444444444444444444444", 3277);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444Enaaa444444444444444444444444" + "'", str2.equals("44444444444444444444444Enaaa444444444444444444444444"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("###################################", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################" + "'", str2.equals("###################################"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Gn/T/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("noitacificepsipamroftalpavaJ", "...    ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils5 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray6 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3, systemUtils4, systemUtils5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray6);
        org.junit.Assert.assertNotNull(systemUtilsArray6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 47, 15);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#####", "/Users");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "###########################################    ne    ############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.6", "_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_gener...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("#####", "clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####" + "'", str2.equals("#####"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;", (java.lang.CharSequence) "mvvrevresvtib-rav)mt(topstohvavaj");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ih");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixeda amode" + "'", str3.equals("mixeda amode"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "Java(TM) SE Runtime Environment", "s/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                1.4", "noitacificepsipamroftalpavaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepsipamroftalpavaJ" + "'", str2.equals("noitacificepsipamroftalpavaJ"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Up UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp Up", "tnemnorivnescihpargc.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Up UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp U" + "'", str2.equals("Up UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp U"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_801.7.0_801.7.0_801.7.0_80", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a1.7.0_801.7.0_801.7.0_801.7.0_80aa" + "'", str3.equals("a1.7.0_801.7.0_801.7.0_801.7.0_80aa"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) ".!1.7.0_80-b15ih                 1 100..._96424_1", (java.lang.CharSequence) "eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ".!1.7.0_80-b15ih                 1 100..._96424_1" + "'", charSequence2.equals(".!1.7.0_80-b15ih                 1 100..._96424_1"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("####################################################################################################################################################################################################################kit1", "          1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################################################################################################################################kit1" + "'", str2.equals("####################################################################################################################################################################################################################kit1"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 9.0f, (double) 84.0f, (double) 15);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("http:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: http: is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        char[] charArray8 = new char[] { '4', '#', '#', ' ', '#', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VM", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sophie44444444444444444444444444444444444444444444444444444444444444444444", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444sophie44444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ORAnnn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUN_RANDOOP.PL_962_1560211758/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JARAVAPLATFORMAPISPECIFICATIONEN    AAAAAAAAAAAAAAAAAA", "clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;" + "'", str2.equals("clssAorg.pche.commons.lng3.mth.NumberUtilsclssAorg.pche.commons.lng3.mth.NumberUtilsclssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;clssA[Ljv.lng.Object;"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        double[] doubleArray1 = new double[] { 0L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("!1.7.0_80-b15ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!1.7.0_80-b15ih" + "'", str1.equals("!1.7.0_80-b15ih"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        int[] intArray6 = new int[] { (short) 1, (short) 100, (byte) 100, (short) 10, 10, 'a' };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int[] intArray5 = new int[] { 10, (short) 1, ' ', 0, (byte) 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "24", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "http:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "java platform api specification", (java.lang.CharSequence) "24.80-b11                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun . lwhwt . mhcosx . lwctoolkit", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", "                 noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        short[] shortArray2 = new short[] { (short) 0, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1 100", (int) '4', 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "1 100");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(strArray4);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence[]) strArray4);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Librbry/Jbvb/JbvbVirtublMbchines/jdk1.7.0_80.jdk/Contents/Home/jre                                      sunlwhwtmhcosxLWCToolkit                                      /Librbry/Jbvb/JbvbVirtublMbchines/jdk1.7.0_80.jdk/Contents/Home/jre                                      sunlwhwtmhcosxLWCToolkit                                      /Librbry/Jbvb/JbvbVirtublMbchines/jdk1.7.0_80.jdk/Contents/Home/jre                                      sunlwhwtmhcosxLWCToolkit                                      /Librbry/Jbvb/JbvbVirtublMbchines/jdk1.7.0_80.jdk/Contents/Home/jre                                      sunlwhwtmhcosxLWCToolkit                                      /Librbry/Jbvb/JbvbVirtublMbchines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "!ih" + "'", str13.equals("!ih"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "5", charSequence1, 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 10, (int) (short) 10);
        java.lang.Class<?> wildcardClass7 = strArray2.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str8.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "444444444444444444gn/T/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "    en    ", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkithttp://j", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.4", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("44444444444444444444444444444444444", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ih" + "'", str1.equals("!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ihJAVA HOTSPOT(TM) 64-BIT SERVER VM!1.7.0_80-b15ih"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("         Java(TM)SERuntimeEnvironment          ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         Java(TM)SERuntimeEnvironment          " + "'", str2.equals("         Java(TM)SERuntimeEnvironment          "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " noitacificeps ipa mroftalp avaJ", charSequence1, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444", (java.lang.CharSequence) "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "kit1", 47);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "        ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ls", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "GN/t/", (java.lang.CharSequence) "emnorivnEscihparGC.twa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "java platform api specification");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " 44444444444444444444444444444444444 ", (java.lang.CharSequence[]) strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                                      sunlwhwtmhcosxLWCToolkit                                      ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "en", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("..._96424_1 100..._96424_", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..._96424_1 100..._96424_" + "'", str2.equals("..._96424_1 100..._96424_"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Gn/T/j jas");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih" + "'", str1.equals("!ih"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 27L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                      ", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              " + "'", str2.equals("                              "));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("444444444444444444444444444", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("t/usjava virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual macc.twa.nus", (-1), "TF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "t/usjava virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual macc.twa.nus" + "'", str3.equals("t/usjava virtual machine specificationjava virtual ma/java virtual machine specificationjava virtual macc.twa.nus"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("!1.7.0_80-b15ih                 ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ls");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Up UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp Up", (java.lang.CharSequence) "sun.lwhwt.mhcosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Li4444444444444444444444/Li", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0Mixedmode9", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0Mixedmode9" + "'", str2.equals("0Mixedmode9"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", 5, 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...wawt.macosx.LWCToo..." + "'", str3.equals("...wawt.macosx.LWCToo..."));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Up Up", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Up Up                              " + "'", str2.equals("Up Up                              "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("        ", 6, "                              ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        " + "'", str3.equals("        "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 0, 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("_96424_1560211758/trgt/clsss:/Usrs/sophi/Documts/dfcOrclCorportio", 168);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_96424_1560211758/trgt/clsss:/Usrs/sophi/Documts/dfcOrclCorportio                                                                                                       " + "'", str2.equals("_96424_1560211758/trgt/clsss:/Usrs/sophi/Documts/dfcOrclCorportio                                                                                                       "));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "  ne/Library/Java/J...", 30, 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "###########################################    ne    ############################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("htt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "htt" + "'", str1.equals("htt"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwhwt.mhcosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "http:", "java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwjwa.mjcosx.LWCToolkiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwjwa.mjcosx.LWCToolkiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "htt", 3277);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API SpecificationJava PlatforUp UpJava Platform API SpecificationJava PlatforUp UpJaen");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame!1.7.0_80-b15ihdefects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en    aaaaaaaaaaaaaaaaaafication java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification ", (java.lang.CharSequence) "mixeda amode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "   ", 55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Gn/T/j jas", (java.lang.CharSequence) "444    en    aaaaaaaaaaaaaaaaaa4444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Gn/T/j jas" + "'", charSequence2.equals("Gn/T/j jas"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_962_1560211758/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa", "java hotspot(tm) 64-bit server vm", 4, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Usejava hotspot(tm) 64-bit server vmhie/Documents/defectsj/tmp/run_randoop.pl_962_1560211758/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa" + "'", str4.equals("/Usejava hotspot(tm) 64-bit server vmhie/Documents/defectsj/tmp/run_randoop.pl_962_1560211758/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ttp:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion4.atLeast(javaVersion7);
        boolean boolean10 = javaVersion0.atLeast(javaVersion7);
        java.lang.String str11 = javaVersion0.toString();
        java.lang.String str12 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.9" + "'", str6.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.5" + "'", str11.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.5" + "'", str12.equals("1.5"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "noitacificepSIPAmroftalPavaraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8571120651_42469_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7\n1.71.71.71.71.71.71.71.71.7", (java.lang.CharSequence) "Java platform api specification ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96424_1560211758                               ", "", "java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("######################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######################" + "'", str2.equals("######################"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444444444444444444444444444", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("80-b11", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "80-b11" + "'", str2.equals("80-b11"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0Mixedmode9", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0Mixedmode9" + "'", str2.equals("0Mixedmode9"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.6                         ", (java.lang.CharSequence) "gc.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "tnemnorivnescihpargc.twa.nustnemnorivnescihpargc.entnemnorivnescihpargc.twa.nustnemnorivnescihpargc.", (java.lang.CharSequence) "!sun . lwhwt . mhcosx . lwctoolkitih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "##...", (java.lang.CharSequence) "..._96424_1 100..._96424_1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("TF-8/Users/sophie/Library/Java/Extensions:/Library/J", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("NOITACIFICEPS IPA MROFTALP AVAJ", "noitacificepSIPAmroftalPavaraj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/8571120651_42469_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Li4444444444444444444444/Li");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Gn/T/j jas", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("...wawt.macosx.LWCToo...", 9, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "acosx.LWCToo..." + "'", str3.equals("acosx.LWCToo..."));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ttp:", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                                                                                                                                   4444444444444444444444", 28, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                ..." + "'", str3.equals("...                ..."));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ".!1.7.0_80-b15ih                 1 100..._96424_1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("En", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophi", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " noitacificeps ipa mroftalp avaJ", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed# #mode", "!sun.lwhwt.mhcosx.LWCTool...ih");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 10, (float) 31, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "edomdexiMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "4444444444444444444444444444", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                " + "'", str2.equals("51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                ie1 100/Users/sophie/51.0                                                "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        char[] charArray13 = new char[] { '4', '#', '#', ' ', '#', ' ' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "tnemnorivnescihpargc.twa.nus", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "..._96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_gener...", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        long[] longArray6 = new long[] { '#', 'a', (byte) -1, 26, 5L, 97 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("class org.apache.commons.lang3.math.NumberUtilsclass org.apache.commons.lang3.math.NumberUtilsclass [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object;class [Ljava.lang.Object");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalcslitUrebmuN.htam.3gnal.snommoc.ehcapa.gro ssalcslitUrebmuN.htam.3gnal.snommoc.ehcapa.gro ssalc" + "'", str1.equals("tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalcslitUrebmuN.htam.3gnal.snommoc.ehcapa.gro ssalcslitUrebmuN.htam.3gnal.snommoc.ehcapa.gro ssalc"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...    ...", ";TCEJBo.GNL.VJl[ SSLC;TCEJBo.GNL.VJl[ SSLC;TCEJBo.GNL.VJl[ SSLC;TCEJBo.GNL.VJl[ SSLCSLITuREBMUn.HTM.3GNL.SNOMMOC.EHCP.GRO SSLCSLITuREBMUn.HTM.3GNL.SNOMMOC.EHCP.GRO SSLC");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "java platform api specification", (java.lang.CharSequence) "ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(8L, (long) 84, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Users/sophie1 100/Users/sophie/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USERS/SOPHIE1 100/USERS/SOPHIE/" + "'", str1.equals("USERS/SOPHIE1 100/USERS/SOPHIE/"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Gn/T/", (java.lang.CharSequence) "24");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) 'a', "aaaaa24.80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!a" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!a"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("!1.7.0_80-b15ih", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96424_1560211758                               ", (java.lang.CharSequence) "..._96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_gener...    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "/Users/sophie/Document    ne    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("    en    ", 216);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    en    " + "'", str2.equals("    en    "));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ng.Object;", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ng.Object;" + "'", str3.equals("ng.Object;"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ers/sophie1 100/Users/sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ers/sophie1 100/Users/sophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "HOTSPOT(TM) 6a-B", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("!#ih", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "En");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("####################################################", "ORA...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa", "444444444444444444444444444", "                      1.7                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects j/tmp/run_randoop.pl_96 2 _1560211758/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa" + "'", str3.equals("/Users/sophie/Documents/defects j/tmp/run_randoop.pl_96 2 _1560211758/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "..._96424_1 100..._96424_1", 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("80-b11", "!                                1.4ih", 84);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwhwt.mhcosx.lwctoolkit", (int) (short) 0, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwhwt.mhcosx.lwctoolkit" + "'", str3.equals("sun.lwhwt.mhcosx.lwctoolkit"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        byte[] byteArray2 = new byte[] { (byte) -1, (byte) 100 };
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 100 };
        byte[][] byteArray6 = new byte[][] { byteArray2, byteArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray6);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("!#ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!#ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "en    aaaaaaaaaaaaaaaaaafication java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444444444444444444gn/T/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                      ", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("444444444444444444gn/T/", "tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalc;tcejbO.gnal.avajL[ ssalcslitUrebmuN.htam.3gnal.snommoc.ehcapa.gro ssalcslitUrebmuN.htam.3gnal.snommoc.ehcapa.gro ssalc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444gn/T/" + "'", str2.equals("444444444444444444gn/T/"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Mac OS X", "Java HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VMEnaaaJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("atform api specification java platform api specification java platform api specification Oracle Corp");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        long[] longArray3 = new long[] { (byte) 100, (short) 1, 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ers/sophie1 100/Users/sophie/", (int) (short) -1, "/Users/sophie/Documents/defects j/tmp/run_randoop.pl_96 2 _1560211758/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ers/sophie1 100/Users/sophie/" + "'", str3.equals("ers/sophie1 100/Users/sophie/"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "    en    ", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444/         4444444444444", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100L, (double) 35L, (double) 103);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.8", (int) (short) 5, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "latf");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) 0, (byte) -1, (byte) -1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.Class<?> wildcardClass12 = byteArray5.getClass();
        java.lang.String[] strArray13 = new java.lang.String[] {};
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "hi!");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "");
        java.lang.Class<?> wildcardClass18 = strArray13.getClass();
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(objArray19, 'a');
        java.lang.Class<?> wildcardClass22 = objArray19.getClass();
        java.lang.String[] strArray23 = new java.lang.String[] {};
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray23, "hi!");
        java.lang.Class<?> wildcardClass26 = strArray25.getClass();
        char[] charArray30 = new char[] {};
        int int31 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray30);
        int int32 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray30);
        boolean boolean33 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwhwt.mhcosx.LWCToolkit", charArray30);
        java.lang.Class<?> wildcardClass34 = charArray30.getClass();
        java.lang.String[] strArray37 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#", "UTF-8");
        java.lang.Class<?> wildcardClass38 = strArray37.getClass();
        java.lang.reflect.Type[] typeArray39 = new java.lang.reflect.Type[] { wildcardClass12, wildcardClass18, wildcardClass22, wildcardClass26, wildcardClass34, wildcardClass38 };
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.join(typeArray39);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(typeArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "class [Bclass [Ljava.lang.String;class [Ljava.lang.Object;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;" + "'", str40.equals("class [Bclass [Ljava.lang.String;class [Ljava.lang.Object;class [Ljava.lang.String;class [Cclass [Ljava.lang.String;"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Gn/T/j jas", "  ne/Library/Java/J...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Gn/T/j jas" + "'", str2.equals("Gn/T/j jas"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "gc.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("51.0                                                ", strArray3, strArray9);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("!ih");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, "1 100", (int) '4', 0);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "1 100");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray15, strArray22);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray22);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("tnemnorivnEscihparGC.twa.nusaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray9, strArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "51.0                                                " + "'", str11.equals("51.0                                                "));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification Oracle Corporation                 java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("##############################################mixeda");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        long[] longArray4 = new long[] { (byte) 0, (byte) 1, '4', 'a' };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "htt", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Usejava hotspot(tm) 64-bit server vmhie/Documents/defectsj/tmp/run_randoop.pl_962_1560211758/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa", "24.80-b11", 69);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                    1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1 100", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Corporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/         ", strArray1, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/         " + "'", str7.equals("/         "));
        org.junit.Assert.assertNull(strArray8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10.1ng.Object;.3", (java.lang.CharSequence) "va.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6, (float) 6, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "0.9", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("gc.twa.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "gc.twa.nus" + "'", str1.equals("gc.twa.nus"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects j/tmp/run_randoop.pl_96 2 _1560211758/target/classes:/Users/sophie/Documents/defects j/framework/lib/test_generation/generation/randoop-current.jaravaPlatformAPISpecificationen    aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "##...", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96424_1560211758");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sophie                          44444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                             0.9", (int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ", 27L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.8", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "kit1");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.8" + "'", str4.equals("1.8"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "NOITACIFICEPS IPA MROFTALP AVAJ", (java.lang.CharSequence) ".7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwhwt.mhcosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_gener...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "USERS/SOPHIE1 100/USERS/SOPHIE/", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                1.4");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.6", (java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                 noitaroproC elcarO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("mixedmod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmod" + "'", str1.equals("mixedmod"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                         /Us...", (java.lang.CharSequence) "24.80aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444    en    aaaaaaaaaaaaaaaaaa4444", "ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...ORA...", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("_96424_1560211758/TRGT/CLSSS:/USRS/SOPHI/DOCUMTS/DFCORCLCORPORTIO", "sunlwhwtmhcosxLWCToolkit", "Java platform api specification ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "_96424_1560211758/TRGT/CLSSS:/USRS/SOPHI/DOCUMTS/DFCORCLCORPORTIO" + "'", str3.equals("_96424_1560211758/TRGT/CLSSS:/USRS/SOPHI/DOCUMTS/DFCORCLCORPORTIO"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "          ", (java.lang.CharSequence) "CLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSaORG.PCHE.COMMONS.LNG3.MTH.nUMBERuTILSCLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;CLSSa[lJV.LNG.oBJECT;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "tnemnorivnEemitnuRES)MT(avaJ", (java.lang.CharSequence) "/Users");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(100.0f, 32.0f, (float) 22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed# #mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("://java.oracle.com/", "sun.lwhwt.mhcosx.LWCToolkit    ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.8     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("80-b11                  ", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 83, 217L, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "javavhotspot(tm)var-bitvservervvm", (java.lang.CharSequence) "1e", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.9");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "1 100");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "x86_64", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "!                                1.4ih");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "en" + "'", str6.equals("en"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("e", 216, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = javaVersion0.atLeast(javaVersion7);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("://java.oracle.com/", "/        ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "Mac OS X                                              ", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en    aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7", "1 100", (int) '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Ho...", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 31, 10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "4444444444444444444444444444sunlwhwtmhcosxLWCToolkitsunlwhwtmhcosxLWCToolkitsunlwhwtmhcosxLWCToolkit", 100, 24);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + ".7" + "'", str7.equals(".7"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sophie                          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" 1.5");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.5f + "'", float1 == 1.5f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun . lwhwt . mhcosx . lwctoolkit", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("         Java(TM)SERuntimeEnvironment          ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment          " + "'", str2.equals("         Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment                   Java(TM)SERuntimeEnvironment          "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwhwt.mhcosx.LWCToolkithttp://j", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwhwt.mhcosx.LWCToolkithttp://j" + "'", str2.equals("sun.lwhwt.mhcosx.LWCToolkithttp://j"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion0.toString();
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", charSequence1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0Mixedmode9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0Mixedmode9" + "'", str1.equals("0Mixedmode9"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("51.0", "tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ_1424_1 100..._96424..._96tnemnorivnEemitnuRES)MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "n    aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Enaaa", (java.lang.CharSequence) "..._96424_1 100..._96424_1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        double[] doubleArray3 = new double[] { (short) 0, (-1), (short) 1 };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) 5);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80aaa24.80aaa24.80aaa24.80aaa24.80aaa", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ie1 100/Users/sophie/", "ng.Object;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 1, (short) 5);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("en    aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJobhi!sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaa24.80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaa24.80" + "'", str1.equals("aaaaa24.80"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "tform api specification java platform api specification java platform api specification java platform api specification java platform api specification java platform api specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("java platform api specification", "1.7", (int) '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "tF-8", (java.lang.CharSequence) "                                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Us...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Us..." + "'", str1.equals("/Us..."));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        double[] doubleArray3 = new double[] { (short) 0, (-1), (short) 1 };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96424_1560211758                               ", "emnorivnEscihparGC.twa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.reflect.Type[] typeArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(typeArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                              Mac OS X                                              ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!   /    ih", "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("defects4j/tmp/run_randoop.pl_96424_1560211758/target/classes:/Users/sophie/Documents/defects4j/frame", 6.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java(TM) SE Runtime Environment", "Gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "4444444444444444444444444444");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##############################################mixeda", "80-b11                  ", "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################################mixeda" + "'", str3.equals("##############################################mixeda"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("E");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 !1.7.0_80-b15ih                                 Java Platform API Specification                                 ", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Up UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp UpUp Up", 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 3, (int) (short) 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444444444444/         4444444444444", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        long[] longArray3 = new long[] { (byte) 100, (short) 1, 10L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                                                                   4444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("B11", 49, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

