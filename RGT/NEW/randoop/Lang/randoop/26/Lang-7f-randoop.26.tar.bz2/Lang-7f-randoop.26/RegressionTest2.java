import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7.0_80", 3, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0L, (double) 3.0f, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1\n.\n7", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1\n.\n7" + "'", charSequence2.equals("1\n.\n7"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " ", (java.lang.CharSequence) "0.00140.1-40.00140.01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 21 + "'", int2 == 21);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1.0a119.0a100.0a100.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-a0.01a0.001a0.001a0.911a0.1-" + "'", str1.equals("0.1-a0.01a0.001a0.001a0.911a0.1-"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                ", 5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), (double) 30, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "::::::::::::::::::::...", (java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime Environment", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.04100.04-1.04100.0410.04-1.0", "Mac OS X", "                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.04100.04-1.04100.0410.04-1.0" + "'", str3.equals("10.04100.04-1.04100.0410.04-1.0"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6_68x" + "'", str1.equals("6_68x"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10410041004-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("a # # # 4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", "1.21.71.71.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10.14.314.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0#0#30", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("6_68x", "1.7.0_80-b15", "                                                 1.4");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                 1.4", (java.lang.CharSequence) "1\n.\n7", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", 52, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 66 + "'", int3 == 66);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.11.11.11.11.11.11.1  ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 23, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0#10.0#100.0#100.0#119.0#-1.0", "", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                    ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        char[] charArray5 = new char[] { ' ', 'a', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("htt1\n.\n7", "/Users/soph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/soph" + "'", str2.equals("/Users/soph"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "a # # # 4", (java.lang.CharSequence) "oR...", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("6_68x", (int) '#', 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("     ...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Corporation Oracle", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31L, (float) 6, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 31.0f + "'", float3 == 31.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("demixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), (long) '#', (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("21.041.0421.040.0432.04119.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str1.equals("21.041.0421.040.0432.04119.0"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int[] intArray6 = new int[] { 23, (short) 1, 21, (short) 0, (byte) 10, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 23, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 23");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2341421404104-1" + "'", str8.equals("2341421404104-1"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1\n.\n7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/soph", 6, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/soph" + "'", str3.equals("/Users/soph"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "040430", (java.lang.CharSequence) "040430");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("####################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################################################################" + "'", str1.equals("####################################################################################################"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("        ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mac/OS/X", (int) ' ', "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/JavMac/OS/X/Library/Jav" + "'", str3.equals("/Library/JavMac/OS/X/Library/Jav"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "6_68x", (java.lang.CharSequence) "10410041004-1", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophie", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("US", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) " Oracle Corporation # a       a", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, (double) (-1), (double) 119L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_7;
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("2sU80-b//", "1.5", "CorporationxOracle", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2sU80-b//" + "'", str4.equals("2sU80-b//"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0.1-a0.01a0.001a0.001a0.911a0.1-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-a0.01a0.001a0.001a0.911a0.1-" + "'", str1.equals("0.1-a0.01a0.001a0.001a0.911a0.1-"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass3 = javaVersion2.getClass();
        java.lang.String str4 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str8 = javaVersion7.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        java.lang.String str14 = javaVersion12.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray15 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion2, javaVersion5, javaVersion6, javaVersion9, javaVersion12 };
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str17 = javaVersion16.toString();
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass19 = javaVersion18.getClass();
        java.lang.String str20 = javaVersion18.toString();
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str24 = javaVersion23.toString();
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean26 = javaVersion23.atLeast(javaVersion25);
        java.lang.String str27 = javaVersion25.toString();
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
        java.lang.String str30 = javaVersion28.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray31 = new org.apache.commons.lang3.JavaVersion[] { javaVersion16, javaVersion18, javaVersion21, javaVersion22, javaVersion25, javaVersion28 };
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str33 = javaVersion32.toString();
        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass35 = javaVersion34.getClass();
        java.lang.String str36 = javaVersion34.toString();
        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str40 = javaVersion39.toString();
        org.apache.commons.lang3.JavaVersion javaVersion41 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean42 = javaVersion39.atLeast(javaVersion41);
        java.lang.String str43 = javaVersion41.toString();
        org.apache.commons.lang3.JavaVersion javaVersion44 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean45 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion44);
        java.lang.String str46 = javaVersion44.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray47 = new org.apache.commons.lang3.JavaVersion[] { javaVersion32, javaVersion34, javaVersion37, javaVersion38, javaVersion41, javaVersion44 };
        org.apache.commons.lang3.JavaVersion javaVersion48 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str49 = javaVersion48.toString();
        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass51 = javaVersion50.getClass();
        java.lang.String str52 = javaVersion50.toString();
        org.apache.commons.lang3.JavaVersion javaVersion53 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion54 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion55 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str56 = javaVersion55.toString();
        org.apache.commons.lang3.JavaVersion javaVersion57 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean58 = javaVersion55.atLeast(javaVersion57);
        java.lang.String str59 = javaVersion57.toString();
        org.apache.commons.lang3.JavaVersion javaVersion60 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean61 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion60);
        java.lang.String str62 = javaVersion60.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray63 = new org.apache.commons.lang3.JavaVersion[] { javaVersion48, javaVersion50, javaVersion53, javaVersion54, javaVersion57, javaVersion60 };
        org.apache.commons.lang3.JavaVersion javaVersion64 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str65 = javaVersion64.toString();
        org.apache.commons.lang3.JavaVersion javaVersion66 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass67 = javaVersion66.getClass();
        java.lang.String str68 = javaVersion66.toString();
        org.apache.commons.lang3.JavaVersion javaVersion69 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion70 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion71 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str72 = javaVersion71.toString();
        org.apache.commons.lang3.JavaVersion javaVersion73 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean74 = javaVersion71.atLeast(javaVersion73);
        java.lang.String str75 = javaVersion73.toString();
        org.apache.commons.lang3.JavaVersion javaVersion76 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean77 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion76);
        java.lang.String str78 = javaVersion76.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray79 = new org.apache.commons.lang3.JavaVersion[] { javaVersion64, javaVersion66, javaVersion69, javaVersion70, javaVersion73, javaVersion76 };
        org.apache.commons.lang3.JavaVersion javaVersion80 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str81 = javaVersion80.toString();
        org.apache.commons.lang3.JavaVersion javaVersion82 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.Class<?> wildcardClass83 = javaVersion82.getClass();
        java.lang.String str84 = javaVersion82.toString();
        org.apache.commons.lang3.JavaVersion javaVersion85 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion86 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion87 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str88 = javaVersion87.toString();
        org.apache.commons.lang3.JavaVersion javaVersion89 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean90 = javaVersion87.atLeast(javaVersion89);
        java.lang.String str91 = javaVersion89.toString();
        org.apache.commons.lang3.JavaVersion javaVersion92 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean93 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion92);
        java.lang.String str94 = javaVersion92.toString();
        org.apache.commons.lang3.JavaVersion[] javaVersionArray95 = new org.apache.commons.lang3.JavaVersion[] { javaVersion80, javaVersion82, javaVersion85, javaVersion86, javaVersion89, javaVersion92 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray96 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray15, javaVersionArray31, javaVersionArray47, javaVersionArray63, javaVersionArray79, javaVersionArray95 };
        java.lang.String str97 = org.apache.commons.lang3.StringUtils.join(javaVersionArray96);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.2" + "'", str8.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.1" + "'", str11.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7" + "'", str14.equals("1.7"));
        org.junit.Assert.assertNotNull(javaVersionArray15);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.1" + "'", str17.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.5" + "'", str20.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.2" + "'", str24.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1.1" + "'", str27.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.7" + "'", str30.equals("1.7"));
        org.junit.Assert.assertNotNull(javaVersionArray31);
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.1" + "'", str33.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1.5" + "'", str36.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1.2" + "'", str40.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion41 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion41.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1.1" + "'", str43.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion44 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion44.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1.7" + "'", str46.equals("1.7"));
        org.junit.Assert.assertNotNull(javaVersionArray47);
        org.junit.Assert.assertTrue("'" + javaVersion48 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion48.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1.1" + "'", str49.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1.5" + "'", str52.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion53 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion53.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion54 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion54.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion55 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion55.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1.2" + "'", str56.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion57 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion57.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1.1" + "'", str59.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion60 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion60.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1.7" + "'", str62.equals("1.7"));
        org.junit.Assert.assertNotNull(javaVersionArray63);
        org.junit.Assert.assertTrue("'" + javaVersion64 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion64.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "1.1" + "'", str65.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion66 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion66.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1.5" + "'", str68.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion69 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion69.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion70 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion70.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion71 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion71.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "1.2" + "'", str72.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion73 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion73.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1.1" + "'", str75.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion76 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion76.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "1.7" + "'", str78.equals("1.7"));
        org.junit.Assert.assertNotNull(javaVersionArray79);
        org.junit.Assert.assertTrue("'" + javaVersion80 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion80.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "1.1" + "'", str81.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion82 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion82.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "1.5" + "'", str84.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion85 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion85.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion86 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion86.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion87 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion87.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "1.2" + "'", str88.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion89 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion89.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "1.1" + "'", str91.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion92 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion92.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "1.7" + "'", str94.equals("1.7"));
        org.junit.Assert.assertNotNull(javaVersionArray95);
        org.junit.Assert.assertNotNull(javaVersionArray96);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Oracle Corporation", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("a4 4 4 4a4#", "1.4", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4 4 4 4a4#" + "'", str3.equals("a4 4 4 4a4#"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "edom dexim", (java.lang.CharSequence) "10.0a100.0a-1.0a100.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                 1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("CORPORATIONXORACLE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                       Mac/OS/X                                                        ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                    ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " Oracle Corporation # a       a", 21, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.04100.04-1.04100.0410.04-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("oR...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Or..." + "'", str1.equals("Or..."));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.1-a0.01a0.001a0.001a0.911a0.1-", "/Users/soph");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", (int) (byte) 0, 119);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U" + "'", str3.equals(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/T/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) '4', (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 10, (int) (byte) 0);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str9.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str11.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 119.0d + "'", double16 == 119.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 8, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.21.71.71.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.21.71.71.6" + "'", str1.equals("1.21.71.71.6"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", (int) (byte) 1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479" + "'", str3.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("C#orporation# #O#racle", 119, "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio" + "'", str3.equals("C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", charSequence2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) (short) 1, 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 119.0d + "'", double14 == 119.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("        ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     " + "'", str2.equals("                     "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("en");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                     ", (java.lang.CharSequence) "     ooo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "CORPORATIONXORACLE", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " a       ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                       Mac/OS/X", "                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("CORPORATIONXORACLE", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                CORPORATIONXORACLE" + "'", str2.equals("                                                CORPORATIONXORACLE"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("UTF-8", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7.0_80");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("::::::::::::::::::::::::::::::", (int) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "##a# # # #a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java HotSpot(TM) 64-Bit Server VM", 31, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VM" + "'", str3.equals("VM"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100 10 10 -1 -1 -1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 63, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("CorporationxOracle", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CorporationxOracle" + "'", str3.equals("CorporationxOracle"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 100, "htt1\n.\n7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1" + "'", str3.equals("htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java HotSpot(TM) 64-Bit Server VM", "", "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Corporation Oracle", (java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.0a119.0a100.0a100.0a10.0a-1.0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", (java.lang.CharSequence) "                                                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) ' ', 119);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                    ", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray15 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "/Users/sophie");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray8, strArray17);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "/Users/sophie");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, ' ');
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.11.11.11.11.11.11.1  ", (java.lang.CharSequence[]) strArray20);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Corporation Oracle" + "'", str18.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + " Oracle Corporation # a       a" + "'", str22.equals(" Oracle Corporation # a       a"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("UTF-8", "/var/folder:fc0000gn/T/", "Or...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UF-8" + "'", str3.equals("UF-8"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence) "VM", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0", (java.lang.CharSequence) "1.11.11.11.11.11.11.1  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.3", (int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.14." + "'", str3.equals("0.14."));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        char[] charArray6 = new char[] { ' ', ' ', '4', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        char[] charArray2 = new char[] { '#' };
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/soph", 0, "10.04100.04-1.04100.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/soph" + "'", str3.equals("/Users/soph"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_6", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", 23, 21);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation # a       a", "0.1-40.0140.00140.1-40.00140.01");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("x86_6", "demixed modemixed modemixed modemixed modemixed mode", "/T/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6" + "'", str3.equals("x86_6"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "a4 4 4 4a4#", (java.lang.CharSequence) "Oracle Corporation # a       a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a    4", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a    4" + "'", str3.equals("a    4"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "10 1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String[] strArray4 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10 100 100 -1", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("-1.0a119.0a100.0a100.0a10.0a-1.0", "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a119.0a100.0a100.0a10.0a-1.0" + "'", str2.equals("-1.0a119.0a100.0a100.0a10.0a-1.0"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "                                                CORPORATIONXORACLE", "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                CORPORATIONXORACLE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.0", (java.lang.CharSequence) "10.14.314.3", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("CorporationOracle", "noitaroproC elcarO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        java.lang.String str14 = javaVersion12.toString();
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion[] javaVersionArray16 = new org.apache.commons.lang3.JavaVersion[] { javaVersion6, javaVersion11, javaVersion12, javaVersion15 };
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray16);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7" + "'", str14.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertNotNull(javaVersionArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.21.71.71.6" + "'", str17.equals("1.21.71.71.6"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.21.71.71.6" + "'", str18.equals("1.21.71.71.6"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", 66);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 30, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-1", "::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "                                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "10.0a100.0a-1.0a100.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "10 100 100 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, (long) 4, 8L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "1.4", 1, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str4.equals("m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.314.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Corporation Oracl");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Oracle Corporation # a       a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation # a       a" + "'", str2.equals("Oracle Corporation # a       a"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0 0 30", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 30" + "'", str2.equals("0 0 30"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " a       ", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 66, 23);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie", "oR...", "     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                       Mac/OS/X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac/OS/X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "-1.0a119.0a100.0a100.0a10.0a-1.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 0, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 63, 30);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "1.11.11.11.11.11.11.1  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.11.11.11.11.11.11.1  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1" + "'", str3.equals("1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.11.11.11.11.11.11.1  ", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.11.11.11.11.11.11.1  " + "'", str3.equals("1.11.11.11.11.11.11.1  "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "     ooo", (java.lang.CharSequence) "x86_6", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(63, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 63 + "'", int3 == 63);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 119 + "'", int1 == 119);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("2341421404104-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2341421404104-1" + "'", str1.equals("2341421404104-1"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "a    4", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("# a       a", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("##a# # # #a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##a# # # #a" + "'", str1.equals("##a# # # #a"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("##a# # # #a", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##a# # # #a" + "'", str2.equals("##a# # # #a"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00140.01", (java.lang.CharSequence) "                                                 1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" a       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" a       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("040430", (int) '#', 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "21.041.0421.040.0432.04119.0", (int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Corporation # a       a", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Library/JavMac/OS/X/Library/Jav", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/JavMac/OS/X/Library/Jav                                                                    " + "'", str2.equals("/Library/JavMac/OS/X/Library/Jav                                                                    "));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0#10.0#100.0#100.0#119.0#-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0#10.0#100.0#100.0#119.0#-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.11.11.11.11.11.11.1  ", 119.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 119.0d + "'", double2 == 119.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/users/sophie", "                                                 1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("::::::::::::::::::::...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::..." + "'", str2.equals("::::::::::::::::::::..."));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.14.", (java.lang.CharSequence) "demixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("040430");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("040430");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("040430");
        java.math.BigDecimal bigDecimal7 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("040430");
        java.math.BigDecimal bigDecimal9 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("040430");
        java.math.BigDecimal[] bigDecimalArray10 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5, bigDecimal7, bigDecimal9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray10);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimal7);
        org.junit.Assert.assertNotNull(bigDecimal9);
        org.junit.Assert.assertNotNull(bigDecimalArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4043040430404304043040430" + "'", str11.equals("4043040430404304043040430"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/var/folder:fc0000gn/T/", "sophie", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folder:fc0000gn/T/" + "'", str3.equals("/var/folder:fc0000gn/T/"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("htt1\n.\n7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "htt1.7" + "'", str1.equals("htt1.7"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 0, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1.0#10.0#100.0#100.0#119.0#-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#10.0#100.0#100.0#119.0#-1.0" + "'", str1.equals("-1.0#10.0#100.0#100.0#119.0#-1.0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VM" + "'", str1.equals("VM"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/soph", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " a       ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "040430", "100 10 10 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/JavMac/OS/X/Library/Jav", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "100 10 10 -1 -1 -1", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("C orporation   O racle", (int) (short) 0, "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C orporation   O racle" + "'", str3.equals("C orporation   O racle"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                            # a       a                                             ", (int) ' ', "8 0 100 100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                            # a       a                                             " + "'", str3.equals("                                            # a       a                                             "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 23, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Corporation Oracl", " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Corporation Oracl" + "'", str2.equals("Corporation Oracl"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "0#0#30");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                ", "10410041004-1", 63);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("demixed modemixed modemixed modemixed modemixed mode", "-1.0#10.0#100.0#100.0#119.0#-1.0", "Corporation # a       a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "demixed modemixed modemixed modemixed modemixed mode" + "'", str3.equals("demixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_64", (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                       Mac/OS/X                                                        ", (int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("htt1\n.\n7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7\n.\n1tth" + "'", str1.equals("7\n.\n1tth"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        char[] charArray3 = new char[] { '#' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#" + "'", str7.equals("#"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("#", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0", "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 10, 5);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 3, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", "1\n.\n7");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '#', 119.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 119.0d + "'", double3 == 119.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 26, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                          " + "'", str3.equals("                          "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mac/OS/X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac/OS/X" + "'", str1.equals("Mac/OS/X"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0.1-40.0140.00140.1-40.00140.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1-40.0140.00140.1-40.00140.01" + "'", str1.equals("0.1-40.0140.00140.1-40.00140.01"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", (java.lang.CharSequence) "Java Platform API Specification", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "C#orporation# #O#racle", (java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Corporation # a       a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File[] fileArray3 = new java.io.File[] { file0, file1, file2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(fileArray3);
        org.junit.Assert.assertNotNull(file0);
        org.junit.Assert.assertNotNull(file1);
        org.junit.Assert.assertNotNull(file2);
        org.junit.Assert.assertNotNull(fileArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 30, 10);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) (byte) 1, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a # # # 4", ":");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "US");
        java.lang.String[] strArray11 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray11, strArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray13);
        java.lang.String[] strArray20 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.stripAll(strArray20, "/Users/sophie");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray13, strArray22);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray22, "/Users/sophie");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray25, ' ');
        try {
            java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("####################################################################################################", strArray5, strArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Corporation Oracle" + "'", str23.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + " Oracle Corporation # a       a" + "'", str27.equals(" Oracle Corporation # a       a"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("#4a4 4 4 4a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str9.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.1-a0.01a0.001a0.001a0.911a0.1-", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8" + "'", str1.equals("1.7.0_8"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("     ...", "                                                 1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     ..." + "'", str2.equals("     ..."));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", "/Users/soph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaa", 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("6_68x");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_8", "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8" + "'", str2.equals("1.7.0_8"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre " + "'", str2.equals(" /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.3", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "CorporationxOracle", (java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(":", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", 4, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479" + "'", str4.equals(":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "040430");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0.0", (java.lang.CharSequence) "a # # # 4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("46_68x", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x" + "'", str2.equals("46_68x"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), 0.0d, (double) 31);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("# a       a", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/JavMac/OS/X/Library/Jav                                                                    ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/T/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/T/ng0000cf:redlof/rav/" + "'", str1.equals("/T/ng0000cf:redlof/rav/"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 1.1" + "'", str2.equals("                                                                                                 1.1"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("8 0 100 100", (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.1-a0.01a0.001a0.001a0.911a0.1-", "", (int) (short) 100, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0." + "'", str4.equals("0."));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1.0#10.0#100.0#100.0#119.0#-1.0", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray16 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "/Users/sophie");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray9, strArray18);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray9);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "1.11.11.11.11.11.11.1  ");
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray23);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Corporation Oracle" + "'", str19.equals("Corporation Oracle"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", (java.lang.CharSequence) "10.14.314.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("eihpos", 21, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444eihpos" + "'", str3.equals("444444444444444eihpos"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray1, strArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) (byte) 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ":" + "'", str8.equals(":"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.314.3", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.11.11.11.11.11.11.1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.11.11.11.11.11.11.1  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.1", 0, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) 'a', 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "oR...", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                          ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", "040430");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   ...", 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                 1.4", "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..." + "'", str4.equals("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..."));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", (java.lang.CharSequence) "Corporation Oracle", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray16 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "/Users/sophie");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray9, strArray18);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray9);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "1.11.11.11.11.11.11.1  ");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, "1.4", 1, 0);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Corporation Oracle" + "'", str19.equals("Corporation Oracle"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(" Oracle Corporation # a       a", 26, "Corporation Oracle");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " Oracle Corporation # a       a" + "'", str3.equals(" Oracle Corporation # a       a"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.awt.CGraphicsEnvironment", "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie", "040430");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4', (int) (byte) -1, 66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        char[] charArray8 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "CorporationxOracle", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "# a       a" + "'", str10.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US " + "'", str1.equals(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##", "UTF-8");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/T/ng0000cf:redlof/rav/", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0", (java.lang.CharSequence) "##a# # # #a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("2sU80-b//");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2sU80-b//" + "'", str1.equals("2sU80-b//"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                        ", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "# a       ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Platform API Specification" + "'", str1.equals("java Platform API Specification"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " a       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.1-a0.01a0.001a0.001a0.911a0.1-", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "edom dexim", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::::::::::::::::::::::" + "'", str1.equals("::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.CharSequence charSequence3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##", "UTF-8");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence3, (java.lang.CharSequence[]) strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/T/ng0000cf:redlof/rav/", (java.lang.CharSequence[]) strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo", (java.lang.CharSequence[]) strArray6);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/users/sophie", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "/", (int) (byte) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "10#1", (int) (byte) 100, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0", (java.lang.CharSequence[]) strArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", strArray2, strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str14.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::::::::::::::::::::::" + "'", str1.equals("::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        float[] floatArray4 = new float[] { 'a', (byte) 1, '#', (short) 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97.041.0435.040.0" + "'", str8.equals("97.041.0435.040.0"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("X86_64");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "htt1\n.\n7", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0 0 30", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 0 30" + "'", str2.equals("0 0 30"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100 10 10 -1 -1 -1", (java.lang.CharSequence) "51.0", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', (int) (short) 100, 6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "C orporation   O racle", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "##a# # # #a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                     -1", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     -" + "'", str2.equals("                     -"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-8", (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Corporation Oracle", "                                ", "##");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X86_64", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64" + "'", str3.equals("X86_64"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, (int) (byte) 100, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "htt1\n.\n7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("                                 Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_8", "Java Virtual Machine Specification", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8" + "'", str3.equals("1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) " Oracle Corporation # a       a");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "x86_6" + "'", charSequence2.equals("x86_6"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.1-40.0140.00140.1-40.00140.01", 0, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.1-40.0140.00140.1-40.00" + "'", str3.equals("0.1-40.0140.00140.1-40.00"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("CorporationOracle");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CorporationOracle\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("oRACLE cORPORATION", "10410041004-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.awt.CGraphicsEnvironment", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double[] doubleArray6 = new double[] { 10.0d, 100L, (byte) -1, (short) 100, 10.0f, (-1.0f) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04100.04-1.04100.0410.04-1.0" + "'", str8.equals("10.04100.04-1.04100.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a100.0a-1.0a100.0a10.0a-1.0" + "'", str10.equals("10.0a100.0a-1.0a100.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folder:fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10#1", "Java(TM) SE Runtime Environment");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##a# # # #a", '#');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10 100 100 -1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("X86_64", "UF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "htt1.7", (java.lang.CharSequence) "0.", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("040430");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "040430" + "'", str1.equals("040430"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##a# # # #a", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Corporation Oracle", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("a    4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "C#orporation# #O#racle");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 22 + "'", int1 == 22);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaa", 66);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("7\n.\n1tth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7\n.\n1tth" + "'", str1.equals("7\n.\n1tth"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##", "UTF-8");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/T/ng0000cf:redlof/rav/", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.11.11.11.11.11.11.1  ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("X86_6", "0.1-a0.01a0.001a0.001a0.911a0.1-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_6" + "'", str2.equals("X86_6"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.2", "/Users/sophie", 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::::::::::::..." + "'", str1.equals("::::::::::::::::::::..."));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00140.01", "10.04100.04-1.04100.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0#0#30", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  0#0#30  " + "'", str3.equals("  0#0#30  "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("CorporationxOracle", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("100 10 10 -1 -1 -1", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 10 10 -1 -1 -1" + "'", str2.equals("100 10 10 -1 -1 -1"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10#1", "1.7", (int) (short) 1, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "11.71" + "'", str4.equals("11.71"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44", (java.lang.CharSequence) "0.1-40.0140.00140.1-40.00");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                CORPORATIONXORACLE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CORPORATIONXORACLE" + "'", str1.equals("CORPORATIONXORACLE"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("6_68x", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6_68x" + "'", str3.equals("6_68x"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..." + "'", str2.equals("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..."));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        char[] charArray5 = new char[] { ' ', '4', '4', ' ', '#' };
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("   ...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   ..." + "'", str2.equals("   ..."));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10.04100.04-1.04100.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4043040430404304043040430", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         4043040430404304043040430" + "'", str2.equals("                                         4043040430404304043040430"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("        ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4, (long) 100, (long) 66);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10.04100.04-1.04100.0410.04-1.0", 100, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) (short) -1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#10.0#100.0#100.0#119.0#-1.0" + "'", str11.equals("-1.0#10.0#100.0#100.0#119.0#-1.0"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Mac/OS/X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0", 25, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "::::::::::::::::::::...", (java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Corporation Oracle");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, 0);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0#0#30", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "  0#0#30  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Corporation Oracle", "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 31, 30);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "x86_6");
        java.lang.String[] strArray18 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int21 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray18, strArray20);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray20);
        java.lang.String[] strArray27 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray27, "/Users/sophie");
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray20, strArray29);
        int int31 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray20);
        boolean boolean32 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray20);
        java.lang.String[] strArray34 = org.apache.commons.lang3.StringUtils.stripAll(strArray20, "1.11.11.11.11.11.11.1  ");
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/soph", strArray4, strArray34);
        int int36 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Corporation Oracle" + "'", str10.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Corporation Oracle" + "'", str30.equals("Corporation Oracle"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "/Users/soph" + "'", str35.equals("/Users/soph"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                                 1.1", (java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) (-1L), 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio", 119, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "8 0 100 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " ", 119, (int) 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, " ", 119, (int) 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", strArray2, strArray9);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "040430", (int) (byte) -1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479" + "'", str15.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("a    4", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", (int) (short) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4" + "'", str4.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#", (java.lang.CharSequence) "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Vi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                     ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " Oracle Corporation # a       ae");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     " + "'", str3.equals("                     "));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("444444444444444eihpos", "0.1-40.0140.00140.1-40.00140.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444eihpos" + "'", str2.equals("444444444444444eihpos"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "1.5", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) "Oracle Corporation # a       a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0" + "'", str6.equals("0.0"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("US", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "11.71", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java Virtual Machine Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1" + "'", str2.equals("htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                 1.1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("demixed modemixed modemixed modemixed modemixed mode", 63);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 63 + "'", int2 == 63);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("noitaroproC elcarO", "0.1-a0.01a0.001a0.001a0.911a0.1-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcarO" + "'", str2.equals("noitaroproC elcarO"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.1-40.0140.00140.1-40.00140.01", 5, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.1-40.0140.00140.1-40.00140.01" + "'", str3.equals("0.1-40.0140.00140.1-40.00140.01"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) " /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("44444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.4444444E7f + "'", float1.equals(4.4444444E7f));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav                                                                    ", (java.lang.CharSequence) "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10.0a100.0a-1.0a100.0a10.0a-1.0", "  0#0#30  ", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0a100.0a-1.0a100.0a10.0a-1.0" + "'", str4.equals("10.0a100.0a-1.0a100.0a10.0a-1.0"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "10.04100.04-1.04100.0410.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("US", "040430");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("6_68x", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6_68x" + "'", str2.equals("6_68x"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4043040430404304043040430", (java.lang.CharSequence) "10 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "################################", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "oR...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "7\n.\n1tth", (java.lang.CharSequence) "8 0 100 100", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444444444444eihpos", charSequence1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/soph", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/soph" + "'", str2.equals("s/soph"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "0.1-40.0140.00140.1-40.00");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "::::::::::::::::::::::::::::::");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Corporation Oracle");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', 0, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1\n.\n7", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " " + "'", str5.equals(" "));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("  0#0#30  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  0#0#30 " + "'", str1.equals("  0#0#30 "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("a4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A4 4 4 4a4#" + "'", str1.equals("A4 4 4 4a4#"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("java Platform API Specification", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatform API Specifica Plavaj" + "'", str2.equals("tionatform API Specifica Plavaj"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "s/soph");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 66, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 66 + "'", int3 == 66);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "8 0 100 100", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("oR...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oR...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.14.314.3", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.3" + "'", str2.equals("10.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.3"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                       Mac/OS/X", "Mac/OS/X", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                         4043040430404304043040430", 26, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               404304043040430404304043" + "'", str3.equals("               404304043040430404304043"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", 21, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                       Mac/OS/X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double[] doubleArray6 = new double[] { 10.0d, 100L, (byte) -1, (short) 100, 10.0f, (-1.0f) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04100.04-1.04100.0410.04-1.0" + "'", str8.equals("10.04100.04-1.04100.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }
}

