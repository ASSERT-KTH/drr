import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "-1.0a10.0a100.0a100.0a119.0a-1.", "##a# # # #a");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "10.14.310.14.310.14.31010.14.310.14.310.14.310");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6, 119.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          ", "10.14.314.3", (int) (short) 1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "         Mac/OS/X", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwa/Users/sophie/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph" + "'", str1.equals("s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7", "1.21.71.71.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80                                                                                                 ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        char[] charArray3 = new char[] { '#' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0", charArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 0, 308);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("         ", 25, "                       Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                         " + "'", str3.equals("                         "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "##########", "#########################################10#100#100#-1##########################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio", "", 63);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.1-40.0140.00140.1-40.00140.01");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE Runtime Environment", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 17");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                     ", (java.lang.CharSequence) "nment", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("              /Library/JavMac/OS/X/Library/Jav", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav" + "'", str2.equals("              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "vuSERSvSOP", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("a    4", (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("or..", "# a  ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "or.." + "'", str2.equals("or.."));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "#oracle corporation## a       a", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean6 = javaVersion1.atLeast(javaVersion2);
        boolean boolean7 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean10 = javaVersion0.atLeast(javaVersion8);
        java.lang.String str11 = javaVersion8.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7" + "'", str11.equals("1.7"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#-110#100#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#-110#100" + "'", str1.equals("#-110#100"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0" + "'", str6.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0" + "'", str9.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.110.0100.0-1.0100.010.0-1.010.0100.0-1.0100.010.0-1.010.0100.0-1.0100.010.0-1.010.0", "....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.110.0100.0-1.0100.010.0-1.010.0100.0-1.0100.010.0-1.010.0100.0-1.0100.010.0-1.010.0" + "'", str2.equals("1.110.0100.0-1.0100.010.0-1.010.0100.0-1.0100.010.0-1.010.0100.0-1.0100.010.0-1.010.0"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment", (java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 747 + "'", int2 == 747);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Corporation # a       a", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T/" + "'", str1.equals("/var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T/"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "a    4               ", (java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 10, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        char[] charArray8 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "# a       a" + "'", str10.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "##a# # # #a" + "'", str14.equals("##a# # # #a"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Lib" + "'", str1.equals("Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Lib"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("emixed modemixed modemixed mode", 32, 25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("##", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##" + "'", str2.equals("##"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.0a0.0a-/Users/sophie0.0a0.0a-", (java.lang.CharSequence) "aaaaaaaaaaaaaaoR..aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("8 0 100 100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Corporation Oracle", "");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                       Mac/OS/X                                                        ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "10");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java HotSpot(TM) 64-Bit Server VM", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str9.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "uTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment", (int) (byte) 0, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java#          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Corpor tionOr cle");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        float[] floatArray5 = new float[] { 1, 52, 63.0f, 2, 55 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a52.0a63.0a2.0a55.0" + "'", str7.equals("1.0a52.0a63.0a2.0a55.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ORACLE4cORPORATIO", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "##", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                    ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL" + "'", str1.equals("/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#aaa a a aaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#aaa a a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.0 100.0 -1.0 100.0 10.0 -1.0", "                                                       Mac/OS/X                                                        ", "              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean11 = javaVersion4.atLeast(javaVersion7);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.1" + "'", str8.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("A    4", "                                                 1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A    4" + "'", str2.equals("A    4"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("23#1#21#0#10#-1");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("US", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 12 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "vironmentdemixed modemixe", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph", "x86_64");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/####################################################################################################var####################################################################################################/####################################################################################################folders####################################################################################################/####################################################################################################_####################################################################################################v####################################################################################################/####################################################################################################6####################################################################################################v####################################################################################################597####################################################################################################zmn####################################################################################################4####################################################################################################_####################################################################################################v####################################################################################################31####################################################################################################cq####################################################################################################2####################################################################################################n####################################################################################################2####################################################################################################x####################################################################################################1####################################################################################################n####################################################################################################4####################################################################################################fc####################################################################################################0000####################################################################################################gn####################################################################################################/####################################################################################################T####################################################################################################/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/uSERS/SOP", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOP" + "'", str2.equals("/uSERS/SOP"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10a1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1" + "'", str2.equals("10a1"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                 \n                                                  ", (java.lang.CharSequence) "                                         #A4 4 4 4A4", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("444444444444444eihpos", "                                                 \n                                                  ", "CorporationxOracle");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444eihpos" + "'", str3.equals("444444444444444eihpos"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("emixed modemixed modemixed mode", "Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "emixed modemixed modemixed mode" + "'", str2.equals("emixed modemixed modemixed mode"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", (java.lang.CharSequence) "                                                               ", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                        ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("          ", "Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "ers/sophie", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0" + "'", str6.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0" + "'", str9.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "nmen", (java.lang.CharSequence) "A4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("CorporationOracle", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CorporationOracle" + "'", str2.equals("CorporationOracle"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 26, 96);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 21, 3.0f, (float) 3931);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3931.0f + "'", float3 == 3931.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#Oracle Corporation## a       a", 22, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a       a" + "'", str3.equals("a       a"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("8#0#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8#0#100#100" + "'", str1.equals("8#0#100#100"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Mac/OS/Xmodemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) "/####################################################################################################var####################################################################################################/####################################################################################################folders####################################################################################################/####################################################################################################_####################################################################################################v####################################################################################################/####################################################################################################6####################################################################################################v####################################################################################################597####################################################################################################zmn####################################################################################################4####################################################################################################_####################################################################################################v####################################################################################################31####################################################################################################cq####################################################################################################2####################################################################################################n####################################################################################################2####################################################################################################x####################################################################################################1####################################################################################################n####################################################################################################4####################################################################################################fc####################################################################################################0000####################################################################################################gn####################################################################################################/####################################################################################################T####################################################################################################/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", 25, 119);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0.0a0.0a-1.0a1.0a8.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a0.0a-1.0a1.0a8.0" + "'", str1.equals("0.0a0.0a-1.0a1.0a8.0"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1.0a119.0a100.0a100.0a10.0a-1.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a119.0a100.0a100.0a10.0a-1.0" + "'", str2.equals("-1.0a119.0a100.0a100.0a10.0a-1.0"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US " + "'", str1.equals("US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", "46_68x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode" + "'", str2.equals("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "30844");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                 1.1", (int) '4', 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("44444444444444444444444444444444444", "             CorporationOracle             CorporationOracle             CorporationOracle             CorporationOracl");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# a       a", "/var/folder:fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ORACLE4cORPORATION", charSequence1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "m/jreJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                    ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4 4a4#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                       Mac OS X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR", "     ooo", "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR" + "'", str3.equals("CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/t/ng0000cf:redlof/rav/", "US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", (-1));
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.5", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/Library/JavMac/OS/X/Library/Jav                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java(TM) SE Runtime Environment", "                                                       Mac/OS/X                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 10, 5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 8, 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "8a0a100a100" + "'", str15.equals("8a0a100a100"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("101", "10#100#100#-1####################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "101" + "'", str2.equals("101"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaa# a       a", "jre", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "040430" + "'", str7.equals("040430"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 30" + "'", str9.equals("0 0 30"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#0#30" + "'", str12.equals("0#0#30"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("444444444444444444444444444444444444441.7.0_80", "....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.j", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#100#100#-1" + "'", str9.equals("10#100#100#-1"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "/", (int) (byte) 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          ", "10.14.314.3", (int) (short) 1);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", (java.lang.CharSequence[]) strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10 1", strArray4, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10 1" + "'", str12.equals("10 1"));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8", (java.lang.CharSequence) "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "Corporation Oracle");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":/u...", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10#100#100#-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 0, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("       24.80-b11       ", "0.14.", "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       24.80-b11       " + "'", str4.equals("       24.80-b11       "));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4#43#4#43#4#43#4#43#4#43#", (java.lang.CharSequence) "0 0 30");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] { "", "", "", "hi!" };
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "", charSequenceArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray5, "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray5, 'a', 17, 0);
        org.junit.Assert.assertNotNull(charSequenceArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librva/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librva/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librhi!" + "'", str8.equals("va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librva/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librva/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librhi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("#oracle corporation## a       a", "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#oracle corporation##" + "'", str2.equals("#oracle corporation##"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.j" + "'", str1.equals("....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.j"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolkit", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                 Java HotSpot(TM) 64-Bit Server VM", "                                ", 0, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                          Java HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("                                          Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("21.0 1.0 21.0 0.0 32.0 119.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          ", "10.14.314.3", (int) (short) 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str1.equals("Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0a52.0a63.0a2.0a55.0", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a52.0a63.0a2.0a55.0" + "'", str3.equals("1.0a52.0a63.0a2.0a55.0"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "             CorporationOracle             CorporationOracle             CorporationOracle             CorporationOracl", 1, 55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100 10 10 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 10 10 -1 -1 -1" + "'", str1.equals("100 10 10 -1 -1 -1"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0.0a0...", "CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0..." + "'", str2.equals("0.0a0..."));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10410041004-1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "#Oracle Corporation## a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1#10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav              /Library/JavMac/OS/X/Library/Jav", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                 \n                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                 \n                                                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                       Mac/OS/X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "ORACLE CORPORATION # A       A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        float[] floatArray5 = new float[] { 0.0f, 0.0f, (-1.0f), 1, 8L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (short) 0, (-1));
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0a0.0a-1.0a1.0a8.0" + "'", str7.equals("0.0a0.0a-1.0a1.0a8.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 8.0f + "'", float13 == 8.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0a0.0a-1.0a1.0a8.0" + "'", str15.equals("0.0a0.0a-1.0a1.0a8.0"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("444444444444444444444444444444444444441.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 66L, 0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 66.0f + "'", float3 == 66.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        char[] charArray3 = new char[] { '#' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#" + "'", str7.equals("#"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "# a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "444444444444444444444444444444444444441.7.0_80", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("     ooo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ooo" + "'", str1.equals("ooo"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "a    4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(308, 8, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 308 + "'", int3 == 308);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("elcarOxnoitaroproC");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("101", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 101.0f + "'", float2 == 101.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 119.0d + "'", double11 == 119.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) '#', 55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("java Platform API Specification", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Platform API Specification" + "'", str2.equals("java Platform API Specification"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#                                                   " + "'", str1.equals("#                                                   "));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("ers/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ers/sophie" + "'", str1.equals("Ers/sophie"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10a1", (java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        float[] floatArray6 = new float[] { 21, 1.0f, 21, 0L, ' ', 119L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str8.equals("21.041.0421.040.0432.04119.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "21.0a1.0a21.0a0.0a32.0a119.0" + "'", str10.equals("21.0a1.0a21.0a0.0a32.0a119.0"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Oracle Corporation # a       a");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "A4 4 4 4A4#                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac/OS/X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPH" + "'", str1.equals("S/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPHS/SOPH"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0.0a0.0a-/Users/sophie0.0a0.0a-", "/Library/JavMac/OS/X/Library/Jav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0.0a-/Users/sophie0.0a0.0a-" + "'", str2.equals("0.0a0.0a-/Users/sophie0.0a0.0a-"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre", "::::::::::::::::::::::::::::::", (int) (byte) -1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "##########", "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) ' ', 30);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', (int) (byte) 0, (int) (byte) -1);
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410041004-1" + "'", str12.equals("10410041004-1"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Corporation Oracl", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "VM", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("         ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("A    4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a    4" + "'", str1.equals("a    4"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "8#0#100#100", "                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed mode", (int) (byte) 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 10, 5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 63, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 63");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8#0#100#100" + "'", str14.equals("8#0#100#100"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/JRE" + "'", str1.equals("/JRE"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int[] intArray6 = new int[] { 23, (short) 1, 21, (short) 0, (byte) 10, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2341421404104-1" + "'", str8.equals("2341421404104-1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaa10#1", "nment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa10#1" + "'", str2.equals("aaaa10#1"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("a    4", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a    4" + "'", str3.equals("a    4"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1.0 10.0 100.0 100.0 119.0 -1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 10.0 100.0 100.0 119.0 -1.0" + "'", str1.equals("-1.0 10.0 100.0 100.0 119.0 -1.0"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("444444444444444eihpos", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", 503);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) " a      ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        short[] shortArray2 = new short[] { (short) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 1" + "'", str4.equals("10 1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1" + "'", str8.equals("10#1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a1" + "'", str10.equals("10a1"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                         #A4 4 4 4A4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("nmen", "....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.jdk/..EO_EOs/h.m_/j._....0_80.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nmen" + "'", str2.equals("nmen"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.4...a0.001a0.001a0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4...a0.001a0.001a0.9" + "'", str1.equals("1.4...a0.001a0.001a0.9"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("10#100#100#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#100#100#-1" + "'", str1.equals("10#100#100#-1"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# a       a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 18 + "'", int5 == 18);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "              ", 747);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                       Mac OS X", (java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "# a  ...", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/t/ng0000cf:redlof/rav/", "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/t/ng0000cf:redlof/r4v/" + "'", str3.equals("/t/ng0000cf:redlof/r4v/"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.21");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.21" + "'", str1.equals("1.21"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Corporation Oracle", 8);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, " a       ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...dk1.7.0_80.jdk/Contents/Home/jre", (float) 66L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 66.0f + "'", float2 == 66.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("emixed modemixed modemixed mode", "# a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                 \n                                                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, 100.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("44444444444444444cleation OraCorpor44444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444cleation OraCorpor44444444444444444" + "'", str1.equals("44444444444444444cleation OraCorpor44444444444444444"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("...a0.001a0.001a0.911a0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...a0.001a0.001a0.911a0.1-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        java.lang.String str9 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean14 = javaVersion10.atLeast(javaVersion13);
        boolean boolean15 = javaVersion6.atLeast(javaVersion13);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "jre", (java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Corporation Oracle", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 31, 30);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "x86_6");
        java.lang.String[] strArray17 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int20 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray17, strArray19);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray19);
        java.lang.String[] strArray26 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.stripAll(strArray26, "/Users/sophie");
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray19, strArray28);
        int int30 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray19);
        boolean boolean31 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray19);
        java.lang.String[] strArray33 = org.apache.commons.lang3.StringUtils.stripAll(strArray19, "1.11.11.11.11.11.11.1  ");
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/soph", strArray3, strArray33);
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str39 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 0, (int) (short) -1);
        java.lang.String str41 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Corporation Oracle" + "'", str9.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Corporation Oracle" + "'", str29.equals("Corporation Oracle"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "/Users/soph" + "'", str34.equals("/Users/soph"));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Corporation Oracle" + "'", str41.equals("Corporation Oracle"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4    eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/" + "'", str1.equals("4    eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0410.04100.04100.04119.04-1.0" + "'", str12.equals("-1.0410.04100.04100.04119.04-1.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        short[] shortArray2 = new short[] { (short) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 66, 30);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 1" + "'", str4.equals("10 1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1" + "'", str8.equals("10#1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 10 + "'", short14 == (short) 10);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 1 + "'", short15 == (short) 1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 10 + "'", short16 == (short) 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j", ":/u...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j" + "'", str2.equals("....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "cleation OraCorpor", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "cleation OraCorpor" + "'", charSequence2.equals("cleation OraCorpor"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("            10#100#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#100#100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Corporation Oracl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Corporation Oracl" + "'", str1.equals("Corporation Oracl"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(26, (int) (short) 1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "emixed modemixed modemixed mode", (java.lang.CharSequence) "10410041004-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##a# # # #a", (java.lang.CharSequence) "a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', 0, (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "corporationxoracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                 1.4", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwa/Users/sophie/Library/Java/Exten", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#aaa a a aa" + "'", str17.equals("#aaa a a aa"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "                                ", (int) (short) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("emixed modemixed modemixed mode", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4 4a4#", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1\n.\n7", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1\n.\n7" + "'", str2.equals("1\n.\n7"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/uSERS/SOP");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".21", "10a100a100a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Corporation Oracle");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Corporation # a       a");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8L, 30.0d, (double) 26);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("COracleCorporation#aaeorporationOracleCorporation#aaeOracleCorporation#aaeOOracleCorporation#aaeracle");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "11.71", (java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Library/JavMac/OS/X/Library/Jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/JavMac/OS/X/Library/Jav" + "'", str1.equals("/Library/JavMac/OS/X/Library/Jav"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("ORACLE4cORPORATION", (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U" + "'", str2.equals("S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "1.7", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "m/jreJ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 96, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/###############################################################################################" + "'", str3.equals("/###############################################################################################"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 32, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "....0_80.JDK/CONTENTS/HOME/JRE....0_80.JDK/CONTENTS/HOME/JRE....0_80.JDK/CONTENTS/HOME/JRE....0_80.J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) 4, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8 0 100 100" + "'", str10.equals("8 0 100 100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8#0#100#100" + "'", str12.equals("8#0#100#100"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Lib", (int) (short) 100, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nes/jdk1.7.0_80.jdk/C" + "'", str3.equals("nes/jdk1.7.0_80.jdk/C"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "97.0 1.0 35.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00", (java.lang.CharSequence) "nment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", (java.lang.CharSequence) "#aaa a a aaaaaaaaaaaaaaaaa", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray15 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "/Users/sophie");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray8, strArray17);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray17);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Corporation Oracle" + "'", str18.equals("Corporation Oracle"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3, 119.0d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 119.0d + "'", double3 == 119.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(2L, (long) 6, (long) 63);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("nmen", "##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nmen" + "'", str2.equals("nmen"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "a4 4 4 4a4#", (-1));
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a4 4 4 4a4#", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80-b15" + "'", str6.equals("1.7.0_80-b15"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "VM", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/t/ng0000cf:redlof/rav/", (java.lang.CharSequence) "m/jreJ", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 10, (int) (byte) 0);
        java.lang.Class<?> wildcardClass16 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str9.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str11.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 22, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U" + "'", str2.equals("S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "2341421404104-1", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8L, 21.0f, 4.0430403E23f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0430403E23f + "'", float3 == 4.0430403E23f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4444444s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph444444444444444444444444444444        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 6, 747);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0" + "'", str7.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0" + "'", str9.equals("0.0"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("30844");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3084" + "'", str1.equals("3084"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("21.041.0421.040.0432.04119.0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("3084", "97.0#63.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3084" + "'", str2.equals("3084"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "CorporationxOracle", "/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        float[] floatArray4 = new float[] { 'a', (byte) 1, '#', (short) 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 97.0f + "'", float5 == 97.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0 1.0 35.0 0.0" + "'", str9.equals("97.0 1.0 35.0 0.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97.041.0435.040.0" + "'", str11.equals("97.041.0435.040.0"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "                                                 1.4", "10#100#100#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("444444444444444444444444444444444444441.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444441.7.0_80" + "'", str1.equals("444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(503, 308, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10.0 100.0 -1.0 100.0 10.0 -1.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java#          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0 100.0 -1.0 100.0 10.0 -1.0" + "'", str2.equals("10.0 100.0 -1.0 100.0 10.0 -1.0"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "::::::::::::::::::::::::::::::", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S US US US US US US US US US US US " + "'", str2.equals("S US US US US US US US US US US US "));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" # a       a", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " # a       a" + "'", str2.equals(" # a       a"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Corporation Oracle", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 31, 30);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "x86_6");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", " Oracle Corporation # a       a", (int) (short) 0);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10 100 100 -1", (java.lang.CharSequence[]) strArray15);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("# a       a", "1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0", (int) (byte) 10);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("     ...", strArray15, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/", strArray3, strArray20);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Corporation Oracle" + "'", str9.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "     ..." + "'", str21.equals("     ..."));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "/" + "'", str22.equals("/"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("            10#100#100", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            10#100#100" + "'", str2.equals("            10#100#100"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("7\n.\n1tth", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7\n.\n1tth" + "'", str2.equals("7\n.\n1tth"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("A    4");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100 10 10 -1 -1 -1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 10 10 -1 -1 -1" + "'", str2.equals("100 10 10 -1 -1 -1"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0 0 30", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "32a2a25a1", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM) SE Runtime Environment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1.0a10.0a100.0a100.0a119.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1.0a10.0a100.0a100.0a119.0a-1.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "21.041.0421.040.0432.04119.0", (java.lang.CharSequence) "11.71");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                 \n                                                  ", "10410041004-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0.", 63, 46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        short[] shortArray2 = new short[] { (short) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 66, 30);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 1, 119);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 1" + "'", str4.equals("10 1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1" + "'", str8.equals("10#1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10a1" + "'", str15.equals("10a1"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 10 + "'", short16 == (short) 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.0 100.0 -1.0 100.0 10.0", "ORACLE4cORPORATION", (-1));
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0 100.0 -1.0 100.0 10.0" + "'", str5.equals("10.0 100.0 -1.0 100.0 10.0"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_6", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6                                               " + "'", str2.equals("x86_6                                               "));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "2sU80-b//");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) (byte) 0, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', 1, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0" + "'", str15.equals("0.0"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", (java.lang.CharSequence) "0.1-a0.01a0.001a0.001a0.911a0.1-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("emixed modemixed modemixed mode", 0, "# a  ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "emixed modemixed modemixed mode" + "'", str3.equals("emixed modemixed modemixed mode"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray5 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sophie");
        java.lang.String[] strArray11 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "10.14.3", "1.7" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("1.2", strArray5, strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.2" + "'", str12.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                       Mac/OS/X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4#43#4#43#4#43#4#43#4#43#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#43#4#43#4#43#4#43#4#43#" + "'", str1.equals("4#43#4#43#4#43#4#43#4#43#"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004104104-14-14-1" + "'", str9.equals("1004104104-14-14-1"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', (int) '4', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str1.equals("ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', 0, (-1));
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  0#0#30  ", charArray10);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "97.0#63.0", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "##a# # # #a" + "'", str20.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "##a# # # #a" + "'", str23.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "84041004100", (java.lang.CharSequence) "/Users/sophie/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#01" + "'", str1.equals("1#01"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.0a0.0a-1.0a1.0a8.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479" + "'", str1.equals(":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/Users/sophie" + "'", str3.equals("/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL" + "'", str1.equals("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ", "# a       a");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(13, (int) (short) 1, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1421404104-", (java.lang.CharSequence) "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "or..", (java.lang.CharSequence) "aaaaaaaaaaaaa2sU80-b//aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 35, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "Java HStS St(TM) 64-BSt S Uv U VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        char[] charArray6 = new char[] { ' ', ' ', '4', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " a a4a#" + "'", str10.equals(" a a4a#"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("444444444444444444444444444444444444441.7.0_80", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("8a0a100a100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/Users/sophie", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                        " + "'", str1.equals("                        "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444eihpos", "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "x86_6                                               ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.1", "                          ", (int) (short) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.51.-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.51.-" + "'", str1.equals("1.51.-"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("# a       ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a" + "'", str2.equals("#a"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10a100a100a-1", (java.lang.CharSequence) "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/jre", "44444444", 286);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folder:fc0000gn/T/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "VM", (java.lang.CharSequence) "A4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "VM" + "'", charSequence2.equals("VM"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.3", 11, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "UF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0a0a30");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a0a30" + "'", str1.equals("0a0a30"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("a4 4 4 4a4#                                         ", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4 4 4 4a4#                                         " + "'", str2.equals("a4 4 4 4a4#                                         "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("####################################################################################################", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################################################################" + "'", str2.equals("####################################################################################################"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaoR..aaaaaaaaaaaaaa", (java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SUN.LWAWT.MACOSX.cpRINTERjOB", "ORACLE4cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE4cORPORATION" + "'", str2.equals("ORACLE4cORPORATION"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("8#0#100#100", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8#0#100#100" + "'", str2.equals("8#0#100#100"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                       Mac/OS/X                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                       Mac/OS/X                                                        " + "'", str1.equals("                                                       Mac/OS/X                                                        "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("demixed modemixed modemixed modemixed modemixed mode", "......................................................................................................................................................................................................");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "demixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("demixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Corporation Oracle", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 31, 30);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray0 = new org.apache.commons.lang3.SystemUtils[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray0);
        org.junit.Assert.assertNotNull(systemUtilsArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", (java.lang.CharSequence) "CLEATION oRAcORPOR", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("            10#100#100", "23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("http://javaoraclecom/", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                                 1.1", (java.lang.CharSequence) "m/jreJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 31, 22);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0a0a30", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a0a30" + "'", str2.equals("0a0a30"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("#oracle corporation##", "#x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#oracle corporation##" + "'", str2.equals("#oracle corporation##"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#                                                   ", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "     ooo", (java.lang.CharSequence) "                                          Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "     ooo" + "'", charSequence2.equals("     ooo"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044", (java.lang.CharSequence) "nes/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.310.14.310.14.31010.14.310.14.310.14.310", "oR...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#                                                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 7, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0" + "'", str12.equals("0.0"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "#aaa a a aaaaaaaaaaaaaaaaa", 55);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1", charArray9);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 30, (int) (byte) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "##a# # # #a" + "'", str20.equals("##a# # # #a"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("CorporationOracle", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CorporationOracle" + "'", str4.equals("CorporationOracle"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "84041004100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", 63);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("CorporationOracle", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("23#1#21#0#10#-1", strArray5, strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "...dk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CorporationOracle" + "'", str10.equals("CorporationOracle"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "23#1#21#0#10#-1" + "'", str11.equals("23#1#21#0#10#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment", (java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server VM", 747);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 720 + "'", int3 == 720);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("vuSERSvSOP", "  0#0#30 ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", 7);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str8.equals("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/T/ng0000cf:redlof/rav/", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("...a0.001a0.001a0.911a0.1-", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 0, 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0 0 30" + "'", str6.equals("0 0 30"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("CorporationxOracle");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 119.0d + "'", double10 == 119.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 119.0d + "'", double12 == 119.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#oracle corporation##", charSequence1, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("2341421404104-1", ".21");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2341421404104-1" + "'", str2.equals("2341421404104-1"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    " + "'", str1.equals("                                                    "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/soph", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/soph" + "'", str2.equals("/Users/soph"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.00140.1-40.00140.01", (java.lang.CharSequence) "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...dk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/var/folders/_v/6v597zmn _v31cq2n2x1n fc0000gn/T/Users/sophie", (java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librva/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librva/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Librhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#1" + "'", str1.equals("10#1"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0.1-40.0140.00140.1-40.00140.01");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.1-40.0140.00140.1-40.00140.01" + "'", str3.equals("0.1-40.0140.00140.1-40.00140.01"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.1-40.0140.00140.1-40.00140.01" + "'", str5.equals("0.1-40.0140.00140.1-40.00140.01"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "htt1\n.\n7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("0.0a0...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a0..." + "'", str1.equals("0.0a0..."));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Corporation Oracl", (java.lang.CharSequence) "-1.0A119.0A100.0A100.0A10.0A-1.0", 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "      " + "'", str1.equals("      "));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) " Oracle Corporation # a       a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_6                                               ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1\n.\n7");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str6 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.1" + "'", str6.equals("1.1"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Library/JavMac/OS/X/Library/Jav                                                                    ", "1.2", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    " + "'", str3.equals("/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    1.2/Library/JavMac/OS/X/Library/Jav                                                                    "));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" a       ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph", (java.lang.CharSequence) "Corporation Oracl");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph" + "'", charSequence2.equals("s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("30844", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0844" + "'", str2.equals("0844"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...dk1.7.0_80.jdk/contents/home/jre", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/T/ng0000cf:redlof/rav/", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "#aaa a a aa", (java.lang.CharSequence) "demixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode                                              ", 5, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "64mixed modemixed modemixe" + "'", str3.equals("64mixed modemixed modemixe"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(26.0d, (double) 23, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        float[] floatArray6 = new float[] { 21, 1.0f, 21, 0L, ' ', 119L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str8.equals("21.041.0421.040.0432.04119.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("eihpos", 3931, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("...dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...dk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("...dk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#a", (java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test455");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str1 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str7 = javaVersion6.toString();
//        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
//        boolean boolean13 = javaVersion9.atLeast(javaVersion11);
//        boolean boolean14 = javaVersion4.atLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        java.lang.Class<?> wildcardClass16 = javaVersion15.getClass();
//        java.lang.String str17 = javaVersion15.toString();
//        java.lang.String str18 = javaVersion15.toString();
//        java.lang.Class<?> wildcardClass19 = javaVersion15.getClass();
//        boolean boolean20 = javaVersion4.atLeast(javaVersion15);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.5" + "'", str17.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.5" + "'", str18.equals("1.5"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#oracle corporation##", (int) (short) -1, "oR..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#oracle corporation##" + "'", str3.equals("#oracle corporation##"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(" Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0.0a0...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("# a  ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(":", (double) 286);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 286.0d + "'", double2 == 286.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("64mixed modemixed modemixe", 2, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mi" + "'", str3.equals("mi"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "corporationxoracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444444", 0, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444" + "'", str3.equals("44444"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("tionatform API Specifica Plavaj");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.11.11.11.11.11.11.1  ", "                                                       Mac/OS/X                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.11.11.11.11.11.1  " + "'", str2.equals("1.11.11.11.11.11.11.1  "));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#4a4 4 4 4a", (java.lang.CharSequence) "0.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) ' ', 30);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 0, (-1));
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  0#0#30  ", charArray9);
        java.lang.Class<?> wildcardClass21 = charArray9.getClass();
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "##a# # # #a" + "'", str19.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0.", (java.lang.CharSequence) "1.0a52.0a63.0a2.0a55.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "cleation OraCorpor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                          Java HotSpot(TM) 64-Bit Server VM", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VMava                                          J" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VMava                                          J"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                       Mac OS X", (int) '#', 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                       Mac/OS/X", "8#0#100#100", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1421404104-", "   ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1421404104-" + "'", str2.equals("1421404104-"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaa# a       a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " a      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "......................................................................................................................................................................................................");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("C orporation   O racle", "CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("44444444444444444cleation OraCorpor44444444444444444", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444cleation OraCorpor44444444444444444" + "'", str2.equals("44444444444444444cleation OraCorpor44444444444444444"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("97.041.0435.040.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00", (java.lang.CharSequence) "s/soph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a", "x86_64", "#4a4 4 4 4a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', 6, 4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) (short) 1, 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', (int) (byte) 100, 31);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sop", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444", "040430");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.LWCToolkit", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "...dk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "44444444444444444cleation OraCorpor44444444444444444", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("            10#100#100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.LWAWT.MACOSX.cpRINTERjOB", (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) 100, (long) 286);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" HotSpot(TM) 64-Bit Server VMava                                          J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HotSpot(TM) 64-Bit Server VMava J" + "'", str1.equals("HotSpot(TM) 64-Bit Server VMava J"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        long[] longArray2 = new long[] { 308, 4 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "30844" + "'", str4.equals("30844"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4L + "'", long5 == 4L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
    }
}

