import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0 0 30");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("8 0 100 100", "X86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8 0 100 100" + "'", str2.equals("8 0 100 100"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java#          ", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(" a      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " a      " + "'", str1.equals(" a      "));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "-1.0 10.0 100.0 100.0 119.0 -1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "1\n.\n7");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" a       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "97.0 1.0 35.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("21.041.0421.040.0432.04119.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str1.equals("21.041.0421.040.0432.04119.0"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "form API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "10#100#100#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "               404304043040430404304043", (java.lang.CharSequence) "1#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "tionatform API Specifica Plavaj");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "10.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.3", 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("# a       ", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "# a       " + "'", str3.equals("# a       "));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "# a       a");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/T/ng0000cf:redlof/rav/", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 15 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/soph", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/soph" + "'", str3.equals("/Users/soph"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sop", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("CLEATION oRAcORPOR", "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", 22);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) ' ', 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.11.11.11.11.11.11.1  ", (java.lang.CharSequence) " ", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10", "0 0 30");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("US", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1421404104-", "elcarOxnoitaroproC");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1421404104-" + "'", str2.equals("1421404104-"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.11.11.11.11.11.11.1  ", "-", "X86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.11.11.11.11.11.11.1  " + "'", str3.equals("1.11.11.11.11.11.11.1  "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1." + "'", charSequence2.equals("-1.0a10.0a100.0a100.0a119.0a-1."));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr" + "'", str1.equals("Va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10#100#100#-1####################################################################################", "", "a4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#100#100#-1####################################################################################" + "'", str3.equals("10#100#100#-1####################################################################################"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                        ", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "        1.7.0_80         ", (java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) (short) 1, 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 97, 2);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 119.0d + "'", double13 == 119.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1.0410.04100.04100.04119.04-1.0" + "'", str19.equals("-1.0410.04100.04100.04119.04-1.0"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "C orporation   O racle", (java.lang.CharSequence) "A4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0.0", "/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 10, 308);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "                                                       Mac/OS/X");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 31, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       Mac OS X" + "'", str3.equals("                       Mac OS X"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                CORPORATIONXORACLE", (java.lang.CharSequence) "####################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL" + "'", str2.equals("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        char[] charArray3 = new char[] { '#' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Corporation Oracle", charArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("51.0", "2sU80-b//", "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("eihpos", (int) (short) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                       Mac/OS/X", 46, 17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         Mac/OS/X" + "'", str3.equals("         Mac/OS/X"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1\n.\n7", "1.2", "Mac OS X");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "     ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.11.11.11.11.11.11.1  ", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", "46_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.11.11.11.11.11.11.1  " + "'", str3.equals("1.11.11.11.11.11.11.1  "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/jre");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ARY/JAVA/J", (java.lang.CharSequence) "Or...", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "               404304043040430404304043", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 21.0f, (double) 30L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.0d + "'", double3 == 30.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        double[] doubleArray3 = new double[] { 0.21f, 10, 1.0f };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', (int) (byte) 10, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "7\n.\n1tth", (java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", (java.lang.CharSequence) "JAVA hOTsPOT(tm) 64-bIT sERVER vm", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "a4 4 4 4a4#", (-1));
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15" + "'", str4.equals("1.7.0_80-b15"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(46, 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence6, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " Oracle Corporation # a       a", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                        ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mode", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, 26.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("# a       a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# a       a" + "'", str1.equals("# a       a"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/soph", "10#100#100#-1####################################################################################", "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/soph" + "'", str3.equals("/Users/soph"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x", (java.lang.CharSequence) "         Mac/OS/X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("....0_80.jdk/contents/home/jre", "/T/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "....0_80.jdk/contents/home/jre" + "'", str2.equals("....0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("corporationxoracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "corporationxoracle" + "'", str1.equals("corporationxoracle"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod", 63);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("CorporationOracle", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("23#1#21#0#10#-1", strArray5, strArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.21.71.71.6", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CorporationOracle" + "'", str10.equals("CorporationOracle"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "23#1#21#0#10#-1" + "'", str11.equals("23#1#21#0#10#-1"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "040430" + "'", str10.equals("040430"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("44444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444" + "'", str1.equals("4444444"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) ' ', 30);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410041004-1" + "'", str12.equals("10410041004-1"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10#100#100#-1" + "'", str16.equals("10#100#100#-1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10 100 100 -1" + "'", str18.equals("10 100 100 -1"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Corporation Oracle", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaa# a       a", (java.lang.CharSequence) "http://java.oracle.com/", 119);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        int[] intArray6 = new int[] { 23, (short) 1, 21, (short) 0, (byte) 10, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) '#', 31);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 97, 4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2341421404104-1" + "'", str8.equals("2341421404104-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "23 1 21 0 10 -1" + "'", str18.equals("23 1 21 0 10 -1"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52, 10.0d, 4.043040430404304E24d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "     ooo", (java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, 100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/t/ng0000cf:redlof/rav/", "...dk1.7.0_80.jdk/contents/home/jre", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "COracleCorporation#aaeorporationOracleCorporation#aaeOracleCorporation#aaeOOracleCorporation#aaeracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-b11", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("7\n.\n1tth", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7\n.\n1tth" + "'", str2.equals("7\n.\n1tth"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Oracle Corporation", "23#1#21#0#10#-1", (-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "23#1#21#0#10#-1" + "'", str4.equals("23#1#21#0#10#-1"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.3", (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mixed mode", "10#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        int[] intArray6 = new int[] { 23, (short) 1, 21, (short) 0, (byte) 10, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 25, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2341421404104-1" + "'", str8.equals("2341421404104-1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 23 + "'", int9 == 23);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie", "100 10 10 -1 -1 -1", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.0a100.0a-1.0a100.0a10.0a-1.0", "aaaaaaaaaaaaa2sU80-b//aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0 0 30", "0.1-a0.01a0.001a0.001a0.911a0.1-", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 0 30" + "'", str3.equals("0 0 30"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mv REVREs TIb-46 )mt(TOPsTOh AVAJ", (java.lang.CharSequence) "            10#100#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        double[] doubleArray6 = new double[] { 10.0d, 100L, (byte) -1, (short) 100, 10.0f, (-1.0f) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 0, (int) (short) 1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04100.04-1.04100.0410.04-1.0" + "'", str8.equals("10.04100.04-1.04100.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a100.0a-1.0a100.0a10.0a-1.0" + "'", str10.equals("10.0a100.0a-1.0a100.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0" + "'", str14.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", 25, 30);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0.0a0.0a-1.0a1.0a8.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0.0a-1.0a1.0a8.0" + "'", str2.equals("0.0a0.0a-1.0a1.0a8.0"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("uTF-8", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", (java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        ", "a # # # 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL" + "'", str2.equals("/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "0.0a0...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        char[] charArray5 = new char[] { 'a', '#', '#', '#', '4' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 17, 17);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "a # # # 4" + "'", str7.equals("a # # # 4"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', (int) (byte) 10, 30);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                     -1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "C orporation   O racle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                       Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                       Mac OS X" + "'", str1.equals("                       Mac OS X"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "0.", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30", (java.lang.CharSequence) "11.71");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray15 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "/Users/sophie");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray8, strArray17);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("::::::::::::::::::::::::::::::", "Corporation Oracl");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("A4 4 4 4a4#", strArray19, strArray22);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Corporation Oracle" + "'", str18.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "A4 4 4 4a4#" + "'", str23.equals("A4 4 4 4a4#"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("COracleCorporation#aaeorporationOracleCorporation#aaeOracleCorporation#aaeOOracleCorporation#aaeracle", "htt1\n.\n7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "COracleCorporation#aaeorporationOracleCorporation#aaeOracleCorporation#aaeOOracleCorporation#aaeracle" + "'", str2.equals("COracleCorporation#aaeorporationOracleCorporation#aaeOracleCorporation#aaeOOracleCorporation#aaeracle"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0a0.0a-1.0a1.0a8.0", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_8", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_8" + "'", str4.equals("1.7.0_8"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "A4 4 4 4A4#                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("corporationxoracle", (int) (byte) 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "corporationxoracle" + "'", str3.equals("corporationxoracle"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "X86_6", (java.lang.CharSequence) "nment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 0, 308);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "-1.0a10.0a100.0a100.0a119.0a-1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1." + "'", str2.equals("-1.0a10.0a100.0a100.0a119.0a-1."));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "elcarOxnoitaroproC", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (short) 0, (int) (byte) 1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("mv REVREs TIb-46 )mt(TOPsTOh AVAJ", "UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mv REVREs TIb-46 )mt(TOPsTOh AVAJ" + "'", str3.equals("mv REVREs TIb-46 )mt(TOPsTOh AVAJ"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("a    4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A    4" + "'", str1.equals("A    4"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#aaa a a aa", 26, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aaa a a aaaaaaaaaaaaaaaaa" + "'", str3.equals("#aaa a a aaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("  0#0#30  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#0#30" + "'", str1.equals("0#0#30"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Mac/OS/X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac/OS/X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("2341421404104-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2341421404104-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a1", (java.lang.CharSequence) "#aaa a a aa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed mode", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("8#0#100#100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("ORACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE cORPORATION" + "'", str1.equals("ORACLE cORPORATION"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav", (java.lang.CharSequence) "1.4", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("....0_80.jdk/contents/home/jre", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "....0_80.jdk/contents/home/jre" + "'", str2.equals("....0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44", 119, "23#1#21#0#10#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044" + "'", str3.equals("23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray16 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "/Users/sophie");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray9, strArray18);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray9);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "1.11.11.11.11.11.11.1  ");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4');
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Corporation Oracle" + "'", str19.equals("Corporation Oracle"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(".../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", "s/soph", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..." + "'", str3.equals(".../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..."));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "\n");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Corporation Oracle");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a', 0, 0);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("0.9", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1\n.\n7" + "'", str4.equals("1\n.\n7"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("http://java.oracle.com/", 26, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(26.0d, (double) 63.0f, (double) 4.0430403E23f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.043040272485348E23d + "'", double3 == 4.043040272485348E23d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("C orporation   O racle", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100 10 10 -1 -1 -1", 0, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 10 10 -1 -1 -1" + "'", str3.equals("100 10 10 -1 -1 -1"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", "  0#0#30  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "a4 4 4 4a4#                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 23, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str9.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0#10.0#100.0#100.0#119.0#-1.0" + "'", str11.equals("-1.0#10.0#100.0#100.0#119.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 119.0d + "'", double12 == 119.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("::::::::::::::::::::...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::..." + "'", str2.equals("::::::::::::::::::::..."));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("oRACLE cORPORATION", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        long[] longArray5 = new long[] { '4', 52, 52, (short) 1, 8L };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 23, 32L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(23.0f, (float) 119L, (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 23.0f + "'", float3 == 23.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "emixed modemixed modemixed mode" + "'", str2.equals("emixed modemixed modemixed mode"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("CORPORATIONXORACLE", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" Oracle Corporation # a       ae", "::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Oracle Corporation # a       ae" + "'", str2.equals(" Oracle Corporation # a       ae"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        float[] floatArray2 = new float[] { 97.0f, 63.0f };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97.0#63.0" + "'", str4.equals("97.0#63.0"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("0", "a    4");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97.0f, (double) 22.0f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "0.9", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.1-a0.01a0.001a0.001a0.911a0.1-", charSequence1, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "x86_6");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "     ...", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "eihpos", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                         4043040430404304043040430", "23#1#21#0#10#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         4043040430404304043040430" + "'", str2.equals("                                         4043040430404304043040430"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10#1", "                                                 1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("a4 4 4 4a4#                                         ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4 4 4 4a4#                                         " + "'", str2.equals("a4 4 4 4a4#                                         "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJob", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 286 + "'", int1 == 286);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0" + "'", str1.equals("10.0"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                     -1", (java.lang.CharSequence) "...dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                     -1" + "'", charSequence2.equals("                     -1"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "2341421404104-1", (java.lang.CharSequence) "#aaa a a aa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# a       a", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        java.lang.String[] strArray4 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray4, strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Corporation Oracle", "");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                       Mac/OS/X                                                        ", (java.lang.CharSequence[]) strArray12);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(".21", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "46_68X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("m1.4ixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 100, (int) (byte) 10);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0 0 30" + "'", str6.equals("0 0 30"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a30" + "'", str8.equals("0a0a30"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(286, 2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/var/folder:fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        char[] charArray7 = new char[] { ' ', ' ', '4', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "21.041.0421.040.0432.04119.0", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("# a       a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# a       a" + "'", str1.equals("# a       a"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044", "cleation OraCorpor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044" + "'", str2.equals("23#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#10#-123#1#21#0#1044"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                     -1", 97, 30);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("                                            # a       a                                             ");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("8 0 100 100", strArray10, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", strArray2, strArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "8 0 100 100" + "'", str13.equals("8 0 100 100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD" + "'", str14.equals("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10", (java.lang.CharSequence) "23 1 21 0 10 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("# a       a");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "7\n.\n1tth");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http://java.oracle.com/", "-1.0 10.0 100.0 100.0 119.0 -1.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://javaoraclecom/" + "'", str3.equals("http://javaoraclecom/"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("CorporationOracle", "#4a4 4 4 4a", "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Corpor tionOr cle" + "'", str3.equals("Corpor tionOr cle"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1.0a10.0a100.0a100.0a119.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0a10.0a100.0a100.0a119.0a-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/Exten");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Exten\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "6_68x", (java.lang.CharSequence) "elcarOxnoitaroproC");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("##a# # # #a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##a# # # #a" + "'", str1.equals("##a# # # #a"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "htt1\n.\n7", (java.lang.CharSequence) ":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.0a52.0a63.0a2.0a55.0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, (int) (byte) 0, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "nment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray1 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray1);
        org.junit.Assert.assertNotNull(numberUtilsArray1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Users/sop");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(31L, (long) 7, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                       Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                             -");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 100, (float) 63, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "elcarOxnoitaroproC");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        java.lang.String str11 = javaVersion6.toString();
        java.lang.String str12 = javaVersion6.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.2" + "'", str12.equals("1.2"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(4L, 21L, 31L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Corporation Oracle", (java.lang.CharSequence) "Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10#100#100#-1####################################################################################", (java.lang.CharSequence) "....0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("CLEATION oRAcORPOR", (float) 66L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 66.0f + "'", float2 == 66.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        char[] charArray11 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, ' ');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                        ", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "# a       a" + "'", str13.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("form API Specification", "0.0a0.0a-1.0a1.0a8.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "form API Specification" + "'", str2.equals("form API Specification"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", "101", "#Oracle Corporation## a       a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52#5O_#56O279479" + "'", str3.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52#5O_#56O279479"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', (int) (short) 100, (int) (short) 100);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Corporation Oracl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Corporation Oracl" + "'", str1.equals("Corporation Oracl"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Corporation # a       a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION # A       A" + "'", str1.equals("ORACLE CORPORATION # A       A"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US " + "'", str2.equals("US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification", (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("htt1\n.\n7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"htt1\n.\n7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#                                                   ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                       Mac/OS/X                                                        ", "444444444444444444444444444444444444441.7.0_80", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52#5O_#56O279479", 55);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                       Mac/OS/X                                                        " + "'", str4.equals("                                                       Mac/OS/X                                                        "));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("UTF-8", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("cleation OraCorpor", 52, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444cleation OraCorpor44444444444444444" + "'", str3.equals("44444444444444444cleation OraCorpor44444444444444444"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a0a30", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "2sU80-b//");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        float[] floatArray6 = new float[] { 21, 1.0f, 21, 0L, ' ', 119L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str8.equals("21.041.0421.040.0432.04119.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 119.0f + "'", float9 == 119.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 119.0f + "'", float10 == 119.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "21.0 1.0 21.0 0.0 32.0 119.0" + "'", str12.equals("21.0 1.0 21.0 0.0 32.0 119.0"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " Oracle Corporation # a       a", (java.lang.CharSequence) "/jre", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0a119.0a100.0a100.0a10.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0.", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "#aaa a a aa", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" a       ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "CorporationOracle", (java.lang.CharSequence) "A    4", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-1", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS X", "VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#aaa a a aaaaaaaaaaaaaaaaa", (int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("noitaroproC elcarO", "##a# # # #a");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.21", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/uSERS/SOP", (java.lang.CharSequence) " Oracle Corporation # a       ae");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1421404104-", "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1421404104-" + "'", str2.equals("1421404104-"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" a      ", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#aaa a a aaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "23 1 21 0 10 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "6_68x", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 100 100 -1", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java#          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ORACLE4cORPORATION", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATION" + "'", str2.equals("ORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATION"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4043040430404304043040430", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "ARY/JAVA/J");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444444444444444cleation OraCorpor44444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Corporation Oracle", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        double[] doubleArray6 = new double[] { 10.0d, 100L, (byte) -1, (short) 100, 10.0f, (-1.0f) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 0, (int) (short) 1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04100.04-1.04100.0410.04-1.0" + "'", str8.equals("10.04100.04-1.04100.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a100.0a-1.0a100.0a10.0a-1.0" + "'", str10.equals("10.0a100.0a-1.0a100.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0" + "'", str14.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10.0 100.0 -1.0 100.0 10.0 -1.0" + "'", str17.equals("10.0 100.0 -1.0 100.0 10.0 -1.0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1421404104-", (java.lang.CharSequence) "/T/ng0000cf:redlof/rav/", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java HotSpot(TM) 64-Bit Server VM", "/users/sophie", " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HStS St(TM) 64-BSt S Uv U VM" + "'", str3.equals("Java HStS St(TM) 64-BSt S Uv U VM"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("44444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444" + "'", str2.equals("44444444"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ORACLE CORPORATION # A       A", (int) (byte) 100, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "demixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                       Mac/OS/X", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                       Mac/OS/X", "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       Mac/OS/X" + "'", str2.equals("                                                       Mac/OS/X"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444441.7.0_80", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444441.7.0_80" + "'", str2.equals("444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        double[] doubleArray6 = new double[] { 10.0d, 100L, (byte) -1, (short) 100, 10.0f, (-1.0f) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.04100.04-1.04100.0410.04-1.0" + "'", str8.equals("10.04100.04-1.04100.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1.0#10.0#100.0#100.0#119.0#-1.0", "  0#0#30 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0#10.0#100.0#100.0#119.0#-1." + "'", str2.equals("-1.0#10.0#100.0#100.0#119.0#-1."));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "21.041.0421.040.0432.04119.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "....0_80.jdk/contents/home/jre", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x");
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0", "10 1", 2);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "2sU80-b//", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("mixed mode");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("################################");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.21", "...dk1.7.0_80.jdk/contents/home/jre", "4 4a4#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.4", "   ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "ers/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80", "0.0a0.0a-1.0a1.0a8.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 308, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", (java.lang.CharSequence) "C orporation   O racle");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specification", 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo", "                                                       Mac/OS/X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("corporationxoracle", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "corporationxoracle" + "'", str2.equals("corporationxoracle"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "Mac/OS/X", 26, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac/OS/Xmodemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str4.equals("Mac/OS/Xmodemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("X86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "....0_80.jdk/contents/home/jre", 35, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", "a4 4 4 4a4#", (-1));
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a4 4 4 4a4#", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7.0_80-b15" + "'", str7.equals("1.7.0_80-b15"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4444444", "10.0 100.0 -1.0 100.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "CorporationOracle", charSequence1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", "10#100#100#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        ", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        " + "'", str2.equals("a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0.1-a0.01a0.001a0.001a0.911a0.1-", 10, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...a0.001a0.001a0.911a0.1-" + "'", str3.equals("...a0.001a0.001a0.911a0.1-"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ", "http://javaoraclecom/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre " + "'", str2.equals(" /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "   ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATION", (int) (short) 1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATION" + "'", str3.equals("ORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATIONORACLE4cORPORATION"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) ' ', 30);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#', 21, 0);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 119L, 46.0d, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Co\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0.0a0.0a-/Users/sophie0.0a0.0a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0a0.0a-/Users/sophie0.0a0.0a-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "", "7\n.\n1tth");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("a    4", 21, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a    4               " + "'", str3.equals("a    4               "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("A    4", (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", (int) (byte) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", (java.lang.CharSequence) "ARY/JAVA/J", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                         4043040430404304043040430", "....0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "ers/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U" + "'", str2.equals("S US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 66 + "'", int1 == 66);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("nment", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://javaoraclecom/", (java.lang.CharSequence) "97.0#63.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray2 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray2);
        org.junit.Assert.assertNotNull(systemUtilsArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               " + "'", str2.equals("                                                               "));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "     ooo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " Oracle Corporation # a       a", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("97.0#63.0", "htt1\n.\n7", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                 ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        short[] shortArray2 = new short[] { (short) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 1" + "'", str4.equals("10 1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1" + "'", str8.equals("10#1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 10 + "'", short11 == (short) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10a1" + "'", str13.equals("10a1"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "         ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a0a30", (java.lang.CharSequence) "x86_64", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("java HotSpot(TM) 64-Bit Server VM", "1.11.11.11.11.11.11.1  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Library/JavMac/OS/X/Library/Jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Libr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "edom dexim", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "...dk1.7.0_80.jdk/contents/home/jre", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0.1-40.0140.00140.1-40.00140.01", " Oracle Corporation # a       ae");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.1-40.0140.00140.1-40.00140.01" + "'", str2.equals("0.1-40.0140.00140.1-40.00140.01"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                     -");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "         Mac/OS/X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaa", 35, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "8a0a100a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /jre is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.0a100.0a-1.0a100.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00140.01", (java.lang.CharSequence) " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US U");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                       Mac OS X", "4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       Mac OS X" + "'", str2.equals("                       Mac OS X"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "C#orporation# #O#racle", (java.lang.CharSequence) "/Users/sophie/Library/Java/Exten", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("46_68x", "a4 4 4 4a4#                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x" + "'", str2.equals("46_68x"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                 1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 1.4" + "'", str1.equals("                                                 1.4"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("X86_64", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "  0#0#30 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  0#0#30 ", "84041004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  0#0#30 " + "'", str2.equals("  0#0#30 "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "edom dexim", (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle", "################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', 31, 10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 3, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0" + "'", str9.equals("-1.0a10.0a100.0a100.0a119.0a-1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-1.0 10.0 100.0 100.0 119.0 -1.0" + "'", str19.equals("-1.0 10.0 100.0 100.0 119.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1.0#10.0#100.0#100.0#119.0#-1.0" + "'", str21.equals("-1.0#10.0#100.0#100.0#119.0#-1.0"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", 28, "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..." + "'", str3.equals("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..."));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "X86_64", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "            10#100#100", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (short) 100, "CORPORATIONXORACLE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0a0a30", ":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8, 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("en", "-1.0410.04100.04100.04119.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Mac/OS/Xmodemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL" + "'", str2.equals("...XORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.1");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.1f + "'", number1.equals(1.1f));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.", "4444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0." + "'", str2.equals("0."));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String[] strArray1 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##", "UTF-8");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray1, strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTF-8" + "'", str8.equals("UTF-8"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', 0, (-1));
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  0#0#30  ", charArray10);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "# a       ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "##a# # # #a" + "'", str20.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "##a# # # #a" + "'", str23.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 5L, (float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "             CorporationOracle", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "Corporation # a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(".21");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".21" + "'", str1.equals(".21"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", (java.lang.CharSequence) "/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(26, 3, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) -1, (byte) 0, (byte) 10, (byte) 0, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "        1.7.0_80         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52#5O_#56O279479", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ORACLE CORPORATION # A       A", "mixed mode", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.21");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.21" + "'", str1.equals("1.21"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("040430", "/var/folder:fc0000gn/T/", (-1), 308);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/var/folder:fc0000gn/T/" + "'", str4.equals("/var/folder:fc0000gn/T/"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) ' ', 30);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410041004-1" + "'", str12.equals("10410041004-1"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10a100a100a-1" + "'", str16.equals("10a100a100a-1"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/var/folder:fc0000gn/T/", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T/" + "'", str2.equals("/var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T//var/folder:fc0000gn/T/"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1", 8, 3931);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0#10.0#100.0#100.0#119.0#-1.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "a", (java.lang.CharSequence) "a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) -1, "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" Oracle Corporation # a       ae", "             CorporationOracle");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "CLEATION oRAcORPOR", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("A4 4 4 4A4#                                         ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10a1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("21.041.0421.040.0432.04119.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str1.equals("21.041.0421.040.0432.04119.0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444444", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", "0.1-a0.01a0.001a0.001a0.911a0.1-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444" + "'", str3.equals("4444444"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        java.lang.String[] strArray3 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "hi!");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray3, strArray6);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-", (java.lang.CharSequence[]) strArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "demixed modemixed modemixed modemixed modemixed mode", (int) (short) 1, (int) (byte) 0);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "        ", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + ":" + "'", str10.equals(":"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("demixed modemixed modemixed modemixed modemixed mode", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "demixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("demixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#aaa a a aaaaaaaaaaaaaaaaa", 17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "         Mac/OS/X", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "         Mac/OS/X" + "'", charSequence2.equals("         Mac/OS/X"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("nment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Exten", (java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/JavMac/OS/X/Library/Jav                                                                    ", (int) (short) 100, "tionatform API Specifica Plavaj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/JavMac/OS/X/Library/Jav                                                                    " + "'", str3.equals("/Library/JavMac/OS/X/Library/Jav                                                                    "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " a       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10#100#100#-110#100#100#-110#1", 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#-110#100#" + "'", str3.equals("#-110#100#"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "8a0a100a100", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0" + "'", str6.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0" + "'", str9.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10 100 100 -1", "        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 100 100 -1" + "'", str2.equals("10 100 100 -1"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "Mac/OS/X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod" + "'", str1.equals("ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle" + "'", str1.equals("C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("################################", "", "Or...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "CorporationOracle", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#" + "'", str11.equals("#"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("US", "1421404104-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(21L, (long) 66, 66L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 21L + "'", long3 == 21L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str1.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444444444444444444444444444444444444444444444444        ", "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph", 7, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph444444444444444444444444444444        " + "'", str4.equals("4444444s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph444444444444444444444444444444        "));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                     -", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "8 0 100 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

