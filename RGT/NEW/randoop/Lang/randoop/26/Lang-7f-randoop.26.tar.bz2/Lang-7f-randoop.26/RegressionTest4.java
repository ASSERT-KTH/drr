import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0.0a0.0a-/Users/sophie0.0a0.0a-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0A0.0A-/uSERS/SOPHIE0.0A0.0A-" + "'", str1.equals("0.0A0.0A-/uSERS/SOPHIE0.0A0.0A-"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("     ...", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                ", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "       ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Mac OS X", "0.1-40.0140.00140.1-40.00140.01", "aaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("        ", 66, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444        " + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444        "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("21.041.0421.040.0432.04119.0", "46_68x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " a      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 10, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "23#1#21#0#10#-1", (java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "                     -1", 97, 30);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("                                            # a       a                                             ");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("8 0 100 100", strArray12, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", strArray4, strArray12);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/users/sophie", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "8 0 100 100" + "'", str15.equals("8 0 100 100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD" + "'", str16.equals("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "/users/sophie" + "'", str17.equals("/users/sophie"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0 0 30", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "10.04100.04-1.04100.0410.04-1.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        char[] charArray6 = new char[] { '4', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "C#orporation# #O#racle", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a    4", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(119L, 0L, 21L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 119L + "'", long3 == 119L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("corporationxoracle", (int) (short) 100, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "x86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0." + "'", str1.equals("0."));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 0, (-1));
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray9);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', (int) ' ', (int) (byte) 10);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "# a       a" + "'", str11.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "##a# # # #a" + "'", str19.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("form API Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0.0a0.0a-1.0a1.0a8.0", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0..." + "'", str2.equals("0.0a0..."));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("US", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("8 0 100 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "8 0 100 100" + "'", str1.equals("8 0 100 100"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("tionatform API Specifica Plavaj", "10#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionatform API Specifica Plavaj" + "'", str2.equals("tionatform API Specifica Plavaj"));
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test034");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        boolean boolean7 = javaVersion3.atLeast(javaVersion5);
//        boolean boolean8 = javaVersion1.atLeast(javaVersion3);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# a       a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Exten", (java.lang.CharSequence) "Corporation Oracle");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("tionatform API Specifica Plavaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tionatform API Specifica Plavaj" + "'", str1.equals("tionatform API Specifica Plavaj"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("8#0#100#100", "11.71");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8#0#100#100" + "'", str2.equals("8#0#100#100"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("eihpos", "4444444444444444444444444444444444444444444444444444444444        ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "1.7", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", "10#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD" + "'", str2.equals("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4043040430404304043040430", (java.lang.CharSequence) "  0#0#30 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("     ooo", "1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8", 8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/Jcorporationxoracle");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("CORPORATIONXORACLE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CORPORATIONXORACLE" + "'", str1.equals("CORPORATIONXORACLE"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("####################################################################################################", "2sU80-b//", (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2sU80-b//" + "'", str4.equals("2sU80-b//"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10#1", 8, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaa10#1" + "'", str3.equals("aaaa10#1"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "...dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 6, (int) (short) -1);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "8#0#100#100" + "'", str15.equals("8#0#100#100"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "/", (int) (byte) 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "10#1", (int) (byte) 100, 0);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10.14.314.3", (java.lang.CharSequence[]) strArray6);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "100 10 10 -1 -1 -1", 10, 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#Oracle Corporation## a       a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#Oracle Corporation## a       a" + "'", str1.equals("#Oracle Corporation## a       a"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0A0.0A-/uSERS/SOPHIE0.0A0.0A-");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("# a       a");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("uTF-8", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uTF-8" + "'", str2.equals("uTF-8"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("##a# # # #a", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##a# # # #a" + "'", str2.equals("##a# # # #a"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97L, (float) (short) 1, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/t/ng0000cf:redlof/rav/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/t/ng0000cf:redlof/rav/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "101");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("2sU80-b//");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2sU80-b//\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0.0a0...", "C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0..." + "'", str2.equals("0.0a0..."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_8", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/OME/JRE /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/OME/JRE /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/OME/JRE /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/OME/JRE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/users/sophie", "", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.0a100.0a-1.0a100.0a10.0a-1.0", "1.21");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".21" + "'", str2.equals(".21"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("VM", "#Oracle Corporation## a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VM" + "'", str2.equals("VM"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/T/ng0000cf:redlof/rav/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/T/ng0000cf:redlof/rav/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ARY/JAVA/J", (java.lang.CharSequence) "10 100 100 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#100#100#-1", 97, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#100#100#-1####################################################################################" + "'", str3.equals("10#100#100#-1####################################################################################"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) '#', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("cleation OraCorpor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CLEATION oRAcORPOR" + "'", str1.equals("CLEATION oRAcORPOR"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...dk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray6, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray15 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "/Users/sophie");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray8, strArray17);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "/Users/sophie");
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.split("                                            # a       a                                             ");
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("8 0 100 100", strArray23, strArray25);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("C orporation   O racle", strArray20, strArray23);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Corporation Oracle" + "'", str18.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "8 0 100 100" + "'", str26.equals("8 0 100 100"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "C orporation   O racle" + "'", str27.equals("C orporation   O racle"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "10#100#100#-1####################################################################################", (java.lang.CharSequence) "                                                       Mac/OS/X                                                        ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10#100#100#-1####################################################################################" + "'", charSequence2.equals("10#100#100#-1####################################################################################"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444        ", (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-1.0a119.0a100.0a100.0a10.0a-1.0", "VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a119.0a100.0a100.0a10.0a-1.0" + "'", str2.equals("-1.0a119.0a100.0a100.0a10.0a-1.0"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                CORPORATIONXORACLE", (java.lang.CharSequence) "97.0 1.0 35.0 0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4444444444444444444444444444444444444444444444444444444     ooo44444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444444444444444444444444444        ", 308, "a    4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        " + "'", str3.equals("a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                       Mac/OS/X", (java.lang.CharSequence) "# a  ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "nment", (int) (byte) -1, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##", (java.lang.CharSequence) "10#100#100#-110#100#100#-110#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ers/sophie", "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 5, (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Corporation Oracle", (int) (short) 10, 3931);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "46_68x", (java.lang.CharSequence) "10.14.314.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("corporationxoracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CORPORATIONXORACLE" + "'", str1.equals("CORPORATIONXORACLE"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String[] strArray5 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray14 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "/Users/sophie");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray7, strArray16);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "/Users/sophie");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray19, ' ');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray19);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Corporation Oracle" + "'", str17.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + " Oracle Corporation # a       a" + "'", str21.equals(" Oracle Corporation # a       a"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("a4 4 4 4a4#", (int) (short) 1, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 4 4 4a4#" + "'", str3.equals("4 4 4 4a4#"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##a# # # #a", (java.lang.CharSequence) "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 63, (float) 1L, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("form API Specification", "                                                                        ", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("  0#0#30  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 6, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0#0#30", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(".../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444", (float) 66);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.4444444E7f + "'", float2 == 4.4444444E7f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 26.0f, (double) 30L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.0d + "'", double3 == 30.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("oR...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oR..." + "'", str1.equals("oR..."));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("2341421404104-1", 3, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1421404104-" + "'", str3.equals("1421404104-"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sop", "aaaaaaaaaaaaa2sU80-b//aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", "             CorporationOracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM" + "'", str2.equals("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/t/ng0000cf:redlof/rav/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/t/ng0000cf:redlof/rav/" + "'", str2.equals("/t/ng0000cf:redlof/rav/"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.0a10.0a100.0a100.0a119.0a-1.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0a10.0a100.0a100.0a119.0a-1.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "8 0 100 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaa10#1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("10#100#100#-1", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#100#100#-1" + "'", str2.equals("10#100#100#-1"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        char[] charArray8 = new char[] { '#', '#', ' ', '4', '4', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Corporation # a       a", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.0a0...", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10#1", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE cORPORATION" + "'", str1.equals("ORACLE cORPORATION"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "CorporationOracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CorporationOracle" + "'", str2.equals("CorporationOracle"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0a10.0a100.0a100.0a119.0a-1.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                         4043040430404304043040430", 1, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "htt1\n.\n7", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oR...", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oR..." + "'", str4.equals("oR..."));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("X86_64", "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre", "1.7.0_8", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str3.equals("/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "CLEATION oRAcORPOR", "21.041.0421.040.0432.04119.0", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ORACLE cORPORATION", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE4cORPORATION" + "'", str3.equals("ORACLE4cORPORATION"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test146");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str6 = javaVersion5.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str12 = javaVersion11.toString();
//        boolean boolean13 = javaVersion9.atLeast(javaVersion11);
//        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
//        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
//        boolean boolean18 = javaVersion14.atLeast(javaVersion16);
//        boolean boolean19 = javaVersion9.atLeast(javaVersion14);
//        java.lang.String str20 = javaVersion14.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str22 = javaVersion21.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
//        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean26 = javaVersion23.atLeast(javaVersion25);
//        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str28 = javaVersion27.toString();
//        boolean boolean29 = javaVersion25.atLeast(javaVersion27);
//        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean31 = javaVersion27.atLeast(javaVersion30);
//        java.lang.String str32 = javaVersion27.toString();
//        boolean boolean33 = javaVersion14.atLeast(javaVersion27);
//        boolean boolean34 = javaVersion0.atLeast(javaVersion27);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.2" + "'", str12.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.7" + "'", str20.equals("1.7"));
//        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.2" + "'", str22.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1.2" + "'", str28.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1.2" + "'", str32.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " a      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, 3.0f, 23.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 23.0f + "'", float3 == 23.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "cleation OraCorpor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/T/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/T/ng0000cf:redlof/rav/" + "'", str1.equals("/T/ng0000cf:redlof/rav/"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "C#orporation# #O#racle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporatio", (java.lang.CharSequence) "0#0#30");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        char[] charArray8 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 3, 3);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "# a       a" + "'", str10.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30", ".../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", "x86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30" + "'", str3.equals("-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode" + "'", str1.equals("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "Corporation Oracle");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "/var/folder:fc0000gn/T/", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        long[] longArray0 = new long[] {};
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4043040430404304043040430");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.043040430404304E24d + "'", double1.equals(4.043040430404304E24d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4", 52, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils5 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray6 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3, systemUtils4, systemUtils5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray6);
        org.junit.Assert.assertNotNull(systemUtilsArray6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("##a# # # #a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("# a       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#" + "'", str9.equals("#"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                     ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4043040430404304043040430", "44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4043040430404304043040430" + "'", str2.equals("4043040430404304043040430"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "#                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "s/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/sophs/soph", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("  0#0#30  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("a4 4 4 4a4#                                         ", "COracleCorporation#aaeorporationOracleCorporation#aaeOracleCorporation#aaeOOracleCorporation#aaeracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4 4 4 4a4#                                         " + "'", str2.equals("a4 4 4 4a4#                                         "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10 100 100 -1", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sophie", "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("cleation OraCorpor", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cleation OraCorpor" + "'", str2.equals("cleation OraCorpor"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("             CorporationOracle", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java(TM) SE Runtime Environment", "10.0", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "...", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM" + "'", str1.equals("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ", 0, "1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US " + "'", str3.equals(" US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#                                                   ", (java.lang.CharSequence) "/t/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444        ", (java.lang.CharSequence) "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("# a       a", "             CorporationOracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# a       a" + "'", str2.equals("# a       a"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "2sU80-b//", (java.lang.CharSequence) "2341421404104-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "6_68x");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10#100#100#-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("uTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uTF-8" + "'", str1.equals("uTF-8"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("# a       a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "0");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "# a       a", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10#100#100#-1", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1f + "'", float1.equals(1.1f));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("uTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("CorporationOracle", "10#100#100");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("8 0 100 100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("46_68X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORACLE4cORPORATION", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0.", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", "7\n.\n1tth");
        java.lang.String[] strArray7 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "/Users/sophie");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("44444444", strArray3, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 9 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10#100#100#-110#100#100#-110#1", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HI!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(31.0f, 3.0f, (float) 30);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 100, "....0_80.jdk/contents/home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j" + "'", str3.equals("....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/t/ng0000cf:redlof/rav/", "10 1", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4 4a4#", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4 4a4#" + "'", str2.equals("4 4a4#"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("eihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0" + "'", str3.equals("1.110.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.04100.04-1.04100.0410.04-1.010.0"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("             CorporationOracle", "10.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.3", "", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "             CorporationOracle" + "'", str4.equals("             CorporationOracle"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..." + "'", str1.equals("     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ..."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ers/sophie", " a      ", "1421404104-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ers/sophie" + "'", str3.equals("ers/sophie"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1\n.\n7", (java.lang.CharSequence) "8 0 100 100", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 1, (double) 5.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "  0#0#30  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "97.0 1.0 35.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("46_68x", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/t/ng0000cf:redlof/rav/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/ng0000cf:redlof/rav/" + "'", str1.equals("/t/ng0000cf:redlof/rav/"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        short[] shortArray2 = new short[] { (short) 10, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 66, 30);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 1" + "'", str4.equals("10 1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10#1" + "'", str8.equals("10#1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 1 + "'", short14 == (short) 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("a4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4 4 4 4a4#" + "'", str1.equals("a4 4 4 4a4#"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Oracle Corporation # a       a", "               404304043040430404304043");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4 4 4 4a4#", "", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10410041004-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "0#0#30", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1421404104-");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray8 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion2, javaVersion5 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray9 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray8 };
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str11 = javaVersion10.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str13 = javaVersion12.toString();
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray18 = new org.apache.commons.lang3.JavaVersion[] { javaVersion10, javaVersion12, javaVersion15 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray19 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray18 };
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str21 = javaVersion20.toString();
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str23 = javaVersion22.toString();
        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        boolean boolean27 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray28 = new org.apache.commons.lang3.JavaVersion[] { javaVersion20, javaVersion22, javaVersion25 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray29 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray28 };
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str31 = javaVersion30.toString();
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str33 = javaVersion32.toString();
        boolean boolean34 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion32);
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean36 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion35);
        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion35);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray38 = new org.apache.commons.lang3.JavaVersion[] { javaVersion30, javaVersion32, javaVersion35 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray39 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray38 };
        org.apache.commons.lang3.JavaVersion javaVersion40 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str41 = javaVersion40.toString();
        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str43 = javaVersion42.toString();
        boolean boolean44 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion42);
        org.apache.commons.lang3.JavaVersion javaVersion45 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean46 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion45);
        boolean boolean47 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion45);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray48 = new org.apache.commons.lang3.JavaVersion[] { javaVersion40, javaVersion42, javaVersion45 };
        org.apache.commons.lang3.JavaVersion[][] javaVersionArray49 = new org.apache.commons.lang3.JavaVersion[][] { javaVersionArray48 };
        org.apache.commons.lang3.JavaVersion[][][] javaVersionArray50 = new org.apache.commons.lang3.JavaVersion[][][] { javaVersionArray9, javaVersionArray19, javaVersionArray29, javaVersionArray39, javaVersionArray49 };
        java.lang.String str51 = org.apache.commons.lang3.StringUtils.join(javaVersionArray50);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(javaVersionArray8);
        org.junit.Assert.assertNotNull(javaVersionArray9);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.3" + "'", str11.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.1" + "'", str13.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(javaVersionArray18);
        org.junit.Assert.assertNotNull(javaVersionArray19);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.3" + "'", str21.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.1" + "'", str23.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(javaVersionArray28);
        org.junit.Assert.assertNotNull(javaVersionArray29);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.3" + "'", str31.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.1" + "'", str33.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(javaVersionArray38);
        org.junit.Assert.assertNotNull(javaVersionArray39);
        org.junit.Assert.assertTrue("'" + javaVersion40 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion40.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1.3" + "'", str41.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1.1" + "'", str43.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + javaVersion45 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion45.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(javaVersionArray48);
        org.junit.Assert.assertNotNull(javaVersionArray49);
        org.junit.Assert.assertNotNull(javaVersionArray50);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "C orporation   O racle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.0a100.0a-1.0a100.0a10.0a-1.0", "/Users/sop", "CLEATION oRAcORPOR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a100.0a-1.0a100.0a10.0a-1.0" + "'", str3.equals("10.0a100.0a-1.0a100.0a10.0a-1.0"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) ".../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j" + "'", str1.equals("....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.jdk/contents/home/jre....0_80.j"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        long[] longArray3 = new long[] { 10L, ' ', (short) 100 };
        long[] longArray7 = new long[] { 10L, ' ', (short) 100 };
        long[] longArray11 = new long[] { 10L, ' ', (short) 100 };
        long[][] longArray12 = new long[][] { longArray3, longArray7, longArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray12);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("eihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.310.14.314.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.00140.1-40.00140.01", (java.lang.CharSequence) "21.041.0421.040.0432.04119.0", 308);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "0.00140.1-40.00140.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', (int) (short) -1, 23);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "elcarOxnoitaroproC", (java.lang.CharSequence) "-1.0#10.0#100.0#100.0#119.0#-1.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("htt1.7", "1.21.71.71.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "htt1.7" + "'", str2.equals("htt1.7"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.21", "a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        ", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.21" + "'", str3.equals("1.21"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30", (java.lang.CharSequence) "                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", charSequence1, 119);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10#1", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("UTF-8");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("::::::::::::::::::::...", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "va/Extensions:/usr/lib/javary/Ja/Extensions:/System/Libravary/Ja/Extensions:/Network/Libravary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/LibralMaVirtuava/Javary/Ja/Extensions:/Libravary/Ja/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, 5.0d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int[] intArray6 = new int[] { 23, (short) 1, 21, (short) 0, (byte) 10, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 46, 31);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2341421404104-1" + "'", str8.equals("2341421404104-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "23#1#21#0#10#-1" + "'", str10.equals("23#1#21#0#10#-1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                         4043040430404304043040430", "-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a100.0a119.0a-1.0-1.0a10.0a100.0a10 0 30");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         4043040430404304043040430" + "'", str2.equals("                                         4043040430404304043040430"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0.0a0.0a-1.0a1.0a8.0", (java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Corporation # a       a");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10.14.314.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10 100 100 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 100 100 -1" + "'", str1.equals("10 100 100 -1"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-1.0a119.0a100.0a100.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0A119.0A100.0A100.0A10.0A-1.0" + "'", str1.equals("-1.0A119.0A100.0A100.0A10.0A-1.0"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, (double) 31.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "97.0 1.0 35.0 0.0", (java.lang.CharSequence) "/Users/sophie/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "97.0 1.0 35.0 0.0" + "'", charSequence2.equals("97.0 1.0 35.0 0.0"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "uTF-8", (java.lang.CharSequence) "ers/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 10, 5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (short) -1, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8#0#100#100" + "'", str14.equals("8#0#100#100"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0#0#30", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#0#30" + "'", str3.equals("0#0#30"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1", (float) 22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1#10", "6_68x", "Corporation Oracle");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3931, (float) 100, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3931.0f + "'", float3 == 3931.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkit", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", "uTF-8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                                                        ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "CorporationOracle", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.1-40.0140.00140.1-40.00", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "A4 4 4 4a4#", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        long[] longArray1 = new long[] { (byte) 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a    4", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a    4" + "'", str2.equals("a    4"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 100, (byte) 100, (byte) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', (int) ' ', 30);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10410041004-1" + "'", str12.equals("10410041004-1"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10#100#100#-1" + "'", str16.equals("10#100#100#-1"));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 100 + "'", short17 == (short) 100);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52150_1560279479/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        char[] charArray7 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', 0, (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "# a       a" + "'", str9.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#4a4 4 4 4a" + "'", str16.equals("#4a4 4 4 4a"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_64mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x" + "'", str1.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 4, 46);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1421404104-", "10#100#100#-1####################################################################################", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1421404104-" + "'", str3.equals("1421404104-"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/JavMac/OS/X/Library/Jav", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              /Library/JavMac/OS/X/Library/Jav" + "'", str2.equals("              /Library/JavMac/OS/X/Library/Jav"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/soph", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ":/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52150_1560279479", (java.lang.CharSequence) "11.71");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4 4 4 4a4#", "demixed modemixed modemixed modemixed modemixed mode", "", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4 4 4 4a4#" + "'", str4.equals("4 4 4 4a4#"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_8", (float) 46);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 46.0f + "'", float2 == 46.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("23#1#21#0#10#-1", 119L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 119L + "'", long2 == 119L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                         4043040430404304043040430", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("nment");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", 5.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("...", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "......................................................................................................................................................................................................" + "'", str2.equals("......................................................................................................................................................................................................"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("               404304043040430404304043");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0430403E23f + "'", float1.equals(4.0430403E23f));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo     ooo", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.1", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "# a       a" + "'", str10.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("#", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1421404104-", (java.lang.CharSequence) "nment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b11", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("##a# # # #a", "# a       a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " Oracle Corporation # a       ae");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0.0a0.0a-1.0a1.0a8.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.1-a0.01a0.001a0.001a0.911a0.1-", "                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4", (java.lang.CharSequence) "6_68x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("a", "51.0", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10#100#100#-1####################################################################################", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM" + "'", str2.equals("ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.314.3", "edom dexim");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("040430", "/t/ng0000cf:redlof/rav/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Oracle Corporation", "1.21.71.71.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 10, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 23, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/var/folder:fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VM" + "'", str1.equals("VM"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10#100#100#-110#100#100#-110#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#100#100#-110#100#100#-110#1" + "'", str1.equals("10#100#100#-110#100#100#-110#1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("# a       a", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("HI!", (double) 308);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 308.0d + "'", double2 == 308.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444444444        ", (int) '4', "a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444        " + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444        "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                       /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie-Bit Server VM", "7\n.\n1tth");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " a       ", (-1), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) (-1), (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("          ", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("21.041.0421.040.0432.04119.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "21.041.0421.040.0432.04119.0" + "'", str2.equals("21.041.0421.040.0432.04119.0"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', 'a', ' ', ' ', ' ', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folder:fc0000gn/T/", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ', 0, (-1));
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray10);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "# a       a" + "'", str12.equals("# a       a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "##a# # # #a" + "'", str20.equals("##a# # # #a"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "#aaa a a aa" + "'", str23.equals("#aaa a a aa"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/JavMac/OS/X/Library/Jav                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "1.7.0_8", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "C Oracle Corporation # a       aeorporation Oracle Corporation # a       ae  Oracle Corporation # a       aeO Oracle Corporation # a       aeracle");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#Oracle Corporation## a       a", "form API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#Oracle Corporation## a       a" + "'", str2.equals("#Oracle Corporation## a       a"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("A4 4 4 4a4#", (int) (short) 10, 22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("10#100#100", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            10#100#100" + "'", str2.equals("            10#100#100"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4", "#                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("demixed modemixed modemixed modemixed modemixed mode", "     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     .../var/folder:fc0000gn/T/     ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "demixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("demixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "hi!");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) (byte) 100, 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", " /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("46_68X", "::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-1.0a10.0a100.0a100.0a119.0a-1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0a10.0a100.0a100.0a119.0a-1." + "'", str1.equals("-1.0a10.0a100.0a100.0a119.0a-1."));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("UF-8", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UF-8" + "'", str2.equals("UF-8"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("              /Library/JavMac/OS/X/Library/Jav", "     ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              /Library/JavMac/OS/X/Library/Jav" + "'", str2.equals("              /Library/JavMac/OS/X/Library/Jav"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "   ...", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/t/ng0000cf:redlof/rav/", "Mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0.1-40.0140.00140.1-40.00140.01", (int) (byte) 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.1-40.0140.00140.1-40.00140.01" + "'", str3.equals("0.1-40.0140.00140.1-40.00140.01"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, (int) (byte) 10, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environmentdemixed modemixed modemixed modemixed modemixed modeJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "tionatform API Specifica Plavaj", (java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "              /Library/JavMac/OS/X/Library/Jav", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL", "                                                    ", "             CorporationOracle");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JAVA hOTsPOT(tm) 64-bIT sERVER vm", "10#100#100#-1####################################################################################", 3931);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("a    4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/var/folder:fc0000gn/T/", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "040430" + "'", str7.equals("040430"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 30" + "'", str9.equals("0 0 30"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.11.11.11.11.11.11.1  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "C orporation   O racle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 1.1" + "'", str1.equals("                                                                                                 1.1"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, 4L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        long[] longArray4 = new long[] { 8, (short) 0, (short) 100, 100L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) -1, (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 10, 5);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 7, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "8a0a100a100" + "'", str15.equals("8a0a100a100"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("# a  ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.14.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.5", 3931, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Mac/OS/X", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim46_68x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac/OS/X" + "'", str2.equals("Mac/OS/X"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 31.0f, (double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 10, (byte) -1, (byte) -1, (byte) -1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        double[] doubleArray6 = new double[] { (short) -1, 10.0f, 100.0d, 100.0f, 119, (short) -1 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 119.0d + "'", double8 == 119.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(3931.0f, (float) 97, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3931.0f + "'", float3 == 3931.0f);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#4a4 4 4 4a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                     -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     -1" + "'", str1.equals("                     -1"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80", 46, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444441.7.0_80" + "'", str3.equals("444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("# a       ", "eihpos", 0);
        java.lang.String[] strArray10 = new java.lang.String[] { "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "          " };
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray10, strArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray19 = new java.lang.String[] { "/", "Oracle Corporation", "# a       a" };
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray19, "/Users/sophie");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("Corporation Oracle", strArray12, strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray21, "/Users/sophie");
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/soph", strArray4, strArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Corporation Oracle" + "'", str22.equals("Corporation Oracle"));
        org.junit.Assert.assertNotNull(strArray24);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         " + "'", str1.equals("         "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a    4a 4444444444444444444444444444444444444444444444444444444444        ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("ers/sophie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/ome/jre", "a    4", 119);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "2sU80-b//", (int) (byte) -1, 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2sU80-b//" + "'", str4.equals("2sU80-b//"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "C orporation   O racle", 5);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.5", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("0#0#30", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int[] intArray3 = new int[] { (byte) 0, (short) 0, 30 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "8a0a100a100", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaa# a       a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "::::::::::::::::::::...", (java.lang.CharSequence) "ARY/JAVA/J", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sop");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOP" + "'", str1.equals("/uSERS/SOP"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("444444444444444444444444444444444444441.7.0_80", 119);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444441.7.0_80" + "'", str2.equals("444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.4");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 55, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("::::::::::::::::::::::::::::::", "", 119);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("                                            # a       a                                             ");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', 31, (int) (byte) -1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("CorporationxOracle", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("...dk1.7.0_80.jdk/contents/home/jre", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/jre" + "'", str2.equals("/jre"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("     ooo", "/users/sophie");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 100, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "1.5aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 46.0f, (double) 10.0f, (double) 21);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.0d + "'", double3 == 46.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Corporation # a       a", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Corporation # a       a" + "'", charSequence2.equals("Corporation # a       a"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "......................................................................................................................................................................................................");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.LWCToolkit", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "ers/sophie", "/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk/contents/home/jre", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str4.equals("xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "xed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (java.lang.CharSequence) "htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1\n.\n7htt1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, 8L, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ORACLE4cORPORATION", "   ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE4cORPORATION" + "'", str2.equals("ORACLE4cORPORATION"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                 1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(".21", (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.21f + "'", float2 == 0.21f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "8a0a100a100", (java.lang.CharSequence) "444444444444444eihpos", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("mv REVREs TIb-46 )mt(TOPsTOh AVAJ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "CorporationOracle");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("44", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("form API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"form API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4.4444444E7f, (float) 17, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10#100#100", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("demixed modemixed modemixed modemixed modemixed mode", " US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US US ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "demixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("demixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("htt1\n.\n7", "            10#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "htt1\n.\n7" + "'", str2.equals("htt1\n.\n7"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaa10#1", "/Users/sophCORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACLECORPORATIONXORACL");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa10#1" + "'", str2.equals("aaaa10#1"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4 4 4 4a4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 4 4 4a4#" + "'", str1.equals("4 4 4 4a4#"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "97.041.0435.040.0", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4 4 4 4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4 4 4 4a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                            # a       a                                             ", (int) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ARY/JAVA/J", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                     -1", 97, 30);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("                                            # a       a                                             ");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("# a       a");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("8 0 100 100", strArray11, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD", strArray3, strArray11);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8Java Virtual Machine Specification1.7.0_8", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8 0 100 100" + "'", str14.equals("8 0 100 100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD" + "'", str15.equals("ED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MOD"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3931 + "'", int16 == 3931);
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("HI!", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("        1.7.0_80         ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        1.7.0_80         " + "'", str2.equals("        1.7.0_80         "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" Oracle Corporation # a       a", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a" + "'", str2.equals(" Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a Oracle Corporation # a       a"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4", (int) (short) 100, "                                                 1.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie    4"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode" + "'", str2.equals("Mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("444444444444444444444444444444444444441.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1Corporation Oracle1.1", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " Oracle Corporation # a       a", (java.lang.CharSequence) "2sU80-b//");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UF-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("CLEATION oRAcORPOR", "", 55);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR" + "'", str3.equals("CLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPORCLEATION oRAcORPOR"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                       Mac/OS/X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaenaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4043040430404304043040430", 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("ers/sophie", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ers/..." + "'", str2.equals("ers/..."));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("444444444444444444444444444444444444441.7.0_80", "11.71");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444441.7.0_80" + "'", str2.equals("444444444444444444444444444444444444441.7.0_80"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("...dk1.7.0_80.jdk/contents/home/jre", (int) ' ', 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jre" + "'", str3.equals("jre"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.21.71.71.6", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.21.71.71.6" + "'", str3.equals("1.21.71.71.6"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("0.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.14." + "'", str1.equals("0.14."));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("htt1\n.\n7", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javau/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javar/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javao/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javap/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javah/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javai/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javae/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.11.11.11.11.11.11.1  ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/uSERS/SOP", (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "            10#100#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                ");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#4a4 4 4 4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a4 4 4 4a" + "'", str1.equals("#4a4 4 4 4a"));
    }
}

