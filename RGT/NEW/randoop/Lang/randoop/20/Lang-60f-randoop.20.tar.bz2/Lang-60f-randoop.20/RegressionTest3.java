import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test01");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("0.00.0");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setLength((int) (short) 0);
        org.junit.Assert.assertNotNull(strBuilder3);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test02");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.io.Reader reader3 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder0.insert(0, '#');
        int int8 = strBuilder0.lastIndexOf("#0.0f");
        int int9 = strBuilder0.length();
        int int12 = strBuilder0.lastIndexOf("6.00.01", (int) (short) 10);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(reader3);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test03");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append(0.0f);
        java.util.Iterator iterator6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.appendWithSeparators(iterator6, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) 0);
        boolean boolean11 = strBuilder2.equals(strBuilder8);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strBuilder2.asTokenizer();
        boolean boolean13 = strTokenizer12.hasNext();
        org.apache.commons.lang.text.StrMatcher strMatcher14 = strTokenizer12.getTrimmerMatcher();
        int int15 = strTokenizer12.previousIndex();
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(strMatcher14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test04");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.util.Iterator iterator3 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendWithSeparators(iterator3, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 0);
        java.lang.String str9 = strBuilder5.leftString((int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.append('.');
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.00.0" + "'", str9.equals("0.00.0"));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test05");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append(0.0f);
        java.util.Iterator iterator6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.appendWithSeparators(iterator6, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) 0);
        boolean boolean11 = strBuilder2.equals(strBuilder8);
        char[] charArray12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder13.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder17.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder17.append((long) (short) -1);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoredChar('a');
        boolean boolean32 = strTokenizer31.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.reset();
        char[] charArray39 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer33.reset(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray39);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder17.append(charArray39);
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer47.setIgnoredChar('a');
        boolean boolean50 = strTokenizer49.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.reset();
        char[] charArray57 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer51.reset(charArray57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray57);
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher61, strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoredChar('a');
        boolean boolean66 = strTokenizer65.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.reset();
        char[] charArray73 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer67.reset(charArray73);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray73);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray73);
        org.apache.commons.lang.text.StrMatcher strMatcher78 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher78, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer80.setIgnoredChar('a');
        boolean boolean83 = strTokenizer82.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.reset();
        int int85 = strTokenizer84.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer84.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer76.setQuoteMatcher(strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = new org.apache.commons.lang.text.StrTokenizer(charArray57, strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder17.deleteFirst(strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = new org.apache.commons.lang.text.StrTokenizer(charArray12, strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder2.deleteFirst(strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder94 = strBuilder2.insert(1, true);
        int int97 = strBuilder94.indexOf('a', (-1));
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(charArray73);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
        org.junit.Assert.assertNotNull(strBuilder94);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-1) + "'", int97 == (-1));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test06");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("0.0", '1');
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test07");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setDelimiterMatcher(strMatcher6);
        java.lang.String str8 = strTokenizer7.previousToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer7.setIgnoredChar('.');
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(strTokenizer10);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test08");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("444444");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test09");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder0.deleteCharAt((int) 'a');
        java.lang.String str8 = strBuilder6.substring(10);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.minimizeCapacity();
        java.io.Reader reader10 = strBuilder6.asReader();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str8.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(reader10);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test10");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.util.Iterator iterator3 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendWithSeparators(iterator3, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder2.ensureCapacity((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder2.reverse();
        java.lang.String str9 = strBuilder8.getNullText();
        int int12 = strBuilder8.indexOf("100aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#StrTokenizer[not tokenized yet]#0.0f100aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 11);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test11");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder9.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder9.append((long) (short) -1);
        char[] charArray22 = new char[] { '4', ' ', '4' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23, strMatcher24);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder17.insert((int) 'a', charArray22);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder17.appendPadding(0, '4');
        boolean boolean30 = strBuilder4.equals(strBuilder17);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.append('#');
        org.apache.commons.lang.text.StrMatcher strMatcher38 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.deleteAll(strMatcher38);
        boolean boolean41 = strBuilder37.startsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder37.deleteFirst("1aaaa#0.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str44 = strBuilder43.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder4.append((java.lang.Object) strBuilder43);
        java.io.Writer writer46 = strBuilder45.asWriter();
        char char48 = strBuilder45.charAt((int) (short) 100);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(writer46);
        org.junit.Assert.assertTrue("'" + char48 + "' != '" + '1' + "'", char48 == '1');
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test12");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteAll(strMatcher7);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder8.insert(100, (int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder11.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst("4a");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append('#');
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.deleteAll(strMatcher24);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append('#');
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.deleteAll(strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setQuoteChar(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer36.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder40.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder40.deleteCharAt((int) 'a');
        java.lang.String str48 = strBuilder46.substring(10);
        java.lang.Object[] objArray49 = new java.lang.Object[] { strTokenizer39, strBuilder46 };
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder32.appendWithSeparators(objArray49, "0.00.0");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder23.appendWithSeparators(objArray49, "#0.0f");
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder53.setNullText("0.00.0");
        org.apache.commons.lang.text.StrMatcher strMatcher57 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher58 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher57, strMatcher58);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer59.setIgnoredChar('a');
        boolean boolean62 = strTokenizer61.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer61.reset();
        int int64 = strTokenizer63.nextIndex();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder65.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder65.deleteCharAt((int) 'a');
        java.lang.String str73 = strBuilder71.substring(10);
        int int74 = strBuilder71.capacity();
        char[] charArray78 = new char[] { '4', ' ', '4' };
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher80 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer81 = new org.apache.commons.lang.text.StrTokenizer(charArray78, strMatcher79, strMatcher80);
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = new org.apache.commons.lang.text.StrTokenizer(charArray78, '#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer85 = new org.apache.commons.lang.text.StrTokenizer(charArray78, 'a');
        boolean boolean86 = strBuilder71.equals((java.lang.Object) charArray78);
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer63.reset(charArray78);
        char[] charArray88 = strBuilder53.getChars(charArray78);
        try {
            strBuilder12.getChars(111, 127, charArray78, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 127");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str48.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str73.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 100 + "'", int74 == 100);
        org.junit.Assert.assertNotNull(charArray78);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(charArray88);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test13");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder4.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder4.append((long) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.insert(0, (int) '4');
        int int17 = strBuilder15.lastIndexOf("0.00.0");
        char[] charArray19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder15.insert(100, charArray19);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append((long) '0');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder20.append(false);
        int int27 = strBuilder24.indexOf('.', (int) (byte) -1);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test14");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append(0.0f);
        java.util.Iterator iterator6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.appendWithSeparators(iterator6, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) 0);
        boolean boolean11 = strBuilder2.equals(strBuilder8);
        java.lang.String str12 = strBuilder2.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.append(0.0f);
        java.io.Reader reader16 = strBuilder13.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder13.insert(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder13.append(false);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder13.deleteFirst(strMatcher22);
        boolean boolean24 = strBuilder2.equals((java.lang.Object) strBuilder13);
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher26, strMatcher27);
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.setIgnoredChar('a');
        boolean boolean31 = strTokenizer30.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.reset();
        char[] charArray38 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer32.reset(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder2.appendFixedWidthPadLeft((java.lang.Object) strTokenizer32, 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder42.replace(0, (int) '4', "0.00.0");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder42.deleteFirst('a');
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.deleteFirst('0');
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strBuilder50.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder52.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder55.append(0.0f);
        java.util.Iterator iterator58 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder57.appendWithSeparators(iterator58, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder60.append((float) 0);
        boolean boolean63 = strBuilder54.equals(strBuilder60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strBuilder54.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher65 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer66 = strTokenizer64.setTrimmerMatcher(strMatcher65);
        java.lang.Object obj67 = strTokenizer66.clone();
        org.apache.commons.lang.text.StrMatcher strMatcher68 = strTokenizer66.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = strTokenizer51.setIgnoredMatcher(strMatcher68);
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer51.setDelimiterString("4a");
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer71.setDelimiterChar('#');
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(reader16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer66);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(strMatcher68);
        org.junit.Assert.assertNotNull(strTokenizer69);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertNotNull(strTokenizer73);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test15");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("StrTokenizer[]");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test16");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder9.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder9.append((long) (short) -1);
        char[] charArray22 = new char[] { '4', ' ', '4' };
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray22, strMatcher23, strMatcher24);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder17.insert((int) 'a', charArray22);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder17.appendPadding(0, '4');
        boolean boolean30 = strBuilder4.equals(strBuilder17);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder31.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder35.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder35.append((long) (short) -1);
        char[] charArray48 = new char[] { '4', ' ', '4' };
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher50 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher49, strMatcher50);
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder43.insert((int) 'a', charArray48);
        org.apache.commons.lang.text.StrMatcher strMatcher54 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher54, strMatcher55);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.setIgnoredChar('a');
        boolean boolean59 = strTokenizer58.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer58.reset();
        int int61 = strTokenizer60.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer60.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder63.append(0.0f);
        java.io.Reader reader66 = strBuilder63.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder63.insert(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder63.append(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strBuilder63.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher74 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher75 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher74, strMatcher75);
        org.apache.commons.lang.text.StrTokenizer strTokenizer78 = strTokenizer76.setIgnoredChar('a');
        boolean boolean79 = strTokenizer78.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer78.reset();
        int int81 = strTokenizer80.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher82 = strTokenizer80.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = strTokenizer72.setDelimiterMatcher(strMatcher82);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray48, strMatcher62, strMatcher82);
        org.apache.commons.lang.text.StrBuilder strBuilder86 = strBuilder4.replaceFirst(strMatcher82, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder4.insert(116, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = strBuilder4.asTokenizer();
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(charArray22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(charArray48);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(reader66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strTokenizer78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(strMatcher82);
        org.junit.Assert.assertNotNull(strTokenizer83);
        org.junit.Assert.assertNotNull(strBuilder86);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strTokenizer90);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test17");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append(0.0f);
        java.util.Iterator iterator6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.appendWithSeparators(iterator6, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) 0);
        boolean boolean11 = strBuilder2.equals(strBuilder8);
        char[] charArray12 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder13.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder17.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder17.append((long) (short) -1);
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher27, strMatcher28);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer29.setIgnoredChar('a');
        boolean boolean32 = strTokenizer31.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer31.reset();
        char[] charArray39 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer33.reset(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray39);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder17.append(charArray39);
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher46 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher45, strMatcher46);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strTokenizer47.setIgnoredChar('a');
        boolean boolean50 = strTokenizer49.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = strTokenizer49.reset();
        char[] charArray57 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer51.reset(charArray57);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray57);
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher62 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher61, strMatcher62);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoredChar('a');
        boolean boolean66 = strTokenizer65.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer67 = strTokenizer65.reset();
        char[] charArray73 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer67.reset(charArray73);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray73);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray73);
        org.apache.commons.lang.text.StrMatcher strMatcher78 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher79 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher78, strMatcher79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer80.setIgnoredChar('a');
        boolean boolean83 = strTokenizer82.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = strTokenizer82.reset();
        int int85 = strTokenizer84.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher86 = strTokenizer84.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer87 = strTokenizer76.setQuoteMatcher(strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer88 = new org.apache.commons.lang.text.StrTokenizer(charArray57, strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder17.deleteFirst(strMatcher86);
        org.apache.commons.lang.text.StrTokenizer strTokenizer90 = new org.apache.commons.lang.text.StrTokenizer(charArray12, strMatcher86);
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder2.deleteFirst(strMatcher86);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder2.append(".00.0", 112, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: startIndex must be valid");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(charArray57);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(strTokenizer67);
        org.junit.Assert.assertNotNull(charArray73);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(strTokenizer84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(strMatcher86);
        org.junit.Assert.assertNotNull(strTokenizer87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test18");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.util.Iterator iterator3 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendWithSeparators(iterator3, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.append((float) 0);
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.replaceAll(strMatcher8, "");
        java.lang.StringBuffer stringBuffer11 = strBuilder5.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder5.setNullText("");
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(stringBuffer11);
        org.junit.Assert.assertNotNull(strBuilder13);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test19");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher1);
        boolean boolean3 = strTokenizer2.hasNext();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer2.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher8 = strTokenizer7.getTrimmerMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = strTokenizer7.getTrimmerMatcher();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strMatcher8);
        org.junit.Assert.assertNotNull(strMatcher9);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test20");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append(0.0f);
        java.util.Iterator iterator6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.appendWithSeparators(iterator6, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) 0);
        boolean boolean11 = strBuilder2.equals(strBuilder8);
        java.lang.String str12 = strBuilder2.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder2.deleteFirst('0');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteFirst("");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.append(strBuilder17, (int) (byte) 1, (int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.replaceFirst('0', '0');
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test21");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.util.Iterator iterator3 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendWithSeparators(iterator3, "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder2.replaceFirst(strMatcher6, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder2.replaceAll('#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder2.appendFixedWidthPadRight((int) (short) -1, (int) (byte) -1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.appendNewLine();
        char[] charArray17 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = new org.apache.commons.lang.text.StrTokenizer(charArray17, strMatcher18, strMatcher19);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = strTokenizer20.setIgnoredMatcher(strMatcher21);
        java.lang.String[] strArray23 = strTokenizer20.getTokenArray();
        java.util.List list24 = strTokenizer20.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.append(0.0f);
        java.util.Iterator iterator28 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder27.appendWithSeparators(iterator28, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append((float) 0);
        org.apache.commons.lang.text.StrMatcher strMatcher33 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder30.replaceAll(strMatcher33, "");
        java.lang.StringBuffer stringBuffer36 = strBuilder30.toStringBuffer();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer("0.00.0", ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder40 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder40.append(0.0f);
        java.io.Reader reader43 = strBuilder40.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder40.insert(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder40.append(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = strBuilder40.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher51 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher51, strMatcher52);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = strTokenizer53.setIgnoredChar('a');
        boolean boolean56 = strTokenizer55.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = strTokenizer55.reset();
        int int58 = strTokenizer57.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher59 = strTokenizer57.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer60 = strTokenizer49.setDelimiterMatcher(strMatcher59);
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer39.setIgnoredMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder30.replaceFirst(strMatcher59, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer20.setQuoteMatcher(strMatcher59);
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder15.append((java.lang.Object) strTokenizer20);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strTokenizer22);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(stringBuffer36);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(reader43);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strTokenizer49);
        org.junit.Assert.assertNotNull(strTokenizer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strTokenizer57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(strMatcher59);
        org.junit.Assert.assertNotNull(strTokenizer60);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strBuilder65);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test22");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder4.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder4.append((long) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.insert(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder12.replaceAll('a', '0');
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher20, strMatcher21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer22.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer24.setDelimiterMatcher(strMatcher25);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.reset("0.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer28.setDelimiterChar('4');
        int int31 = strTokenizer28.size();
        java.lang.String str32 = strTokenizer28.previousToken();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer28.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder18.deleteAll(strMatcher33);
        int int36 = strBuilder18.lastIndexOf("StrTokenizer[]");
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test23");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder4.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder4.append((long) (short) -1);
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher14, strMatcher15);
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer16.setIgnoredChar('a');
        boolean boolean19 = strTokenizer18.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer20 = strTokenizer18.reset();
        char[] charArray26 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer20.reset(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray26);
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder4.append(charArray26);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append(5);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.insert(97, "");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder35.insert(0, (long) 9);
        char[] charArray41 = strBuilder38.toCharArray(0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder38.insert(117, (float) 118);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strTokenizer20);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test24");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append(0.0f);
        java.io.Reader reader6 = strBuilder3.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder3.insert(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder3.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder16.append((long) (short) -1);
        char[] charArray29 = new char[] { '4', ' ', '4' };
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher30, strMatcher31);
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder24.insert((int) 'a', charArray29);
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher36 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher35, strMatcher36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer37.setIgnoredChar('a');
        boolean boolean40 = strTokenizer39.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer39.reset();
        int int42 = strTokenizer41.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher43 = strTokenizer41.getIgnoredMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.append(0.0f);
        java.io.Reader reader47 = strBuilder44.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder44.insert(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder44.append(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strBuilder44.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher56 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer57 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher55, strMatcher56);
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer57.setIgnoredChar('a');
        boolean boolean60 = strTokenizer59.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer59.reset();
        int int62 = strTokenizer61.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher63 = strTokenizer61.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer53.setDelimiterMatcher(strMatcher63);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray29, strMatcher43, strMatcher63);
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder11.deleteAll(strMatcher43);
        org.apache.commons.lang.text.StrMatcher strMatcher68 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher68, strMatcher69);
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer70.setIgnoredChar('a');
        boolean boolean73 = strTokenizer72.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = strTokenizer72.reset();
        int int75 = strTokenizer74.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher76 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer74.setTrimmerMatcher(strMatcher76);
        org.apache.commons.lang.text.StrMatcher strMatcher78 = strTokenizer74.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer79 = new org.apache.commons.lang.text.StrTokenizer("0.00.0", strMatcher43, strMatcher78);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer1.setDelimiterMatcher(strMatcher43);
        int int81 = strTokenizer80.nextIndex();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(reader6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(strMatcher43);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(reader47);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(strMatcher63);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(strTokenizer74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strMatcher78);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test25");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('a');
        boolean boolean6 = strTokenizer3.isEmptyTokenAsNull();
        boolean boolean7 = strTokenizer3.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer3.reset("#0.0");
        int int10 = strTokenizer3.size();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer3.setQuoteChar('a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer12.setIgnoreEmptyTokens(true);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(strTokenizer14);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test26");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.deleteAll(strMatcher7);
        boolean boolean10 = strBuilder6.startsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder6.deleteFirst("1aaaa#0.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder6.appendPadding(101, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append(0.0f);
        java.util.Iterator iterator19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.appendWithSeparators(iterator19, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append((float) 0);
        org.apache.commons.lang.text.StrMatcher strMatcher24 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder21.replaceAll(strMatcher24, "");
        org.apache.commons.lang.text.StrMatcher strMatcher27 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder21.replaceAll(strMatcher27, "0.0");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder21.append((float) 6);
        boolean boolean32 = strBuilder15.equals(strBuilder21);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher35 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher34, strMatcher35);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer36.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setDelimiterMatcher(strMatcher39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = strTokenizer40.reset("0.0");
        int int43 = strTokenizer40.nextIndex();
        org.apache.commons.lang.text.StrMatcher strMatcher44 = strTokenizer40.getDelimiterMatcher();
        int int46 = strBuilder21.lastIndexOf(strMatcher44, (int) (short) 100);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(strMatcher44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test27");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.io.Reader reader3 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder0.insert(0, '#');
        int int8 = strBuilder0.indexOf('4');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder0.ensureCapacity((int) (short) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.append(0.0f);
        java.util.Iterator iterator14 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder13.appendWithSeparators(iterator14, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.append((float) 0);
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder16.replaceAll(strMatcher19, "");
        java.lang.StringBuffer stringBuffer22 = strBuilder16.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder10.append(stringBuffer22);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.append(5);
        int int26 = strBuilder23.size();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder23.append(true);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(reader3);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(stringBuffer22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test28");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder4.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder4.append((long) (short) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.deleteFirst('a');
        org.apache.commons.lang.text.StrMatcher strMatcher15 = null;
        boolean boolean16 = strBuilder12.contains(strMatcher15);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder12.appendFixedWidthPadLeft((int) '#', 1, ' ');
        char[] charArray21 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher23 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray21, strMatcher22, strMatcher23);
        java.util.List list25 = strTokenizer24.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder20.appendWithSeparators((java.util.Collection) list25, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        int int29 = strBuilder20.indexOf(strMatcher28);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test29");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher4 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setTrimmerMatcher(strMatcher4);
        java.lang.String str6 = strTokenizer5.getContent();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = strTokenizer5.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer5.reset("6688aa6f4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444432.0");
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher7);
        org.junit.Assert.assertNotNull(strTokenizer9);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test30");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("StrTokenizer[0.0]");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test31");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.util.Iterator iterator3 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder2.appendWithSeparators(iterator3, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("");
        java.util.List list8 = strTokenizer7.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder5.appendWithSeparators((java.util.Collection) list8, "#0.0");
        int int12 = strBuilder10.indexOf('1');
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test32");
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher1, strMatcher2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('a');
        boolean boolean6 = strTokenizer5.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.reset();
        char[] charArray13 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strTokenizer7.reset(charArray13);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray13);
        org.apache.commons.lang.text.StrTokenizer strTokenizer17 = new org.apache.commons.lang.text.StrTokenizer(charArray13, "0.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer17.setIgnoredChar('#');
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher21, strMatcher22);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer23.setIgnoredMatcher(strMatcher26);
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', '#');
        java.util.List list32 = strTokenizer31.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher33 = strTokenizer31.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer23.setQuoteMatcher(strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer17.setIgnoredMatcher(strMatcher33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoredChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strTokenizer35.reset();
        org.apache.commons.lang.text.StrMatcher strMatcher39 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setDelimiterMatcher(strMatcher39);
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strTokenizer14);
        org.junit.Assert.assertNotNull(strTokenizer15);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(strMatcher33);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strTokenizer40);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test33");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder0.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder4.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder4.appendPadding(1, 'a');
        java.lang.String str15 = strBuilder4.rightString(0);
        char char17 = strBuilder4.charAt((int) 'a');
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + char17 + "' != '" + 'a' + "'", char17 == 'a');
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test34");
        org.apache.commons.lang.text.StrBuilder strBuilder0 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder0.append(0.0f);
        java.io.Reader reader3 = strBuilder0.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder0.insert(0, '#');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder0.append(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strBuilder0.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder0.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.append(100.0d);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder10.replaceFirst('#', '.');
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder();
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.appendFixedWidthPadRight((java.lang.Object) 100L, (int) (short) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append('#');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder20.appendFixedWidthPadRight((int) (byte) 10, (int) (byte) 10, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher28 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher29 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher28, strMatcher29);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = strTokenizer30.setIgnoredChar('a');
        boolean boolean33 = strTokenizer32.hasPrevious();
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.reset();
        char[] charArray40 = new char[] { '4', 'a', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer41 = strTokenizer34.reset(charArray40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray40);
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder20.append(charArray40);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strBuilder20.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher45 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer44.setIgnoredMatcher(strMatcher45);
        org.apache.commons.lang.text.StrMatcher strMatcher48 = null;
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher48, strMatcher49);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer50.setIgnoredChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher53 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer50.setIgnoredMatcher(strMatcher53);
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a', '#');
        java.util.List list59 = strTokenizer58.getTokenList();
        org.apache.commons.lang.text.StrMatcher strMatcher60 = strTokenizer58.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer50.setQuoteMatcher(strMatcher60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = strTokenizer46.setIgnoredMatcher(strMatcher60);
        int int63 = strBuilder10.indexOf(strMatcher60);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertNotNull(reader3);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strTokenizer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(strTokenizer41);
        org.junit.Assert.assertNotNull(strTokenizer42);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(strMatcher60);
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strTokenizer62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
    }
}

