import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(300, (int) (byte) 1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SU", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avaj" + "'", str1.equals("noitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avaj"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification" + "'", str1.equals("java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("b", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "hi!");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("SU", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("x86_64", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US" + "'", str1.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("en", "sun.lwawt.macosx.CPrinterJob10.14.3", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/", "http://java.oracle.com/", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "uTF-8", (java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ", "3");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("            mixed mode             ", "r");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "US", (int) (short) 1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15" + "'", str4.equals("1.7.0_80-b15"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "08_0.7.1");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/UUTF-8/Us", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         /UUTF-8/Us" + "'", str2.equals("                         /UUTF-8/Us"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("http://java.oracle.com/         ", "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/         " + "'", str2.equals("http://java.oracle.com/         "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", "r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("            mixed mode             ", (int) (byte) 1, "                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            mixed mode             " + "'", str3.equals("            mixed mode             "));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "noitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("sun.lwaw", "r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(":http://java.oracle.com/http://java.oracle.com/http:", "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("US", "08_0.7.1", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com/         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/         " + "'", str1.equals("HTTP://JAVA.ORACLE.COM/         "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("SU/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/", "08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Users/sophie", "E Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie" + "'", str2.equals("Users/sophie"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", '4');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("mixed mode", strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "##############################################10.14.3###############################################");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("###############################################10.1.3###############################################", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(":http://java.oracle.com/http://java.oracle.com/http:", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":http://java.oracle.com/http://java.oracle.com/http:" + "'", str2.equals(":http://java.oracle.com/http://java.oracle.com/http:"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 862, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "Java Platform API Specificationsun.lwawt.macosx.LWCT");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM" + "'", charSequence2.equals("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                ", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                " + "'", str2.equals("                "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "Users/sophie", "08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        char[] charArray7 = new char[] { 'a', '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":http://java.oracle.com/http://java.oracle.com/http:", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/         ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "            mixed mode             ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("e", "", "            \n");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("UTF-8", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("            mixed mode             ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("b", 300);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) 10, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("sun.lwaw", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwaw" + "'", str2.equals("sun.lwaw"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("UUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UUS" + "'", str1.equals("UUS"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Platf", "http://java.oracle.com/", "UUS", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platf" + "'", str4.equals("Java Platf"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("jAVA(tm) se rUNTIME eNVIRONMENT", 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                              sophie                              ", "b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              sophie                              " + "'", str2.equals("                              sophie                              "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("hi!", "en", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                         /UUTF-8/Us");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("86_64", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86_64" + "'", str3.equals("86_64"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(":http://java.oracle.com/http://java.oracle.com/http:", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, (float) 0L, 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(31.0d, (double) (short) 0, (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("en", 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1L), (float) 52L, 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, ":http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":http://ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "Oracle Corporation", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/users/sophie", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("            mixed mode             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("atio", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                                                                                                                                                                                                                            ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixedmode", "AVA(tm) se rUNTIME eNVIRONMENT", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("          ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java(TM) SE Runtime Environmentosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(51.0f, 1.7f, (float) 13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              "));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("          ", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "51.0", "http://java.oracle.com/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("10.1. 1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "UUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":http://ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":http://ja" + "'", str1.equals(":http://ja"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, 0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("e", ":http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("##############################################10.14.3###############################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, 1.7f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "Java Platform API Specification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.1.3" + "'", str1.equals("10.1.3"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("AVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "###############################################10.1.3###############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US", "sun.lwawt.macosx.CPrinterJob", 66);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "3", 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("\n", "                         /UUTF-8/Us");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("51.0", 143, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("jAVA(tm) se rUNTIME eNVIRONMENT", "Oracle Corporation", (int) (byte) -1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("poratio", strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_64", "en");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64" + "'", str4.equals("x86_64"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.LWCToolkit", "en", "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                         /UUTF-8/Us", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300 + "'", int2 == 300);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":http://java.oracle.com/http://java.oracle.com/http:", 862, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (-1L), 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java Platform API Specification", "/", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 66, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", "###############################################10.1.3###############################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("46_68X", "Library/Ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":http://ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt", "/Users/sophie/Libr#ry/J#v#/Extensions:/Libr#ry/J#v#/Extensions:/Network/Libr#ry/J#v#/Extensions:/System/Libr#ry/J#v#/Extensions:/usr/lib/j#v#:.", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "###############################################10.1.3###############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "          ", "mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US", "1.7");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Oracle Corporation", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("3", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("http://java.oracle.com/         ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("http://java.oracle.com/", (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                         /UUTF-8/Us", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         /UUTF-8/Us" + "'", str2.equals("                         /UUTF-8/Us"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("O p", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O p                                                                                                 " + "'", str2.equals("O p                                                                                                 "));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java Platf", "sun.lwaw");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platf" + "'", str2.equals("Java Platf"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.1. 1.1", "86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("08_0.7.1", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt", (float) 12);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "AVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, (int) (byte) 100, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", "O p                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("            \n", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("O p", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O p" + "'", str2.equals("O p"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("Java Virtual Machine Specification", "r", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                ", "                              sophie                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("SU/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SU/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sophie", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sophie", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("E Runtime Environmen", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:", "sun.lwaw");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E Runtime Environmen" + "'", str3.equals("E Runtime Environmen"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("utf-8", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8" + "'", str2.equals("utf-8"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Vi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", ":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("noitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avajnoitacificeps ipa mroftalp avaj", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(51.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("r");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r" + "'", str1.equals("r"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int[] intArray5 = new int[] { '#', (-1), (short) -1, (byte) 1, (byte) -1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("SU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, 0L, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.1. 1.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.1. 1.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("b", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "/UUTF-8/Us");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("\n", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "##############################################10.14.3###############################################", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("          ", "            \n", 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n          " + "'", str3.equals("                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n          "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "###############################################10.1.3###############################################", (int) (byte) 100);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(":http://ja", strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "poratio", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE Runtime Environment", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("E Runtime Environmen");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "http://java.oracle.com/         ", "O p                                                                                                 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US", "1.7", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("i");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: i is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US", "UUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US" + "'", str2.equals("Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "SU/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(" ", "O p                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "/", "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("mixed mode", (long) 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("HTTP://JAVA.ORACLE.COM/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HTTP://JAVA.ORACLE.COM/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("10.14.3", strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/", 10, (int) (short) 10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 0, 170);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.CPrinterJob10.14.3", 31, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "14.3" + "'", str3.equals("14.3"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Library/Ja", "Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Ja" + "'", str2.equals("Library/Ja"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("atio", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14." + "'", str1.equals("14."));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS X", "Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "          ", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "1.7.0_80");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (byte) 10, 10);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("O p                                                                                                 ", strArray3, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "UUS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("jAVA hOTsPOT(tm) 64-bIT sERVER vm", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) (short) 10, 70L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US" + "'", str2.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "Java Platf", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/UUTF-8/Us", "##############################################10.14.3###############################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("b", (int) (byte) 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b" + "'", str3.equals("b"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("51.0", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                         /UUTF-8/Us", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         /UUTF-8/Us" + "'", str2.equals("                         /UUTF-8/Us"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, (int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("mixedmode", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                              sophie                              ", "O p                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.14.3", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("E Runtime Environmen", ":http://ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie", 5, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("O p", "1.7.0_80", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("e", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("i");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/", (int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("            \n", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            \n" + "'", str2.equals("            \n"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("mixed mode", "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Library/Ja", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ibrary/Ja" + "'", str2.equals("ibrary/Ja"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("O p", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("e");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ibrary/Ja", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixedmode", 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (-1), "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "uTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "ibrary/Ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ibrary/Ja" + "'", str1.equals("ibrary/Ja"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environmentosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM)\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("UTF-8", "java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("SU", "UTF-8", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "46_68X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "            \n", "10.14.3");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:", "b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0, "10.1.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "b" + "'", str1.equals("b"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("14.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"14.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", 66, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", 862);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..." + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..."));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.CharSequence[] charSequenceArray0 = new java.lang.CharSequence[] {};
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray0, "            mixed mode             ");
        org.junit.Assert.assertNotNull(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("###############################################10.1.3###############################################", "ibrary/Ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwaw");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("http://java.oracle.com/         ", (int) (byte) 100, 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(" ", "r", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "i", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("O p", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O p" + "'", str3.equals("O p"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51.0", 70);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test314");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("            mixed mode             ", "Users/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "10.1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "E Runtime Environmen");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(12.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mac OS X", (int) (byte) 0, "SU");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Library/Ja", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Library/Ja" + "'", str2.equals("Library/Ja"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("UUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UUS" + "'", str1.equals("UUS"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("X86_64", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "\n");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("e", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e" + "'", str8.equals("e"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" ", 8, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " /Users/" + "'", str3.equals(" /Users/"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        char[] charArray8 = new char[] { 'a', '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":http://java.oracle.com/http://java.oracle.com/http:", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":http://java.oracle.com/http://java.oracle.com/http:", charArray8);
        java.lang.Class<?> wildcardClass12 = charArray8.getClass();
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("Java Platform API Specification", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("O p                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"O p                                                                                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("b", (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("14.3", "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14.3" + "'", str2.equals("14.3"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("            mixed mode             ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            mixed mode             " + "'", str2.equals("            mixed mode             "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Mac OS X", 862);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                           Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                           " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                           Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                           "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixedmode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "O p");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/", "b", "atio", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "uTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("en", "Library/Ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        char[] charArray8 = new char[] { 'a', '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("HTTP://JAVA.ORACLE.COM/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 8, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle C" + "'", str3.equals("Oracle C"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                                                                                                                                                                                                                            ", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                            " + "'", str2.equals("                                                                                                                                                                                                                                                                                                            "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n          ", "3", 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      \n          3                     \n          " + "'", str3.equals("                      \n          3                     \n          "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("###############################################10.1.3###############################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java Platform API Specificationsun.lwawt.macosx.LWCT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificationsun.lwawt.macosx.LWCT" + "'", str1.equals("Java Platform API Specificationsun.lwawt.macosx.LWCT"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("java platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specificationjava platform api specification", (-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java platform api specificationjava platform api specificationjava platform api specificationj..." + "'", str3.equals("java platform api specificationjava platform api specificationjava platform api specificationj..."));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                    ", "3", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                                                                                                                                                                                                                                            ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("46_68X", "10.1.3", "Mac OS X", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "46_68X" + "'", str4.equals("46_68X"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(170);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("jAVA(tm) se rUNTIME eNVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA(tm) se rUNTIME eNVIRONMENT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "Java(TM) SE Runtime Environment", "3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..." + "'", str2.equals("m API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        short[] shortArray6 = new short[] { (short) 10, (byte) 0, (byte) -1, (short) 1, (short) -1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Platf", "mixed mode", 70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("24.80-b11", "http://java.oracle.com/         ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "Oracle C", "mixedmode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":", (int) (short) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":###################################################################################################" + "'", str3.equals(":###################################################################################################"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) " /Users/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " /Users/" + "'", str1.equals(" /Users/"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("AVA(tm) se rUNTIME eNVIRONMENT", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "86_64", "http://java.oracle.com/         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com" + "'", str1.equals("http://java.oracle.com"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("utf-8", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "utf-8" + "'", str2.equals("utf-8"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("java platform api specificationjava platform api specificationjava platform api specificationj...", 300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 12, (float) 100, 51.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("10.1.3", "uTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("O p                                                                                                 ", 143, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaO p                                                                                                 aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaO p                                                                                                 aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "                         /UUTF-8/Us", ":http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specification", "            mixed mode             ", 70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("mixedmode", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(70, 66, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("HTTP://JAVA.ORACLE.COM/", "                         /UUTF-8/Us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM" + "'", str2.equals("HTTP://JAVA.ORACLE.COM"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("uTF-8", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Platf", "utf-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platf" + "'", str2.equals("Java Platf"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "O p");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("10.1. 1.1", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob", 862);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Sophie", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("uTF-8", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uTF-8UuTF-8sersuTF-8/uTF-8sophie" + "'", str3.equals("/uTF-8UuTF-8sersuTF-8/uTF-8sophie"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("http://java.oracle.com/", "", "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM", 16, "e");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMRunJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMEnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnmJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VMnJava Virtual Machine Specificationava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", 3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("sophie", (java.lang.Object[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n", "Java Platform API Specification", (int) (short) 100);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "10.1. 1.1", (int) (byte) 100, 100);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                    ", "Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("1", "uTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) 70, (long) 862);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 862L + "'", long3 == 862L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "hi!", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("/", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("r", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "r", (int) (short) 1, 66);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10699_1560229123", "Oracle C", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("O p", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O p" + "'", str2.equals("O p"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', (long) 100, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "r", "/uTF-8UuTF-8sersuTF-8/uTF-8sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("Oracle Corporation", "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("##############################################10.14.3###############################################", 66);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Sophie", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt.CGraphicsEnvironment", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444410.14.3444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                      \n          3                     \n          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("atio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ATIO" + "'", str1.equals("ATIO"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..." + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..."));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...", "uTF-8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("14.", "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("E Runtime Environmen", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E Runtime Environmen" + "'", str3.equals("E Runtime Environmen"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("atio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ATIO" + "'", str1.equals("ATIO"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        char[] charArray8 = new char[] { 'a', '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "86_64", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("                                                                                                                                                                                                                                                                                                                                                                                                                                           Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                           ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "m API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT" + "'", str1.equals("jAVA(tm) se rUNTIME eNVIRONMENT"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...", 862, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.CPrinterJob", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                ", "", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          :http://java.oracle.com/http://java.oracle.com/http:");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "1.7.0_80");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("x86_64", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "                                                                                                    ");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("jAVA(tm) se rUNTIME eNVIRONMENT", "Oracle Corporation", (int) (byte) -1);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironment", strArray4, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                                                                                                                                                                                                                                                                                            " + "'", str7.equals("                                                                                                                                                                                                                                                                                                            "));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                                                                                                                                                                                                                                                                                                                                           Mac OS X                                                                                                                                                                                                                                                                                                                                                                                                                                           ", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaO p                                                                                                 aaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Platform API Specificationsun.lwawt.macosx.LWCT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Pl\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("##############################################10.14.3###############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/         " + "'", str1.equals("http://java.oracle.com/         "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HTTP://JAVA.ORACLE.COM/", "E Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.1.3", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("US", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((-1.0f));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "08_0.7.1", (int) (short) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("hi!", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTF-8" + "'", str5.equals("UTF-8"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTF-8" + "'", str6.equals("UTF-8"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "UUS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" /Users/", "08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " /Users/" + "'", str2.equals(" /Users/"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/J" + "'", str2.equals("/Users/sophie/Library/J"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                      \n          3                     \n          ", "O p                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n                      \n          ", 30, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               \n      " + "'", str3.equals("               \n      "));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", " /Users/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              " + "'", str2.equals("                              "));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", '4');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("mixed mode", strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "##############################################10.14.3###############################################");
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("", '4');
        int int18 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("mixed mode", strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, 'a');
        boolean boolean21 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray17);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "##############################################10.14.3###############################################");
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Platform API Specification", strArray5, strArray17);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Java Platform API Specification" + "'", str24.equals("Java Platform API Specification"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("10.14.3", strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/", 10, (int) (short) 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aaa" + "'", str10.equals("aaa"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("08_0.7.1///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", "atio", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0.7.1//atio/////////" + "'", str3.equals("08_0.7.1//atio/////////"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("O p", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "14.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environm" + "'", str2.equals("Java(TM) SE Runtime Environm"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(":http://java.oracle.com/http://java.oracle.com/http:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("jAVA(tm) se rUNTIME eNVIRONMENT", "Oracle Corporation", (int) (byte) -1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/J" + "'", str3.equals("/Library/J"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3.0f, (double) (-1.0f), (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 3, "            \n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("Sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", "ibrary/Ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                    ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaO p                                                                                                 aaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "               \n      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server VM", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", "1.7.0_80");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("x86_64", strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Java(TM) SE Runtime Environment", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 170, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Env" + "'", str3.equals("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Env"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Users/sophie", (-1), "jAVA hOTsPOT(tm) 64-bIT sERVER vm");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie" + "'", str3.equals("Users/sophie"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("x86_64", "X86_64", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "08_0.7.1//atio/////////");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("m API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec...", "SU", 5, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mSU SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..." + "'", str4.equals("mSU SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Spec..."));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US" + "'", str1.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/US"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwawt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Library/J", "/UUTF-8/Us", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "UTF-8", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("en", "aaa", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7.0_80", " /Users/", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1), (double) 'a', 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt" + "'", str2.equals("sun.lwawt"));
    }
}

