import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("44444444444444444444444444444444", "             sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), (float) (short) 10, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "HI!H...HI!H...HI!H...HI!H...HI!H...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas" + "'", str1.equals("easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "Users/sop");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        java.lang.Class<?> wildcardClass4 = javaVersion0.getClass();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "OracleCor-1.0JavaVirtualMachineSpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        char[] charArray3 = new char[] { 'a' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Sophi", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " hothpot(u ) 64-iit herver   ava!", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 7, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        double[] doubleArray5 = new double[] { (short) 100, 100L, '#', 100, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("USERS/SOP", "4.a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JAVA VIRTUAL MACHINE SPECIFICATION", 344, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################################################################################################################################################################################################################################################################################################################JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("######################################################################################################################################################################################################################################################################################################################JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie                          on Orcle CorportionCorportion", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                   44444444444444444444444444444                                    ", (java.lang.CharSequence) "SU", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("X664", 65, 41);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X664" + "'", str3.equals("X664"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L", "HI!   H...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L" + "'", str2.equals("rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("           #           ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("HI        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: HI         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaHIaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaHIaa" + "'", str1.equals("aaaHIaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.#");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "4.a");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "lrarO el", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("RMAPISPECIFICATION", "10.14.#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RMAPISPECIFICATION" + "'", str2.equals("RMAPISPECIFICATION"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        char[] charArray12 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "orcleOrcle Corportion Orcle CorportionCorportion", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "orcleorcle corportion orcle corportioncorportion", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", (java.lang.CharSequence) "::::::::::::::::::::::::::sophie", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "##############################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "mixed mo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!HI!hi!aaaaaaaaaaaaaaaaaaa", "             sophie  ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("jAVApLATFORMapisPECIFICATION", 65, "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64x86_64x86_64x86_64x86_64x86_64xjAVApLATFORMapisPECIFICATION" + "'", str3.equals("x86_64x86_64x86_64x86_64x86_64x86_64xjAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Or#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tion" + "'", str3.equals("Or#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tion"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "    SophiSoHI", (java.lang.CharSequence) "cle.com/a.oravahttp://j", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 37L, 37.0f, (float) 46);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 46.0f + "'", float3 == 46.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("noitaroproC elcarOroC elcaro", "4444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_6", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HISOPMIXED MOD");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "                                   44444444444444444444444444444                                    ", "SophiSoHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.j" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos", "n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos" + "'", str2.equals("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ava/JavaVi...", (int) ' ', "oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleCorporation..ava/JavaVi..." + "'", str3.equals("oracleCorporation..ava/JavaVi..."));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292", "", 8, 115);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/S" + "'", str4.equals("/USERS/S"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Hi!SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("OracleaCorporation", 0, 115);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleaCorporation" + "'", str3.equals("OracleaCorporation"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 97, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", (float) 7L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI! H...e specificati", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I! H...e specificati" + "'", str2.equals("I! H...e specificati"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "LATFORMapisPECIFIC", (java.lang.CharSequence) "n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 18, 0L, 18L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "HI!", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = null;
        try {
            boolean boolean4 = javaVersion0.atLeast(javaVersion3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "Oracle CorOracle Corporation", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("44444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_6", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6" + "'", str2.equals("x86_6"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("HI! H...e specificati");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi! h...E SPECIFICATI" + "'", str1.equals("hi! h...E SPECIFICATI"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("unxiwwnxJ.sxxCPCinnnCJ.b", "sOPHIE##########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "unxiwwnxJ.sxxCPCinnnCJ.b" + "'", str2.equals("unxiwwnxJ.sxxCPCinnnCJ.b"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 78, 180.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 'a', (double) 180, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 180.0d + "'", double3 == 180.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "####################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie" + "'", str3.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("444444444444444444", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444" + "'", str2.equals("444444444444444444"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("va!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("      ", 93, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HI!HI!hi!1.7.0_801.7.0_801.7.", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!hi!1.7.0_801.7.0_801.7." + "'", str2.equals("HI!HI!hi!1.7.0_801.7.0_801.7."));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("va!", "                                ", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("              sophie               ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!HI!hi!aaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("24.80-b11         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0", "rmAPI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("...AROPROC ELCARONOITAROP...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 48, (float) 8L, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", "5A0-BA0_A7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification", "                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("...4444", 78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                       ...4444" + "'", str2.equals("                                                                       ...4444"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("::::::::::444444444444444444", 13, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", "SOPHIE!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################" + "'", str2.equals("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "HI");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                        ", 53, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "o", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "   10.14.#", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n", "EN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "               rmAPI               ", "...:::::::::::::::::::::::::::::......:::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(65, 33, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaom deximaaaaa", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaa" + "'", str2.equals("aaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaa"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N2X1N4FC0000GN/t/" + "'", str1.equals("N2X1N4FC0000GN/t/"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                   O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 15, (long) (byte) 10, 33L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 115, (long) (short) 100, (long) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 46, "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersionclas" + "'", str3.equals("class org.apache.commons.lang3.JavaVersionclas"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444", 0, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444" + "'", str3.equals("44444444444444444444444"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.#", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) 13, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("::::::::::444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::444444444444444444" + "'", str1.equals("::::::::::444444444444444444"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "aaaaPOSaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi! h...E SPECIFICATI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi! h...E SPECIFICATI" + "'", str1.equals("hi! h...E SPECIFICATI"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("javaplatformapispecification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 780);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                       ...4444", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.0f, 0.0d, (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("#", "HOTHPOT(U ) 64-IIT HERVER   AVA!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(" hothpot(u ) 64-iit herver   ava!", "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j", "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HOTHPOT(U ) 64-IIT HERVER   AVA!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "e               rmAPI               e               rmAPI               e", (java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION", charSequence1, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("::::::::::", "1.7.0_80-b15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::::" + "'", str3.equals("::::::::::"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                       ...4444", (int) (short) 10, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                       ...4444" + "'", str3.equals("                                                                       ...4444"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("SophiSophiSophiSophiSopmixed mod", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  SophiSophiSophiSophiSopmixed mod                                  " + "'", str2.equals("                                  SophiSophiSophiSophiSopmixed mod                                  "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.a", (int) (short) -1, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.a" + "'", str3.equals("10.14.a"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        char[] charArray6 = new char[] { 'a', 'a', ' ', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/USERS/S", charSequence1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5a0-ba0_a7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5a0-ba0_a7" + "'", str1.equals("5a0-ba0_a7"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " hothpot(u ) 64-iit herver   ava!", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                /Library/Java/JavaVirtualMachines/j                                 ", (double) 66);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 66.0d + "'", double2 == 66.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/lrarO el/Users/s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/lrarO el/Users/s" + "'", str1.equals("/Users/lrarO el/Users/s"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "POS", (java.lang.CharSequence) "aaaaaaa.41.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", str2.equals("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono" + "'", str1.equals("onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " hothpot(u ) 64-iit herver   ava!", (java.lang.CharSequence) "             sophie  ...", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE", "1.1", (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.11.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE" + "'", str4.equals("1.11.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "              sophie               aaa              sophie               ", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.reflect.AnnotatedElement[] annotatedElementArray0 = new java.lang.reflect.AnnotatedElement[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray0);
        org.junit.Assert.assertNotNull(annotatedElementArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("a", (float) 29L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 29.0f + "'", float2 == 29.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                 on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                 on orcle corportioncorportion" + "'", str1.equals("                                                 on orcle corportioncorportion"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#######", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######" + "'", str2.equals("#######"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oracle Corporation", "n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ttp://javaForacleFcom/UF8        ", "", 48);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttp://javaForacleFcom/UF8        " + "'", str3.equals("ttp://javaForacleFcom/UF8        "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("ttp://javaForacleFcom/UF8        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ttp://javaForacleFcom/UF8" + "'", str1.equals("ttp://javaForacleFcom/UF8"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", 82, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "#######", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sOPHIE##########################", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sOPHIE##########################" + "'", str2.equals("sOPHIE##########################"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/LIB", (java.lang.CharSequence) "e4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "RMAPISPECIFICATION", (java.lang.CharSequence) "HI!   H...                                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("    ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ttp://jvForcleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95312_1560210292_95312_1560210292" + "'", str2.equals("/ttp://jvForcleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!H...HI!H...HI!H...HI!H...HI!H...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "HI");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVi...", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.9", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                      51.0                    us", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      51.0                    us" + "'", str2.equals("                      51.0                    us"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        double[] doubleArray1 = new double[] { 35.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("x86_6", 14, 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaa.41.01", (java.lang.CharSequence) "444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#################################################################################################", 7, "lrarO el");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################################################################" + "'", str3.equals("#################################################################################################"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("HI!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi!   hi! HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!   HI! hi!" + "'", str1.equals("HI!   HI! hi!"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.#", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("oracleCorporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracleCorporation" + "'", str2.equals("oracleCorporation"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hI!", (java.lang.CharSequence) " Hothpot(U ) 64-iit herver   ava!", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int[] intArray5 = new int[] { 7, (byte) 10, (byte) 100, (byte) 100, 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                      51.0                    us");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                      51.0                    us\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "             SOPHIE               ", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("         11b-08.42", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("mixed mode", "JavaPlatformAPISpecification", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed mode" + "'", str3.equals("mixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed mode"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "hi! h...E SPECIFICATI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Or#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaa", (int) (short) 100, "mixed mo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaamixed momixed momixed momixed momixed momixed momixed momixed momixed momixed momixed momixed m" + "'", str3.equals("aaaaamixed momixed momixed momixed momixed momixed momixed momixed momixed momixed momixed momixed m"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("tionacle Corporacle CorOraOr");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HISOPMIXED MOD" + "'", str1.equals("HISOPMIXED MOD"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "                                                                 SOPHIE##########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI! HI! hi!", " hothpot(u ) 64-iit herver   ava!", 41);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("rmAPISpecification", "44444444US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rmAPISpecification" + "'", str2.equals("rmAPISpecification"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SOPHI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroprocaelcaro" + "'", str1.equals("noitaroprocaelcaro"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "#", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Sophi", 82);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                 on Orcle CorportionCorportion", 73);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaHISOPMIXED MOD", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("va!", 344);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!" + "'", str2.equals("va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!va!"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Mac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac" + "'", str1.equals("mac"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa", (java.lang.CharSequence) "ORACLE CORORACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Librury/Juvu/JuvuVirtuulsunhines/j.................................", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass8 = javaVersion6.getClass();
        boolean boolean9 = javaVersion0.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        java.lang.Class<?> wildcardClass13 = javaVersion11.getClass();
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean16 = javaVersion0.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
        boolean boolean20 = javaVersion0.atLeast(javaVersion17);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 73L, 0.0d, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.0d + "'", double3 == 73.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "a", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "oracle   Corporation", (java.lang.CharSequence) "http://java.oracle.com/1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "................../Librury/Juvu/JuvuVirtuulsunhines/j................................." + "'", str2.equals("................../Librury/Juvu/JuvuVirtuulsunhines/j................................."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "onoonoonoo", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str4.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                   O", 7, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                   O" + "'", str3.equals("                                                   O"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!   H...", "#", (int) (short) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HI!   H..." + "'", str5.equals("HI!   H..."));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "HI!HI!hi!1.7.0_801.7.0_801.7.");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie" + "'", str3.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::HI!HI!hi!1.7.0_801.7.0_801.7.sophie" + "'", str6.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::HI!HI!hi!1.7.0_801.7.0_801.7.sophie"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":\n", "onoonoonoo", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":\n" + "'", str4.equals(":\n"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion1.atLeast(javaVersion5);
        java.lang.String str9 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.9" + "'", str9.equals("0.9"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                 on orcle corportioncorportion", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclas");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        java.lang.Class<?> wildcardClass4 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass8 = javaVersion6.getClass();
        java.lang.String str9 = javaVersion6.toString();
        java.lang.String str10 = javaVersion6.toString();
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean13 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.9" + "'", str9.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ttp://javaForacleFcom/UF8        ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", (java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("oracle Corporation");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!" + "'", str1.equals("hI!"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("noitaroproCaelcarO", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "...aroproC elcarOnoitarop...", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str7 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("on Orcle C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "on Orcle C" + "'", str1.equals("on Orcle C"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("             sophie               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...", (java.lang.CharSequence) "oracle CorOracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("onoonoonoonoonoonoonoonoono");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "onoonoonoonoonoonoonoonoono" + "'", str1.equals("onoonoonoonoonoonoonoonoono"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        char[] charArray3 = new char[] { 'a' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                         #######", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(780, 0, 78);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("noitaroproC elcarOroC elcaro", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "proC elcarOroC elcaro" + "'", str2.equals("proC elcarOroC elcaro"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                   O", 10, " hothpot(u ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                   O" + "'", str3.equals("                                                   O"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaamixed moaaaaaa", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaamixed moaaaaaa" + "'", str3.equals("aaaaamixed moaaaaaa"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                        ", 18, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        " + "'", str3.equals("                        "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/lrarO el/Users/s", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/lrarO el/Users/s" + "'", str3.equals("/Users/lrarO el/Users/s"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "5a0-ba0_a7", (java.lang.CharSequence) "HI!   H...                                                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("un.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "un.lwwt.mosx.CPrinterJob" + "'", str1.equals("un.lwwt.mosx.CPrinterJob"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        char[] charArray13 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!   hi! HI!", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaa", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnviro", charArray13);
        java.lang.Class<?> wildcardClass22 = charArray13.getClass();
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "oracle corporation", 65);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleaCorporation" + "'", str1.equals("OracleaCorporation"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, 0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "noitaroprocaelcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("US", "                                                 on orcle corportioncorportion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "X664                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4, 100L, (long) 19);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("oracleOracle Corporation Oracle CorporationCorporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracleOracle Corporation Oracle CorporationCorporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("X664");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X66" + "'", str1.equals("X66"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", "noitaroproC elcarOroC elcaro");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292" + "'", str2.equals("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("rmAPI", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "UN.LWWT.MOSX.CPRINTERJOB", (java.lang.CharSequence) "ONO", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie", "                                   44444444444444444444444444444                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 41, 0.0f, 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 41.0f + "'", float3 == 41.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "aa7a0_a0-ba5                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...porationOracle Corpora...", 65, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa...porationOracle Corpora..." + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa...porationOracle Corpora..."));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!   HI! hi!", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("USERS/SOP", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USERS/SOP" + "'", str2.equals("USERS/SOP"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("...on Oracle CorporationCorporation", "HI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...on Oracle CorporationCorporation" + "'", str2.equals("...on Oracle CorporationCorporation"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str5 = javaVersion1.toString();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.9" + "'", str5.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4.a", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.a " + "'", str2.equals("4.a "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "                                                 on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("HOTHPOT(U ) 64-IIT HERVER   AVA!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HOTHPOT(U ) 64-IIT HERVER   AVA!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444OracleCor", "aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rcleor" + "'", str3.equals("rcleor"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("\n", 6, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa\naaa" + "'", str3.equals("aa\naaa"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "mixed mod", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie" + "'", str3.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophiemixed mod:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        double[] doubleArray1 = new double[] { 35.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("x86_64", "hi!hi!hi!", "aa\naaa", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64" + "'", str4.equals("x86_64"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        int[] intArray5 = new int[] { (short) 10, (byte) 10, 3, (byte) 100, (short) 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unxiwwnxj.sxxcpcinnncj.b" + "'", str1.equals("unxiwwnxj.sxxcpcinnncj.b"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################################################" + "'", str2.equals("##############################################################################"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, (int) (short) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HI!   H...", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaa", 82);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                       " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa                                                       "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", "aaaSOPaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("             SOPHIE               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             SOPHIE               " + "'", str1.equals("             SOPHIE               "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("             ...4444             ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A", strArray1, strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A" + "'", str4.equals("                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hi!hi!hi!", "1.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaa", "#######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        char[] charArray12 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!   hi! HI!", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                                   ", "1.7", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   " + "'", str3.equals("                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                  SophiSophiSophiSophiSopmixed mod                                  ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("boJretnirPC.xsocam", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oracleCorporation", (int) (short) 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleCorporation" + "'", str3.equals("oracleCorporation"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclas", (java.lang.CharSequence) "un.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/", "                      51.0                    US", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/" + "'", str3.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Sun.lwawt.macosx.CPrinterJob", "e", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                 SOPHIE##########################", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "", (java.lang.CharSequence) "X664");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "aaa", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sun.awt.CGraphicsEnvironment");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 4, 4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ORACLE CORORACLE CORPORATION", "Java HotSpot(TM) 64-Bit Server VM");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "RMAPISPECIFICATION", 0, 66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ORACLE CORORACLE CORPORATION", "Java HotSpot(TM) 64-Bit Server VM");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 18, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.j", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.j" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defectsj/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", ":");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("####################################################", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "####################################################" + "'", str7.equals("####################################################"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "             ...4444             ", (java.lang.CharSequence) "..");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("              sophie               aaa              sophie               ", (long) 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "o", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Cor", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ONO", 82, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "SophiSoHI ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#######", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph", "class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("oracleCorporation..ava/JavaVi...", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("..", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".." + "'", str2.equals(".."));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "hi!hi!hi!", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " HOTHPOT(U ) 64-IIT HERVER   AVA!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie                      ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        char[] charArray0 = new char[] {};
        char[][] charArray1 = new char[][] { charArray0 };
        char[][][] charArray2 = new char[][][] { charArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(charArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray2);
        org.junit.Assert.assertNotNull(charArray0);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9L, (float) (-1L), (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "SophiSoHI", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HI! H...e specificati", 31, "10.14.#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.#10.HI! H...e specificati" + "'", str3.equals("10.14.#10.HI! H...e specificati"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SOPHI", 6, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".", "10.14.a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.Class<?> wildcardClass6 = javaVersion1.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '#', (float) 10L, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "5A0-BA0_A7", (java.lang.CharSequence) "noitaroproC elcarO", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph" + "'", str2.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "va!", (java.lang.CharSequence) "mixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("             ...4444             ", (int) 'a', "####################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             ...4444             ################################################################" + "'", str3.equals("             ...4444             ################################################################"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                                                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Hothpot(U)64-iitherverava!", 66, "aa7a0_a0-ba5                                        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa7a0_a0-ba5                            Hothpot(U)64-iitherverava!" + "'", str3.equals("aa7a0_a0-ba5                            Hothpot(U)64-iitherverava!"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "y/Java/Java");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SOPHISOPHISOPHISOPHISOPHISOPHISOP", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SOPHISOPHISOPHISOPHISOPHISOPHISOP" + "'", str3.equals("SOPHISOPHISOPHISOPHISOPHISOPHISOP"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                      51.0                    us");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        int[] intArray5 = new int[] { (short) 10, (byte) 10, 3, (byte) 100, (short) 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "class o...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("orcleOrcle Corportion Orcle CorportionCorportion");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "un.lwwt.mosx.CPrinterJob", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "              sophie               ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "orcle              sophie               Orcle              sophie                              sophie               Corportion              sophie                              sophie               Orcle              sophie                              sophie               Corportion              sophie               Corportion" + "'", str5.equals("orcle              sophie               Orcle              sophie                              sophie               Corportion              sophie                              sophie               Orcle              sophie                              sophie               Corportion              sophie               Corportion"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                  SOPHIE##########################                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                  SOPHIE##########################                                  " + "'", str1.equals("                                  SOPHIE##########################                                  "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "EN", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                    .", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaamixed moaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaamixed moaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) " hothpot(u ) 64-iit herver   ava!", (java.lang.CharSequence) "1.11.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMavaJ", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", str1.equals("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("orcleOrcle Corportion Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "orcleOrcle Corportion Orcle CorportionCorportion" + "'", str1.equals("orcleOrcle Corportion Orcle CorportionCorportion"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification", "              sophie               a5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) 0L, (float) 115);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 115.0f + "'", float3 == 115.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("OCLE CORORACLE CORPORATION", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OCLE CORORACLE CORPORATION" + "'", str2.equals("OCLE CORORACLE CORPORATION"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", str2.equals("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                /library/java/javavirtualmachines/j                                 " + "'", str1.equals("                                /library/java/javavirtualmachines/j                                 "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sophie", "SophiSophiSophiSophiSopmixed mod", "...rati...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", 66, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!" + "'", str3.equals("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "ORACLE CORORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("    hi!hi!hi!", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "mixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.1", 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaSOPaaaa", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Users/sop", "SOPHI", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.a", strArray3, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.awt.CGraphicsEnviro", (java.lang.CharSequence[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.14.a" + "'", str8.equals("10.14.a"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80-b15" + "'", str11.equals("1.7.0_80-b15"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", "10.14.a", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        float[] floatArray6 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("51.0", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "SOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("y/Java/Java", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "y/Java/Java" + "'", str2.equals("y/Java/Java"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aa7a0_a0-ba5                                        ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("racleaCorporation", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "                                  SOPHIE##########################                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(":::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                  SOPHIE##########################                                  ", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  SOPHIE##########################                                  " + "'", str2.equals("                                  SOPHIE##########################                                  "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mAPIOracle CorporationOracle CorporationOracle Corpo" + "'", str2.equals("mAPIOracle CorporationOracle CorporationOracle Corpo"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/USERS/S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/S" + "'", str1.equals("/USERS/S"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292" + "'", str1.equals("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Users/sophie                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "unxiwwnxj.sxxcpcinnncj.b", (java.lang.CharSequence) "onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7" + "'", str1.equals("1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("USERS/SOP");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "racleaCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("    hi!hi!hi!", "44444444444444444444444444444444444", "..", 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "    hi!hi!hi!" + "'", str4.equals("    hi!hi!hi!"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "on Orcle CorportionCorportion", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "noitaroproCaelcar");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "10.14.", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UNXIWWNXJ.SXXCPCINNNCJ.BAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("UNXIWWNXJ.SXXCPCINNNCJ.BAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "rcleor", (java.lang.CharSequence) "oracle CorOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas", (java.lang.CharSequence) "             SOPHIE               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("              sophie               ", "Oracle Cor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "ents/Home/jre", 8);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("         11b-08.42", "noitaroprocaelcaro", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("           #           ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("oracleCorporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(23, 0, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "HI!   H...e specificati", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "########:\n", 19, 65);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "########:\n" + "'", str4.equals("########:\n"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HI!HI!hi!1.7.0_801.7.0_801.7.", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("unxiwwnxj.sxxcpcinnncj.b", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("HI!HI!hi!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" HotSpot(TM) 64-Bit Server VMavaJ", "", (int) '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str5.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str7.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Sophi", (java.lang.CharSequence) "Or...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Users/sop", "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", 28);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("HI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaa" + "'", str1.equals("HI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Sophi", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", "::::::::::444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "class [D");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oracleCorporation", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "oracleOracle Corporation Oracle CorporationCorporation", (java.lang.CharSequence) "    hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI!   H...e specificati", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                    ", "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                    .");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "." + "'", str1.equals("."));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":\n", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "mixed mod");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "...aroproC elcarOnoitarop..");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1 == 51.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4.a ", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   " + "'", str2.equals("                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   1.7                                                                                                                   "));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "    hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("noitaroproC elcarOroC elcaro");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("ORACLE CORORACLE CORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"O\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "sophie               aaa              sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Oracle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "y/Java/Java", (java.lang.CharSequence) "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hi!hi!hi!", "oracle CorOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Librury/Juvu/JuvuVirtuulsunhines/j.................................", 93);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "aa7a0_a0-ba5", (int) 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "...rati...", 73, 9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x86_64onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono", (java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("X664                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X664                                                                                                                                                                                                                                                                                                                                                    " + "'", str1.equals("X664                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("             ...4444             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "             sophie               ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob", 180, "r VMavaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJobr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJ" + "'", str3.equals("sun.lwawt.macosx.CPrinterJobr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJr VMavaJ"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/lrarO el/Users/s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/lrarO el/Users/s" + "'", str1.equals("/Users/lrarO el/Users/s"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "...aroproC elcarOnoitarop..");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 115, (float) 27, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 115.0f + "'", float3 == 115.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI!", "/USERS/S");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JavaPlatformAPISpecification", "Hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, (-1), 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!", "Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Users/sopun.lwwt.mosx.CPrinterJob", "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("::sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aa7a0_a0-ba", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###########################################aa7a0_a0-ba###########################################" + "'", str3.equals("###########################################aa7a0_a0-ba###########################################"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(71, 13, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("on Orcle C", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#", (java.lang.CharSequence) "sun.awt.CGraphicsEnviro", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                      51.0                    US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      51.0                    US" + "'", str2.equals("                      51.0                    US"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!   H...                                                        ", (java.lang.CharSequence) "class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/LIB", 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                             /LIB" + "'", str2.equals("                                                             /LIB"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!hi!1.7.0_801.7.0_801.7.", "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "...aroproC elcarOnoitarop...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

