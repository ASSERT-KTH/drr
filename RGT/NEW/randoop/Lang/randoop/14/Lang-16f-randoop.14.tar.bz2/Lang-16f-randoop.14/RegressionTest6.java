import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaom deximaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaom deximaaaaa" + "'", str1.equals("aaaaaaom deximaaaaa"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "X664                                                                                                                                                                                                                                                                                                                                                    ", 115);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!   H...                                                        ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "\n", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Users/sopun.lwwt.mosx.CPrinterJob", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("...:::::::::::::::::::::::::::::::...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "OracleCor-1.0JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.Class<?> wildcardClass5 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j" + "'", str3.equals("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "y/Jv/Jv", (java.lang.CharSequence) "USERS/SOP", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "              sophie               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI! H...e specificati", (java.lang.CharSequence) "             sophie               ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaPOSaaa", (java.lang.CharSequence) "4.a", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa", "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", (int) ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("OracleCor-1.0JavaVirtualMachineSpecification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCor-1.0JavaVirtualMachineSpecification" + "'", str2.equals("OracleCor-1.0JavaVirtualMachineSpecification"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("HI!HI!hi!1.7.0_801.7.0_801.7.", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7." + "'", str2.equals("7."));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("un.lwwt.mosx.CPrinterJob", "n2x1n4fc0000gn/T/", (int) (short) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob" + "'", str4.equals("n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################" + "'", str1.equals("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("noitaroproCaelcarO", 82);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCaelcarO" + "'", str2.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" Hothpot(U ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " hothpot(u ) 64-iit herver   ava!" + "'", str1.equals(" hothpot(u ) 64-iit herver   ava!"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(180, 32, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 180 + "'", int3 == 180);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("24.80-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("    SophiSoHI", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SophiSoHI" + "'", str2.equals("SophiSoHI"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/lrarO el/Users/s", "HI!HI!hi!", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/lrarO el/Users/s" + "'", str3.equals("/Users/lrarO el/Users/s"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", 53, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophi" + "'", str1.equals("Sophi"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", "Oracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java(TM) SE Runtime Environment", "boJretnirPC.xsocam");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("HI!HI!hi!", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo", "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", "                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo" + "'", str3.equals("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("###################################################################################################################", "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################################################" + "'", str2.equals("###################################################################################################################"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "...on Oracle CorporationCorporation", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', 28, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "un.lwwt.mosx.CPrinterJob", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(46, 4, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!hi!aaaaaaaaaaaaaaaaaaa", "phiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oracleOracle Corporation Oracle CorporationCorporation", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str3.equals("oracleOracle Corporation Oracle CorporationCorporation"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "HI!H...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                  SOPHIE##########################                                  ", "HI        ", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        double[] doubleArray1 = new double[] { (short) 1 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "JavaPlatformAPISpecification", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        double[] doubleArray6 = new double[] { (byte) 10, (-1L), 100, 1.0d, 3, 1.0f };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac OS X24.80-b1124.80-b1124.", "Oracle Cor -1.0 Java Virtual Machine Specification", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "orcleOrcle Corportion Orcle CorportionCorportion", 344);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVi...", "e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LWAWT.MACOSX.LWCTOOLKIT", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str3.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("HI!HI!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!hi!" + "'", str1.equals("HI!HI!hi!"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("\nhi!", "aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nhi!" + "'", str2.equals("\nhi!"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "oracle Corporation");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "class o...");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "phiSophiSophiSophi", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 18 + "'", int6 == 18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "mixed mod");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                         #######", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("         11b-08.42##############################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         11b-08.42##############################" + "'", str2.equals("         11b-08.42##############################"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "javaplatformapispeciono");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j", 9, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach(".", strArray3, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "." + "'", str9.equals("."));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("cle.com/a.oravahttp://j", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI! H...e specificati");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI! H...E SPECIFICATI" + "'", str1.equals("HI! H...E SPECIFICATI"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/1.8", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaamixed moaaaaaa", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "HI");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "aaa", 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracleOracle Corporation Oracle CorporationCorporation", strArray4, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str9.equals("oracleOracle Corporation Oracle CorporationCorporation"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String[] strArray2 = new java.lang.String[] { "O" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sun.awt.CGraphicsEnvironment");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                      51.0                    US", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      51.0                    US" + "'", str2.equals("                      51.0                    US"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::", (java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/j", "son Orcle CorportionCorportionmacosx.CPrinterJob", 344);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444" + "'", str3.equals("4444"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                    .", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", "SophiSoHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "           #           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                               US", (int) ' ', 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATION", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        double[] doubleArray6 = new double[] { (byte) 10, (-1L), 100, 1.0d, 3, 1.0f };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SOPHIE##########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", ":");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "              sophie               aaa              sophie               ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment", 19, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "o", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!   hi! HI!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("rmAPISpecification", "SophiSoHI ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                    ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                    ", 344, 53);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Oracle Corporation");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SophiSoHI ", "orcleorcle corportion orcle corportioncorportion");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str5.equals("oracleOracle Corporation Oracle CorporationCorporation"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!H...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        float[] floatArray6 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "HI!   H...e specificati", (java.lang.CharSequence) "aaaaPOSaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                         #######", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) '4', 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aa7a0_a0-ba5                                        ", (java.lang.CharSequence) "4444444444444", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("rmAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rmAPISpecification" + "'", str1.equals("rmAPISpecification"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...:::::::::::::::::::::::::::::::...", "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("##########################EIHPOS", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########################EIHPOS" + "'", str2.equals("##########################EIHPOS"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE" + "'", str1.equals("SOPHIE"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                    on Orcle CorportionCorportion", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 28, (long) 66);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophieents/Home/jre/Users/sophie", (java.lang.CharSequence) "aaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hI!", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("    ", (float) 48);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.0f + "'", float2 == 48.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "mixed mo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HI! H...e specificati", (java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie" + "'", str1.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.8", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.8f + "'", float2 == 1.8f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...aroproC elcarOnoitarop...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...aroproC elcarOnoitarop.." + "'", str1.equals("...aroproC elcarOnoitarop.."));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation" + "'", str3.equals("Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######" + "'", str2.equals("#######"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "y/Jv/Jv", 31, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("oracle CorOracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"o\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) 31, 53.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#", "mixed mode", 7);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "...porationOracle Corpora...");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sop", "                                /Library/Java/JavaVirtualMachines/j                                 ", 37);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("n2x1n4fc0000gn/T/", strArray6, strArray12);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.3", 3);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", strArray12, strArray17);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray17);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "n2x1n4fc0000gn/T/" + "'", str13.equals("n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j" + "'", str18.equals("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("oracle Corporation", (double) 23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.0d + "'", double2 == 23.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.3", 3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI        ", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aa7a0_a0-ba5                                        ", "HI!   H...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aa7a0_a0-ba5                                        " + "'", str4.equals("aa7a0_a0-ba5                                        "));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ORACLE CORORACLE CORPORATION", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORORACLE CORPORATION" + "'", str2.equals("ORACLE CORORACLE CORPORATION"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "...aroproC elcarOnoitarop...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode", ' ');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...", 100, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                         ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("...:::::::::::::::::::::::::::::...", "Users/sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...:::::::::::::::::::::::::::::..." + "'", str2.equals("...:::::::::::::::::::::::::::::..."));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("javaplatformapispecification", "javaplatformapispeciono", "OracleaCorporation", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "javaplatformapispecification" + "'", str4.equals("javaplatformapispecification"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 33, "SOPHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SOPHISOPHISOPHISOPHISOPHISOPHISOP" + "'", str3.equals("SOPHISOPHISOPHISOPHISOPHISOPHISOP"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 3, (int) (short) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!hi!hi!", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hi!hi!hi!" + "'", str2.equals("    hi!hi!hi!"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/1.8", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/1.8" + "'", str2.equals("http://java.oracle.com/1.8"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("OCLE CORORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OCLE CORORACLE CORPORATION" + "'", str1.equals("OCLE CORORACLE CORPORATION"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracle.com/1.8", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SOP", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/j", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/j" + "'", str3.equals("/Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...on Oracle CorporationCorporation", 13, 82);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("phiSophiSophiSophi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phiSophiSophiSophi" + "'", str2.equals("phiSophiSophiSophi"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r", "ORACLE CORORACLE CORPORATIO", "HI");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("::::::::::444444444444444444", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::444444444444444444" + "'", str2.equals("::::::::::444444444444444444"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("SOPHIE##########################", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HI!   H...                                                        ", "7.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!   H...                                                        " + "'", str2.equals("HI!   H...                                                        "));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "/", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaa", "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..", "1.1", 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaa" + "'", str4.equals("aaa"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                 SOPHIE##########################", (java.lang.CharSequence) "HI!HI!hi!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                 SOPHIE##########################" + "'", charSequence2.equals("                                                                 SOPHIE##########################"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HotSpot(TM) 64-Bit Server VMavaJ" + "'", str1.equals("HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("HI        ", "ORACLE CORORACLE CORPORATIO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "hi!", 7);
        java.lang.CharSequence charSequence6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "0.9");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence6, (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HI!   H...", strArray5, strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "...on Oracle CorporationCorporation", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "HI!   H..." + "'", str11.equals("HI!   H..."));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        int[] intArray5 = new int[] { 7, (byte) 10, (byte) 100, (byte) 100, 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HI! H...e specificati", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI! H...e specificati" + "'", str3.equals("HI! H...e specificati"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("on Orcle CorportionCorportion", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "on Orcle C" + "'", str2.equals("on Orcle C"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4444444444444444444444444444444444444444044444444444444444444444444444444444444444");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..." + "'", str1.equals("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..."));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mod", (java.lang.CharSequence) "son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nos");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooJrPC.r" + "'", str3.equals("ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooJrPC.r"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophi", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/1.8", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", (java.lang.CharSequence) "4444", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                   44444444444444444444444444444                                    ", 23, "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   44444444444444444444444444444                                    " + "'", str3.equals("                                   44444444444444444444444444444                                    "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("phiSophiSophiSophi", "oracleOracle Corporation Oracle CorporationCorporation", "Oracle Corporation                                                                                  ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...", 344, "a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("oracle CorOracle Corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        float[] floatArray6 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass11 = floatArray6.getClass();
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle Cor", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORACLE CORORACLE CORPORATION", 180, "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", ":");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", strArray3, strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "aaaSOPaaaa");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str10.equals("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 1.8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.8f + "'", float2 == 1.8f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "USERS/SOP", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarO" + "'", str1.equals("noitaroproC elcarO"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class o...", "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", "ttp://javaForacleFcom/UF8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class o..." + "'", str3.equals("class o..."));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("51.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" HOTHPOT(U ) 64-IIT HERVER   AVA!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  HOTHPOT(U ) 64-IIT HERVER   AVA! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob" + "'", str1.equals("n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "5a0-ba0_a7", (java.lang.CharSequence) "HI!   H...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "phiSophiSophiSophi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4.a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                   44444444444444444444444444444                                    ", (java.lang.CharSequence) "                                                                                               US", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 4, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444" + "'", str3.equals("4444"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specification", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(51.0d, 0.0d, (double) 19);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMavaJ", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("::::::::::", "sun.lwawt.macosx.CPrinterJob", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292", 46);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "::::::::::" + "'", str4.equals("::::::::::"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "10.14.a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Mac OS X");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 31, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "O10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI        ", "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI        " + "'", str2.equals("HI        "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray1 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray1);
        org.junit.Assert.assertNotNull(numberUtilsArray1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444044444444444444444444444444444444444444444", (java.lang.CharSequence) "#########################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("             ...4444             ", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             ...4444             " + "'", str3.equals("             ...4444             "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle Cor", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("javaplatformapispeciono", "             sophie               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10.14.", (java.lang.CharSequence) "aaaaamixed moaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HI! H...E SPECIFICATI", "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI! H...E SPECIFICATI" + "'", str2.equals("HI! H...E SPECIFICATI"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(66, 100, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", str1.equals("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/LIB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIB" + "'", str1.equals("/LIB"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("...4444", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaPOSaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "HI!HI!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#########################################################################", (java.lang.CharSequence) "phiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray15 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray15);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray15);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray15);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray15);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oracle Corporation", charArray15);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray15);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI", charArray15);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaa", charArray15);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray15);
        int int25 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray15);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "rmAPISpecification", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "lrarO el", (java.lang.CharSequence) "OracleCor-1.0JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ono", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono" + "'", str2.equals("onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "javaplatformapispecification", (java.lang.CharSequence) "a", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '4', (long) 33, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A" + "'", str3.equals("                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("          ", 78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            "));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) " HOTHPOT(U ) 64-IIT HERVER   AVA!", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", "         11b-08.42");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        double[] doubleArray5 = new double[] { (short) 100, 100L, '#', 100, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.Class<?> wildcardClass8 = doubleArray5.getClass();
        java.io.File file9 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.lang.Class<?> wildcardClass10 = file9.getClass();
        java.lang.CharSequence charSequence11 = null;
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("10.14.a", "mixed mode");
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence11, (java.lang.CharSequence[]) strArray14);
        java.lang.Class<?> wildcardClass16 = strArray14.getClass();
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", (int) (byte) 10);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3", "HI", 100);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa7a0_a0-ba5", strArray21, strArray25);
        java.lang.Class<?> wildcardClass27 = strArray25.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray28 = new java.lang.reflect.GenericDeclaration[] { wildcardClass8, wildcardClass10, wildcardClass16, wildcardClass27 };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray28);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(file9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "aa7a0_a0-ba5" + "'", str26.equals("aa7a0_a0-ba5"));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(genericDeclarationArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str29.equals("class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.CharSequence[] charSequenceArray5 = new java.lang.CharSequence[] { "Sophi", "hi!hi!hi!", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "SOPHI", "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!" };
        java.lang.CharSequence[] charSequenceArray11 = new java.lang.CharSequence[] { "Sophi", "hi!hi!hi!", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "SOPHI", "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!" };
        java.lang.CharSequence[] charSequenceArray17 = new java.lang.CharSequence[] { "Sophi", "hi!hi!hi!", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "SOPHI", "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!" };
        java.lang.CharSequence[][] charSequenceArray18 = new java.lang.CharSequence[][] { charSequenceArray5, charSequenceArray11, charSequenceArray17 };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charSequenceArray18);
        org.junit.Assert.assertNotNull(charSequenceArray5);
        org.junit.Assert.assertNotNull(charSequenceArray11);
        org.junit.Assert.assertNotNull(charSequenceArray17);
        org.junit.Assert.assertNotNull(charSequenceArray18);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("USERS/SOP", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "easpecificationoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("class o...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        double[] doubleArray6 = new double[] { (byte) 10, (-1L), 100, 1.0d, 3, 1.0f };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi" + "'", str2.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SophiSoHI ", 9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", ":::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" hothpot(u ) 64-iit herver   ava!", "Oracle Corporation", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!" + "'", str3.equals(" hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("O10.14.3", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O10.14.3" + "'", str2.equals("O10.14.3"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444" + "'", str2.equals("4444"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("e", "               rmAPI               ", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e               rmAPI               e               rmAPI               e" + "'", str3.equals("e               rmAPI               e               rmAPI               e"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "       ", (java.lang.CharSequence) "           #           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("oracle CorOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarOroC elcaro" + "'", str1.equals("noitaroproC elcarOroC elcaro"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("O", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                   O" + "'", str2.equals("                                                   O"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("...porationOracle Corpora...", "...AROPROC ELCARONOITAROP...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("EN", "0.9");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "7.", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java Platform API Specification", "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", charSequence2.equals("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos", (java.lang.CharSequence) "son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("       ", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                         " + "'", str2.equals("                                                                         "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle CorOracle Corporation", (java.lang.CharSequence) "aa7a0_a0-ba");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("...aroproC elcarOnoitarop...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...aroproC elcarOnoitarop..." + "'", str1.equals("...aroproC elcarOnoitarop..."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        java.lang.Class<?> wildcardClass6 = javaVersion4.getClass();
        java.lang.String str7 = javaVersion4.toString();
        java.lang.String str8 = javaVersion4.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean11 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("HotSpot(TM) 64-Bit Server VMavaJ", "aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HotSpot(TM) 64-Bit Server VMavaJ" + "'", str2.equals("HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        char[] charArray13 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "\n", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracleOracle Corporation Oracle CorporationCorporation", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/LIB", ":", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        int[] intArray5 = new int[] { 7, (byte) 10, (byte) 100, (byte) 100, 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", "JavaPlatformAPISpecification");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SophiSoHI ", "orcleorcle corportion orcle corportioncorportion");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("oracleOracle Corporation Oracle CorporationCorporation", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str7.equals("oracleOracle Corporation Oracle CorporationCorporation"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "ORACLE CORORACLE CORPORATION");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Oracle Corporation                                                                                  ", (java.lang.CharSequence) "hI!", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Hothpot(U ) 64-iit herver   ava!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 14 + "'", int15 == 14);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("              sophie               aaa              sophie               ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("#################################################################################################", "n2x1n4fc0000gn/T/", "x86_64");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaplatformapispecification" + "'", str1.equals("javaplatformapispecification"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI ", (java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 51.0f, (float) 29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 9, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono", 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "onoonoonoo" + "'", str3.equals("onoonoonoo"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "y/Jv/Jv", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("OracleCor-1.0JavaVirtualMachineSpecification", "ents/Home/jre", "1.3", 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleCor-1.0JavaVirtualMachineSpecification" + "'", str4.equals("OracleCor-1.0JavaVirtualMachineSpecification"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7", "/LIB", "                   Oracle Cor", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7" + "'", str4.equals("1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################" + "'", charSequence2.equals("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    ." + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    ."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(14, 15, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 0, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SOPHIE##########################", (java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "                                                                                               US");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                               US" + "'", charSequence2.equals("                                                                                               US"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", ":");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "SU");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "sun.lwawt.macosx.cprinterjob", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophieents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("              sophie               aaa              sophie               ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", (java.lang.CharSequence) "\nhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j", "               rmAPI               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) '#', (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("10.14.a", "mixed mode");
        java.lang.CharSequence charSequence5 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("10.14.a", "mixed mode");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence5, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a", strArray4, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a" + "'", str10.equals("a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("easpecificationoracleacora-1.0ajavaavirtualamachineas", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "easpecificationoracleacora-1.0ajavaavirtualamachineas" + "'", str2.equals("easpecificationoracleacora-1.0ajavaavirtualamachineas"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("24.80-b11         ", "jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "                   Oracle Cor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation", "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation" + "'", str2.equals("Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oracleCorporation" + "'", str4.equals("oracleCorporation"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "5a0-ba0_a7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 " + "'", str2.equals("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 "));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x664");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "class o...", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI        ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 14, 82);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        short[] shortArray5 = new short[] { (short) 100, (short) 1, (short) 1, (short) -1, (byte) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" Hothpot(U ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hothpot(U)64-iitherverava!" + "'", str1.equals("Hothpot(U)64-iitherverava!"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) 73, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.0d + "'", double3 == 73.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292", (double) 115.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 115.0d + "'", double2 == 115.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sOPHIE##########################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sOPHIE##########################" + "'", str2.equals("sOPHIE##########################"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 65, 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("...aroproC elcarOnoitarop..");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "5a0-ba0_a7", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!   H...                                                        ", (java.lang.CharSequence) "             ...4444             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass8 = javaVersion6.getClass();
        boolean boolean9 = javaVersion0.atLeast(javaVersion6);
        java.lang.String str10 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean12 = javaVersion6.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.9" + "'", str10.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "Hothpot(U)64-iitherverava!", "y/Java/Java", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(".");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "." + "'", str1.equals("."));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("##########################EIHPOS", ":\n", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "on Orcle CorportionCorportion");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "              sophie               ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "##########################EIHPOS" + "'", str6.equals("##########################EIHPOS"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "o", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Cor", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "O10.14.3", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "#########################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444" + "'", str3.equals("4444444444444"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "...:::::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "...:::::::::::::::::::::::::::::::..." + "'", charSequence2.equals("...:::::::::::::::::::::::::::::::..."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, 23, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oracleCorporation", 180);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("x86_64", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.3", "                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                 SOPHIE##########################", (java.lang.CharSequence) "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nos");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaSOPaaaa", 0, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaSOPaaaa" + "'", str3.equals("aaaSOPaaaa"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "###################################################################################################################", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph", 31, "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("       HI", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) ".");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas", "1.7.0_80", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas" + "'", str3.equals("easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 780 + "'", int1 == 780);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 73L, (double) 10.0f, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.0d + "'", double3 == 73.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                   44444444444444444444444444444                                    ", (java.lang.CharSequence) "e               rmAPI               e               rmAPI               e", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 41 + "'", int3 == 41);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("on Orcle C", 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("oracle CorOracle Corporation", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle CorOracle Corporation" + "'", str2.equals("oracle CorOracle Corporation"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.5", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "lrarO el");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        char[] charArray4 = new char[] { 'a' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "########:\n", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation                                                                                  ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "noitaroproC elcarOroC elcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 19, (long) (byte) 1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Mac OS X24.80-b1124.80-b1124.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ORACLE CORORACLE CORPORATION", (-1), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "N" + "'", str3.equals("N"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                      51.0                    us");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 13, 115);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 115 + "'", int3 == 115);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 27, 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/LIB", 65, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##########################EIHPOS", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 14, (float) 24, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_64", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "ORACLE CORORACLE CORPORATIO", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "Or...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "aa7a0_a0-ba", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.aaaaaaa", "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/1.8", (java.lang.CharSequence) "phiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8L, (double) 23L, (double) 1.8f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.0d + "'", double3 == 23.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" HOTHPOT(U ) 64-IIT HERVER   AVA!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HOTHPOT(U ) 64-IIT HERVER   AVA!" + "'", str1.equals("HOTHPOT(U ) 64-IIT HERVER   AVA!"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.1", (float) 15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.1f + "'", float2 == 1.1f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "e specificationoracle cor -1.0 java virtual machine s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ", (java.lang.CharSequence) "    hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444", (java.lang.CharSequence) "\nhi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80", "##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 100, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", 180, "onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono" + "'", str3.equals("x86_64onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Cor -1.0 Java Virtual Machine Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "o", 37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80-b15", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Virtual Machine Specification", 33, 780);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str7 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str9 = javaVersion8.toString();
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = javaVersion8.atLeast(javaVersion10);
        boolean boolean13 = javaVersion0.atLeast(javaVersion10);
        java.lang.String str14 = javaVersion10.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.8" + "'", str9.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.8" + "'", str11.equals("1.8"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.8" + "'", str14.equals("1.8"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION", (java.lang.CharSequence) "1.5", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVi...", 780, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVi..." + "'", str3.equals("/Library/Java/JavaVi..."));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/", "...:::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "..." + "'", str3.equals("..."));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "noitaroproC elcarOroC elcaro");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("orcleorcle corportion orcle corportioncorportion", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "orcleorcle corportion orcle corportioncorportion" + "'", str2.equals("orcleorcle corportion orcle corportioncorportion"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 30, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "RMAPISPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                  SOPHIE##########################                                  ", "hi!   hi! HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/lrarO el/Users/s", (java.lang.CharSequence) "10.14.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("class o...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "#######", 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "HI!", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "oracle Corporation");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVi...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVi...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", (java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ":::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono", 0, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "onoonoonoonoonoonoonoonoono" + "'", str3.equals("onoonoonoonoonoonoonoonoono"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor", (java.lang.CharSequence) "###################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                /Library/Java/JavaVirtualMachines/j                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                /Library/Java/JavaVirtualMachines/j                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("5A0-BA0_A7");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("HI!   H...e specificati");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!   H...e specificati\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10.14.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.14.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Sun.lwawt.macosx.CPrinterJob", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "Users/sopun.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("7.", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa", "                                   44444444444444444444444444444                                    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "         11b-08.42", (java.lang.CharSequence) "X664");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444OracleCor" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444OracleCor"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (float) 82);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 82.0f + "'", float2 == 82.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "44444444444444444444444444444", (java.lang.CharSequence) "phiSophiSophiSophi", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" HotSpot(TM) 64-Bit Server VMavaJ", "                                    on Orcle CorportionCorportion", "/Users/sophieents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/HhSh(TM)/64-B/Sv/VMavaJ" + "'", str3.equals("/HhSh(TM)/64-B/Sv/VMavaJ"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444444444444444444444444444", "US", 8, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444US" + "'", str4.equals("44444444US"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation                                                                                  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "aa7a0_a0-ba5", (int) 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "...porationOracle Corpora...");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str6.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 115, 52);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("::::::::::", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::" + "'", str2.equals("::::::::::"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("son Orcle CorportionCorportionmacosx.CPrinterJob", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "son Orcle CorportionCorportionmacosx.CPrinterJob" + "'", str2.equals("son Orcle CorportionCorportionmacosx.CPrinterJob"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Oracle Corporation                                                                                  ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!" + "'", str1.equals("hi!hi!hi!"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "...porationOracle Corpora...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                 on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "on Orcle CorportionCorportion" + "'", str1.equals("on Orcle CorportionCorportion"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specification", 180);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }
}

