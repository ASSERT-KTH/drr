import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "OracleaCorporation", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", (java.lang.CharSequence) "           #           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test003");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UN.LWWT.MOSX.CPRINTERJOB", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaa", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5a0-ba...", "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test005");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "oracle Corporation", (java.lang.CharSequence) "javaplatformapispecification");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "oracle Corporation" + "'", charSequence2.equals("oracle Corporation"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test006");
        int[] intArray5 = new int[] { (short) 10, (byte) 10, 3, (byte) 100, (short) 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("mixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed mode" + "'", str1.equals("mixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed modeJavaPlatformAPISpecificationmixed mode"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ONO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################" + "'", str2.equals("SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("4444444444444444444444444444444444444444044444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444044444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444044444444444444444444444444444444444444444"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " HotSpot(TM) 64-Bit Server VMavaJ" + "'", str1.equals(" HotSpot(TM) 64-Bit Server VMavaJ"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test013");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "mixed mod");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', (int) ' ', 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 54");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test014");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("USERS/SOP", "   10.14.#", "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", 115);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "USERS/SOP" + "'", str4.equals("USERS/SOP"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("onoonoonoo", 41, ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie                          on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "onoonoonoo:::::::::::::::::::::::::::::::" + "'", str3.equals("onoonoonoo:::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "SOPHIE##########################", (java.lang.CharSequence) "n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test017");
        double[] doubleArray5 = new double[] { (short) 100, 100L, '#', 100, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tionachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jaor" + "'", str2.equals("tionachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jaor"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("HI!H...", " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!H..." + "'", str2.equals("HI!H..."));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test020");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("ttp://javaForacleFcom/UF8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ttp://javaForacleFcom/UF8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test021");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!   H...", (java.lang.CharSequence) "I! H...e specificati");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test022");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" HotSpot(TM) 64-Bit Server VMavaJ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4H4ot4S4pot4(4TM4)4 4644-4B4it4 4S4erver4 4VM4ava4J" + "'", str3.equals(" 4H4ot4S4pot4(4TM4)4 4644-4B4it4 4S4erver4 4VM4ava4J"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HISOPMIXED MOD", "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HISOPMIXED MOD" + "'", str2.equals("HISOPMIXED MOD"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("n2x1n4fc0000gn/T/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n2x1n4fc0000gn/T/" + "'", str2.equals("n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "########:\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test026");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str7 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str9 = javaVersion8.toString();
        java.lang.Class<?> wildcardClass10 = javaVersion8.getClass();
        boolean boolean11 = javaVersion0.atLeast(javaVersion8);
        java.lang.Class<?> wildcardClass12 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.8" + "'", str9.equals("1.8"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test028");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Librury/Juvu/JuvuVirtuulsunhines/j.................................", "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Librury/Juvu/JuvuV" + "'", str2.equals("Librury/Juvu/JuvuV"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test030");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "              sophie               aaa              sophie               ", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "              sophie               aaa              sophie               " + "'", charSequence2.equals("              sophie               aaa              sophie               "));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##############################################", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("o10.14.3", "10.14.#10.HI! H...e specificati");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "lrarO el", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test034");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "########:\n", (java.lang.CharSequence) "SOPHI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test035");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                 SOPHIE##########################", (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test036");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "UNXIWWNXJ.SXXCPCINNNCJ.BAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("!ih", "5A0-BA0_A7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih" + "'", str3.equals("!ih"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test038");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("x664");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("HISOPMIXED MOD");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HISOPMIXED MOD" + "'", str1.equals("HISOPMIXED MOD"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7" + "'", str2.equals("1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava/JavaVi...", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.0", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test043");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UN.LWWT.MOSX.CPRINTERJOB", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaa", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 35 + "'", int17 == 35);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test044");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test045");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "OracleCor-1.0JavaVirtualMachineSpecification", 0, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UNXIWWNXJ.SXXCPCINNNCJ.BAAAAAAAAAAAAAAAAAAAAAAAAAAAA", ":::::::::::::::::::::::::::::::::::", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "on Orcle CorportionCorportion" + "'", str1.equals("on Orcle CorportionCorportion"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test049");
        char[] charArray4 = new char[] { 'a', 'a', '4', '4' };
        char[] charArray9 = new char[] { 'a', 'a', '4', '4' };
        char[][] charArray10 = new char[][] { charArray4, charArray9 };
        char[] charArray15 = new char[] { 'a', 'a', '4', '4' };
        char[] charArray20 = new char[] { 'a', 'a', '4', '4' };
        char[][] charArray21 = new char[][] { charArray15, charArray20 };
        char[] charArray26 = new char[] { 'a', 'a', '4', '4' };
        char[] charArray31 = new char[] { 'a', 'a', '4', '4' };
        char[][] charArray32 = new char[][] { charArray26, charArray31 };
        char[][][] charArray33 = new char[][][] { charArray10, charArray21, charArray32 };
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(charArray33);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertNotNull(charArray20);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertNotNull(charArray32);
        org.junit.Assert.assertNotNull(charArray33);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("4.a", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaom deximaaaaa", "mAPIOracle CorporationOracle CorporationOracle Corpo", "44444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444d4x4444444" + "'", str3.equals("444444444d4x4444444"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("OracleaCorporation", " HOTHPOT(U ) 64-IIT HERVER   AVA!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                                   ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test055");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test056");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test057");
        long[] longArray5 = new long[] { 0, 10L, (-1), 7, 1 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test058");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI! H...E SPECIFICATI", "son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI! H...E SPECIFICATI" + "'", str2.equals("HI! H...E SPECIFICATI"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test061");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HiSopmixed mod");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", (java.lang.CharSequence) "aaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("phiSophiSophiSophi", "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phiSophiSophiSophi" + "'", str2.equals("phiSophiSophiSophi"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("unxiwwnxj.sxxcpcinnncj.b", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "unxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.b" + "'", str2.equals("unxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.b"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test066");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence3, charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444444444444444444444", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "             sophie  ...", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::::", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test067");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test069");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 65, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...rati...", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################" + "'", str2.equals("#################################"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j" + "'", str1.equals("/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "son Orcle CorportionCorportionmacosx.CPrinterJob" + "'", str1.equals("son Orcle CorportionCorportionmacosx.CPrinterJob"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("HI!H...HI!H...HI!H...HI!H...HI!H...", "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!H...HI!H...HI!H...HI!H...HI!H..." + "'", str2.equals("HI!H...HI!H...HI!H...HI!H...HI!H..."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "5a0-ba...", (java.lang.CharSequence) "hI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test076");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6L, (float) 9L, (float) 14);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test078");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("          ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi! h...E SPECIFICATI", "Oracle Cor");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi! h...E SPECIFICATI" + "'", str2.equals("hi! h...E SPECIFICATI"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test080");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 18);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "HI");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/" + "'", str8.equals("/"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str9.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test081");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("###########################################aa7a0_a0-ba###########################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###########################################aa7a0_a0-ba###########################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", "/Library/Java/JavaVi...");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sophie");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Hi!hi!hi!", 46, "4444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444Hi!hi!hi!" + "'", str3.equals("4444444444444444444444444444444444444Hi!hi!hi!"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("             sophie               ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            sophie               " + "'", str2.equals("            sophie               "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ONO", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ONO" + "'", str2.equals("ONO"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test087");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 9, (long) 46, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 46L + "'", long3 == 46L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test088");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Java Platform API Specification", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("phiSophiSophiSophi", 35, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaphiSophiSophiSophiaaaaaaaaa" + "'", str3.equals("aaaaaaaaphiSophiSophiSophiaaaaaaaaa"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test090");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("x664");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("noitaroproC elcarO", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcarO" + "'", str2.equals("noitaroproC elcarO"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test093");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Users/sopun.lwwt.mosx.CPrinterJob", (int) (byte) -1, 71);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test094");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("noitaroproCaelcarO", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("phiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "phiSophiSophiSophi" + "'", str1.equals("phiSophiSophiSophi"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("javaplatformapispeciono", "N2X1N4FC0000GN/t/", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("###################################################", "SOPHI", "Users/sopun.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################" + "'", str3.equals("###################################################"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("         11b-08.42", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         11b-08.42" + "'", str2.equals("         11b-08.42"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test099");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Librury/Juvu/JuvuV");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test101");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80-b11", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test102");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mod", "ents/Home/jre");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test103");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) "unxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.bunxiwwnxj.sxxcpcinnncj.b", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "             ...4444             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test105");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test106");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie" + "'", str4.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("sophie               aaa              sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie aaa sophie" + "'", str1.equals("sophie aaa sophie"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("   10.14.#", "44444444444444444444444444444444444", "      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   10.14.#" + "'", str3.equals("   10.14.#"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test111");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("              sophie               ", "rmAPI", 31);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "              sophie               " + "'", str5.equals("              sophie               "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "HI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test115");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SOPHIE", "HI!   HI! hi!", 52);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "              sophie               ");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hiSopmixed mod", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SOPHIE" + "'", str6.equals("SOPHIE"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test117");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "class [D", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test119");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HISOPMIXED MOD");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HISOPMIXED MOD" + "'", str1.equals("HISOPMIXED MOD"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "USERS/SOP", 78);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test122");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (short) 0, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test123");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "/v r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::HI!HI!hi!1.7.0_801.7.0_801.7.sophie", "javaplatformapispecification", 780);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.14.aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test126");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, (long) 66, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test127");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(82, 29, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test128");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "                                                    .", 7, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                    ." + "'", str4.equals("                                                    ."));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test129");
        char[] charArray14 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray14);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray14);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!   hi! HI!", charArray14);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaa", charArray14);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnviro", charArray14);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle CorOracle Corporation", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "44444444US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie                      ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test132");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test133");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ttp://javaForacleFcom/UF8", "class o...", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttp://javaForacleFcom/UF8" + "'", str3.equals("ttp://javaForacleFcom/UF8"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::::::::::::::::::::::::::::::", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292", (int) (byte) 100);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test136");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [D");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Cor", 24, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaOracle Coraaaaaaa" + "'", str3.equals("aaaaaaaOracle Coraaaaaaa"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test138");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test139");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" HOTHPOT(U ) 64-IIT HERVER   AVA!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HOTHPOT(U ) 64-IIT HERVER   AVA!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test140");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test141");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("SOPHIE!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SOPHIE!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                         ", 71, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         " + "'", str3.equals("                                                                         "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "             SOPHIE               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test144");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" hothpot(u ) 64-iit herver   ava!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test145");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", ":");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "easpecificationoracleacora-1.0ajavaavirtualamachineas", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "   10.14.#", (java.lang.CharSequence) "                                                                 SOPHIE##########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("http://java.oracle.com/", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aa7a0_a0-ba5                                        ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                      51.0                    US", (java.lang.CharSequence) "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Librury/Juvu/JuvuV");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test151");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                   44444444444444444444444444444                                    ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   4444444444444444444444444444444                                    " + "'", str3.equals("                                   4444444444444444444444444444444                                    "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test152");
        long[] longArray3 = new long[] { 1L, (byte) 0, 100L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SOPHIE!", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "en");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "OracleaCorporation" + "'", str7.equals("OracleaCorporation"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;", "              sophie               aaa              sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("unxiwwnxJ.sxxCPCinnnCJ.b", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("SOP", "e4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOP" + "'", str2.equals("SOP"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", "aaaHIaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/1.8", (java.lang.CharSequence) "mixed mo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaa", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaa" + "'", str2.equals("aaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaaaaaaaaom deximaaaaa"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mAPIOracle CorporationOracle CorporationOracle Corpo", (java.lang.CharSequence) "hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test163");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("O10.14.3", "SU", 37);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("::::::::::");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("noitaroproCaelcarO", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "noitaroproCaelcarO" + "'", str7.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################################################################" + "'", str3.equals("#################################################################################################"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("4444444444444", "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test166");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "aaaaamixed momixed momixed momixed momixed momixed momixed momixed momixed momixed momixed momixed m");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "    hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!   H...", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("noitaroproCaelcarO", "", 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarO" + "'", str3.equals("noitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarOnoitaroproCaelcarO"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "              sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ORACLE CORORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORORACLE CORPORATION" + "'", str1.equals("ORACLE CORORACLE CORPORATION"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test172");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Hi!SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", 53);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test175");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("HI! HI! HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", "Mac OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS " + "'", str2.equals("Mac OS "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("::sophie", "                                   4444444444444444444444444444444                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::sophie" + "'", str2.equals("::sophie"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("unxiwwnxj.sxxcpcinnncj.b", "4.a ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("tionachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jationorachine specifical ma virtuavacle cor -1.0 jaor", "aaaaaaaaaaaaa", "HI!H...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tionHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHor" + "'", str3.equals("tionHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHtionorHchine specificHl mH virtuHvHcle cor -1.0 jHor"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test180");
        long[] longArray3 = new long[] { 0L, 0L, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!", "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test182");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "hi!", 7);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "HI", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test183");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", "Oracle Corporation", "/Library/Java");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test184");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 24, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                                   ", "e4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                   " + "'", str2.equals("                                                                                                                   "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test187");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!   HI! hi!", "##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "jAVApLATFORMapisPECIFICATION", 46);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test189");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!   HI! hi!", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tionacle Corporacle CorOraOr", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi" + "'", str1.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test191");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooJrPC.r");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "...on Oracle CorporationCorporation", "aaaaaaaaaaaaaa/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292aaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test193");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SU", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test194");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", "10.14.#");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "HOTHPOT(U ) 64-IIT HERVER   AVA!", 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "...:::::::::::::::::::::::::::::...", (java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test197");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("y/Java/Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("i!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI! ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test199");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test200");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ttp://javaForacleFcom/UF8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test201");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aa7a0_a0-ba5                                        ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("              sophie               aaa              sophie               ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              sophie               aaa              sophie               " + "'", str2.equals("              sophie               aaa              sophie               "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("########:\n", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test204");
        float[] floatArray6 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass11 = floatArray6.getClass();
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("orcleOrcle Corportion Orcle CorportionCorportion", "US");
        java.lang.Class<?> wildcardClass15 = strArray14.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean18 = javaVersion16.atLeast(javaVersion17);
        java.lang.Class<?> wildcardClass19 = javaVersion17.getClass();
        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
        java.lang.Class<?> wildcardClass22 = javaVersion17.getClass();
        char[] charArray31 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean32 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray31);
        boolean boolean33 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray31);
        boolean boolean34 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", charArray31);
        java.lang.Class<?> wildcardClass35 = charArray31.getClass();
        java.lang.String[] strArray37 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray39 = org.apache.commons.lang3.StringUtils.stripAll(strArray37, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray37);
        java.lang.Class<?> wildcardClass41 = strArray37.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion43 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean44 = javaVersion42.atLeast(javaVersion43);
        org.apache.commons.lang3.JavaVersion javaVersion45 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion46 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean47 = javaVersion45.atLeast(javaVersion46);
        boolean boolean48 = javaVersion42.atLeast(javaVersion46);
        java.lang.String str49 = javaVersion42.toString();
        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str51 = javaVersion50.toString();
        java.lang.Class<?> wildcardClass52 = javaVersion50.getClass();
        boolean boolean53 = javaVersion42.atLeast(javaVersion50);
        java.lang.Class<?> wildcardClass54 = javaVersion42.getClass();
        java.lang.reflect.Type[] typeArray55 = new java.lang.reflect.Type[] { wildcardClass11, wildcardClass15, wildcardClass22, wildcardClass35, wildcardClass41, wildcardClass54 };
        java.lang.String str56 = org.apache.commons.lang3.StringUtils.join(typeArray55);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(charArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion43 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion43.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + javaVersion45 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion45.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion46 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion46.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0.9" + "'", str49.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.8" + "'", str51.equals("1.8"));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(typeArray55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "class [Fclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion" + "'", str56.equals("class [Fclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Cclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test206");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################################################################################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test207");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac4OS4X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Or#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tionOr#cle Cor -1.0 J#v# Virtu#l M#chine Specific#tion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test209");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#################################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test210");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.Class<?> wildcardClass5 = javaVersion3.getClass();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = javaVersion8.atLeast(javaVersion12);
        boolean boolean15 = javaVersion3.atLeast(javaVersion12);
        boolean boolean16 = javaVersion0.atLeast(javaVersion3);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                /library/java/javavirtualmachines/j                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                /library/java/javavirtualmachines/j                                 " + "'", str1.equals("                                /library/java/javavirtualmachines/j                                 "));
    }
}

