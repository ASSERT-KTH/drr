import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaa", "HI", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaHIaa" + "'", str3.equals("aaaHIaa"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("onoonoonoo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "onoonoonoo" + "'", str1.equals("onoonoonoo"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "...AROPROC ELCARONOITAROP...", (java.lang.CharSequence) "HI! HI! hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "...:::::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("ono", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 ono" + "'", str2.equals("                                                                                                 ono"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("unxiwwnxJ.sxxCPCinnnCJ.b", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(" HOTHPOT(U ) 64-IIT HERVER   AVA!", "#########################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 344, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("         11b-08.42##############################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         11b-08.42##############################" + "'", str2.equals("         11b-08.42##############################"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("x86_64onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("unxiwwnxJ.sxxCPCinnnCJ.b", "hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "unxiwwnxJ.sxxCPCinnnCJ.b" + "'", str2.equals("unxiwwnxJ.sxxCPCinnnCJ.b"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        float[] floatArray6 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.Class<?> wildcardClass11 = floatArray6.getClass();
        java.lang.reflect.Type[] typeArray12 = new java.lang.reflect.Type[] { wildcardClass11 };
        float[] floatArray19 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray19);
        float float21 = org.apache.commons.lang3.math.NumberUtils.max(floatArray19);
        float float22 = org.apache.commons.lang3.math.NumberUtils.min(floatArray19);
        float float23 = org.apache.commons.lang3.math.NumberUtils.min(floatArray19);
        java.lang.Class<?> wildcardClass24 = floatArray19.getClass();
        java.lang.reflect.Type[] typeArray25 = new java.lang.reflect.Type[] { wildcardClass24 };
        float[] floatArray32 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float33 = org.apache.commons.lang3.math.NumberUtils.min(floatArray32);
        float float34 = org.apache.commons.lang3.math.NumberUtils.max(floatArray32);
        float float35 = org.apache.commons.lang3.math.NumberUtils.min(floatArray32);
        float float36 = org.apache.commons.lang3.math.NumberUtils.min(floatArray32);
        java.lang.Class<?> wildcardClass37 = floatArray32.getClass();
        java.lang.reflect.Type[] typeArray38 = new java.lang.reflect.Type[] { wildcardClass37 };
        java.lang.reflect.Type[][] typeArray39 = new java.lang.reflect.Type[][] { typeArray12, typeArray25, typeArray38 };
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.join(typeArray39);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(typeArray12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + (-1.0f) + "'", float20 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 100.0f + "'", float21 == 100.0f);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + (-1.0f) + "'", float22 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + (-1.0f) + "'", float23 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(typeArray25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + (-1.0f) + "'", float33 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 100.0f + "'", float34 == 100.0f);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + (-1.0f) + "'", float35 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + (-1.0f) + "'", float36 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(typeArray38);
        org.junit.Assert.assertNotNull(typeArray39);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("HI!HI!hi!1.7.0_801.7.0_801.7.", "hi!hi!hi!", "class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!HI!hi!1.7.0_801.7.0_801.7." + "'", str4.equals("HI!HI!hi!1.7.0_801.7.0_801.7."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "...", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 46, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "              sophie               aaa              sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                  SOPHIE##########################                                  ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", "Users/sop");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!HI!hi!", "########:\n");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Oracle Corporation");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "USERS/SOP", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "" + "'", charSequence2.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, 10, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                    on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("             sophie               ", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             sophie  ..." + "'", str2.equals("             sophie  ..."));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("jAVApLATFORMapisPECIFICATION", 5, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LATFORMapisPECIFIC" + "'", str3.equals("LATFORMapisPECIFIC"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " HOTHPOT(U ) 64-IIT HERVER   AVA!", (java.lang.CharSequence) "on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "              sophie               a5", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaPOSaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "POS" + "'", str2.equals("POS"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("ORACLE CORORACLE CORPORATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORACLE CO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("orcleorcle corportion orcle corportioncorportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "orcleorcle corportion orcle corportioncorportion" + "'", str1.equals("orcleorcle corportion orcle corportioncorportion"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HiSopmixed mod" + "'", str1.equals("HiSopmixed mod"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("########:\n", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "10.14.#");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "HI!   H...", (java.lang.CharSequence) "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.1", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("LATFORMapisPECIFIC", "SOPHIE", "aaaaPOSaaa", 37);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LATFORMapisPECIFIC" + "'", str4.equals("LATFORMapisPECIFIC"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444444444444444444444", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("             sophie  ...", "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             sophie  ..." + "'", str2.equals("             sophie  ..."));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos", 82, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "         11b-08.42##############################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " Hothpot(U ) 64-iit herver   ava!", (java.lang.CharSequence) "                                                    ", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        short[] shortArray5 = new short[] { (short) 100, (short) 1, (short) 1, (short) -1, (byte) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("SU", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU" + "'", str2.equals("SU"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#######", "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "########:\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("n2x1n4fc0000gn/T/", "hi!   hi! HI!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("unxiwwnxJ.sxxCPCinnnCJ.b", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "unxiwwnxJ.sxxCPCinnnCJ.b" + "'", str2.equals("unxiwwnxJ.sxxCPCinnnCJ.b"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnviro", 41, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("ttp://javaForacleFcom/UF8        ", "Oracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#CorporationOracle#Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://javaForacleFcom/UF8        " + "'", str2.equals("ttp://javaForacleFcom/UF8        "));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r" + "'", str2.equals("ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ono");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ONO" + "'", str1.equals("ONO"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "lrarO el");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aa7a0_a0-ba5", (java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMavaJ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        char[] charArray7 = new char[] { 'a', 'a', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "Mac OS X24.80-b1124.80-b1124.", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        char[] charArray8 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", charArray8);
        java.lang.Class<?> wildcardClass12 = charArray8.getClass();
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMavaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...aroproc elcaronoitarop...", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "hi!   hi! HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...", "/Library/Java/JavaVi...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaHIaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaHIaa" + "'", str2.equals("aaaHIaa"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("44444444US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444US" + "'", str1.equals("44444444US"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...:::::::::::::::::::::::::::::......:::::::::::::::::::::::::::::...", (java.lang.CharSequence) "HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j", 82);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("class o...", "on Orcle C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class o..." + "'", str2.equals("class o..."));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "                                         #######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4.a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4.a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HI!   HI! hi!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 52.0f + "'", float6 == 52.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "              sophie               ", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ORACLE CORORACLE CORPORATIO", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification" + "'", str2.equals("oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "...4444", (java.lang.CharSequence) "#################################################################################################", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        float[] floatArray6 = new float[] { 0.0f, 1, 100.0f, (short) -1, 10L, 18 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Oracle Corporation");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 53, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str4.equals("oracleOracle Corporation Oracle CorporationCorporation"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "oracle   Corporation" + "'", str11.equals("oracle   Corporation"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L", "             ...4444             ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("HI! HI! hi!", "Librury/Juvu/JuvuVirtuulsunhines/j.................................");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Librury/Juvu/JuvuVirtuulsunhines/j................................." + "'", str2.equals("Librury/Juvu/JuvuVirtuulsunhines/j................................."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_64onoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoonoono", (java.lang.CharSequence) " Hothpot(U ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                 on Orcle CorportionCorportion", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", (-1), 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie                          on Orcle CorportionCorportion" + "'", str4.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie                          on Orcle CorportionCorportion"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JavaPlatformAPISpecification", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.3", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                      51.0                    us", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################" + "'", str2.equals("##############################################"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI! HI! hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI! HI! HI!" + "'", str1.equals("HI! HI! HI!"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("##########################EIHPOS", ":\n", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SOP", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SU", "on Orcle C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("class [Dclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [D" + "'", str2.equals("class [D"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!IH" + "'", str1.equals("!IH"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HI", (java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("y/Java/Java");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.14.#");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation                                                                                  ", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("51.0");
        java.lang.Class<?> wildcardClass2 = bigDecimal1.getClass();
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "444444444444444444", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                      51.0                    US", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "       HI", 32, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", 1, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUA..." + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUA..."));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("n2x1n4fc0000gn/T/", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n2x1n4fc0000gn/T/" + "'", str3.equals("n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("oracleCorporation", "...:::::::::::::::::::::::::::::::...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation" + "'", str3.equals("oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A" + "'", str1.equals("                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "javaplatformapispeciono");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ", "7.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 " + "'", str2.equals("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 "));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "HI! H...E SPECIFICATI", (java.lang.CharSequence) "44444444US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaa", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaPOSaaa", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification", 24, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed mod", 97, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mod" + "'", str3.equals("mixed mod"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 29, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCaelcar" + "'", str1.equals("noitaroproCaelcar"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UN.LWWT.MOSX.CPRINTERJOB", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("44444444444444444444444444444", (double) 53.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444444445E28d + "'", double2 == 4.444444444444445E28d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("       HI", "HOTHPOT(U ) 64-IIT HERVER   AVA!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HOTHPOT(U ) 64-IIT HERVER   AVA!" + "'", str2.equals("HOTHPOT(U ) 64-IIT HERVER   AVA!"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "O10.14.3", (java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!   HI! hi!" + "'", str1.equals("HI!   HI! hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "LATFORMapisPECIFIC", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "0", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", 48, 53);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI! " + "'", str3.equals("i!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI! "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".." + "'", str1.equals(".."));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "orcleOrcle Corportion Orcle CorportionCorportion", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "             sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "HI!   H...                                                        ", 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!HI!hi!1.7.0_801.7.0_801.7.", (java.lang.CharSequence) "Java Virtual Machine Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Oracle Cor", "SOPHIE##########################", "http://java.oracle.com/1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Cor" + "'", str3.equals("Oracle Cor"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H..." + "'", str2.equals("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H..."));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("N");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("    ");
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", strArray2, strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("HI        ", "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ONO", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    ." + "'", str6.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    ."));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ONO" + "'", str10.equals("ONO"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::" + "'", str1.equals("::::::::::"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("orcleorcle corportion orcle corportioncorportion", "##########################EIHPOS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "orcleorcle corportion orcle corportioncorportion" + "'", str2.equals("orcleorcle corportion orcle corportioncorportion"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("##########################EIHPOS", ":\n", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "##########################EIHPOS" + "'", str5.equals("##########################EIHPOS"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("on Orcle C", "aaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("HI! HI! hi!", "orcleOrcle Corportion Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "orcleOrcle Corportion Orcle CorportionCorportion" + "'", str2.equals("orcleOrcle Corportion Orcle CorportionCorportion"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specification", 51.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.14.", "/Library/Java/JavaVi...", 180);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "    ", "aaaSOPaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                   ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("oracleOracle Corporation Oracle CorporationCorporation", "y/Java/Java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str2.equals("oracleOracle Corporation Oracle CorporationCorporation"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "SOPHIE##########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooJrPC.r", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooJrPC.r" + "'", str2.equals("ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooJrPC.r"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass8 = javaVersion6.getClass();
        boolean boolean9 = javaVersion0.atLeast(javaVersion6);
        java.lang.String str10 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        java.lang.Class<?> wildcardClass14 = javaVersion12.getClass();
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        boolean boolean23 = javaVersion17.atLeast(javaVersion21);
        boolean boolean24 = javaVersion12.atLeast(javaVersion21);
        boolean boolean25 = javaVersion0.atLeast(javaVersion12);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.3" + "'", str10.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", (java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 93, "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Or...", "rmAPI", 37);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("e", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("             SOPHIE               ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hiSopmixed mod", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiSopmixed mod" + "'", str2.equals("hiSopmixed mod"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "...", (java.lang.CharSequence) "/Users/sophieents/Home/jre/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("USERS/SOP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi" + "'", charSequence2.equals("SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("OracleaCorporation");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                                ", "son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "son Orcle CorportionCorportionmacosx.CPrinterJob" + "'", str2.equals("son Orcle CorportionCorportionmacosx.CPrinterJob"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "HI!H...", (java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass7 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("    SophiSoHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    SophiSoHI" + "'", str1.equals("    SophiSoHI"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation", "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation" + "'", str2.equals("oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Sophi", "oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation...:::::::::::::::::::::::::::::::...oracleCorporation", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("a", "7.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 180, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Hothpot(U)64-iitherverava!", "onoonoonoo", 180);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("easpecificationoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "easpecificationoracleacora-1.0ajavaavirtualamachineas" + "'", str1.equals("easpecificationoracleacora-1.0ajavaavirtualamachineas"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "phiSophiSophiSophi", 37, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!" + "'", str1.equals("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI! H...e specificati", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("..");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.8", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "javaplatformapispecification", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\nhi", (java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.0d + "'", double2 == 24.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("HI        ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph", "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", "                   Oracle Cor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph" + "'", str3.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", "JavaPlatformAPISpecification");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/", (int) ' ', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("::::::::::", "::::::::::", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("...:::::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...:::::::::::::::::::::::::::::::..." + "'", str1.equals("...:::::::::::::::::::::::::::::::..."));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 65, (float) 1L, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 18.0f, (double) 4.4444444E12f, (double) 37.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 73, 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("o", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.reflect.Type[][][] typeArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(typeArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", "oracle Corporation", "HI        ", 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292" + "'", str4.equals("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!H...HI!H...HI!H...HI!H...HI!H..." + "'", str2.equals("HI!H...HI!H...HI!H...HI!H...HI!H..."));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        short[] shortArray5 = new short[] { (short) 100, (short) 1, (short) 1, (short) -1, (byte) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("HI! HI! HI!", "SOPHIE", 10, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SOPHIE!" + "'", str4.equals("SOPHIE!"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6" + "'", str1.equals("x86_6"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "cle.com/a.oravahttp://j", (java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", (java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/HhSh(TM)/64-B/Sv/VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SOPHIE", (java.lang.CharSequence) "SophiSoHI ", 344);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("n2x1n4fc0000gn/T/", "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", "easpecificationoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n2x1n4fc0000gn/T/" + "'", str3.equals("n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "mixed mo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "O", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0" + "'", str1.equals("10.0"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("HI! H...E SPECIFICATI", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String[] strArray5 = new java.lang.String[] { "Hi!", "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444", " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!", "aa7a0_a0-ba5", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" };
        java.lang.String[] strArray11 = new java.lang.String[] { "Hi!", "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444", " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!", "aa7a0_a0-ba5", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" };
        java.lang.String[] strArray17 = new java.lang.String[] { "Hi!", "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444", " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!", "aa7a0_a0-ba5", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" };
        java.lang.String[] strArray23 = new java.lang.String[] { "Hi!", "44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444", " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!", "aa7a0_a0-ba5", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" };
        java.lang.String[][] strArray24 = new java.lang.String[][] { strArray5, strArray11, strArray17, strArray23 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(strArray24);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray24);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 'a', (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hiSopmixed mod");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("SOPHIE!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE!" + "'", str1.equals("SOPHIE!"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("              sophie               aaa              sophie               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie               aaa              sophie" + "'", str1.equals("sophie               aaa              sophie"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) " hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...", (java.lang.CharSequence) "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.14.aaaaaaa", "ono", "e");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/", (java.lang.CharSequence) "aa7a0_a0-ba5                                        ", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ":::::::::::::::::::::::::::::::::::", (int) (byte) 100);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("       HI", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/" + "'", str5.equals("/"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "       HI" + "'", str12.equals("       HI"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                   44444444444444444444444444444                                    ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   44444444444444444444444444444                                    " + "'", str2.equals("                                   44444444444444444444444444444                                    "));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "##########################EIHPOS", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("y/Jv/Jv");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", "...aroproC elcarOnoitarop...");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "x86_6", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!" + "'", str1.equals("Hi!hi!hi!"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("on Orcle CorportionCorportion", "oracle corporation", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", "aa7a0_a0-ba");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/LIB", "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIB" + "'", str2.equals("/LIB"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "noitaroproCaelcarO", (java.lang.CharSequence) "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "OracleaCorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 6, (long) ' ', (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "HI        ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType(":::::::::::::::::::::::::::::::::::");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "...AROPROC ELCARONOITAROP...", (java.lang.CharSequence[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ":::::::::::::::::::::::::::::::::::" + "'", str11.equals(":::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVi...", 10, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava/JavaVi..." + "'", str3.equals("ava/JavaVi..."));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(" HOTHPOT(U ) 64-IIT HERVER   AVA!", "...:::::::::::::::::::::::::::::......:::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HOTHPOT(U ) 64-IIT HERVER   AVA!" + "'", str2.equals(" HOTHPOT(U ) 64-IIT HERVER   AVA!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", 78, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j" + "'", str3.equals("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("             sophie  ...", 9, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             sophie  ..." + "'", str3.equals("             sophie  ..."));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.cprinterjob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.Class<?> wildcardClass5 = javaVersion3.getClass();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = javaVersion8.atLeast(javaVersion12);
        boolean boolean15 = javaVersion3.atLeast(javaVersion12);
        boolean boolean16 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str17 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.7" + "'", str17.equals("1.7"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("i!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI! ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie", "oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j" + "'", str1.equals("/Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 78, 24);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "!IH", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/HhSh(TM)/64-B/Sv/VMavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 52.0f + "'", float6 == 52.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int[] intArray5 = new int[] { (short) 10, (byte) 10, 3, (byte) 100, (short) 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", 13, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", "sophie               aaa              sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("e", 53, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e4444444444444444444444444444444444444444444444444444" + "'", str3.equals("e4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "O10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixed mode", "1.7.0_80", 24);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 35, 14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.a", "mixed mode");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("10.14.a", "mixed mode");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence4, (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a", strArray3, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a" + "'", str9.equals("a"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", 52, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("::::::::::", "oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo", 48);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_80", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", (int) ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str5.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.0", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("oracle corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracle corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                      51.0                    us", (java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMavaJ", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "::::::::::444444444444444444", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("javaplatformapispecification", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaPOSaaa", 73, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (java.lang.CharSequence) "hi!   hi! HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("easpecificationoracleacora-1.0ajavaavirtualamachineas", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "easpecificationoracleacora-1.0ajavaavirtualamachineas" + "'", str2.equals("easpecificationoracleacora-1.0ajavaavirtualamachineas"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("4444444444", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                                                    ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("US", "...AROPROC ELCARONOITAROP...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Oracle Cor -1.0 Java Virtual Machine Specification", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification" + "'", str2.equals("Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::::sophie" + "'", str2.equals("::::::::::::::::::::::::::sophie"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "orcleorcle corportion orcle corportioncorportion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                    on Orcle CorportionCorportion", (java.lang.CharSequence) "##########################EIHPOS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("             ...4444             ", "JavaPlatformAPISpecification", "aaaHIaa", 53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "             ...4444             " + "'", str4.equals("             ...4444             "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnviro", "aa7a0_a0-ba", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("onoonoonoonoonoonoonoonoono", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "onoonoonoonoonoonoonoonoono" + "'", str2.equals("onoonoonoonoonoonoonoonoono"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        double[] doubleArray6 = new double[] { (byte) 10, (-1L), 100, 1.0d, 3, 1.0f };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Hi!", "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", (int) 'a', 37);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hi!SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################" + "'", str4.equals("Hi!SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaSOPaaaa", "HI! H...E SPECIFICATI", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "...aroproc elcaronoitarop...", (java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "HI!   HI! hi!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 18, (double) 1.1f, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "##############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        " + "'", str2.equals("                        "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (long) 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 48.0f, (double) 'a', (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac4OS4X", "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "...rati...", (int) (byte) 10);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", (java.lang.CharSequence) "x664");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "SOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################", (java.lang.CharSequence) "HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str1.equals("class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A", "4444444444444444444444444444444444444444044444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "      ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray15 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray15);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray15);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray15);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray15);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oracle Corporation", charArray15);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray15);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI", charArray15);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaa", charArray15);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray15);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI! HI! hi!", charArray15);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "oracle corporation");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                   O", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("noitaroproCaelcar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racleaCorporation" + "'", str1.equals("racleaCorporation"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HiSopmixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HISOPMIXED MOD" + "'", str1.equals("HISOPMIXED MOD"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!hi!", "...:::::::::::::::::::::::::::::::...", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ttp://javaForacleFcom/UF8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("X664");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X664\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aa7a0_a0-ba", 9, "..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa7a0_a0-ba" + "'", str3.equals("aa7a0_a0-ba"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!Oracle Corporation hothpot(u ) 64-iit herver   ava!", (java.lang.CharSequence) "51.0", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.3", 3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.b", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.a", "10.14.#");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray7, strArray14);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n2x1n4fc0000gn/T/n.lwwt.mosx.CPrinterJob", "             sophie  ...", 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaa.41.01", strArray14, strArray19);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "aaaaaaa.41.01" + "'", str20.equals("aaaaaaa.41.01"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292", "aaaSOPaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", "unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(4.0d, 37.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 19, 7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#########################################################################", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "\nhi!", (java.lang.CharSequence) "Librury/Juvu/JuvuVirtuulsunhines/j.................................");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", "4.a", "\nhi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j" + "'", str3.equals("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", 73, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97, (float) 35, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) 23, (double) 53.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292", "O");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) ".", (java.lang.CharSequence) "AVA VIRTUAL MACHINE SPECIFICATION", 180);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                /AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/AEA/E/EABB/A/L/b///y/N/J//AxLAE/N/J/ SV/LA/T ASJ HBAA//A/L/A/AEA/E/EABB/A/L/b///y/N/J//AxLAE/A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/lrarO el/Users/s", (java.lang.CharSequence) "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie                      " + "'", str2.equals("/Users/sophie                      "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("O10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "o10.14.3" + "'", str1.equals("o10.14.3"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.#");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "4.a");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444044444444444444444444444444444444444444444", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4444444444444444444444444444444444444444044444444444444444444444444444444444444444" + "'", str10.equals("4444444444444444444444444444444444444444044444444444444444444444444444444444444444"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaaaPOSaaa", 66, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!H...HI!H...HI!H...HI!H...HI!H...", "UN.LWWT.MOSX.CPRINTERJOB", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie                          on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("e", "#######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        char[] charArray13 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "\n", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                    .", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "             ...4444             ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("::::::::::::::::::::::::::sophie", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::sophie" + "'", str2.equals("::sophie"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        int[] intArray5 = new int[] { (short) 10, (byte) 10, 3, (byte) 100, (short) 0 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI! ", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 9, 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/1.8" + "'", str1.equals("http://java.oracle.com/1.8"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "HI");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(97.0d, (double) 0.0f, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi" + "'", str2.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "easpSOPHIE####################son Orcle CorportionCorportionmacosx.CPrinterJobSOPHIE####################onoracleacora-1.0ajavaavirtualamachineas", 344);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    ", (-1), '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    " + "'", str3.equals("    "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/lrarO el/Users/s", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophORACLE CORORACLE CORPORATION/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("5a0-ba0_a7");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaom deximaaaaa", "1.1", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!hi!aaaaaaaaaaaaaaaaaaa", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                                 ono", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                                                                                 ono" + "'", str7.equals("                                                                                                 ono"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.7", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("javaplatformapispeciono", "SophiSoHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaplatformapispeciono" + "'", str2.equals("javaplatformapispeciono"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaa.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa.41.01" + "'", str1.equals("aaaaaaa.41.01"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("JavaPlatformAPISpecification", "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("AVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("AVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                                                                                   ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 73, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hi!   hi! HI!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!   hi! HI!" + "'", str2.equals("hi!   hi! HI!"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" Hothpot(U ) 64-iit herver   ava!", 30, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "va!" + "'", str3.equals("va!"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaa", "HISOPMIXED MOD", 93, 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaHISOPMIXED MOD" + "'", str4.equals("aaaHISOPMIXED MOD"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("7.", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/", charSequence1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "HI        ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SophiSophiSophiSophiSopmixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SophiSophiSophiSophiSopmixed mod" + "'", str1.equals("SophiSophiSophiSophiSopmixed mod"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HOTHPOT(U ) 64-IIT HERVER   AVA!", "http://java.oracle.com/1.8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        double[] doubleArray5 = new double[] { 29, 52L, 18, 37L, 28 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.0d + "'", double6 == 18.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("HI!HI!hi!aaaaaaaaaaaaaaaaaaa", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaa" + "'", str2.equals("HI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaaHI!HI!hi!aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SophiSoHI ", "orcleorcle corportion orcle corportioncorportion");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.#");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str9.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 33, (long) 115, (long) 33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "un.lwwt.mosx.CPrinterJob", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("HI!H...HI!H...HI!H...HI!H...HI!H...", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("noitaroproCaelcarO", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCaelcarO" + "'", str2.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...", (java.lang.CharSequence) "javaplatformapispecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "USERS/SOP", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Users/sop", "javaplatformapispecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    hi!hi!hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "class [D");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATION" + "'", str1.equals("jAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "HI!H...HI!H...HI!H...HI!H...HI!H...", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ttp://javaForacleFcom/UF8        ", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", 344);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/", "aaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("o10.14.3", "10.14.#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "o10.14.3" + "'", str2.equals("o10.14.3"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SU", (java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie                      ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                        ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("JavaPlatformAPISpecification", "Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":", 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HotSpot(TM) 64-Bit Server VMavaJ", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r VMavaJ" + "'", str2.equals("r VMavaJ"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie" + "'", str2.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: sophie"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("easpecificationoracleacora-1.0ajavaavirtualamachineas");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "easpecificationoracleacora-1.0ajavaavirtualamachineas" + "'", str1.equals("easpecificationoracleacora-1.0ajavaavirtualamachineas"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("noitaroproCaelcar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCaelcar" + "'", str2.equals("noitaroproCaelcar"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("e               rmAPI               e               rmAPI               e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: e               rmAPI               e               rmAPI               e is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("SU", "rmAPI", "      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SU" + "'", str3.equals("SU"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("RMAPISPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RMAPISPECIFICATION" + "'", str1.equals("RMAPISPECIFICATION"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.aaaaaaa", (java.lang.CharSequence) "! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS ", "r VMavaJ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("       ", "hi!", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.cprinterjob", (int) (short) 100, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str3.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMavaJ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444US", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("noitaroproCaelcarO", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.8");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/HhSh(TM)/64-B/Sv/VMavaJ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "un.lwwt.mosx.CPrinterJob", (java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "un.lwwt.mosx.CPrinterJob" + "'", charSequence2.equals("un.lwwt.mosx.CPrinterJob"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 35, (long) 6, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("...4444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...4444" + "'", str1.equals("...4444"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                         #######", "10.14.aaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444OracleCor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("HI ", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", ":::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaa.41.01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "########:\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                 SOPHIE##########################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str8 = javaVersion4.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "SOPHISOPHISOPHISOPHISOPHISOPHISOP", (java.lang.CharSequence) "Users/sopun.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Oracle Corporation", 19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("              sophie               a5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              sophie               a5" + "'", str1.equals("              sophie               a5"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X664", "Hothpot(U)64-iitherverava!", "! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo", (java.lang.CharSequence) "                                                   O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "POS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                   44444444444444444444444444444                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                        ", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ", strArray2, strArray8);
        java.lang.Class<?> wildcardClass10 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 " + "'", str9.equals("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 "));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                  SOPHIE##########################                                  ", (java.lang.CharSequence) "             sophie  ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/lrarO el/Users/s", 115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115 + "'", int2 == 115);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.CharSequence[] charSequenceArray8 = new java.lang.CharSequence[] { "HI!", "", "", "HI!", "hi!" };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charSequenceArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", charSequenceArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292", charSequenceArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray8, "oracle Corporation", (int) (byte) 1, (int) (short) 1);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray8);
        org.junit.Assert.assertNotNull(charSequenceArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", charSequence1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("5a0-ba0_a7", (int) (byte) 100, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5a0-ba..." + "'", str3.equals("5a0-ba..."));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 180, (long) 33, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 180L + "'", long3 == 180L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!   HI! hi!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

