import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "44444444444444444444444444444", (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 0, (int) (short) 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Library/Java/JavaVi...");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        double[] doubleArray5 = new double[] { (short) 100, 100L, '#', 100, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.Class<?> wildcardClass8 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 115);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################################################" + "'", str2.equals("###################################################################################################################"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/", 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Mac OS X24.80-b1124.80-b1124.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Users/sop", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sop" + "'", str2.equals("Users/sop"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "x664", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie" + "'", str3.equals(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("oracleOracle Corporation Oracle CorporationCorporation", "http://java.oracle.com/1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str2.equals("oracleOracle Corporation Oracle CorporationCorporation"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Users/sop", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("un.lwwt.mosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UN.LWWT.MOSX.CPRINTERJOB" + "'", str1.equals("UN.LWWT.MOSX.CPRINTERJOB"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporation                                                                                  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H..." + "'", str1.equals("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H..."));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java", "Users/sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java" + "'", str2.equals("/Library/Java"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("4.a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 10, (float) 31, (float) 53);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 53.0f + "'", float3 == 53.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ", (java.lang.CharSequence) "ttp://javaForacleFcom/UF8");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               " + "'", charSequence2.equals("              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0", 82, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444044444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444044444444444444444444444444444444444444444"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaa", "Sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("24.80-b11         ", "oracle CorOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "on Orcle CorportionCorportion", (java.lang.CharSequence) "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Mac OS X24.80-b1124.80-b1124.", (java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("o", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "o" + "'", str2.equals("o"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":\n", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":\n" + "'", str2.equals(":\n"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "                                                    ", 4, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                    " + "'", str4.equals("                                                    "));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "x664", 13);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "mixed mod");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.cprinterjob", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str3.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r", 82);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\nhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", "", 7);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "########:\n", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("\nhi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\nhi" + "'", str1.equals("\nhi"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 31, (double) 100.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_95312_1560210292", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("rmAPISpecification", (int) (short) 100, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L" + "'", str3.equals("rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "aa7a0_a0-ba");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaplatformapispecification" + "'", str1.equals("javaplatformapispecification"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation", "             sophie               ", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporation" + "'", str4.equals("Oracle Corporation"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "x664", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("oracle Corporation", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aa7a0_a0-ba5", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sophi", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "mixed mo", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SOP", (int) (byte) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaSOPaaaa" + "'", str3.equals("aaaSOPaaaa"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("on Orcle CorportionCorportion", 78, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                 on Orcle CorportionCorportion" + "'", str3.equals("                                                 on Orcle CorportionCorportion"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("HI!HI!hi!aaaaaaaaaaaaaaaaaaa", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                    ", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "ORACLE CORORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        char[] charArray12 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaSOPaaaa", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("...aroproC elcarOnoitarop...", "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...aroproC elcarOnoitarop..." + "'", str2.equals("...aroproC elcarOnoitarop..."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("O10.14.3", "HI!HI!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("x664", 8, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x664" + "'", str3.equals("x664"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", (java.lang.CharSequence) ":\n", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Mac OS ", charSequence1, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HI!   HI! hi!", 115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 115 + "'", int2 == 115);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        char[] charArray10 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.8", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\nhi!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                         ", 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         " + "'", str3.equals("                                                                         "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "oracle CorOracle Corporation", (java.lang.CharSequence) "ORACLE CORORACLE CORPORATION", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java", " HotSpot(TM) 64-Bit Server VMavaJ", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java" + "'", str3.equals("/Library/Java"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 180.0f, (double) 35, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                    .", (java.lang.CharSequence) "Mac4OS4X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-b11         ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray4 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3 };
        org.apache.commons.lang3.math.NumberUtils numberUtils5 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils6 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray9 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils5, numberUtils6, numberUtils7, numberUtils8 };
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils11 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils12 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils13 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray14 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils10, numberUtils11, numberUtils12, numberUtils13 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray15 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray4, numberUtilsArray9, numberUtilsArray14 };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray15);
        org.junit.Assert.assertNotNull(numberUtilsArray4);
        org.junit.Assert.assertNotNull(numberUtilsArray9);
        org.junit.Assert.assertNotNull(numberUtilsArray14);
        org.junit.Assert.assertNotNull(numberUtilsArray15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HI!H...", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!H..." + "'", str3.equals("HI!H..."));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaSOPaaaa", "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaSOPaaaa" + "'", str2.equals("aaaSOPaaaa"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(":", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation                                                                                  ", (java.lang.CharSequence) "ORACLE CORORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                 on Orcle CorportionCorportion", (java.lang.CharSequence) " Hothpot(U ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCor-1.0JavaVirtualMachineSpecification" + "'", str1.equals("OracleCor-1.0JavaVirtualMachineSpecification"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Cor", "", (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Sun.lwawt.macosx.CPrinterJob", (int) (byte) 10, 0);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java HotSpot(TM) 64-Bit Server VM", 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;class org.apache.commons.lang3.javaversionclass [ljava.lang.string;class [ljava.lang.string;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("rmAPISpecification", "24.80-b11         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rmAPISpecification" + "'", str2.equals("rmAPISpecification"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 5, (double) 78, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "44444444444444444444444444444444444" + "'", charSequence2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach(".", strArray3, strArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ', 82, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 82");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "." + "'", str9.equals("."));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("noitaroproCaelcarO", "Mac OS X24.80-b1124.80-b1124.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCaelcarO" + "'", str2.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, 0.0d, (double) 33L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-b11", "###################################################################################################################", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", str8.equals("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophi", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophi" + "'", str3.equals("sophi"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("         11b-08.42", "Oracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine SpecificationOracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("e", "HI!H...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("un.lwwt.mosx.CPrinterJob", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Mac OS ", 33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "un.lwwt.mosx.CPrinterJob" + "'", str4.equals("un.lwwt.mosx.CPrinterJob"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("unxiwwnxJ.sxxCPCinnnCJ.b", 52, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("JAVA VIRTUAL MACHINE SPECIFICATION", " Hothpot(U ) 64-iit herver   ava!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", 180);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio" + "'", str2.equals("                                                                                /Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', (int) (short) 100, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("SophiSophiSophiSophiSopmixed mod", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oracleOracle Corporation Oracle CorporationCorporation", 18, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str3.equals("oracleOracle Corporation Oracle CorporationCorporation"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("HI!HI!hi!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("5a0-ba0_a7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5A0-BA0_A7" + "'", str1.equals("5A0-BA0_A7"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/1.8", "Users/sop", "              sophie               a5");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.lwawt.macosx.CPrinterJob", "on Orcle CorportionCorportion", (int) (short) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "son Orcle CorportionCorportionmacosx.CPrinterJob" + "'", str4.equals("son Orcle CorportionCorportionmacosx.CPrinterJob"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("SophiSoHI ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SophiSoHI " + "'", str1.equals("SophiSoHI "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UN.LWWT.MOSX.CPRINTERJOB", (java.lang.CharSequence) "           #           ", 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 32, "                                /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", 78);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SophiSoHI ", "Sun.lwawt.macosx.CPrinterJob", (int) '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("hI!", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hI!" + "'", str6.equals("hI!"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10.14.a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.a" + "'", str1.equals("10.14.a"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("\nhi!", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nhi!" + "'", str2.equals("\nhi!"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "###################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", "ORACLE CORORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292" + "'", str2.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "::::::::::");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass8 = javaVersion6.getClass();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean16 = javaVersion14.atLeast(javaVersion15);
        boolean boolean17 = javaVersion11.atLeast(javaVersion15);
        boolean boolean18 = javaVersion6.atLeast(javaVersion15);
        boolean boolean19 = javaVersion1.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean22 = javaVersion20.atLeast(javaVersion21);
        java.lang.String str23 = javaVersion21.toString();
        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        boolean boolean25 = javaVersion6.atLeast(javaVersion21);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0.9" + "'", str23.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oracle Corporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Oracle Corporation");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 23, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 23");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleOracle Corporation Oracle CorporationCorporation" + "'", str3.equals("oracleOracle Corporation Oracle CorporationCorporation"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 32, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "un.lwwt.mosx.CPrinterJob", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SOPHI", (int) (short) 10, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str5 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HI        ", "noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI        " + "'", str2.equals("HI        "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(51.0d, 0.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ttp://javaForacleFcom/UF8", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://javaForacleFcom/UF8" + "'", str2.equals("ttp://javaForacleFcom/UF8"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "####################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "on Orcle CorportionCorportion", (java.lang.CharSequence) "4444444444444444444444444444444444444444044444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("HI!HI!hi!aaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!HI!hi!aaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos" + "'", str1.equals("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("...:::::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...:::::::::::::::::::::::::::::::..." + "'", str1.equals("...:::::::::::::::::::::::::::::::..."));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "##########################EIHPOS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r", 115);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("jAVApLATFORMapisPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLATFORMapisPECIFICATION" + "'", str2.equals("jAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 7L, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "########:\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("44444444444444444444444444444444", 97, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...4444" + "'", str3.equals("...4444"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(" Hothpot(U ) 64-iit herver   ava!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        short[] shortArray5 = new short[] { (short) 100, (short) 1, (short) 1, (short) -1, (byte) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("::::::::::444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/JavaVirtualMachines/j", "mixed mo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi" + "'", str2.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 115, (float) 53, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 115.0f + "'", float3 == 115.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi", "e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292" + "'", str1.equals("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10.14.", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("HI ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI " + "'", str2.equals("HI "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Hothpot(U ) 64-iit herver   ava!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", "oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie" + "'", str2.equals("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cle.com/a.oravahttp://j" + "'", str1.equals("cle.com/a.oravahttp://j"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("SOPHIE", 115);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIE" + "'", str2.equals("SOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIE"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" HotSpot(TM) 64-Bit Server VMavaJ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", (java.lang.CharSequence) "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("HI!H...", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIB" + "'", str2.equals("/LIB"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("...:::::::::::::::::::::::::::::::...", "", "                                                    .");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                               US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                               US" + "'", str1.equals("                                                                                               US"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mixed mo", "                   Oracle Cor", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "HI!HI!hi!aaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!hi!aaaaaaaaaaaaaaaaaaa" + "'", str2.equals("HI!HI!hi!aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("SOP", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOP" + "'", str2.equals("SOP"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!   hi! HI!", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("O10.14.3", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("5A0-BA0_A7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5A0-BA0_A7" + "'", str1.equals("5A0-BA0_A7"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("EN", "Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "::::::::::444444444444444444", (java.lang.CharSequence) "o", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("noitaroproCaelcarO", "oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCaelcarO" + "'", str2.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 18L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Users/sop", "SOPHI", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("10.14.a", strArray2, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.14.a" + "'", str7.equals("10.14.a"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HI        ", "###################################################", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) -1, (byte) 10 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4.a", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 31, (double) 73, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.0d + "'", double3 == 73.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", (int) (byte) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        short[] shortArray5 = new short[] { (short) 100, (short) 1, (short) 1, (short) -1, (byte) 10 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "             SOPHIE               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("SOPHIE##########################", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.14.aaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaa.41.01" + "'", str1.equals("aaaaaaa.41.01"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sophie", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.#", (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.14.aaaaaaa", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("###################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("\nhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\nhi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Oracle Cor\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j" + "'", str1.equals("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "cle.com/a.oravahttp://j", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("###################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################################################################################" + "'", str1.equals("###################################################################################################################"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("HI", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("::::::::::");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::::" + "'", str1.equals("::::::::::"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaa.41.01", "", "Mac OS ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Cor", "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", "noitaroproCaelcarO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "lrarO el" + "'", str3.equals("lrarO el"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("noitaroproCaelcarO", "x664");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCaelcarO" + "'", str2.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle Cor -1.0 Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor -1.0 Java Virtual Machine Specification" + "'", str2.equals("Oracle Cor -1.0 Java Virtual Machine Specification"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle Cor -1.0 Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Cor -1.0 Java Virtual Machine Specification" + "'", str2.equals("Oracle Cor -1.0 Java Virtual Machine Specification"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ", "                                  SOPHIE##########################                                  ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("              sophie               a5", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              sophie               a5" + "'", str3.equals("              sophie               a5"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(":\n", "rmAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rmAPISpecification" + "'", str2.equals("rmAPISpecification"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("5A0-BA0_A7", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                   Oracle Cor", (java.lang.CharSequence) "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("orcleOrcle Corportion Orcle CorportionCorportion", "US");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLE CORORACLE CORPORATIO", "    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo", "                                                 on Orcle CorportionCorportion", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo" + "'", str3.equals("oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5A0-BA0_A7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5A0-BA0_A7" + "'", str1.equals("5A0-BA0_A7"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "44444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":\n", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.a", "mixed mode");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "...rati...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray1 = new org.apache.commons.lang3.StringUtils[] { stringUtils0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray1);
        org.junit.Assert.assertNotNull(stringUtilsArray1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_8SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                    .", (java.lang.CharSequence) "OCLE CORORACLE CORPORATION", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        char[] charArray9 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.9", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("rmAPISpecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rmAPISpecification" + "'", str1.equals("rmAPISpecification"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ttp://javaForacleFcom/UF8", (java.lang.CharSequence) "...on Oracle CorporationCorporation", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 32, 180);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 180 + "'", int3 == 180);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("...porationOracle Corpora...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...porationOracle Corpora..." + "'", str1.equals("...porationOracle Corpora..."));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih" + "'", str1.equals("!ih"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("             SOPHIE               ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("             sophie               ", "ttp://javaForacleFcom/UF8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             sophie               " + "'", str2.equals("             sophie               "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("OracleaCorporation", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleaCorporation" + "'", str2.equals("OracleaCorporation"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nos" + "'", str2.equals("boJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nos"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mac4OS4X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac4OS4X" + "'", str1.equals("Mac4OS4X"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 37, 0L, (long) 82);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), (int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java", (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Users/sop", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sop" + "'", str2.equals("Users/sop"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("##############################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 7, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "y/Java/Java" + "'", str3.equals("y/Java/Java"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                               US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("...aroproc elcaronoitarop...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...AROPROC ELCARONOITAROP..." + "'", str1.equals("...AROPROC ELCARONOITAROP..."));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/LIB", (-1), "/Library/Java/JavaVi...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIB" + "'", str3.equals("/LIB"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...aroproC elcarOnoitarop...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "\nhi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 52.0f + "'", float6 == 52.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/1.8", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("hI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!" + "'", str1.equals("hI!"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        double[] doubleArray5 = new double[] { (short) 100, 100L, '#', 100, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 115);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                   " + "'", str2.equals("                                                                                                                   "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 4, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 53, (float) 78, (float) 82);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 53.0f + "'", float3 == 53.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("javaplatformapispecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) 100 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("n2x1n4fc0000gn/T/", "::::::::::");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n2x1n4fc0000gn/T/" + "'", str2.equals("n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Mac", "10.14.a", 115);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion1.atLeast(javaVersion5);
        java.lang.String str9 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.9" + "'", str9.equals("0.9"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("mixed mod", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("HI!", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HI!" + "'", str8.equals("HI!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "1.8", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L", (java.lang.CharSequence) "/Library/Java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi.." + "'", str1.equals("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi.."));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "::::::::::");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mac OS X", 2, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("noitaroproCaelcarO", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitaroproCaelcarO" + "'", str3.equals("noitaroproCaelcarO"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Users/sop");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USERS/SOP" + "'", str1.equals("USERS/SOP"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j/Library/Java/JavaVirtualMachines/j", "...aroproC elcarOnoitarop...");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://java.oracle.com/1.8", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/LIB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIB" + "'", str1.equals("/LIB"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("SOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIESOPHIE", "...:::::::::::::::::::::::::::::::...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("              sophie               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 115, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) 35, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "hi!", 7);
        java.lang.CharSequence charSequence5 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "0.9");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence5, (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("HI!   H...", strArray4, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', 18, 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "HI!   H..." + "'", str10.equals("HI!   H..."));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str11.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("::::::::::444444444444444444", "son Orcle CorportionCorportionmacosx.CPrinterJob", "hI!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444444444444444444444444444410.0444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("jAVApLATFORMapisPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVApLATFORMapisPECIFICATION" + "'", str2.equals("jAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "ORACLE CORORACLE CORPORATION");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "mixed mo");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, (int) 'a', 82);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.hi!   hi! HI!10.14.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("             SOPHIE               ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             SOPHIE               " + "'", str2.equals("             SOPHIE               "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "SOPHI", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4444444444444", "class o...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444" + "'", str2.equals("4444444444444"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", (long) 73);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 73L + "'", long2 == 73L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                 on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#", "mixed mode", 7);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "...porationOracle Corpora...");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Users/sop", "                                /Library/Java/JavaVirtualMachines/j                                 ", 37);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("n2x1n4fc0000gn/T/", strArray11, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("1.7", strArray5, strArray17);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "n2x1n4fc0000gn/T/" + "'", str18.equals("n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.7" + "'", str19.equals("1.7"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Oracle Cor", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Users/sop", "un.lwwt.mosx.CPrinterJob", 33, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Users/sopun.lwwt.mosx.CPrinterJob" + "'", str4.equals("Users/sopun.lwwt.mosx.CPrinterJob"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "HI!H...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Virtual Machine Specification", "", "SophiSoHI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(35.0d, (double) 29, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("...AROPROC ELCARONOITAROP...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...AROPROC ELCARONOITAROP..." + "'", str2.equals("...AROPROC ELCARONOITAROP..."));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "HI!H...", (java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.b");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarO" + "'", str1.equals("noitaroproC elcarO"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                   44444444444444444444444444444                                    ", (java.lang.CharSequence) "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nosboJretnirPC.xsocamnoitroproCnoitroproC elcrO nos");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "y/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ", (java.lang.CharSequence) "oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ORACLE CORORACLE CORPORATION", 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################################################", "/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "              sophie               a5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", 29, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...:::::::::::::::::::::::::::::..." + "'", str3.equals("...:::::::::::::::::::::::::::::..."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 97, (long) 82, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.0f), (double) 37L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("          ", (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("SOPHIE##########################", "1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.710.14.a1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE##########################" + "'", str2.equals("SOPHIE##########################"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!" + "'", str1.equals("HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("#######", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         #######" + "'", str2.equals("                                         #######"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "noitaroproCaelcarO", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("...on Oracle CorporationCorporation", "                                         #######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...on Oracle CorporationCorporation" + "'", str2.equals("...on Oracle CorporationCorporation"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "................................/Librury/Juvu/JuvuVirtuulsunhines/j................................." + "'", str2.equals("................................/Librury/Juvu/JuvuVirtuulsunhines/j................................."));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("noitaroproC elcarO", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo", "HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...HI!H...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "HI!", charSequence1, 48);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(":::::::::::::::::::::::::::::::::::", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "O10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "10.14.#");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.14.#" + "'", charSequence2.equals("10.14.#"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!", "...aroproC elcarOnoitarop...", 48);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("orcleorcle corportion orcle corportioncorportion");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("           #           ", "5A0-BA0_A7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           #           " + "'", str2.equals("           #           "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        long[] longArray5 = new long[] { 100L, 100, 10, 'a', 29 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("OCLE CORORACLE CORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OCLE CORORACLE CORPORATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Mac4OS4X", "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(82, 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("             sophie               ", "#######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                 SOPHIE##########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...4444", 33, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             ...4444             " + "'", str3.equals("             ...4444             "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "hi!", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi..", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SOPHIE##########################", (java.lang.CharSequence) "oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification", 35, 53);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e specificationoracle cor -1.0 java virtual machine s" + "'", str3.equals("e specificationoracle cor -1.0 java virtual machine s"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server VM", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed mo", 19, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaamixed moaaaaaa" + "'", str3.equals("aaaaamixed moaaaaaa"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ndoop.pl_95312_1560210292a/Users/sophie/Documents/defects4j/tmp/run_r");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.awt.CGraphicsEnviro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnviro" + "'", str1.equals("sun.awt.CGraphicsEnviro"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("orcleOrcle Corportion Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION" + "'", str1.equals("ORCLEORCLE CORPORTION ORCLE CORPORTIONCORPORTION"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle Cor -1.0 Java Virtual Machine Specification", (java.lang.CharSequence) "/ttp://javaForacleFcom/UF8ERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292_95312_1560210292");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aa7a0_a0-ba5", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa7a0_a0-ba5                                        " + "'", str3.equals("aa7a0_a0-ba5                                        "));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaamixed moaaaaaa", "boJretnirPC.xsocamnoitroproCnoitroproC elcrO nos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaamixed moaaaaaa" + "'", str2.equals("aaaaamixed moaaaaaa"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("SU", "             SOPHIE               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU" + "'", str2.equals("SU"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aa7a0_a0-ba5                                        ", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa7a0_a0-ba5                                        " + "'", str2.equals("aa7a0_a0-ba5                                        "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j44444444444444444444444444444/Library/Java/JavaVirtualMachines/j", "/LIB", 19);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) " HOTHPOT(U ) 64-IIT HERVER   AVA!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("    ", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "mixed mod" + "'", charSequence2.equals("mixed mod"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("###################################################", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################" + "'", str2.equals("###################################################"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Oracle CorporationOracle CorporationOracle CorprmAPIOracle CorporationOracle CorporationOracle Corpo", "O10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.8", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("           #           ", " Hothpot(U ) 64-iit herver   ava!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "oracleOracle Corporation Oracle CorporationCorporation", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "OracleCor-1.0JavaVirtualMachineSpecification", (java.lang.CharSequence) "                                                 on Orcle CorportionCorportion", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                /Library/Java/JavaVirtualMachines/j                                 ", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("              sophie               ", "aaa", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              sophie               aaa              sophie               " + "'", str3.equals("              sophie               aaa              sophie               "));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                    .", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                               US", "51.0", 48);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      51.0                    US" + "'", str3.equals("                      51.0                    US"));
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test440");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.3", "oracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specificationoracle cor -1.0 java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "HI ", (java.lang.CharSequence) "hiSopmixed mod", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("rmAPI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rmAPI" + "'", str1.equals("rmAPI"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, (long) 29, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "unxiwwnxJ.sxxCPCinnnCJ.baaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass java.io.Fileclass org.apache.commons.lang3.JavaVersionclass java.io.File");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test448");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str1 = javaVersion0.toString();
//        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
//        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("y/Java/Java", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "y/Jv/Jv" + "'", str2.equals("y/Jv/Jv"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "ORACLE CORORACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...", 53, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_95312_1560210292");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "10.14.3", 3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "oracle corporationoracle corporationoracle corprmapioracle corporationoracle corporationoracle corpo", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 78, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "e", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ORACLE CORORACLE CORPORATIO", "", "hI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORORACLE CORPORATIO" + "'", str3.equals("ORACLE CORORACLE CORPORATIO"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.", (java.lang.CharSequence) "! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SophiSophiSophiSophiSophiSophiSophiSophiSophiSophi", 48, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', 52, (int) (short) -1);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/ExtensiJava Platform API Specification/Users/sophie/Library/Java/Extensio", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                   44444444444444444444444444444                                    ", "             ...4444             ", "", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                   44444444444444444444444444444                                    " + "'", str4.equals("                                   44444444444444444444444444444                                    "));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi!SUHI!   HI! hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi..." + "'", str1.equals("! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi!suhi!   hi! hi..."));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("mixed mod", "son Orcle CorportionCorportionmacosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mod" + "'", str2.equals("mixed mod"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = javaVersion0.atLeast(javaVersion4);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str8 = javaVersion0.toString();
        java.lang.String str9 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.9" + "'", str9.equals("0.9"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444" + "'", str2.equals("444444444444444444"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 28, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.awt.CGraphicsEnviro", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("              sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie                             sophie               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("4.a", "................................/Librury/Juvu/JuvuVirtuulsunhines/j.................................");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        char[] charArray11 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/1.8", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "O", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "rmAPISpecification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/L", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophi");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Oracle Corporation", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 ", strArray2, strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "                                                                                                                   ", 73, (int) ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 " + "'", str9.equals("                                /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                                                 /Library/Java/JavaVirtualMachines/j                                 "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("              sophie               aaa              sophie               ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("SOPHIE##########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sOPHIE##########################" + "'", str1.equals("sOPHIE##########################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/j", (java.lang.CharSequence) "1.1", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray12 = new char[] { '#', '4', '#', '4', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::sophie", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.8", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, 5, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("o", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SU", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                   Oracle Cor");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("             SOPHIE               ", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             SOPHIE               " + "'", str2.equals("             SOPHIE               "));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;", 31, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;" + "'", str3.equals("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "                                         #######", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("          ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("rmAPI", (int) '#', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               rmAPI               " + "'", str3.equals("               rmAPI               "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "class o...", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                 on Orcle CorportionCorportion");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 78 + "'", int1 == 78);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "!ih", 29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "                   Oracle Cor");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("JAVA VIRTUAL MACHINE SPECIFICATION", "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("AVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }
}

