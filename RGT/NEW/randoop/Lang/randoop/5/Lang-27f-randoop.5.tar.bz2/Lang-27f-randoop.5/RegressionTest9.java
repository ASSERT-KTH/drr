import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test001");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test002");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("tents/Home/jr", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hipecific...!pecific...4444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hipecific...!pecific...4444444" + "'", str1.equals("hipecific...!pecific...4444444"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test004");
        long[] longArray3 = new long[] { (-1), 0, (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("      /uSERS/SOPHIE\n      ", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ORACLE# #CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPROC# #ELCARO" + "'", str1.equals("NOITAROPROC# #ELCARO"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "tents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test008");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) 1.0f, 0.15000000596046448d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("javatualac.n17cfcat.n", "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test011");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "#######################################################################################ts/Home/jr");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("JAVA VIRTUAL MACHINE SPECIFICATION", strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test013");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oracle Corporati/Users/sophi", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("sun.lwawt.macosx.LWCToolkit                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test015");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("noitroproC elcrO", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitroproC elcrO" + "'", str2.equals("noitroproC elcrO"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test017");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("http4444444444444444hi!4444444444444444//java.oracle.com/", "", (int) ' ', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444//java.oracle.com/" + "'", str4.equals("4444444//java.oracle.com/"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Java Vi!ih", "                                                                                                                                                                                                               ...eneneaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test019");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", "enenene...");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 1, (int) (byte) 0);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("javaVirtualMachineSpecification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaVirtualMachineSpecification/Users/sophie/Libr" + "'", str1.equals("javaVirtualMachineSpecification/Users/sophie/Libr"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", (int) (short) -1, "ahotsaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test023");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " hots", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test024");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("...", "/", "aaaaaaaaE Runtime Environmenttionen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "..." + "'", str4.equals("..."));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test025");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                             1#utf-8                                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1#utf-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", "TnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..." + "'", str2.equals("Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..."));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test027");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virttime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "enJava Virtual Machine Specification");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "java tual achn spcfcaton");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("TnninE itnuR ES )MT(J", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/java tual achn spcfcaton/java tual achn spcfcatondjava tual achn spcfcatons/_java tual achn spcfcaton/6java tual achn spcfcaton597zmjava tual achn spcfcaton4_java tual achn spcfcaton31java tual achn spcfcatonq2java tual achn spcfcaton2x1java tual achn spcfcaton4java tual achn spcfcaton0000gjava tual achn spcfcaton/T/" + "'", str5.equals("/java tual achn spcfcaton/java tual achn spcfcatondjava tual achn spcfcatons/_java tual achn spcfcaton/6java tual achn spcfcaton597zmjava tual achn spcfcaton4_java tual achn spcfcaton31java tual achn spcfcatonq2java tual achn spcfcaton2x1java tual achn spcfcaton4java tual achn spcfcaton0000gjava tual achn spcfcaton/T/"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/TnninE itnuR ES )MT(J/TnninE itnuR ES )MT(JdTnninE itnuR ES )MT(Js/_TnninE itnuR ES )MT(J/6TnninE itnuR ES )MT(J597zmTnninE itnuR ES )MT(J4_TnninE itnuR ES )MT(J31TnninE itnuR ES )MT(Jq2TnninE itnuR ES )MT(J2x1TnninE itnuR ES )MT(J4TnninE itnuR ES )MT(J0000gTnninE itnuR ES )MT(J/T/" + "'", str6.equals("/TnninE itnuR ES )MT(J/TnninE itnuR ES )MT(JdTnninE itnuR ES )MT(Js/_TnninE itnuR ES )MT(J/6TnninE itnuR ES )MT(J597zmTnninE itnuR ES )MT(J4_TnninE itnuR ES )MT(J31TnninE itnuR ES )MT(Jq2TnninE itnuR ES )MT(J2x1TnninE itnuR ES )MT(J4TnninE itnuR ES )MT(J0000gTnninE itnuR ES )MT(J/T/"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(" ", "OJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific... CorpJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test030");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("boJretnirPC.xsocam.twawl.nuS", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("http4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!44:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Chttp4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!444", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "boJretnirPC.xsocam.twawl.nuS" + "'", str4.equals("boJretnirPC.xsocam.twawl.nuS"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test031");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("javahotspot(tm)64-bitservervm", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test032");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("J", "                               ", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test034");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("US#", "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test035");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("HotSpot(TM) 6-Bit Server VM", "TnemnorivnE e...", 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test036");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS", "J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test037");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test039");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "1.7.0_80");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("R", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "R" + "'", str8.equals("R"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("tents/Home/jr", 278, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test041");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JAVA VIRTUAL MACHINE SPECIFICATION", "SUN.LWAWT.MACOSX.cpRINTEutf-", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test042");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test043");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 100L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test044");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Machine ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test045");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_9212_1560227300/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_9212_1560227300/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test046");
        char[] charArray12 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "X SO caM", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test047");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(34.0f, 0.0f, 31.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth-FTU:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth-FTU:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth" + "'", str1.equals("/:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth-FTU:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test049");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("#", "ava tual achn spcfcaton");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test050");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitacificepS IPA mroftalP avaJ", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test052");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.14.", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", "TUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test054");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwwt.mcosx.CPrinterJob                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("ORACLE# #CORPORATION", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE# #CORPORATION" + "'", str3.equals("ORACLE# #CORPORATION"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO", "US#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO" + "'", str2.equals("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test058");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 52, (long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test059");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 447);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("   sun.awt.CGraphicsEnvironment    ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   sun.awt.CGraphicsEnvironment    " + "'", str2.equals("   sun.awt.CGraphicsEnvironment    "));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test062");
        char[] charArray10 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("                                             1#UTF-8                                             ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "      /Users/sophie\n      ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("...vI...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...Iv..." + "'", str1.equals("...Iv..."));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("javaVirtualMachineSpecification/Users/sophie/Libr", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "44444444444444444444444444444444444444444441.7.0_8...44444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("HotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVM", "Java HotSpot(TM) 6 -Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("TUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tual machine specification" + "'", str1.equals("tual machine specification"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test069");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mixed mode", 46, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("javahotspot(tm)64-bitservervm", "O444444444444444444!tion         ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 3, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test072");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("jAVA pLATFORM api sPECIFICATION", "aaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJob", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("1.7.0_8...", "-FTU4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", (int) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nenenenenene" + "'", str3.equals("nenenenenene"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test076");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment                     ", " HotSpot(TM) 6-Bit Server VM", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444444444444444!4444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444!4444444444444444" + "'", str1.equals("444444444444444444!4444444444444444"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("R", "Java HotSpot(TM) 6 -Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R" + "'", str2.equals("R"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hots", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hots" + "'", str2.equals("hots"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("44444444444444444444444444444444444444444441.7.0_8...44444444444444444444444444444444444444444444", "http4444444444444444hi!4444444444444444//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test082");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("RACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test083");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("a Virtual Mach", "Orcle Corportion", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test084");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test085");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                                               UTF-8", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test086");
        char[] charArray14 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray14);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", charArray14);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray14);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray14);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth", charArray14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "://javOracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", charArray14);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Orcle Corportion", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test087");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("biL/eihpos/sresU/noitacificepS enihcaM lautriV ava", "", 5);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "biL/eihpos/sresU/noitacificepS enihcaM lautriV ava" + "'", str4.equals("biL/eihpos/sresU/noitacificepS enihcaM lautriV ava"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test088");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test089");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/ng00000f4n1x2n2q01", "...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("   sun.awt.CGraphicsEnvironment    ", 4, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.awt.CGraphicsEnvironment    " + "'", str3.equals("un.awt.CGraphicsEnvironment    "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test091");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("a", "Oracle70_0b5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test093");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenene...", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenene...", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("Java HotSpot(TM) 64-Bit Server VM", strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", 34, 28);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray4, strArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "hipecific...!pecific...4444444");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "enene..." + "'", str17.equals("enene..."));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " " + "'", str18.equals(" "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hipecific...!pecific...4444444hipecific...!pecific...4444444enene..." + "'", str20.equals("hipecific...!pecific...4444444hipecific...!pecific...4444444enene..."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle Corp", "RacEEL  ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("1a Virtual Machine5", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test095");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray9);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    sun.awt.CGraphicsEnvironment    ", 3, 92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str10.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test096");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 100, (short) 1, (byte) 1, (byte) -1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", "en");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop...", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                         O Corp                                                                                                          ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test099");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(":", "", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("sun.lwawt.macosx.CPrinterJob", strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":" + "'", str5.equals(":"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ":" + "'", str9.equals(":"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "JavaVirtualMachineSpecific...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test102");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test103");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hipecific...!pecific...4444444", 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad(" ", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            " + "'", str2.equals("                                                                                            "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwwt.mcosx.CPrinterJob                                                                         ", "SUN.LWAWT.MACOSX.CPRINTERJOB", "4HOTS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwwt.mcosx.CPrinterJob                                                                         " + "'", str3.equals("sun.lwwt.mcosx.CPrinterJob                                                                         "));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test106");
        char[] charArray11 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "enenene...", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("ts/Home/jr", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "4444444444444444hi!4444444444444444");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("O444444444444444444!tion         ", strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("java hotspot(tm) 64-bit server vm", "enenene...", "/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str3.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwwt.mcosx.CPrinterJob                                                                         ", 92, 278);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       " + "'", str3.equals("       "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test110");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sPECIFICATION mACHINE vIRTUAL JAVA", (long) 22);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 22L + "'", long2 == 22L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test112");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test113");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(184L, (long) 27, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 184L + "'", long3 == 184L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test114");
        char[] charArray3 = new char[] { 'a' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "java hotspo...", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HTTP://J#V#.OR#CLE.COM/1UTF-8HTTP:/", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("javahotspot(tm)64-bitservervm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javahotspot(tm)64-bitservervm" + "'", str1.equals("javahotspot(tm)64-bitservervm"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("SPECIFICATION MACHINE VIRTUAL JAVA", "rary/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SPECIFICATION MACHINE VIRTUAL JAVA" + "'", str2.equals("SPECIFICATION MACHINE VIRTUAL JAVA"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                          ...", "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or" + "'", str2.equals("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test118");
        short[] shortArray2 = new short[] { (short) 0, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test119");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test120");
        int[] intArray3 = new int[] { (byte) -1, 34, (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.Class<?> wildcardClass6 = intArray3.getClass();
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass8 = intArray3.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 34 + "'", int7 == 34);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test121");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ORACLEOracle CorporationCORPORATI/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr", "Java HotSpot(TM) 6-Bit Server VM");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("biL/eihpos/sresU/noitacificepS enihcaM lautriV ava", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "bLhhL/bUbnbc" + "'", str5.equals("bLhhL/bUbnbc"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test125");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                Oracle# #Corporation                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 14, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              " + "'", str3.equals("              "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test127");
        long[] longArray3 = new long[] { (-1), (short) 0, (short) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("hipecific...!pecifenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen", "aaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test130");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0L, (double) 137.0f, (double) 16);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 137.0d + "'", double3 == 137.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_8", "444444444444444444!444444...", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification" + "'", str1.equals("java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr", "HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test135");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test136");
        long[] longArray2 = new long[] { 28L, '#' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28L + "'", long4 == 28L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test137");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] { '4', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "java Virtual Machine Specification", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("...vI...", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("chines/jdk1.7....Javary/Ja/Libr", "...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7....Javary/Ja/Libr" + "'", str2.equals("chines/jdk1.7....Javary/Ja/Libr"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test139");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("1a Virtual Machine5", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie" + "'", str4.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie" + "'", str6.equals("/Users/sophie"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test141");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(184L, (long) 98, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("dk1.jdk/Contents/Home/jr", "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..." + "'", str2.equals("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunawCGaisEninn" + "'", str3.equals("sunawCGaisEninn"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "   sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_64", 28, "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nx86_64" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nx86_64"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test146");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray4, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny("HI!", strArray4);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str10.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie" + "'", str11.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test147");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", charSequence2.equals("TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "########/Users/sop/ng00000f4n1x2n2q01ments/defects4j/tmp/run_rndoop.pl_9212_1560227300/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr#######ts/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-4444444444444444444444444444444", "");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X SO caM");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "enene...");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Java Virtual Machine Specific...", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Xenene...SOenene...caM" + "'", str7.equals("Xenene...SOenene...caM"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                          boJretnirPC.xsocm.twwl.nus", "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO" + "'", str2.equals("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("enJava Virtual Machine Specification", "x86_64");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enJava Virtual Machine Specification" + "'", str3.equals("enJava Virtual Machine Specification"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virt", ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("444444444444444444!4444444444444444");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 13 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("jAVA vIRTUAL mACHINE sPECIFICATION", "XENENE...SOENENE...CAM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v" + "'", str1.equals("Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test157");
        char[] charArray9 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "biL/eihpos/sresU/noitacificepS enihcaM lautriV ava", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "dk1.7.0_80.jdk/Contents/Home/jr", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test158");
        short[] shortArray2 = new short[] { (short) 0, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test159");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sers", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Users/sophie", "java tual achn spcfcaton");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                                                        Sun.lwawt.macosx.CPrinterJob", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test162");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth-FTU:ptthvaj//:ptthvaj//:ptthvaj//:ptthvaj//:ptth", "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("AAAAAAUTF-JAVAVIRTUALMACHINESPE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaautf-javavirtualmachinespe" + "'", str1.equals("aaaaaautf-javavirtualmachinespe"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51." + "'", str2.equals("51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "achineSpecification", "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Oracle Corporati/Users/sophi", "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test168");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "tionachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavaj");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test170");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Ho...                ", "UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test171");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java(TM) SE Runtime Environment", "ual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test172");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test173");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray13 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "orporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test174");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("BOjRETNIRpc.XSOCAM.TWAWL.NUs", " HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test175");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray3, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "a Virtual Machine");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str9.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie" + "'", str10.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie" + "'", str11.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie" + "'", str13.equals("/Users/sophie"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test176");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_9212_1560227300/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test177");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 80.0f, (double) 8, (double) 8L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(":", "Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test179");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("java Virtual Machine Specification                                                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO " + "'", str2.equals("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test181");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("enenene...://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ava tual achn spcfcaton");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test183");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("OrJava(TM) SE Runtime EnvironmenJava Virtual Machine SpecificationOrJava(TM) SE Runtime Environme", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com", 92);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "                          sun.lwawt.macosx.LWCToolkit                                            ", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJob", "Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJob" + "'", str2.equals("1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJobaaaa1.7.0_8un.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("dk1.7.0_80.jdk/Contents/Home/jr", "JAVA#VIRTUAL#MACHINE#SPECIFICATION");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("SUN.LWAWT.MACOSX.CPRINTERJOB", "...");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test189");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.", "/uSERS/SOPHIE\n", "#CORPORATION", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51./USERS/...51./USERS/...51./USERS/...51./USERS/...51." + "'", str4.equals("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51."));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test190");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("enene...", "", "aaaaaaSun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "enene..." + "'", str4.equals("enene..."));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "8" + "'", str5.equals("8"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test192");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("X SO caM", "TnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("OracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporationOracleCorporation", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/java tual achn spcfcaton/java tual achn spcfcatondjava tual achn spcfcatons/_java tual achn spcfcaton/6java tual achn spcfcaton597zmjava tual achn spcfcaton4_java tual achn spcfcaton31java tual achn spcfcatonq2java tual achn spcfcaton2x1java tual achn spcfcaton4java tual achn spcfcaton0000gjava tual achn spcfcaton/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/java tual achn spcfcaton/java tual achn spcfcatondjava tual achn spcfcatons/_java tual achn spcfcaton/6java tual achn spcfcaton597zmjava tual achn spcfcaton4_java tual achn spcfcaton31java tual achn spcfcatonq2java tual achn spcfcaton2x1java tual achn spcfcaton4java tual achn spcfcaton0000gjava tual achn spcfcaton/T/" + "'", str1.equals("/java tual achn spcfcaton/java tual achn spcfcatondjava tual achn spcfcatons/_java tual achn spcfcaton/6java tual achn spcfcaton597zmjava tual achn spcfcaton4_java tual achn spcfcaton31java tual achn spcfcatonq2java tual achn spcfcaton2x1java tual achn spcfcaton4java tual achn spcfcaton0000gjava tual achn spcfcaton/T/"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test195");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }
}

