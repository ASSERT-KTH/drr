import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("s", "aaaaaaSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", "Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) 5, (double) 0.15f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.15000000596046448d + "'", double3 == 0.15000000596046448d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444...                          ...4444444444444444", 7, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444...                          ...4444444444444444" + "'", str3.equals("4444444444444444...                          ...4444444444444444"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", "en");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...", 18, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("UTF-4444444444444444444444444444444", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444" + "'", str2.equals("44444"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("O Corp", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O Corp" + "'", str2.equals("O Corp"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "##########", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                            java tual ac.n 17cfcat.n", "   ", (int) (byte) 100, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                               " + "'", str4.equals("                               "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java HotSpot(TM) 6 -Bit Server VM", "boJretnirPC.xsocam.twawl.nuS", "http://jav");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("444444444444444444!444444...", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(7, (-1), 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("4444444444444444...                          ...4444444444444444", "noitroproC elcrO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, 1.0f, 32.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":", '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sun.lwwt.mcosx.CPrinterJob");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("\n", "en");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.Class<?> wildcardClass10 = strArray8.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-4444444444444444444444444444444", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "\n" + "'", str9.equals("\n"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTF-4444444444444444444444444444444" + "'", str11.equals("UTF-4444444444444444444444444444444"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("enene...", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("boJretnirPC.xsocam.twawl.nuS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocam.twawl.nuS" + "'", str1.equals("boJretnirPC.xsocam.twawl.nuS"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java Platform API Specification", "1UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1a.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "://jav", 7, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "://jav" + "'", str4.equals("://jav"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "44444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../U...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../U..." + "'", str1.equals("Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../U..."));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", (int) ' ');
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo...", "1.7.0_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..." + "'", str2.equals("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..."));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIO" + "'", str1.equals("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIO"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 1, 170.0d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray5, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith("http://jav", (java.lang.Object[]) strArray5);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass17 = strArray16.getClass();
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.concatWith("en", (java.lang.Object[]) strArray16);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo...", strArray5, strArray16);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str11.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie" + "'", str12.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/Users/sophie" + "'", str18.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..." + "'", str19.equals("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..."));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Specific... Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Java", "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "hi!4444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-B15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "javatualac.n17cfcat.n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("javatualachnspcfcaton", "1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("x so CAm", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ".15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ts/Home/jr", "/Users/sophie", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jr" + "'", str3.equals("ts/Home/jr"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Virtual Machine Specific...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pecific..." + "'", str2.equals("pecific..."));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("http4444444444444444hi!4444444444444444//javavoraclevcom/", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http4444444444444444hi!4444444444444444//javavoraclevcom/" + "'", str2.equals("http4444444444444444hi!4444444444444444//javavoraclevcom/"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        float[] floatArray1 = new float[] { 100.0f };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOB", (java.lang.CharSequence) "enOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("hots", "      /Users/sophie\n      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java HotSpot(TM) 6-Bit Server VM", "RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(97.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                             1#UTF-8                                             ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja" + "'", str2.equals("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(21, 97, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie", "1.7.0_80-b15", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", strArray5, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie\n", strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4', (int) (byte) 100, 7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth" + "'", str11.equals("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaenene...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "4444444444444444hi!4444444444444444");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie" + "'", str7.equals("/Users/sophie"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "             enene...              ", "/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "  7 0_ 0 b 5" + "'", str4.equals("  7 0_ 0 b 5"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(".", (int) '4', 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "                                             1#UTF-8                                             ", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("JAVA vIRTUAL mACHINE sPECIFICATION", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA vIRTUAL mACHINE sPECIFICATION" + "'", str2.equals("JAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("tents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/HSUN.LWAWT.MACOSX.cpRINTERjOB", "444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("noitroproC elcrO", 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("enJava Virtual Machine Specification", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_9212_1560227300/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("X SO caM", "                                                                            java tual ac.n 17cfcat.n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("dk1.jdk/Contents/Home/jr", "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java HotSpot(TM) 6-Bit Server VM", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 6-Bit Server VM" + "'", str2.equals(" HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virt", "JAVA vIRTUAL mACHINE sPECIFICATION", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("a", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-FTU", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34L, (float) 4, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporati/Users/sophi", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", 217);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporati/Users/sophi" + "'", str4.equals("Oracle Corporati/Users/sophi"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/", (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0.15f, (double) (byte) 100, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hots");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(":", "", 100);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("Oracle Corporation         ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("TnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("E Runtime Environmenttionen", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, 100L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "  ://jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("10.14.3", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("java Virtual Machine Specification", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification" + "'", str2.equals("java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JAVA#VIRTUAL#MACHINE#SPECIFICATION", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) (short) 1, 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenene...", "mixed mode");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http4444444444444444hi!4444444444444444//java.oracle.com/", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "4444444444444444...                          ...4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        short[] shortArray3 = new short[] { (byte) 10, (byte) 0, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, (long) 1, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "HI!", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("          ", "JavaVirtualMachineSpecification", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV ava", "/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//", (int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//" + "'", str4.equals("rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("enene...", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", (int) (short) 1, "http://jav");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..." + "'", str3.equals("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..."));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("          ", "rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java#Virtual#Machine#Specification", "aaaaaaUTF-");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 27, (float) 18, (float) 170L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ORACLE CORPORATI/USERS/SOPHI", " ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ORACLEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCORPORATI/USERS/SOPHI" + "'", str4.equals("ORACLEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCORPORATI/USERS/SOPHI"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", " HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "JAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              " + "'", str2.equals("              "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UTF-8", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.7.0_80", "                                                                            java tual achn spcfcaton", "Oracle Corporati/Users/sophi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("Java HotSpot(TM) 64-Bit Server VM", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("4444444444444444...                          ...4444444444444444", "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " hots");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment", "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, 0.0d, (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Mac OS X", "ORACLEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCORPORATI/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "dk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dk1.7.0_80.jdk/Contents/Home/jr" + "'", str1.equals("dk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JavaVirtualMachineSpecification", (int) (byte) -1, "1#UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaVirtualMachineSpecification" + "'", str3.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", "1UTF-8", "java hotspo...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("   sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaa1.7.0_8un.lwawt.macosx.CPrinterJob", "US#", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaa1.7.0_8un.lwawt.macosx.CPrinterJob" + "'", str3.equals("aaaa1.7.0_8un.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC..." + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC..."));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("...                          ...", "ORACLEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCORPORATI/USERS/SOPHI", "                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                          ..." + "'", str3.equals("...                          ..."));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(32L, 0L, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("JAVA vIRTUAL mACHINE sPECIFICATION", "/Users/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "      /Users/sophie\n      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str1.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) (short) 10, (float) 4L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                            java tual achn spcfcaton");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                            JAVA TUAL ACHN SPCFCATON" + "'", str1.equals("                                                                            JAVA TUAL ACHN SPCFCATON"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Oracle Corporation         ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("tents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-FTU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF", "1a.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF" + "'", str2.equals("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray4, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.concatWith("javaVirtualMachineSpecification/Users/sophie/Libr", (java.lang.Object[]) strArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str10.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java Virtual Machine Specification" + "'", str12.equals("java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("...                          ...", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          ..." + "'", str2.equals("                          ..."));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java Virtual Machine Specification/Users/sophie/Libr", "51.");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                                    ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Orcle Corportion", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JavaVirtualMachineSpecification", "Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific...", (int) (short) 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JavaVirtualMachineSpecification" + "'", str5.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "                                                                            JAVA TUAL ACHN SPCFCATON", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaSun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS", "rbiL/eihpos/sresU/noitacificepS enihcaM lautriV ava");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("x so CAm", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x so CAm" + "'", str2.equals("x so CAm"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                ", "444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                " + "'", str2.equals("                                                                                "));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X SO caM", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("boJretnirPC.xsocam.twawl.nuS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BOjRETNIRpc.XSOCAM.TWAWL.NUs" + "'", str1.equals("BOjRETNIRpc.XSOCAM.TWAWL.NUs"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth" + "'", str1.equals("/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (double) 34L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenene...", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 3);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "enene..." + "'", str5.equals("enene..."));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "enene..." + "'", str6.equals("enene..."));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "mixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("!ih", " HotSpot(TM) 6-Bit Server VM", "hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                               UTF-8" + "'", str1.equals("                                                                                               UTF-8"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("SUN.LWAWT.MACOSX.cpRINTERjOB", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...", "E Runtime Environmenttionen", 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str4.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("s", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("##########", "   sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1), (float) 26, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle 1a.a7a.a0a_a80a-aba15ration", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle 1a.a7a.a0a_a80a-aba15ration" + "'", str2.equals("Oracle 1a.a7a.a0a_a80a-aba15ration"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("enenene...", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("Java HotSpot(TM) 64-Bit Server VM", strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny("                                                    ", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "enene..." + "'", str9.equals("enene..."));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("rary/", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("TTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444hi!4444444444444444", 217, "Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtua4444444444444444hi!4444444444444444" + "'", str3.equals("Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtua4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr" + "'", str2.equals("rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion", "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JavaVirtualMachineSpecification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("   sun.awt.CGraphicsEnvironment    ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "US#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        char[] charArray8 = new char[] { '4', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("Mac OS X", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " ", charArray8);
        java.lang.Class<?> wildcardClass13 = charArray8.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1UTF-8", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "      /Users/sophie\n      ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie\n", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie\n" + "'", str2.equals("/Users/sophie\n"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("E Runtime Environmenttionen", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaE Runtime Environmenttionen" + "'", str3.equals("aaaaaaaaE Runtime Environmenttionen"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Virtual Machine Specific...", "Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM", "E Runtime Environmenttionen");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("sun.lwwt.mcosx.CPrinterJob", "boJretnirPC.xsocam.twawl.nuS", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        char[] charArray12 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                               UTF-8", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 95 + "'", int19 == 95);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "             enene...              ", (java.lang.CharSequence) "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 278 + "'", int2 == 278);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...", (int) ' ', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific...", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie", "##########", "rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie" + "'", str3.equals("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaa1.7.0_8un.lwawt.macosx.CPrinterJob", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "hots");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hots" + "'", str2.equals("hots"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("java hotspo...", "", "biL/eihpos/sresU/noitacificepS enihcaM lautriV ava");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sophi", 21, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 4L, 80.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 80.0f + "'", float3 == 80.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444...                          ...4444444444444444", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("://java.oracle.com/", (int) (short) 0, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java Virtual Machine Specific...", "dk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specific..." + "'", str2.equals("Java Virtual Machine Specific..."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("  7 0_ 0 b 5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "70_0b5" + "'", str1.equals("70_0b5"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80-B15", "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("TUAL mACHINE sPECIFICATION", "Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TUAL mACHINE sPECIFICATION" + "'", str2.equals("TUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 6, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######" + "'", str3.equals("######"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("1a.", "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: !ih is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/...", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sers" + "'", str2.equals("sers"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Mac OS X", "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or", 34, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or" + "'", str3.equals("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        char[] charArray7 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "enJava Virtual Machine Specification", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("444444444444444444!", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444!" + "'", str2.equals("444444444444444444!"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-FTU");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"FTU\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http4444444444444444hi!4444444444444444//java.oracle.com/", "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("##########", "E Runtime Environmenttionen", 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "", "ts/Home/jr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(80.0f, (float) 18, (float) 80);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 80.0f + "'", float3 == 80.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "jAVA pLATFORM api sPECIFICATION", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/Users/sophie", "javaVirtualMachineSpecification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ts/Home/jr", 100, "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr" + "'", str3.equals("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Oracle Corporation         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("JAVA VIRTUAL MACHINE SPECIFICATION", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("sophie", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("JAVA#VIRTUAL#MACHINE#SPECIFICATION", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "java tual achn spcfcaton", "O Corp");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JR"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("#######################################################################################ts/Home/jr", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######################################################################################ts/Home/jr" + "'", str2.equals("#######################################################################################ts/Home/jr"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) '4', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle# #Corporation", "javaVirtualMachineSpecification/Users/sophie/Libr", 278);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("http4444444444444444hi!4444444444444444//javavoraclevcom/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja", 4, 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "av://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE:" + "'", str3.equals("av://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE:"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "...vI...", (int) (byte) 10, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "70_0b5", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a Virtual Machine ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a Virtual Machine" + "'", str1.equals("a Virtual Machine"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(278, 26, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", "en");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("dk1.7.0_80.jdk/Contents/Home/jr", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.7.0_8...", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("tents/Home/jr", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaa1.7.0_8un.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_8...", "JavaVirtualMachineSpecific...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("http4444444444444444hi!4444444444444444//javavoraclevcom/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle Corporation         ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("://jav", "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaa1.7.0_8un.lwawt.macosx.CPrinterJob", "rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("http://jav", "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hine Specification" + "'", str2.equals("hine Specification"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Specific... Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Java", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", 10, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poration" + "'", str3.equals("poration"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "rbiLreihphL/rrbrUbnoitatirbcipS t iitieppppprtrr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("OracleCorporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300OracleCorporati", 8, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7.0_80-b15");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 278, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a.a7a.a0a_a80a-aba15" + "'", str3.equals("1a.a7a.a0a_a80a-aba15"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV ava", (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment    " + "'", str1.equals("sun.awt.CGraphicsEnvironment    "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1, (double) 137, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                          ...", "java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("en", "Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV ava", "Oracle# #Corporation", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corporation         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth" + "'", str1.equals("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaSun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "java#virtual#machine#specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "javatualachnspcfcaton", (java.lang.CharSequence) "rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 137, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Orcle Corportion", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("ual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..." + "'", str2.equals("ual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..."));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("javaVirtualMachineSpecification/Users/sophie/Libr", ":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "javaVirtualMachineSpecification/Users/sophie/Libr" + "'", str3.equals("javaVirtualMachineSpecification/Users/sophie/Libr"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "javaVirtualMachineSpecification/Users/sophie/Libr" + "'", str4.equals("javaVirtualMachineSpecification/Users/sophie/Libr"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "                                                                            java tual ac.n 17cfcat.n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaSun.lwawt.macosx.CPrinterJob", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("444444444444444444!", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.", "Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../U...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("70_0b5", 35, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        char[] charArray8 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!4444444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "pecific...");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!4444444" + "'", str2.equals("hi!4444444"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hipecific...!pecific...4444444" + "'", str4.equals("hipecific...!pecific...4444444"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "biL/eihpos/sresU/noitacificepS enihcaM lautriV ava");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...", "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", "##########", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("tents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/HSUN.LWAWT.MACOSX.cpRINTERjOB", "Oracle Corporation         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle 1a.a7a.a0a_a80a-aba15ration", "Oracle# #Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Java HotSpot(TM) 64-Bit Server VM", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaUTF-", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.14.3", "-FTU", 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//", "RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "tents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/HSUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "OJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific... CorpJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific...", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "...                          ...");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Oracle Corporation         ", "                                                                        Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        Sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("                                                                        Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("JavaVirtualMachineSpecific...", "OrJava(TM) SE Runtime EnvironmenJava Virtual Machine SpecificationOrJava(TM) SE Runtime Environme");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("javatualac.n17cfcat.n");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("pecific...", "Oracle 1a.a7a.a0a_a80a-aba15ration");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pecific..." + "'", str2.equals("pecific..."));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Oracle 1a.a7a.a0a_a80a-aba15ration", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle 1a.a7a.a0a_a80a-aba15ration" + "'", str2.equals("Oracle 1a.a7a.a0a_a80a-aba15ration"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!4444444", "1.7.0_80-b15", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("  7 0_ 0 b 5", "sophie", "aaaa1.7.0_8un.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  7 0_ 0 b 5" + "'", str3.equals("  7 0_ 0 b 5"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("TUAL mACHINE sPECIFICATION", "", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "RACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 184 + "'", int1 == 184);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        float[] floatArray3 = new float[] { 0L, 1, (-1) };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", "aaaaaaaaE Runtime Environmenttionen", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 35, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "aaaaaaSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle# #Corporation", 170, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle# #Corporation" + "'", str3.equals("Oracle# #Corporation"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("BOjRETNIRpc.XSOCAM.TWAWL.NUs", "sun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...", "1.7.0_80-B15", "://jav");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "E Runtime Environmenttionen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 217, "http4444444444444444hi!4444444444444444//javavoraclevcom/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!44:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Chttp4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!444" + "'", str3.equals("http4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!44:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Chttp4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!444"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "UTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..." + "'", str2.equals("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..."));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                                                                               UTF-8", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "http4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!44:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Chttp4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("dk1.7.0_80.jdk/Contents/Home/jr", 278);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JAVA#VIRTUAL#MACHINE#SPECIFICATION", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                   ", "51.0");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1#UTF-8", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-FTU", 5, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-FTU4" + "'", str3.equals("-FTU4"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x so CAm", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...", "4444444444444444hi!4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("   sun.awt.CGraphicsEnvironment    ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        char[] charArray10 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java#Virtual#Machine#Specification", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "://javOracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation         ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("tents/Home/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rj/emoH/stnet" + "'", str1.equals("rj/emoH/stnet"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "sun.lwwt.mcosx.CPrinterJob");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.CPrinterJob", 6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("javaVirtualMachineSpecification/Users/sophie/Libr", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaVirtualMachineSpecification/Users/sophie/Libr" + "'", str2.equals("javaVirtualMachineSpecification/Users/sophie/Libr"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java HotSpot(TM) 64-Bit Server VM", "UTF-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("http4444444444444444hi!4444444444444444//javavoraclevcom/", "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", "", 80);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http4444444444444444hi!4444444444444444//javavoraclevcom/" + "'", str4.equals("http4444444444444444hi!4444444444444444//javavoraclevcom/"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4, (long) 8, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                          ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Mac OS X", "OrJava(TM) SE Runtime EnvironmenJava Virtual Machine SpecificationOrJava(TM) SE Runtime Environme");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 0, (int) (short) -1, 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 95 + "'", int3 == 95);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                             1#UTF-8                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                             1#utf-8                                             " + "'", str1.equals("                                             1#utf-8                                             "));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_", 28);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("  7 0_ 0 b 5");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("java Virtual Machine Specification/Users/sophie/Libr", "dk1.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("   sun.awt.CGraphicsEnvironment    ", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("en", (java.lang.Object[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny("JAVA#VIRTUAL#MACHINE#SPECIFICATION", strArray13);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               UTF-8", "en");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray13, strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                        Sun.lwawt.macosx.CPrinterJob", strArray5, strArray17);
        java.lang.String[] strArray20 = null;
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("BOjRETNIRpc.XSOCAM.TWAWL.NUs", strArray17, strArray20);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie" + "'", str7.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie" + "'", str8.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "                                                                        Sun.lwawt.macosx.CPrinterJob" + "'", str19.equals("                                                                        Sun.lwawt.macosx.CPrinterJob"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BOjRETNIRpc.XSOCAM.TWAWL.NUs" + "'", str21.equals("BOjRETNIRpc.XSOCAM.TWAWL.NUs"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java HotSpot(TM) 6-Bit Server VM", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("://jav");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, " ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "://jav" + "'", str3.equals("://jav"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "://jav" + "'", str4.equals("://jav"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str1.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        char[] charArray7 = new char[] { '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("Mac OS X", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "java tual achn spcfcaton", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("!ih", " hots");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " hots" + "'", str2.equals(" hots"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("rj/emoH/stnet", 46, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("java Virtual Machine Specification", 95, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Virtual Machine Specification                                                             " + "'", str3.equals("java Virtual Machine Specification                                                             "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "TnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("pecific...", 46, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java tual achn spcfcaton", (double) 95);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 95.0d + "'", double2 == 95.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1UTF-8");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("http://jav", strArray4, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("java tual achn spcfcaton", (java.lang.Object[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "http://jav" + "'", str8.equals("http://jav"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1UTF-8" + "'", str9.equals("1UTF-8"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                          ...", "TUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          ..." + "'", str2.equals("                          ..."));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A" + "'", str1.equals("A"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle# #Corporation", (int) (byte) -1, "av://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle# #Corporation" + "'", str3.equals("Oracle# #Corporation"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 21, 170.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 170.0f + "'", float3 == 170.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http4444444444444444hi!4444444444444444//javavoraclevcom/", "", 21);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http4444444444444444hi!4444444444444444//javavoraclevcom/" + "'", str5.equals("http4444444444444444hi!4444444444444444//javavoraclevcom/"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("TENTS/hOME/JR", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "R" + "'", str2.equals("R"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//", "                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Oracle Corporation         ", "444444444444444444!", 14, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "O444444444444444444!tion         " + "'", str4.equals("O444444444444444444!tion         "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("://java.oracle.com/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "tents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#######################################################################################ts/Home/jr", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################################################################################ts/Home/jr" + "'", str3.equals("#######################################################################################ts/Home/jr"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", "aaaaaaUTF-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..." + "'", str2.equals("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..."));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "dk1.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtua4444444444444444hi!4444444444444444", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtua4444444444444444hi!4444444444444444" + "'", str3.equals("Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtua4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("enOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("a Virtual Machine", "51.0", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "javatualachnspcfcaton", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(31, 0, 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 95 + "'", int3 == 95);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("      /Users/sophie\n      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        long[] longArray3 = new long[] { (-1), 0, (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ORACLEOracle CorporationCORPORATI/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEOracle CorporationCORPORATI/USERS/SOPHI" + "'", str1.equals("ORACLEOracle CorporationCORPORATI/USERS/SOPHI"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("tents/Home/j", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 8, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("TnemnorivnE emitnuR ES )MT(avaJ", "://java.oracle.com/", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TnninE itnuR ES )MT(J" + "'", str3.equals("TnninE itnuR ES )MT(J"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1a.a7a.a0a_a80a-aba15", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a.a7a.a0a_a80a-aba15" + "'", str2.equals("1a.a7a.a0a_a80a-aba15"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "O444444444444444444!tion         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", 'a');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("JAVA#VIRTUAL#MACHINE#SPECIFICATION", strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               UTF-8", "en");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("tnemnorivnE emitnuR ES )MT(avaJ", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HotSpot(TM) 6-Bit Server VM" + "'", str1.equals("HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Orcle Corportion", (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mixed modemixed modemixed modemixed modemixed mode", "Java Virtual Machine Specific...", "http4444444444444444hi!4444444444444444//javavoraclevcom/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...                          ...", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("enOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen" + "'", str2.equals("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Mac OS X", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("sun.lwwt.mcosx.CPrinterJob", "/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwwt.mcosx.CPrinterJob" + "'", str3.equals("sun.lwwt.mcosx.CPrinterJob"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "jAVA vIRTUAL mACHINE sPECIFICATION", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("US", "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("TnninE itnuR ES )MT(J", (long) 184);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 184L + "'", long2 == 184L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specification/Users/sophie/Lib" + "'", str1.equals("java Virtual Machine Specification/Users/sophie/Lib"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 46, 28L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("4444444444444444hi!4444444444444444", "Orcle Corportion");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(".", "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java hotspot(tm) 64-bit server vm", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                        Sun.lwawt.macosx.CPrinterJob", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                        Sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("                                                                        Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("O444444444444444444!tion         ", "poration");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O444444444444444444!tion         " + "'", str2.equals("O444444444444444444!tion         "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob", "/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...", "rary/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("TUAL mACHINE sPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("JAVA VIRTUAL MACHINE SPECIFICATION", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("java hotspot(tm) 64-bit server vm", 34, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION" + "'", str2.equals("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("70_0b5", 27, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                   ", "UTF-8", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hots");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hots" + "'", str1.equals("hots"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("poration");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "poration" + "'", str1.equals("poration"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("enenene...", "://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", 97, 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "enenene...://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati" + "'", str4.equals("enenene...://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("A");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("dk1.7.0_80.jdk/Contents/Home/jr", 34, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", 8);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("dk1.jdk/Contents/Home/jr", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("rj/emoH/stnet", 80, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("://jav", "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://jav" + "'", str2.equals("://jav"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("jAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", "######");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA vIRTUAL mACHINE sPECIFICATION" + "'", str1.equals("jAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        short[] shortArray3 = new short[] { (byte) 10, (byte) 0, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle# #Corporation", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("://java.oracle.com/", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://java.oracle.com/" + "'", str2.equals("://java.oracle.com/"));
    }
}

