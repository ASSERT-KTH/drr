import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("mixed mode", "Java(TM) SE Runtime Environment", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih" + "'", str1.equals("!ih"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("http://jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://jav" + "'", str1.equals("http://jav"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java HotSpot(TM) 6 -Bit Server VM", (int) ' ', "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 6 -Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 6 -Bit Server VM"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java HotSpot(TM) 6 -Bit Server VM");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444444444444444444!4444444444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("HI!", "51.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b15", 1, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_8..." + "'", str3.equals("1.7.0_8..."));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JavaVirtualMachineSpecification", (int) 'a', 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray3, strArray8);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str9.equals("4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specification", (int) (short) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "1.7.0_80-b15", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "enenene...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "java Virtual Machine Specification/Users/sophie/Libr", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth" + "'", str2.equals("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sun.lwawt.macosx.CPrinterJob", (int) (short) 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                        Sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("                                                                        Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwwt.mcosx.CPrinterJob", (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.OS_VERSION;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "10.14.3" + "'", str0.equals("10.14.3"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("java Virtual Machine Specification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Virtual Machine Specification" + "'", str2.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.EMPTY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Virtual Machine Specification", (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specific..." + "'", str3.equals("Java Virtual Machine Specific..."));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4444444444444444hi!4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7.0_80-b15", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', 0.0d, (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1a.a7a.a0a_a80a-aba15");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1UTF-8", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1UTF-8" + "'", str2.equals("1UTF-8"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java HotSpot(TM) 6 -Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JavaVirtualMachineSpecification", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironment", "java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("1.7.0_8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironment", "Java HotSpot(TM) 6 -Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("SUN.LWAWT.MACOSX.cpRINTERjOB", "4444444444444444hi!4444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob", (int) (byte) 100, "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or" + "'", str3.equals("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("java#Virtual#Machine#Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java HotSpot(TM) 6-Bit Server VM", "UTF-8", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("java#Virtual#Machine#Specification", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.Object[] objArray3 = new java.lang.Object[] { (short) 1, "UTF-8" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("", objArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(objArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concat(objArray3);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1UTF-8" + "'", str4.equals("1UTF-8"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1UTF-8" + "'", str5.equals("1UTF-8"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1#UTF-8" + "'", str7.equals("1#UTF-8"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1UTF-8" + "'", str8.equals("1UTF-8"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "sun.lwwt.mcosx.CPrinterJob");
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray6, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass12 = strArray11.getClass();
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.Class<?> wildcardClass14 = strArray13.getClass();
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("java Virtual Machine Specification", strArray6, strArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", "Java(TM) SE Runtime Environment", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, 10.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac OS X", (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophie", "mixed mode", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_HOME;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                                               UTF-8", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":", (-1), 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_8...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8..." + "'", str2.equals("1.7.0_8..."));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("en", "Mac OS X", ":");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("\n", "sun.awt.CGraphicsEnvironment", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n" + "'", str3.equals("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str3.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("24.80-b11", "", "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("\n", "4444444444444444hi!4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str2.equals("4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(21, 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.", "444444444444444444!4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51." + "'", str2.equals("51."));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_98;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 10, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "java#Virtual#Machine#Specification", "enene...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("enenene...", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (-1L), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("X SO caM", "1a.a7a.a0a_a80a-aba15", "http://jav");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caM" + "'", str3.equals("X SO caM"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("1.7.0_8", "1.7.0_80-b15", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".15" + "'", str1.equals(".15"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a.a7a.a0a_a80a-aba15", (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", 18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("mixed mode", "enJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n", "enJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sophie", "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus" + "'", str1.equals("ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10L, (double) 'a', (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long[] longArray3 = new long[] { (-1), 0, (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, 35.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1a.a7a.a0a_a80a-aba15", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a.a7a.a0a_a80a-aba15" + "'", str2.equals("1a.a7a.a0a_a80a-aba15"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, (double) 1, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        char[] charArray4 = new char[] { '4', '4', '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str1.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) '#', 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_ME;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_NT;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.7.0_80", "java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("US", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj" + "'", str1.equals("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                        Sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_8...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_8...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "4444444444444444hi!4444444444444444");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444hi!4444444444444444", strArray4, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str10.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specific...", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specific..." + "'", str3.equals("Java Virtual Machine Specific..."));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":", (int) '4', "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C" + "'", str3.equals(":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "Java HotSpot(TM) 6-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_SOLARIS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification", (int) (short) 1, "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//" + "'", str3.equals("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("http://jav");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java#virtual#machine#specification" + "'", str1.equals("java#virtual#machine#specification"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1UTF-8", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1UTF-8" + "'", str2.equals("1UTF-8"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("sun.awt.CGraphicsEnvironment", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(32.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Sun.lwawt.macosx.CPrinterJob", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("JavaVirtualMachineSpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("java#virtual#machine#specification", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", "enene...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                               UTF-8", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "JavaVirtualMachineSpecification", "1a.a7a.a0a_a80a-aba15");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_8", (int) (short) 1, "Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_8" + "'", str3.equals("1.7.0_8"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 34, (long) 8, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("UTF-8", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("SUN.LWAWT.MACOSX.cpRINTERjOB");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("http://jav", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://jav" + "'", str2.equals("://jav"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(":", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("enenene...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenene..." + "'", str1.equals("enenene..."));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", ":", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specific...", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..." + "'", str2.equals("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific..."));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, 0L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..." + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "!ih", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", "java Virtual Machine Specification/Users/sophie/Libr", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str2.equals(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//", "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("java#Virtual#Machine#Specification", "enenene...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java#Virtual#Machine#Specification" + "'", str2.equals("java#Virtual#Machine#Specification"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".15");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.CPrinterJob", (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("http://jav", (-1), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("X SO caM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X SO caM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1#UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("http4444444444444444hi!4444444444444444//java.oracle.com/", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("!ih");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8" + "'", str1.equals("1.7.0_8"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 35, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.7.0_80.jdk/Contents/Home/jr" + "'", str3.equals("dk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("enenene...", 170, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("http://jav", "/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) ":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, (double) 1, (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7000000476837158d + "'", double3 == 1.7000000476837158d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("enene...", (int) (byte) -1, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enene..." + "'", str3.equals("enene..."));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                                                        Sun.lwawt.macosx.CPrinterJob", "Java HotSpot(TM) 64-Bit Server VM", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment                     " + "'", str2.equals("Java(TM) SE Runtime Environment                     "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("enJava Virtual Machine Specification", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enJava Virtual Machine Specification" + "'", str2.equals("enJava Virtual Machine Specification"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_8...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_8...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 8, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sun.lwawt.macosx.CPrinterJob", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "                                                                        Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specific...", "Oracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "enJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment                     ", (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Sun.lwawt.macosx.CPrinterJob", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JavaVirtualMachineSpecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", "enene...", "sun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("java#virtual#machine#specification", "java#Virtual#Machine#Specification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java#virtual#machine#specification" + "'", str3.equals("java#virtual#machine#specification"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("444444444444444444!4444444444444444", "Java(TM) SE Runtime Environment                     ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                        Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java(TM) SE Runtime Environment", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "java#Virtual#Machine#Specification", (java.lang.CharSequence) "444444444444444444!4444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "java#Virtual#Machine#Specification" + "'", charSequence2.equals("java#Virtual#Machine#Specification"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("http://jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://jav" + "'", str1.equals("http://jav"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "x86_64", "/Users/sophie");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("java#Virtual#Machine#Specification", 1, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java#Virtual#Machine#Specification" + "'", str3.equals("java#Virtual#Machine#Specification"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(":", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(10.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("!ih", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lwwt.mcosx.CPrinterJob", "", "java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("1.7.0_80-b15", ":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("51.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51." + "'", str1.equals("51."));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444hi!4444444444444444", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray3, strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str10.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str12.equals("4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("dk1.7.0_80.jdk/Contents/Home/jr", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tents/Home/jr" + "'", str2.equals("tents/Home/jr"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwwt.mcosx.CPrinterJob", 0, "ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwwt.mcosx.CPrinterJob" + "'", str3.equals("sun.lwwt.mcosx.CPrinterJob"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.concat(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("tents/Home/jr", "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80", "mixed mode");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "http://jav", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("UTF-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("tents/Home/jr", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.7.0_8...", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.7.0_8..." + "'", charSequence2.equals("1.7.0_8..."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "                                                                        Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("java hotspot(tm) 64-bit server vm", (int) (byte) -1, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java hotspo..." + "'", str3.equals("java hotspo..."));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Platform API Specification", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (short) 100, "://jav");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja" + "'", str3.equals("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                                                        Sun.lwawt.macosx.CPrinterJob", "51.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mixed mode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sophie", "1a.a7a.a0a_a80a-aba15", "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Java(TM) SE Runtime Environment", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specification", "Java HotSpot(TM) 64-Bit Server VM", "java hotspo...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java tual achn spcfcaton" + "'", str3.equals("java tual achn spcfcaton"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("://jav", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ://jav" + "'", str2.equals("  ://jav"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("24.80-b11", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("java#virtual#machine#specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: java#virtual#machine#specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.LWCToolkit", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("enene...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enene..." + "'", str1.equals("enene..."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444444444444444444!4444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444!4444444444444444" + "'", str1.equals("444444444444444444!4444444444444444"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF" + "'", str2.equals("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "enene...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("UTF-", 100, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, 10.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(".15", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".15" + "'", str2.equals(".15"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie" + "'", str2.equals("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF", "sun.awt.CGraphicsEnvironment", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF" + "'", str3.equals("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("enenene...", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenene..." + "'", str2.equals("enenene..."));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SUN.LWAWT.MACOSX.cpRINTERjOB", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java HotSpot(TM) 64-Bit Server VM", (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JavaVirtualMachineSpecification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("!ih", "  ://jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", "4444444444444444hi!4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', 97L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!", (int) (short) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!4444444" + "'", str3.equals("hi!4444444"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja", "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "1a.a7a.a0a_a80a-aba15");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironment", (int) (byte) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Java(TM) SE Runtime Environment                     ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed mode", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "mixed mode", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 8, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj", "Java(TM) SE Runtime Environment                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj" + "'", str2.equals("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_" + "'", str1.equals("1.7.0_"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", "Oracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("http4444444444444444hi!4444444444444444//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http4444444444444444hi!4444444444444444//java.oracle.com/" + "'", str1.equals("http4444444444444444hi!4444444444444444//java.oracle.com/"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment                     ", 8, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment                     " + "'", str3.equals("Java(TM) SE Runtime Environment                     "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("4444444444444444hi!4444444444444444", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", charSequence2.equals("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 100, (float) 1L, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, "UTF-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("tents/Home/jr", 3, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ts/Home/jr" + "'", str3.equals("ts/Home/jr"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(".15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/..." + "'", str2.equals("/Users/..."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("X SO caM", "enJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444444444444hi!4444444444444444", ".15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str2.equals("4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http4444444444444444hi!4444444444444444//java.oracle.com/", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sun.lwawt.macosx.CPrinterJob", 34, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaSun.lwawt.macosx.CPrinterJob" + "'", str3.equals("aaaaaaSun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("UTF-8", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Sun.lwawt.macosx.CPrinterJob", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str1.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("444444444444444444!4444444444444444", (int) (short) 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444!444444..." + "'", str3.equals("444444444444444444!444444..."));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", "                                                                        Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("HI!", (float) 21);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie", "Java HotSpot(TM) 6 -Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java HotSpot(TM) 6 -Bit Server VM", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("  ://jav", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ://jav" + "'", str2.equals("  ://jav"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("tents/Home/jr", (int) (byte) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tents/Home/jr" + "'", str3.equals("tents/Home/jr"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", "tents/Home/jr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 8, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophie", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                               UTF-8", "", "Java HotSpot(TM) 6 -Bit Server VM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '4', (double) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Sun.lwawt.macosx.CPrinterJob", "sun.lwawt.macosx.CPrinterJob", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) ' ', (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("tnemnorivnE emitnuR ES )MT(avaJ", "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth", "sun.awt.CGraphicsEnvironment", "JavaVirtualMachineSpecification", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth" + "'", str4.equals("/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("enene...", "                                                                        Sun.lwawt.macosx.CPrinterJob", 137);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.FILE_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/" + "'", str0.equals("/"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Oracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", "X SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("1.7.0_", "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Oracle Corporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporati/Users/sophi" + "'", str2.equals("Oracle Corporati/Users/sophi"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java HotSpot(TM) 6 -Bit Server VM", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 10L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sun.lwawt.macosx.CPrinterJob", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaSun.lwawt.macosx.CPrinterJob", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaSun.lwawt.macosx.CPrinterJob" + "'", str2.equals("aaaaaaSun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http4444444444444444hi!4444444444444444//java.oracle.com/", "1a.a7a.a0a_a80a-aba15", "Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http4444444444444444hi!4444444444444444//javavoraclevcom/" + "'", str3.equals("http4444444444444444hi!4444444444444444//javavoraclevcom/"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja", "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja" + "'", str2.equals("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("tents/Home/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tents/Home/j" + "'", str1.equals("tents/Home/j"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("enJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enJava Virtual Machine Specification" + "'", str1.equals("enJava Virtual Machine Specification"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj", "java#virtual#machine#specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj" + "'", str2.equals("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("http://jav", "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptthboJretnirPC.xsocam.twawl.nus", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("X SO caM", "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("444444444444444444!444444...", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-", 28, "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinteUTF-" + "'", str3.equals("sun.lwawt.macosx.CPrinteUTF-"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java HotSpot(TM) 6-Bit Server VM", (java.lang.CharSequence) "Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 137, 1.0d, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 137.0d + "'", double3 == 137.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("java Virtual Machine Specification/Users/sophie/Libr", "                                                                                               UTF-8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed mode", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(":/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja" + "'", str2.equals("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1a.a7a.a0a_a80a-aba15", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a.a7a.a0a_a80a-aba15" + "'", str2.equals("1a.a7a.a0a_a80a-aba15"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("tents/Home/j", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tents/Home/j" + "'", str2.equals("tents/Home/j"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//" + "'", str1.equals("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", 137);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("://jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ://jav is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java HotSpot(TM) 6 -Bit Server VM", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.3", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("java tual achn spcfcaton", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("4444444444444444hi!4444444444444444", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_8...", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) 170, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 170L + "'", long3 == 170L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(".15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specification/Users/sophie/Libr" + "'", str1.equals("java Virtual Machine Specification/Users/sophie/Libr"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                        Sun.lwawt.macosx.CPrinterJob", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/...", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/..." + "'", str2.equals("/Users/..."));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("  ://jav", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ://jav" + "'", str2.equals("  ://jav"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("://jav", "java tual achn spcfcaton");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://jav" + "'", str2.equals("://jav"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444444444444444444!444444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444!444444..." + "'", str1.equals("444444444444444444!444444..."));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpot(TM) 6 -Bit Server VM", "/Users/sophie", "/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("java Virtual Machine Specification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaVirtualMachineSpecification/Users/sophie/Libr" + "'", str1.equals("javaVirtualMachineSpecification/Users/sophie/Libr"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".15", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", str3.equals("Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("java#virtual#machine#specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA#VIRTUAL#MACHINE#SPECIFICATION" + "'", str1.equals("JAVA#VIRTUAL#MACHINE#SPECIFICATION"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("http4444444444444444hi!4444444444444444//javavoraclevcom/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: http4444444444444444hi!4444444444444444//javavoraclevcom/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4444444444444444hi!4444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8" + "'", str1.equals("1.7.0_8"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                        Sun.lwawt.macosx.CPrinterJob", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                        Sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("                                                                        Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1UTF-8", "ts/Home/jr", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1UTF-8" + "'", str3.equals("1UTF-8"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10.14.3");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "enenene...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "  ://jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "JAVA#VIRTUAL#MACHINE#SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Virtual Machine Specific...", "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("HI!", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!" + "'", str4.equals("HI!"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1a.a7a.a0a_a80a-aba15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

