import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("mixed modemixed modemixed modemixed modemixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed modemixed modemixed modemixed modemixed mode\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        double[] doubleArray5 = new double[] { (byte) 0, 18, (short) 100, (short) 1, (short) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("444444444444444444!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("JAVA#VIRTUAL#MACHINE#SPECIFIC...", "aaaaaaaaE Runtime Environmenttionen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA#VIRTUAL#MACHINE#SPECIFIC..." + "'", str2.equals("JAVA#VIRTUAL#MACHINE#SPECIFIC..."));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Xenene...SOenene...caM", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM" + "'", str2.equals("Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.", "", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("      /uSERS/SOPHIE\n      ", "Java(TM) SE Runtime Environment                     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 95, 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 95 + "'", int3 == 95);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".com/" + "'", str2.equals(".com/"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", '4');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.Class<?> wildcardClass6 = strArray5.getClass();
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                               ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.awt.CGraphicsEnvironment    ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", ":", 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr                                     ", (int) (short) 0, "UTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr                                     " + "'", str3.equals("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr                                     "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        short[] shortArray3 = new short[] { (byte) 1, (byte) 100, (byte) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "OracleCorporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300OracleCorporati", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        long[] longArray3 = new long[] { (-1), 0, (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwwt.mcosx.CPrinterJob                                                                          Sun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JAVA vIRTUAL mACHINE sPECIFICATION                                                             ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaE Runtime Environmenttionen", 1800, "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaE Runtime Environmenttionen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     " + "'", str3.equals("aaaaaaaaE Runtime Environmenttionen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("OracleCorporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300OracleCorporati", "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit                 ", 2300);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         "));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("             enene...              ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("                                                                          boJretnirPC.xsocm.twwl.nus", "Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java HotSpot(TM) 6 -Bit Server VM", "44444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 6 -Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 6 -Bit Server VM"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 52, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" hots", "enOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Java(TM) SE Runtime Environment", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("hi!", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "rary/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle Corp");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-", "mixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-" + "'", str2.equals("UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1a.", "Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a." + "'", str2.equals("1a."));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 94, (long) 100, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        char[] charArray9 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "enenene...", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("1.7.0_80-b15", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) (byte) 10, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                        1.7.0_80-B15", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) 92, (float) 16);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 92.0f + "'", float3 == 92.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444444444444444444!444444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444!444444..." + "'", str1.equals("444444444444444444!444444..."));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str1.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("HI!", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("poration", "pecific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("x86_64", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/", (int) (byte) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://j#v#.or#cle.com/1UTF-8http:/" + "'", str3.equals("http://j#v#.or#cle.com/1UTF-8http:/"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                          ...", "rj/emoH/stnet");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          ..." + "'", str2.equals("                          ..."));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("sun/Users/..../Users/...lwawt/Users/..../Users/...macosx/Users/..../Users/...CP/Users/...rinter/Users/...J/Users/...obhttp/Users/...:///Users/...java/Users/..../Users/...oracle/Users/..../Users/...com/Users/...//Users/...1/Users/...UTF/Users/...-/Users/...8/Users/...http/Users/...:///Users/...java/Users/..../Users/...oracle/Users/..../Users/...com/Users/...//Users/...1/Users/...UTF/Users/...-/Users/...8/Users/...http/Users/...:///Users/...java/Users/..../Users/...or", "4444444444444444...                          ...4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(75);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 27, (long) 3, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Oracle 1a.a7a.a0a_a80a-aba15ration", "...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("A", 137, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sophi", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophi" + "'", str3.equals("sophi"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(".com/", "noitacificepS IPA mroftalP avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("://jav", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("TnemnorivnE emitnuR ES )MT(avaJ", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TnemnorivnE e..." + "'", str2.equals("TnemnorivnE e..."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "biL/eihpos/sresU/noitcificepS enihcM lutriV v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!ih", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih" + "'", str3.equals("!ih"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr" + "'", str1.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Hipecific...!pecific...4444444", "r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hipecific...!pecific...4444444" + "'", str2.equals("Hipecific...!pecific...4444444"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "avaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("java Virtual Machine Specification                                                             ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) 92, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("avaVirtualMachineSpecification", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr", 5, 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("US#", "#######################################################################################ts/Home/jr", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US#" + "'", str3.equals("US#"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        char[] charArray9 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny("", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ts/Home/jr", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO" + "'", str1.equals("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "#", 26);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("4444444444444444hi!4444444444444444", strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "javaVirtualMachineSpecification/Users/sophie/Libr");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("US", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 101");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sop/ng00000f4n1x2n2q01ments/defects4j/tmp/run_rndoop.pl_9212_1560227300/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("444444444444444444!4444444444444444uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/uSERS/SOPHIE/dOCUMENTS/DEFEC...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwwt.mcosx.CPrinterJob", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", "sophie", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(278, (int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 278 + "'", int3 == 278);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ts/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ts/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr" + "'", str1.equals("ts/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Oracle Corporati/Users/sophi", "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                 RACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/1utf-8HTTP://JAVA.ORACLE.COM/", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Hipecific...!pecific...4444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hipecific...!pecific...4444444" + "'", str1.equals("Hipecific...!pecific...4444444"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo...", "TnemnorivnE e...", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..." + "'", str3.equals("...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo..."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", "ORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONEN", "Java Virtual Machine Specific...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(137.0d, 52.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Xenene...SOenene...caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XENENE...SOENENE...CAM" + "'", str1.equals("XENENE...SOENENE...CAM"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1a.", (long) 1800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1800L + "'", long2 == 1800L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "ahotsaa", "ORACLEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCORPORATI/USERS/SOPHI", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("\nsun.awt.cgraphicsenvironment\nsun.awt.cgraphicsenvironment\nsun.awt.cgraphicsenvironment", (int) (byte) 100, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("tionachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavationjachine Specifical Ma Virtuavaj", "http://j#v#.or#cle.com/1UTF-8http:/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("...vI...", (int) ' ', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "http://j#v#.or#cle.com/1UTF-8http:/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://j#v#.or#cle.com/1UTF-8http:/" + "'", str1.equals("http://j#v#.or#cle.com/1UTF-8http:/"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 97, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://jav", "Java HotSpot(TM) 6-Bit Server VM", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-", 19, 92);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-" + "'", str3.equals("UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-UTF-"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", "E Runtime Environmenttionen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-" + "'", str1.equals("-"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("4hots", "O Corp", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("e", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "...vI...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM", 46, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nene...SOenene...caMXenene...SOene" + "'", str3.equals("nene...SOenene...caMXenene...SOene"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("44444444444444444444444444444444444444444441.7.0_8...44444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt.CGraphicsEnvironment", (int) (short) 100, "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-8sun.awt.CGraphicsEnvironment" + "'", str3.equals("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-8sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("biL/eihpos/sresU/noitacificepS enihcaM lautriV ava", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "  ://jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Orcle Corportion", "://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Orcle Corportion" + "'", str3.equals("Orcle Corportion"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4444444444444444...                          ...4444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        long[] longArray3 = new long[] { 3L, 19, 12 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3L + "'", long4 == 3L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.o" + "'", str2.equals("http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.o"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java HotSpot(TM) 6-Bit Server VM", "hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Java HotSpot(TM) 64-Bit Server VM", "://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth8-FTU1/mocdk1.7.0_80.jdk/Contents/Home/jrdk1.7.0_80.jdk/Contents/Home/jrlcarodk1.7.0_80.jdk/Contents/Home/jravaj//:ptth", "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("java hotspot(tm) 64-bit server vm", "enene...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java hotspot(tm) 64-bit server vm" + "'", str2.equals("java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/ng00000f4n1x2n2q01", "1a.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(137, 35, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 137 + "'", int3 == 137);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim" + "'", str2.equals("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "mixed modemixed modemixed modemixed modemixed mode", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "  ://jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        long[] longArray3 = new long[] { (-1), 0, (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Orcle Corportion", "XENENE...SOENENE...CAM", "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Orcle Corportion" + "'", str4.equals("Orcle Corportion"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  ://jav", (int) (byte) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  ://jav" + "'", str3.equals("  ://jav"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!ih", "http://jav");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!ih" + "'", str4.equals("!ih"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("java Virtual Machine Specification/Users/sophie/Lib");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virttime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr", (int) '#', "...                          ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virttime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr" + "'", str3.equals("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virttime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("JavaVirtualMachineSpecific...", "O Corpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(184);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TnemnorivnE e...", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("US", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("44444444444444444444444444444444444444444441.7.0_8...44444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", 14, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a Virtual Mach" + "'", str3.equals("a Virtual Mach"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...", "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttion");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific..." + "'", str4.equals("JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific..."));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific..." + "'", str6.equals("JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific..."));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/ng00000f4n1x2n2q01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/ng00000f4n1x2n2q01" + "'", str1.equals("/ng00000f4n1x2n2q01"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 6 -Bit Server VM", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 6 -Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 6 -Bit Server VM"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        float[] floatArray3 = new float[] { 0L, 1, (-1) };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("poration");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "poration" + "'", str1.equals("poration"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("a", "Java(TM) SE Runtime Environment                     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...", "-FTU", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 49);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM", "ORACLE# #CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "O444444444444444444!tion         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("vaj//:  ", "                          sun.lwawt.macosx.LWCToolkit                                            ", "Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "vaj//:  " + "'", str3.equals("vaj//:  "));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("8", "javaVirtualMachineSpecification/Users/sophie/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaenene...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...eneneaa" + "'", str1.equals("...eneneaa"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '4', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7", charArray6);
        java.lang.Class<?> wildcardClass9 = charArray6.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nuS", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ehi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/", "444444444444444444!4444444444444444", 7);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ehi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/" + "'", str4.equals("ehi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#######################################################################################ts/Home/jr", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######################################################################################ts/Home/jr" + "'", str2.equals("#######################################################################################ts/Home/jr"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("BOjRETNIRpc.XSOCAM.TWAWL.NUs", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("rary/", "TnninE itnuR ES )MT(J", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("OJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific... CorpJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific...", 34, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific... CorpJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific..." + "'", str3.equals("OJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific... CorpJava http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific..."));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("jAVA vIRTUAL mACHINE sPECIFICATION", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        char[] charArray9 = new char[] { '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("Mac OS X", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("hi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jarhi!", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " ", charArray9);
        java.lang.Class<?> wildcardClass14 = charArray9.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1UTF-8", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("mixed modemixed modemixed modemixed modemixed mode", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/USERS/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hine Specification", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pecification" + "'", str2.equals("pecification"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 137);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                          boJretnirPC.xsocm.twwl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocm.twwl.nus" + "'", str1.equals("boJretnirPC.xsocm.twwl.nus"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("51.", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51." + "'", str2.equals("51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51."));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("av://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sun.lwwt.mcosx.CPrinterJob                                                                          ", 1800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("ts/Home/jr", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" HotSpot(TM) 6-Bit Server VM", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 6-Bit Server VM" + "'", str2.equals(" HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(170L, (long) 0, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 170L + "'", long3 == 170L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("jAVA pLATFORM api sPECIFICATION", "rj/emoH/stnet", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocm.twwl.nusaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                  " + "'", str1.equals("boJretnirPC.xsocm.twwl.nusaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                  "));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("javahotspot(tm)64-bitservervm", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("TnemnorivnE emitnuR ES )MT(avaJ", "/", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 137);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TnemnorivnE emitnuR ES )MT(avaJ" + "'", str4.equals("TnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("JAVA vIRTUAL mACHINE sPECIFICATION                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA vIRTUAL mACHINE sPECIFICATION" + "'", str1.equals("JAVA vIRTUAL mACHINE sPECIFICATION"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("enenene...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("JavaVirtualMachineSpecification", "poration");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("TENTS/hOME/JR", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TENTS/hOME/JR" + "'", str2.equals("TENTS/hOME/JR"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "://java.oracle.com/enOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("7 0_ 0 b 5", 92.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 92.0f + "'", float2 == 92.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Specific... Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Specific...Java Machine Virtual Java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aj//:vaj//:vaj//:ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/j//:vaj//:vaj//:" + "'", str1.equals("aj//:vaj//:vaj//:ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/j//:vaj//:vaj//:"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hipecific...!pecifenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen", (int) (byte) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("vaj//:  ", "http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.o", "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RacEEL  " + "'", str3.equals("RacEEL  "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        double[] doubleArray5 = new double[] { (byte) 0, 18, (short) 100, (short) 1, (short) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "av://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE:", (java.lang.CharSequence) "                                                                 UTF-4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "rj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/st", "/var/f1ldhrs/_v/6v597zmt4_vOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation2t2x1t4f00000gt//");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfr" + "'", str3.equals("O/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfrO/aclrOCf/pf/ahvfr"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("1.7", "BOjRETNIRpc.XSOCAM.TWAWL.NUs");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("1.7.0_80", "SUN.LWAWT.MACOSX.CPRINTERJOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "a Virtual Machine ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                   ", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 0L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie" + "'", str1.equals("Users/sophie"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "TENTS/hOME/JR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) " HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("X SO caM", "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("://jav");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, " ");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "://jav" + "'", str3.equals("://jav"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "\nsun.awt.cgraphicsenvironment\nsun.awt.cgraphicsenvironment\nsun.awt.cgraphicsenvironment", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444444444444444444!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444!" + "'", str1.equals("444444444444444444!"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("-FTU4", "Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-FTU4" + "'", str2.equals("-FTU4"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("noitacificepS IPA mroftalP avaJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("ORACLE# #CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE# #CORPORATION" + "'", str1.equals("ORACLE# #CORPORATION"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Corporation Oracle");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Corporation Oracle is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaUTF-JavaVirtualMachineSpe");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAUTF-JAVAVIRTUALMACHINESPE" + "'", str1.equals("AAAAAAUTF-JAVAVIRTUALMACHINESPE"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("java hotspo...", (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "Machine ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Machine " + "'", str2.equals("Machine "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("70_0b5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "70_0b5" + "'", str1.equals("70_0b5"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 10, (byte) 0, (byte) 0, (byte) 1, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("BOjRETNIRpc.XSOCAM.TWAWL.NUs", "Java(TM) SE Runtime Environment                     ", 64);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONEN");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONENORJAVA(TM) SE RUNTIME ENVIRONMENTCLE CORPORJAVA(TM) SE RUNTIME ENVIRONMENTTIONEN\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("OracleCorporati/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300OracleCorporati", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporati/Users/sophie" + "'", str2.equals("OracleCorporati/Users/sophie"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", "51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("s", "TENTS/hOME/JR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1#UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("poration", (long) 80);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 80L + "'", long2 == 80L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "hipecific...!pecifenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime Environmenttionen");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("enenene...", ".com/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 26, 92.0f, (float) 8L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle 1a.a7a.a0a_a80a-aba15ration", 95, "sPECIFICATION mACHINE vIRTUAL JAVA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle 1a.a7a.a0a_a80a-aba15rationsPECIFICATION mACHINE vIRTUAL JAVAsPECIFICATION mACHINE vIRTU" + "'", str3.equals("Oracle 1a.a7a.a0a_a80a-aba15rationsPECIFICATION mACHINE vIRTUAL JAVAsPECIFICATION mACHINE vIRTU"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM", "javatualachnspcfcaton");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM444444444444444444!444444...Java HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(95.0d, (double) 64, (double) 3L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444hi!4444444444444444", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aj//:vaj//:vaj//:ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/j//:vaj//:vaj//:");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str5.equals("4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("pecification", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("BOjRETNIRpc.XSOCAM.TWAWL.NUs", "boJretnirPC.xsocam.twawl.nuS");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BOjRETNIRpXOAMTWAWLNU" + "'", str3.equals("BOjRETNIRpXOAMTWAWLNU"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "51.", (java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nuS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("BOjRETNIRpc.XSOCAM.TWAWL.NUs", "sun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JAVA#VIRTUAL#MACHINE#SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        int[] intArray4 = new int[] { 0, (byte) 0, (short) 10, (short) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://j" + "'", str1.equals("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://j"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                   ", "4444444444444444...                          ...4444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "biL/eihpos/sresU/noitcificepS enihcM lutriV v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("O Corp", 217, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                         O Corp                                                                                                          " + "'", str3.equals("                                                                                                         O Corp                                                                                                          "));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" HotSpot(TM) 6-Bit Server VM", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM" + "'", str2.equals(" HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                ", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("java hotspo...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java hotspo..." + "'", str1.equals("java hotspo..."));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("a Virtual Machine ", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a Virtual Machine         " + "'", str2.equals("a Virtual Machine         "));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV avaj", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO", "http://j#v#.or#cle.com/1UTF-8http:/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixed mode", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "ORACLE# #CORPORATION");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...", "Hipecific...!pecific...4444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific..." + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific..."));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#", "51.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "hipecific...!pecific...4444444");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oraclehipecific...!pecific...4444444 hipecific...!pecific...4444444Corporation" + "'", str3.equals("Oraclehipecific...!pecific...4444444 hipecific...!pecific...4444444Corporation"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virt", "TTP://JAVA.ORACLE.COM/1utf-8...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virt" + "'", str2.equals("al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virt"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sPECIFICATION mACHINE vIRTUAL JAVA", "UTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8X SO caMUTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sPECIFICATION mACHINE vIRTUAL JAVA" + "'", str2.equals("sPECIFICATION mACHINE vIRTUAL JAVA"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle 1a.a7a.a0a_a80a-aba15ration", 217, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle 1a.a7a.a0a_a80a-aba15ration#######################################################################################################################################################################################" + "'", str3.equals("Oracle 1a.a7a.a0a_a80a-aba15ration#######################################################################################################################################################################################"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("TnemnorivnE e...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("TnninE itnuR ES )MT(J", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaE Runtime Environmenttionen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS", "http4444444444444444hi!4444444444444444//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str2.equals("RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "Java http4444444444444444hi!4444444444444444//java.oracle.com/al Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        char[] charArray12 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr                                     ", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/f1lders/_v/6v597zmn4_v310q2n2x1n4f00000gn//", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("O444444444444444444!tion         ", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                 UTF-4444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-4444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        int[] intArray4 = new int[] { 0, (byte) 0, (short) 10, (short) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        char[] charArray13 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "enenene...", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "tents/Home/j", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ahotsaa", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hipecific...!pecific...4444444", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("javaVirtualMachineSpecification/Users/sophie/Libr", "s");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Virtual Machine Specification", "XENENE...SOENENE...CAM", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 217, 3.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 217.0f + "'", float3 == 217.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals(":1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("E Runtime Environmenttionen", "Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtua4444444444444444hi!4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E Runtime Environmenttionen" + "'", str2.equals("E Runtime Environmenttionen"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("UTF-4444444444444444444444444444444", "#######################################################################################ts/Home/jr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        long[] longArray5 = new long[] { (short) 10, (-1), ' ', 0L, '4' };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("a Virtual Machine         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a Virtual Machine\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "...porationOracle CorporationOracle CorporationOracle CorporationOracle Corpo...", 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        double[] doubleArray3 = new double[] { 10.0d, 80, 1.7000000476837158d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.7000000476837158d + "'", double4 == 1.7000000476837158d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.7000000476837158d + "'", double5 == 1.7000000476837158d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4L, (float) 170, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/...", "Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM", "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/..." + "'", str4.equals("/Users/..."));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("O Corpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O Corpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("O Corpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("UTF-4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-4444444444444444444444444444444" + "'", str1.equals("UTF-4444444444444444444444444444444"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO" + "'", str1.equals("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO ", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwwt.mcosx.CPrinterJob                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwwt.mcosx.CPrinterJob                                                                         " + "'", str1.equals("sun.lwwt.mcosx.CPrinterJob                                                                         "));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Hipecific...!pecific...4444444", "rj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/stnenoittnemnorivnE emitnuR Erj/emoH/st", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.", "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "1.7.0_8...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51./USERS/...51./USERS/...51./USERS/...51./USERS/...51." + "'", str3.equals("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51."));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        int[] intArray3 = new int[] { (byte) -1, 34, (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 34 + "'", int4 == 34);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 34 + "'", int5 == 34);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 34 + "'", int6 == 34);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1a.a7a.a0a_a80a-aba15", "Xenene...SOenene...caM", "/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth8-FTU1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "             enene...              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle Corp", 26, "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle Corp" + "'", str3.equals("OrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runtime EnvironmenttionenOrJava(TM) SE Runtime Environmentcle Corp"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "Oracle 1a.a7a.a0a_a80a-aba15rationsPECIFICATION mACHINE vIRTUAL JAVAsPECIFICATION mACHINE vIRTU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80-B15", "TTP://JAVA.ORACLE.COM/1utf-8...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("biL/eihpos/sresU/noitacificepS enihcaM lautriV ava");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Xenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caMXenene...SOenene...caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) 75, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../U...", "Oracle 1a.a7a.a0a_a80a-aba15ration#######################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444!4444444444444444", "                                                    ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java(TM) SE Runtime Environment                     ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", ".");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "rary/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://j", 95, "sun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://j" + "'", str3.equals("://jav://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE://jav://jav://j"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaE Runtime Environmenttionen", 184, "!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!aaaaaaaaE Runtime Environmenttionen" + "'", str3.equals("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!aaaaaaaaE Runtime Environmenttionen"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", "http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.CPrinteUTF-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinteUTF-" + "'", str1.equals("sun.lwawt.macosx.CPrinteUTF-"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                   ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("  ://jav", ".", 1800);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("tents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/Home/jrtents/HSUN.LWAWT.MACOSX.cpRINTERjOB", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tents/Home/jr..." + "'", str2.equals("tents/Home/jr..."));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.", 94, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.#######################################" + "'", str3.equals("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.#######################################"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/TARGET/CLASSES:/uSERS/SOP..." + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9212_1560227300/TARGET/CLASSES:/uSERS/SOP..."));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 1, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "      /uSERS/SOPHIE\n      ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("HotSpot(TM) 6-Bit Server VM", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.", "Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000gt//", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000g" + "'", str2.equals("rbiL/eihpos/sresU/noitacificepS eni/var/f1ldhrs/_v/6v597zmt4_v310q2t2x1t4f00000g"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 5);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        char[] charArray11 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "enenene...", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("ts/Home/jr", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_64", "US#", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Users/sophie", 6, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                                                            java tual achn spcfcaton", "", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "RacEEL  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaa1.7.0_8un.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("a Virtual Machine");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a Virtual Machine\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                   ", "al Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virttime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("rbiL/eihpos/sresU/noitacificepS enihcaM lautriV ava", "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                             1#UTF-8                                             ", "SERS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             1#UTF-8                                             " + "'", str2.equals("                                             1#UTF-8                                             "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment", (int) (short) 0, 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEn" + "'", str3.equals("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEn"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.awt.CGraphicsEnvironment", "444444444444444444!4444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "...eneneaa", "sun.lwwt.mcosx.CPrinterJob                                                                          Sun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hipecific...!pecific...4444444", (java.lang.CharSequence) "http4444444444444444hi!4444444444444444//java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("java Virtual Machine Specification/Users/sophie/Libr", "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A" + "'", str1.equals("A"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4hots", "/java tual achn spcfcaton/java tual achn spcfcatondjava tual achn spcfcatons/_java tual achn spcfcaton/6java tual achn spcfcaton597zmjava tual achn spcfcaton4_java tual achn spcfcaton31java tual achn spcfcatonq2java tual achn spcfcaton2x1java tual achn spcfcaton4java tual achn spcfcaton0000gjava tual achn spcfcaton/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT" + "'", str1.equals("jAVA(tm) se rUNTIME eNVIRONMENT"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwwt.mcosx.CPrinterJob                                                                          ", "24.80-b11", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-8sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("poration", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle 1a.a7a.a0a_a80a-aba15ration", "", 27);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/var/f1ldhrs/_v/6v597zmt4_vOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation2t2x1t4f00000gt//");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle/var/f1ldhrs/_v/6v597zmt4_vOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation2t2x1t4f00000gt//1a.a7a.a0a_a80a-aba15ration" + "'", str5.equals("Oracle/var/f1ldhrs/_v/6v597zmt4_vOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation2t2x1t4f00000gt//1a.a7a.a0a_a80a-aba15ration"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "http4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!44:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Chttp4444444444444444hi!4444444444444444//javavoraclevcom/http4444444444444444hi!444", 16, 18);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..." + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                ", "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "              ", (int) (byte) 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("1.7.0_80-B15", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("TnemnorivnE emitnuR ES )MT(avaJ", "Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("javaVirtualMachineSpecification/Users/sophie/Libr", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jvVirtulMchineSpecifiction/Users/sophie/Libr" + "'", str2.equals("jvVirtulMchineSpecifiction/Users/sophie/Libr"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("TUAL mACHINE sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jvVirtulMchineSpecifiction/Users/sophie/Libr", "enenene...://javOracle Corporati:/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Oracle Corporati");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("A", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "A" + "'", str3.equals("A"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("BOjRETNIRpc.XSOCAM.TWAWL.NUSH/stnetrj/emoH/stnetrj/emoH/stnetrj/emoH/stnetrj/emoH/stnetrj/emoH/stnet", 184, 1800);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4hots");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("E Runtime Environmenttionen", 26, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E Runtime Environmenttionen" + "'", str3.equals("E Runtime Environmenttionen"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaa   sun.awt.CGraphicsEnvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444", "", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or" + "'", str2.equals("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.or"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java tual achn spcfcaton", "##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java tual achn spcfcaton" + "'", str2.equals("java tual achn spcfcaton"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7.0_80-B15", 447);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ts/Home/jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ts/Home/jr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("av://jav://j/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE:");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(64, (int) (short) 1, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..." + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n", "boJretnirPC.xsocm.twwl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.lwwt.mcosx.CPrinterJob                                                                          Sun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJob", "enenene...", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(" HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVM" + "'", str1.equals("HotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVMHotSpot(TM)6-BitServerVM"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific...", 278, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", "hots", 52);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray12 = new char[] { '4', '#', ' ', ' ', ' ' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "enenene...", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Sun.lwawt.macosx.CPrinterJob", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "e", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "tents/Home/j", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://j#v#.or#cle.com/1UTF-8http:/", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("ts/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ts/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", "mac OS X", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("             enene...              ", "ual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             enene...              " + "'", str2.equals("             enene...              "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str1.equals("RO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTH8-FTU1/MOC.ELCARO.AVAJ//:PTTHBOJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle 1a.a7a.a0a_a80a-aba15ration#######################################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...", "biL/eihpos/sresU/noitcificepS enihcM lutriV v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 6-Bit Server VM");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("TUAL mACHINE sPECIFICATION", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaTUAL mACHINE sPECIFICATIONHotSpot(TM)TUAL mACHINE sPECIFICATION6-BitTUAL mACHINE sPECIFICATIONServerTUAL mACHINE sPECIFICATIONVM" + "'", str3.equals("JavaTUAL mACHINE sPECIFICATIONHotSpot(TM)TUAL mACHINE sPECIFICATION6-BitTUAL mACHINE sPECIFICATIONServerTUAL mACHINE sPECIFICATIONVM"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("TTP://JAVA.ORACLE.COM/1utf-8...", "", "e");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TTP://JAVA.ORACLE.COM/1utf-8..." + "'", str3.equals("TTP://JAVA.ORACLE.COM/1utf-8..."));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 0, (byte) 1, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", " HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM HotSpot(TM) 6-Bit Server VM", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwwt.mcosx.CPrinterJob", "Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300Java Virtual Machine Specific...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwwt.mcosx.CPrinterJob" + "'", str2.equals("sun.lwwt.mcosx.CPrinterJob"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("TnninE itnuR ES )MT(J", "Oracle# #Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", '4');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("ORACLE CORPORATI/USERS/SOPHI", ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "JavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...USJavaVirtualMachineSpecific...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("java tual achn spcfcaton", "Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...Java Virtual Machine Specific...", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java tual achn spcfcaton" + "'", str3.equals("java tual achn spcfcaton"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("http4444444444444444hi!4444444444444444//java.oracle.com/", "java tual achn spcfcaton");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                          ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                          ..." + "'", str1.equals("                          ..."));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.51.", "A", "                                                                 UTF-4444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("                                                                                        1.7.0_80-B15", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                            java tual ac.n 17cfcat.n", 64, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...            java tual..." + "'", str3.equals("...            java tual..."));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO", 8, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO" + "'", str3.equals("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SOX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEn", "                                                                                               UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATION", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed mode", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300", 137, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("mac OS X", "                                                                                        1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/1UTF-8http://java.oracle.com/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle# #Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(97L, (long) 80, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a Virtual Mach");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a Virtual Mach" + "'", str2.equals("a Virtual Mach"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("java Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specificationjava Virtual Machine Specification", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '4', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   ", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "enJava Virtual Machine Specification", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinteUTF-", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 5, "   sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http4444444444444444hi!4444444444444444//java.oracle.com/", 10, "4444444444444444...                          ...4444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http4444444444444444hi!4444444444444444//java.oracle.com/" + "'", str3.equals("http4444444444444444hi!4444444444444444//java.oracle.com/"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEn", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aJAVA vIRTUAL mACHINE sPECIFICATION...", "Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aJAVA vIRTUAL mACHINE sPECIFICATION..." + "'", str2.equals("aJAVA vIRTUAL mACHINE sPECIFICATION..."));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "sun.lwwt.mcosx.CPrinterJob                                                                          Sun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJobSun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("JavaVirtualMachineSpecification", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("4444451.444444", "", 1800);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwwt.mcosx.CPrinterJob", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51.", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51./USERS/...51./USERS/...51./USERS/...51./USERS/...51." + "'", str2.equals("51./USERS/...51./USERS/...51./USERS/...51./USERS/...51."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaSun.lwawt.macosx.CPrinterJob", 184);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaSun.lwawt.macosx.CPrinterJob" + "'", str2.equals("aaaaaaSun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java HotSpot(TM) 6 -Bit Server VM", "O444444444444444444!tion         ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("SUN.LWAWT.MACOSX.CPRINTERJOB", "ORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONORACLE CORPORATIONts/Home/jr", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOB" + "'", str3.equals("SUN.LWAWT.MACOSX.CPRINTERJOB"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/" + "'", str1.equals("Http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/1UTF-8http://j#v#.or#cle.com/"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("1UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-81UTF-8sun.awt.CGraphicsEnvironment", "Oracle 1a.a7a.a0a_a80a-aba15rationsPECIFICATION mACHINE vIRTUAL JAVAsPECIFICATION mACHINE vIRTU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444hi!4444444444444444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str2.equals("4444444444444444hi!4444444444444444"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444hi!4444444444444444" + "'", str3.equals("4444444444444444hi!4444444444444444"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lwawt.macosx.LWCToolkit                 ", "javahotspot(tm)64-bitservervm", "MIXED MODE");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("a Virtual Machine ", 28, "sun.lwwt.mcosx.CPrinterJob                                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a Virtual Machine sun.lwwt.m" + "'", str3.equals("a Virtual Machine sun.lwwt.m"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop..."));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaE Runtime Environmenttionen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...eneneaa", 217, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                               ...eneneaa" + "'", str3.equals("                                                                                                                                                                                                               ...eneneaa"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a Virtual Machine", "ts/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jrE Runtime Environmenttionents/Home/jr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        long[] longArray3 = new long[] { (-1), 0, (-1) };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   ", "aaenene...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   " + "'", str2.equals("                  /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/Users/sophie/Documents/defec...                   "));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("Java(TM) SE Runtime Environment                     ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa   sun.awt.cgraphicsenvironment    aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Virtual Machine Specific...Java Virtual Macr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/a/v", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J" + "'", str2.equals("J"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "noitroproC elcrO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java hotspot(tm) 64-bit server vmehi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/ehi!/Users/sophie/Docume", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java hotspot(tm) 64-bit server vmehi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/ehi!/Users/sophie/Docume" + "'", str2.equals("java hotspot(tm) 64-bit server vmehi!/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/ehi!/Users/sophie/Docume"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("chines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedalMaVirtuava/Javary/Ja/Libr", "                                                                 UTF-4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("java hotspot(tm) 64-bit server vm", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                 UTF-4444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                 UTF-4444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0, 64);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Ho..." + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Ho..."));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop..." + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9212_1560227300/target/classes:/Users/sop..."));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...TTP://JAVA.ORACLE.COM/1utf-8...", "://java.oracle.com/enOrJava(TM) SE Runtime Environmentcle CorporJava(TM) SE Runt");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("boJretnirPC.xsocm.twwl.nusaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 52, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        long[] longArray2 = new long[] { 28L, '#' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("BOjRETNIRpc.XSOCAM.TWAWL.NUs");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "      /uSERS/SOPHIE\n      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("racle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\nsun.awt.CGraphicsEnvironment\n", 3, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n.awt.CGraph" + "'", str3.equals("n.awt.CGraph"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ORACLE# #CORPORATION", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#CORPORATION" + "'", str2.equals("#CORPORATION"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, (long) 27, 137L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaSun.lwawt.macosx.CPrinterJob", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaSun.lwawt.macosx.CPrinterJob" + "'", str2.equals("aaaaaaSun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444441.7.0_8...4444444444444444444444444444444444444444444"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        int[] intArray4 = new int[] { 100, 170, (-1), (short) 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 170 + "'", int5 == 170);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 170 + "'", int6 == 170);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 170 + "'", int8 == 170);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 170 + "'", int9 == 170);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 170 + "'", int10 == 170);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("TnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }
}

