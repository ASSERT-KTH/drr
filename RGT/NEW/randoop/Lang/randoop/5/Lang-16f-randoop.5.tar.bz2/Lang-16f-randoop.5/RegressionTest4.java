import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (short) 10, (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("un.lwwt.mcx.LWCTlkt", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("eihpos/sresU/", "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", 26, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15" + "'", str3.equals("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str1.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142", (java.lang.CharSequence) "x.LWCTlkt");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        char[] charArray4 = new char[] { 'a', '4' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i", charArray4);
        java.lang.Class<?> wildcardClass6 = charArray4.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecificatio" + "'", str1.equals("JavaPlatformAPISpecificatio"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 100, (long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.", "JavaPlatformAPISpecification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "e", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("un.lwwt...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "JAVAPLATFaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server VM", "", "Oracle4Corporation", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "\n", 18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "(TM)  Rl el");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("jAVA(tm) se rUNTIME eNVIRONMENT", "1.6", (int) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVA(tm) s1.6" + "'", str4.equals("jAVA(tm) s1.6"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Virtual/Machine/Specification", "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.4", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "424.80-b11/Users/sophie/Library/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1.2", "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 32, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 22 + "'", int4 == 22);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10, 0.0f, (float) 99);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", 67L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 67L + "'", long2 == 67L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################", 97, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80", "", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("un.lwawt.macx.LWCTlkt                               ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "######################################################################/#######################################################################", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, (double) 28, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "X SO caM");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", charSequence2.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15" + "'", str2.equals("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   " + "'", str1.equals("                                                                                                   "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 10, 59);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("aaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/", (java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                   Virtual Machine Specification                   ", "/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   Virtual Machine Specification                   " + "'", str2.equals("                   Virtual Machine Specification                   "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO", "    1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("JAVA PLATFORM API SPECIFICATION", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle \n", (float) 19L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 19.0f + "'", float2 == 19.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("x.LWCTlkt");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x.LWCTlkt\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7" + "'", str1.equals("hI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x.LWCTlkt", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x.LWCTlkt" + "'", str3.equals("x.LWCTlkt"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "               eihpos/sresU/", (java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY", "un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("      ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                   Virtual Machine Specification                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("http:", 67, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 1, (float) 'a', 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "###########################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Oracle \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE \n" + "'", str1.equals("oRACLE \n"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, 142, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.21.21.71.71.21.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("               eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU/" + "'", str1.equals("eihpos/sresU/"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", "JavaPlatformAPISpecification");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", (java.lang.CharSequence) "          ", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(":", (double) 1.6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.600000023841858d + "'", double2 == 1.600000023841858d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRAR..." + "'", str2.equals("/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRAR..."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("OracleJava Virtual Machine SpecificationC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleJava Virtual Machine SpecificationC" + "'", str1.equals("OracleJava Virtual Machine SpecificationC"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("i");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i" + "'", str1.equals("i"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", "    1.7.0_80", "424.80-b11/Users/sophie/Library/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "    hi!hihi!hi     ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "sun.l...", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.lwawt.macosx.CPrinterJob                        ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.CPrinterJob                        awt.masun.lw" + "'", str2.equals("cosx.CPrinterJob                        awt.masun.lw"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Oracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.awt.CGraphicsEnvironment", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("OracleJava Virtual Machine SpecificationC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleJava Virtual Machine SpecificationC" + "'", str1.equals("OracleJava Virtual Machine SpecificationC"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("      ", 4, 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sophi", (java.lang.CharSequence) "OracleJava Virtual Machine SpecificationCorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Oracle \n", (java.lang.CharSequence) "424.80-B11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  " + "'", str2.equals("                  "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8" + "'", str1.equals("utf-8"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 0, "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 59, (long) (byte) 1, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 19, (float) 10L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 19.0f + "'", float3 == 19.0f);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "    hi!hihi!hi     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Un.lwawt.macx.LWCTlkt                               ", (java.lang.CharSequence) "hi!hihi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################", (int) (byte) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################" + "'", str3.equals("1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.1", "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", (int) (short) -1, "                 \n                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar" + "'", str3.equals("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Oracle4Corporation", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 22, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA PLATFa", "VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("10.14.3", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "                                                    ", "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 35.0f, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(52.0d, (double) 51, (double) 19L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.CPrinterJob                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 35, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 29, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("n", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("snetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.2", "1.2", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                 \n                 ", "un.lwawt.macx.LWCTlkt                               ", (int) (byte) 100, 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                 \n           un.lwawt.macx.LWCTlkt                               " + "'", str4.equals("                 \n           un.lwawt.macx.LWCTlkt                               "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i", (java.lang.CharSequence) "######################################################################/#######################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRAR...", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                 ", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("OracleCorporation", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double[] doubleArray0 = new double[] {};
        double[][] doubleArray1 = new double[][] { doubleArray0 };
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray2 };
        double[] doubleArray4 = new double[] {};
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        double[][][] doubleArray10 = new double[][][] { doubleArray1, doubleArray3, doubleArray5, doubleArray7, doubleArray9 };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1##################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                   ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jv pltform api specifiction" + "'", str1.equals("jv pltform api specifiction"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensio" + "'", str3.equals("/Users/sophie/Library/Java/Extensio"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("    1.7.0_80");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        char[] charArray6 = new char[] { ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.21.21.71.71.21.7", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Jv Pltform API Specifiction", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("un.lwwt.mcx.lwctlkt", "sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str3.equals("un.lwwt.mcx.lwctlkt"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "javaplatfA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(59L, (long) 11, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie" + "'", str2.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                  ", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("VIRTUAL MACHINE SPECIFICATION      ", "      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10.14.3", "U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("tx!", 59, "OracleCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporationOracleCorporationOracleCorporationOracltx!" + "'", str3.equals("OracleCorporationOracleCorporationOracleCorporationOracltx!"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("               eihpos/sresU/", (float) 28);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar" + "'", str2.equals("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("oRACLE \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE " + "'", str1.equals("oRACLE "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("(TM)  Rl el", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM)  Rl el" + "'", str2.equals("(TM)  Rl el"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:", (java.lang.CharSequence) "OracleCorporationOracleCorporationOracleCorporationOracltx!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("OracleJava Virtual Machine SpecificationCorporation", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                 ", (java.lang.CharSequence) "Jv Pltform API Specifiction", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("mixed mode", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  mixed mode                                                                  " + "'", str2.equals("                                                                  mixed mode                                                                  "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/", "EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("HI!", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#######", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "#######", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "ORACLE CORPORATION");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str5.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("JAVA PLATFa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFa" + "'", str1.equals("JAVA PLATFa"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("jAVA(tm) s1.6", "sun.l...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) s1.6" + "'", str2.equals("jAVA(tm) s1.6"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Oracle4Corporation", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle4Corporation" + "'", str2.equals("Oracle4Corporation"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV" + "'", str1.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/", "", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/" + "'", str3.equals("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("cosx.CPrinterJob                        awt.masun.lw", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.CPrinterJob                        awt.masun.lw" + "'", str2.equals("cosx.CPrinterJob                        awt.masun.lw"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "oRACLE \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "JAVAPLATFa");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Oracle \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle \n" + "'", str1.equals("Oracle \n"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "424.80-b11", (java.lang.CharSequence) "javaplatfA", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15" + "'", str2.equals("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("JavaPlatformAPISpecification", 0, 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpec" + "'", str3.equals("JavaPlatformAPISpec"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.600000023841858d, (double) 3L, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#######", "###################################################################################################", 32);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie" + "'", str12.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("e");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hi!hihi!hi", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hihi!hi" + "'", str3.equals("hi!hihi!hi"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        long[] longArray6 = new long[] { 10L, 0, 10, (-1L), (byte) 10, '#' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", "sun.l...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e" + "'", str2.equals("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, (float) 32, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":", (java.lang.CharSequence) "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "###########################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#########################", "1.7.0_80-b15", (int) (short) 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "JAVA PLATFa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "x.LWCTlkt", (java.lang.CharSequence) "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.2a1.2a1.7a1.7a1.2a1.7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        char[] charArray6 = new char[] { ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                  mixed mode                                                                  ", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode                                                                  " + "'", str2.equals("mixed mode                                                                  "));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n", "                                ", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.", (java.lang.CharSequence) "/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRAR...", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#########################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 11);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        char[] charArray7 = new char[] { ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                                  Java(TM) SE Runtime Environment                                   ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, (int) (byte) -1, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV" + "'", str1.equals("/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV" + "'", str1.equals("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("cosx.CPrinterJob                        awt.masun.lw");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"cosx.CP\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#######", "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("javaplatfA", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "javaplatfA" + "'", str4.equals("javaplatfA"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("SUN.LWAWT.MACOSX.LWCTOOLKIT", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("hi!", "", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', (int) (byte) 10, (int) (byte) 10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "                                                                                                   ");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed" + "'", str13.equals("                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("jv pltform api specifiction");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("###########################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ########################################################### is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence) "aaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("######################################################################/#######################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENHCAMLAUTRVAVAJ/AVAJ/YRARBL/", "1##################################################################", 29);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle4Corporation", 0, 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle4Corporation" + "'", str3.equals("Oracle4Corporation"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double[] doubleArray4 = new double[] { (-1L), 10, (byte) 10, (short) 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("E", 35, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/" + "'", str3.equals("E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) 100.0f, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("424.80-b11/Users/sophie/Library/", 89);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e" + "'", str1.equals("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("    hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi" + "'", str1.equals("hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                    ", (-1), 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "Virtual/Machine/Specification", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JAVA PLATFa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "24.80-b11");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "i", (java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "               eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/" + "'", str2.equals("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVA PLATFORM API SPECIFICATION", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("424.80-b11", "s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/" + "'", str2.equals("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("JAVA PLATFa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platfa" + "'", str1.equals("java platfa"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "          ", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "", 100, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.14.3" + "'", charSequence2.equals("10.14.3"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), 1.6f, (float) 51);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("OracleJava Virtual Machine SpecificationC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleJava Virtual Machine SpecificationC" + "'", str1.equals("OracleJava Virtual Machine SpecificationC"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mixed mode                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode                                                                  " + "'", str1.equals("mixed mode                                                                  "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "424.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "UTF-8", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit", strArray4, strArray9);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "", 142, 99);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str10.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("U", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "jv pltform api specifiction");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                 \n           un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jv pltform api specifiction", "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e/library/java/javavirtualmachines/" + "'", str1.equals("e/library/java/javavirtualmachines/"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specification" + "'", str1.equals("java platform api specification"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", 26, 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "e", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "424.80-b11/Users/sophie/Library/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                                   ", (java.lang.CharSequence) "un.lwwt...", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "###################################################################################################\n", (java.lang.CharSequence) "Java Platform API Specification", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11", "sun.l...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11" + "'", str2.equals("VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", (java.lang.CharSequence) "un.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", charSequence2.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", (java.lang.CharSequence) "                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("US", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV", (java.lang.CharSequence) "jv pltform api specifiction");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hihi!hi", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-b15");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!hihi!hi" + "'", str5.equals("hi!hihi!hi"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!hihi!hi" + "'", str7.equals("hi!hihi!hi"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!hihi!hi" + "'", str8.equals("hi!hihi!hi"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sophie", "1.6", 26, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie1.6" + "'", str4.equals("sophie1.6"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 59, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/##########################################################" + "'", str3.equals("/##########################################################"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Virtual Machine Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "U" + "'", str1.equals("U"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 19.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.0d + "'", double2 == 19.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                   Virtual Machine Specification                   ", (java.lang.CharSequence) "    1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", (java.lang.CharSequence) "(TM)  Rl el");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "utf-8", (java.lang.CharSequence) "aaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("JavaPlatformAPISpec", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpec" + "'", str2.equals("JavaPlatformAPISpec"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                  Java(TM) SE Runtime Environment                                   ", (java.lang.CharSequence) "                                  Java(TM) SE Runtime Environment                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("X SO caM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("eihpos/sresU/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "E", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "eihpos/sresU/" + "'", str4.equals("eihpos/sresU/"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e" + "'", str10.equals("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("#######", "suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######" + "'", str3.equals("#######"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Virtual/Machine/Specification", "/Users/sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", "    hi!hihi!hi     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7" + "'", str2.equals("HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sun.l...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "http:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!hihi!hi", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###################################################################################################\n", strArray4, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "  ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str5.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "###################################################################################################\n" + "'", str10.equals("###################################################################################################\n"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str12.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensio", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean12 = javaVersion0.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion13 = null;
        try {
            boolean boolean14 = javaVersion7.atLeast(javaVersion13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        char[] charArray7 = new char[] { ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hi!                                                                                                 ", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualM..." + "'", str2.equals("/Library/Java/JavaVirtualM..."));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("jv pltform api specifiction", 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("    hi!hihi!hi     ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                ", (java.lang.CharSequence) "/", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophie1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":ptthaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals(":ptthaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("i", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "51.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("un.lwwt.mcx.LWCTlkt", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.l...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, (int) (short) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean14 = javaVersion11.atLeast(javaVersion12);
        boolean boolean15 = javaVersion9.atLeast(javaVersion11);
        java.lang.String str16 = javaVersion11.toString();
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean19 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean21 = javaVersion18.atLeast(javaVersion20);
        boolean boolean22 = javaVersion17.atLeast(javaVersion20);
        boolean boolean23 = javaVersion11.atLeast(javaVersion17);
        boolean boolean24 = javaVersion0.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.6" + "'", str16.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("n", 6, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("(TM)  Rl el");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("###################################################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", (int) '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", (int) (short) 1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("###################################################################################################", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################################" + "'", str2.equals("###################################################################################################"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 23, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("E");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi", (java.lang.CharSequence) "###################################################################################################\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97L, (float) (short) 100, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jvUserssophieLibrryJvExtensions:LibrryJvExtensions:NetworkLibrryJvExtensions:SystemLibrryJvExtensions:usrlibjv:./Users/sophie/Librry/Jv/Extensions:/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Librry/Jv/Extensions:/Network/Librry/Jv/Extensions:/System/Librry/Jv/Extensions:/usr/lib/jv");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JAVA PLATFa", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("SOPHIE", (int) '4', 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6", 32, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 25 + "'", int3 == 25);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "Oracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uTF-8" + "'", str1.equals("uTF-8"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("i", "                   Virtual Machine Specification                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142" + "'", str1.equals("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean11 = javaVersion8.atLeast(javaVersion10);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean13 = javaVersion5.atLeast(javaVersion8);
        boolean boolean14 = javaVersion0.atLeast(javaVersion5);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", "s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(26, 26, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("HI!", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("    hi!hihi!hi     ", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!hihi!hi     " + "'", str3.equals("    hi!hihi!hi     "));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray10 = new java.lang.String[] { "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.", "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRAR...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.LWAWT.MACOSX.LWCTOOLKIT", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV", (java.lang.CharSequence) "Java Virtual Machine Specification", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("JavaPlatformAPISpecificatio", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1UN.LWAWT.MACX.lwctLKT                               7UN.LWAWT.MACX.lwctLKT                               0_80-UN.LWAWT.MACX.lwctLKT                               15" + "'", str1.equals("1UN.LWAWT.MACX.lwctLKT                               7UN.LWAWT.MACX.lwctLKT                               0_80-UN.LWAWT.MACX.lwctLKT                               15"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.6", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("EIHPOS/SRESu/", "                  ", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("javaplatfA", "Oracle \n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.CPrinterJob                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(8.0d, (double) 6, 51.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(89, 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                ", 0, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        char[] charArray6 = new char[] { ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 97);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("  ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 29, (float) 0, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 67, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############" + "'", str2.equals("############"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { 'a', '4' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i", charArray4);
        java.lang.Class<?> wildcardClass6 = charArray4.getClass();
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/7/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0_80-/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/15" + "'", str4.equals("1/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/7/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0_80-/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/15"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle \n", "cosx.CPrinterJob                        awt.masun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                 1.7.0_80-b15                                                                 ", "JAVA HOTSPOT(TM) 64-BIT SERVER VM", "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 52, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed", (java.lang.CharSequence) "Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " ", 10, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x.LWCTlkt", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/VIRTU\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(142, (int) (short) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 142 + "'", int3 == 142);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "a", (java.lang.CharSequence) "sophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "JavaPlatformAPISpecificatio", (java.lang.CharSequence) "oRACLE ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("VIRTUAL MACHINE SPECIFICATION");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "OracleCorporation", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java platfa", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javaplatfa" + "'", str2.equals("javaplatfa"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("un.lwawt.macx.LWCTlkt", "sophie", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("      ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("VIRTUAL MACHINE SPECIFICATION", "e/library/java/javavirtualmachines/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jv pltform api specifiction", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("jAVA pLATFORM api sPECIFICATION", "tx!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str3.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                  Java(TM) SE Runtime Environment                                   ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ":", (int) (byte) 100, 10);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("utf-8", strArray1, strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "utf-8" + "'", str8.equals("utf-8"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed" + "'", str2.equals("                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", (java.lang.CharSequence) "424.80-B11", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                 \n           un.lwawt.macx.LWCTlkt                               ", "java platfa", "e");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("###########################################################", "un.lwwt.mcx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################################################" + "'", str2.equals("###########################################################"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                 \n                 ", 8, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 \n                 " + "'", str3.equals("                 \n                 "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence) "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"eihpos/sresU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

