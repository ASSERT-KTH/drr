import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.6", "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Virtual Machine Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", "######################################################################/#######################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.reflect.Type[] typeArray0 = new java.lang.reflect.Type[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(typeArray0);
        org.junit.Assert.assertNotNull(typeArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "###################################################################################################\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ":", 8, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str4.equals("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "Virtua\nchine Specification", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "Mac OS X", 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.6", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "424.80-b11", (java.lang.CharSequence) "eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.l...", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle Corporation" + "'", str6.equals("Oracle Corporation"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("###################################################################################################\n", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################################\n" + "'", str2.equals("###################################################################################################\n"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "#########################", (java.lang.CharSequence) "#######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray5, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray5);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "JAVA PLATFa", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str9.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JavaPlatformAPISpecificatio", (java.lang.CharSequence) "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("OracleJava Virtual Machine SpecificationCorporation", 0, "hi!hihi!hi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleJava Virtual Machine SpecificationCorporation" + "'", str3.equals("OracleJava Virtual Machine SpecificationCorporation"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        long[] longArray6 = new long[] { 10L, 0, 10, (-1L), (byte) 10, '#' };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("US", (int) (byte) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                 \n                 ", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("un.lwwt.mcx.lwctlkt", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str2.equals("un.lwwt.mcx.lwctlkt"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) -1, 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Mac OS X", "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.", (int) '#', 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:." + "'", str4.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:."));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.CPrinterJob                        ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob                        " + "'", str3.equals("sun.lwawt.macosx.CPrinterJob                        "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(142, 52, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 142 + "'", int3 == 142);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                 \n                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_FREE_BSD;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(3L, (long) 10, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION" + "'", str1.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sophie", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(142, (int) (byte) 100, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) '4', (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sophie", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str1.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test055");
//        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
//        java.io.File[] fileArray1 = new java.io.File[] { file0 };
//        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(fileArray1);
//        org.junit.Assert.assertNotNull(file0);
//        org.junit.Assert.assertNotNull(fileArray1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.6", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "", (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                 \n                 ", strArray2, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                 \n                 " + "'", str7.equals("                 \n                 "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVAPLATFa", "", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "sun.lwawt.macosx.LWCToolkit", "Mac OS X", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "UTF-8", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.l...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.l...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("un.lwawt.macx.LWCTlkt", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macx.LWCTlkt                               " + "'", str2.equals("un.lwawt.macx.LWCTlkt                               "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "un.lwwt.mcx.LWCTlkt", (java.lang.CharSequence) "JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000", (int) (byte) 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle4Corporation", "/Users/sophie", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("i", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!hihi!hi", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hihi!hi" + "'", str2.equals("hi!hihi!hi"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("JAVA PLATFa", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                  Java(TM) SE Runtime Environment                                   ", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  Java(TM) SE Runtime Environment                                   " + "'", str2.equals("                                  Java(TM) SE Runtime Environment                                   "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", "1.21.21.71.71.21.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "x.LWCTlkt", "24.80-b11");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("i");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "un.lwwt.mcx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU/" + "'", str1.equals("eihpos/sresU/"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15" + "'", str4.equals("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "x.LWCTlkt", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x.LWCTlkt", 142, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("un.lwwt.mcx.LWCTlkt");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: un.lwwt.mcx.LWCTlkt is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("424.80-b11", "SOPHIE");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x.LWCTlkt", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "    1.7.0_80", 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 10, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("hi!", "###################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#########################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("JavaPlatformAPISpecification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JavaPlatformAPISpecification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ORACLE CORPORATION");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "e", (int) (short) 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                  Java(TM) SE Runtime Environment                                   ");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                    ", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 73");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15" + "'", str3.equals("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "e", "sun.lwawt.macosx.CPrinterJob                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("i");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1", 67, "###################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1##################################################################" + "'", str3.equals("1##################################################################"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        char[] charArray8 = new char[] { ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "###################################################################################################", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        char[] charArray4 = new char[] { ' ' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "i", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/", 0, "1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("HI!", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sophie", "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/", (java.lang.CharSequence) "#########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "Virtua\nchine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), 3L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "UTF-8", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE", 67, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "EIHPOS/SRESu/", "######################################################################/#######################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("          ", "a", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 12, (double) 19L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 19.0d + "'", double3 == 19.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "un.lwwt.mcx.lwctlkt", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "Virtua\nchine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", "                                  Java(TM) SE Runtime Environment                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "eihpos/sresU/", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORACLE CORPORATION", (int) (byte) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATION" + "'", str3.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "un.lwwt.mcx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "#########################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.2a1.2a1.7a1.7a1.2a1.7", 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2a1.2a1.7a1.7a1.2a1.7" + "'", str3.equals("1.2a1.2a1.7a1.7a1.2a1.7"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HI!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("JavaPlatformAPISpecification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaPlatformAPISpecification" + "'", str2.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!", 52, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("424.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "424.80-B11" + "'", str1.equals("424.80-B11"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1##################################################################", (java.lang.CharSequence) "1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("JAVAPLATFa", "/Users/sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                  Java(TM) SE Runtime Environment                                   ", (java.lang.CharSequence) "\n", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("VIRTUAL MACHINE SPECIFICATION      ", "10.14.3", 32);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VIRTUAL MACHINE SPECIFICATION      " + "'", str5.equals("VIRTUAL MACHINE SPECIFICATION      "));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "JavaPlatformAPISpecification", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("x86_64", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("eihpos/sresU/", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/" + "'", str2.equals("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("JAVA PLATFa", "JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA PLATFa" + "'", str2.equals("JAVA PLATFa"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("JAVAPLATFa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("eihpos/sresU/", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 'a', (float) (-1), (float) 35L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle4Corporation" + "'", str3.equals("Oracle4Corporation"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: e is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "i", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b15", 6, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE", "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142", 6);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE" + "'", str5.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 100, (double) 0L, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle4Corporation", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/", "                                  Java(TM) SE Runtime Environment                                   ", "10.14.3");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "U" + "'", str1.equals("U"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("eihpos/sresU/", "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/" + "'", str2.equals("eihpos/sresU/"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray1 = new java.io.File[] { file0 };
        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        java.io.File file4 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray5 = new java.io.File[] { file4 };
        java.io.File file6 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray7 = new java.io.File[] { file6 };
        java.io.File file8 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray9 = new java.io.File[] { file8 };
        java.io.File file10 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        java.io.File[] fileArray11 = new java.io.File[] { file10 };
        java.io.File[][] fileArray12 = new java.io.File[][] { fileArray1, fileArray3, fileArray5, fileArray7, fileArray9, fileArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(fileArray12);
        org.junit.Assert.assertNotNull(file0);
        org.junit.Assert.assertNotNull(fileArray1);
        org.junit.Assert.assertNotNull(file2);
        org.junit.Assert.assertNotNull(fileArray3);
        org.junit.Assert.assertNotNull(file4);
        org.junit.Assert.assertNotNull(fileArray5);
        org.junit.Assert.assertNotNull(file6);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(file8);
        org.junit.Assert.assertNotNull(fileArray9);
        org.junit.Assert.assertNotNull(file10);
        org.junit.Assert.assertNotNull(fileArray11);
        org.junit.Assert.assertNotNull(fileArray12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.2a1.2a1.7a1.7a1.2a1.7", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2a1.2a1.7a1.7a1.2a1.7" + "'", str2.equals("1.2a1.2a1.7a1.7a1.2a1.7"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 100, (long) 26, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142", "un.lwwt.mcx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142" + "'", str2.equals("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "24.80-b11" + "'", charSequence2.equals("24.80-b11"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "VIRTUAL MACHINE SPECIFICATION      ", 12, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str4.equals("/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      ", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "VIRTUAL MACHINE SPECIFICATION      ", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, (float) (short) 0, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("######################################################################/#######################################################################", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1", "EIHPOS/SRESu/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        char[] charArray6 = new char[] { ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.21.21.71.71.21.7", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!hihi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "###################################################################################################", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment", 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######" + "'", str1.equals("#######"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ", "424.80-b11", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("un.lwawt.macx.LWCTlkt", (float) 19L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 19.0f + "'", float2 == 19.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "424.80-b11", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Platform API Specification", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", (java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("###################################################################################################", (int) (byte) 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################################################" + "'", str3.equals("###################################################################################################"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6", (java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "                                                                 1.7.0_80-b15                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "un.lwwt.mcx.lwctlkt");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1##################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 67 + "'", int1 == 67);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 52, 6);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("JAVA HOTSPOT(TM) 64-BIT SERVER VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/lIB\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Mac OS X", "VIRTUAL MACHINE SPECIFICATION      ", "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.14.3", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HI!", (int) (short) 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!" + "'", str3.equals("HI!"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.2a1.2a1.7a1.7a1.2a1.7", (double) 142.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 142.0d + "'", double2 == 142.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                 \n                 ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/", "424.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/" + "'", str2.equals("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specification", 19, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "un.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", "SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190" + "'", str2.equals("/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("UTF-8", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2a1.2a1.7a1.7a1.2a1.7" + "'", str1.equals("1.2a1.2a1.7a1.7a1.2a1.7"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("VIRTUAL MACHINE SPECIFICATION      ", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VIRTUAL MACHINE SPECIFICATION      " + "'", str2.equals("VIRTUAL MACHINE SPECIFICATION      "));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "i", 97, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "OracleCorporation", (-1));
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("JavaPlatformAPISpecificatio", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Oracle4Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.2");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sophie", "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", (int) (byte) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str4.equals("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "Oracle \n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "hi!", 10);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.Class<?> wildcardClass13 = strArray7.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str11.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Oracle4Corporation", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!                                                                                                 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("VIRTUAL MACHINE SPECIFICATION      ", "1.2", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 26, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "Virtua\nchine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Virtua\nchine Specification" + "'", str2.equals("Virtua\nchine Specification"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("VIRTUAL MACHINE SPECIFICATION", "", "http://java.oracle.com/", 19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VIRTUAL MACHINE SPECIFICATION" + "'", str4.equals("VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.3", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", (java.lang.CharSequence) "Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                    ", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("x.LWCTlkt", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#########################", "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142" + "'", str2.equals("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("e", "", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!hihi!hi", 'a');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oracle Corporation");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "###################################################################################################\n", 52, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.2", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion2.toString();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 19.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 19.0d + "'", double3 == 19.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 'a', (float) 19, 1.6f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "######################################################################/#######################################################################", 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "Virtua\nchine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Oracle4Corporation", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specification", "1.6", "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi!hihi!hi", 19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    hi!hihi!hi     " + "'", str2.equals("    hi!hihi!hi     "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("US", (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "    1.7.0_80", 28, 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1##################################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1##################################################################" + "'", str2.equals("1##################################################################"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######" + "'", str1.equals("#######"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", "http://java.oracle.com/", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleJava Virtual Machine SpecificationCorporation", "1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(":", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("424.80-b11");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                    ", "UTF-8");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Oracle \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle" + "'", str1.equals("Oracle"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", (java.lang.CharSequence) "#########################");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", charSequence2.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                 1.7.0_80-b15                                                                 ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("VIRTUAL MACHINE SPECIFICATION", "1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 28, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#######" + "'", str1.equals("#######"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, 10, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "sophie", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                 1.7.0_80-b15                                                                 ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 1.7.0_80-b15                                                                 " + "'", str2.equals("                                                                 1.7.0_80-b15                                                                 "));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x.LWCTlkt", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x.LWCTlkt" + "'", str2.equals("x.LWCTlkt"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hihi!hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!hihi!hi");
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob                        ", 4, "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob                        " + "'", str3.equals("sun.lwawt.macosx.CPrinterJob                        "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "#######", (int) (byte) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str5.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str3.equals("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   " + "'", str1.equals("                                                                                                   "));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(":", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1.equals(1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("JavaPlatformAPISpecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("http://java.oracle.com/", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:" + "'", str2.equals("http:"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, 26, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle \n", "sophie", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \n" + "'", str3.equals("Oracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \n"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.3", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) 52, 142.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("VIRTUAL MACHINE SPECIFICATION      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: VIRTUAL MACHINE SPECIFICATION       is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("a", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie" + "'", str2.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str7 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7" + "'", str7.equals("1.7"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("OracleCorporation", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi" + "'", str2.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("x.LWCTlkt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x.LWCTlkt" + "'", str1.equals("x.LWCTlkt"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#######", 18, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "un.lwwt.mcx.LWCTlkt", (java.lang.CharSequence) "######################################################################/#######################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2a1.2a1.7a1.7a1.2a1.7" + "'", str1.equals("1.2a1.2a1.7a1.7a1.2a1.7"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                    ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 0, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7L, (-1.0f), (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "http:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "e", "EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      ", "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("http:");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("un.lwwt.mcx.lwctlkt", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str2.equals("un.lwwt.mcx.lwctlkt"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JAVA PLATFa", (java.lang.CharSequence) "x86_64", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("http:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "Oracle");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, (int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { ' ' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Virtua\nchine Specification", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("424.80-b11", "http:", "SOPHIE", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "424.80-b11" + "'", str4.equals("424.80-b11"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (byte) 10, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###################################################################################################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", (java.lang.CharSequence) "x.LWCTlkt");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray4, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1##################################################################", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str8.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double[] doubleArray4 = new double[] { (-1L), 10, (byte) 10, (short) 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS X", "Oracle");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("VIRTUAL MACHINE SPECIFICATION      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80", "hi!                                                                                                 ", "OracleCorporation", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.3", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "    1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "###################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie", "sun.lwawt.macosx.CPrinterJob                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str1.equals("/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1##################################################################", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("un.lwwt...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"un.lwwt...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#########################", "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", 7, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("un.lwwt.mcx.lwctlkt");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                 \n                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("JAVA PLATFa", 7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                    ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                 \n                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 \n                 " + "'", str1.equals("                 \n                 "));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Oracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \n");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Platform API Specification", "sun.l...", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironment", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (short) 1, (float) 7L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("un.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "eihpos/sresU/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENHCAMLAUTRVAVAJ/AVAJ/YRARBL/" + "'", str1.equals("ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENHCAMLAUTRVAVAJ/AVAJ/YRARBL/"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1##################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("un.lwwt.mcx.lwctlkt", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "sophie");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str4.equals("un.lwwt.mcx.lwctlkt"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str8.equals("un.lwwt.mcx.lwctlkt"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "###################################################################################################\n", (java.lang.CharSequence) "#######");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "###################################################################################################\n" + "'", charSequence2.equals("###################################################################################################\n"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "JavaPlatformAPISpecification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.2a1.2a1.7a1.7a1.2a1.7", (java.lang.CharSequence) "un.lwawt.macx.LWCTlktaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "424.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142" + "'", str1.equals("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("    hi!hihi!hi     ", "", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi     " + "'", str3.equals("    hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi     "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("424.80-B11", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11" + "'", str2.equals("424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_80-b15", "          ", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("24.80-b11", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str2.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("JAVA PLATFORM API SPECIFICATION", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA PLATFORM API SPECIFICATION" + "'", str3.equals("JAVA PLATFORM API SPECIFICATION"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#######", "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", "un.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11" + "'", str1.equals("424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("OracleCorporation", (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }
}

