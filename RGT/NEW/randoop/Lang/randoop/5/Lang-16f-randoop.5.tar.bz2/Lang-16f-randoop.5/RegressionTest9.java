import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        float[] floatArray4 = new float[] { 100L, 12, (-1L), 0 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray11, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray7, strArray11);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", strArray3, strArray7);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "sun.l...");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str15.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str17.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Oracle#Corporation", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Corporation#Oracle" + "'", str2.equals("Corporation#Oracle"));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("racleJava Virtual Machine SpecificationCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "racleJava Virtual Machine SpecificationCorporation" + "'", str1.equals("racleJava Virtual Machine SpecificationCorporation"));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("java platfa", (int) (byte) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java platfa" + "'", str3.equals("java platfa"));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', (int) '4', 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "un.lwawt.macx.LWCTlkt                               ", 5, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                 \n Un.lwawt.macx.LWCTlkt    ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aFTALPAVAJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aFTALPAVAJ" + "'", str1.equals("aFTALPAVAJ"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/T/ng0000c");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "444444444441##################################################################44444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("VIRTUAL MACHINE SPECIFICATION      ", "                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VIRTUAL MACHINE SPECIFICATION      " + "'", str2.equals("VIRTUAL MACHINE SPECIFICATION      "));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   " + "'", str2.equals("desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   "));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/T/ng0000c", (java.lang.CharSequence) "JavaPlatformAPISpec");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("un.lwawt.macx.LWCTlkt", "Oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleJava Virtual Machine SpecificationC", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        boolean boolean6 = javaVersion1.atLeast(javaVersion4);
        boolean boolean7 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean11 = javaVersion8.atLeast(javaVersion10);
        boolean boolean12 = javaVersion1.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "oRACLE \n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), (double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Corporation#Oracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 15, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("#########################", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####" + "'", str2.equals("####"));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "UTF-8", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit", strArray5, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str11.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.6" + "'", str14.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.6" + "'", str16.equals("1.6"));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATIO", (java.lang.CharSequence) "                      ", 89);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "    hi!hihi!hi     ", (java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT                                                                  ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "cosx.CPrinterJobawt.masun.lw", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation" + "'", str1.equals("OracleCorporation"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80-b15", "OracleJava Virtual Machine SpecificationCorporation/Users/sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HI!", "un.lwwt.mcx.lwctlkt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "######################################################################/#######################################################################", (java.lang.CharSequence) "ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENHCAMLAUTRVAVAJ/AVAJ/YRARBL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test37");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test38");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("vAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", "aaaaaaaaaa/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu" + "'", str2.equals("vAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu"));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test39");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test40");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Sun.lwUn.lwawt.macx.LWCTlkt                               t", 217);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 217 + "'", int2 == 217);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test41");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Un.lwawt.macx.LWCTlkt                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Un.lwaw\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test42");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray8 = new char[] { ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA PLATFa", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test43");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test44");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1", 217, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1" + "'", str3.equals("##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1"));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test45");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test46");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("http:", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:" + "'", str2.equals("http:"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test47");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "OracleJava Virtual Machine SpecificationCorporation", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test48");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 25, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test49");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("################44444444444", "", 59);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444" + "'", str3.equals("################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444################44444444444"));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test50");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("NOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu" + "'", str1.equals("nOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu"));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test51");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray13 = new char[] { ' ' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "eihpos/sresU/", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray13);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray13);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", charArray13);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "424.80-B11", charArray13);
        int int25 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test52");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("TNG0000CF4NX2N2QC3_4NZ956_SREDOFRA", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test53");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/                                                                              " + "'", str2.equals("0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/                                                                              "));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test54");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test55");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test56");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("NOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", "70_15602091904j/tmp/run_randoop.pl_94/Users/sophie/Documents/defects", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test57");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "!", (java.lang.CharSequence) "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test58");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test59");
        int[] intArray2 = new int[] { 1, 8 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test60");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                       bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test61");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 29, (long) 6, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test62");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test63");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.Class<?> wildcardClass13 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str11.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test64");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test65");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("cosx.CPrinterJob                        awt.masun.lw", "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/", "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test66");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("cosx.CPrinterJobawt.masun.lw");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test67");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 43L, 11.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test68");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation" + "'", str1.equals("OracleCorporation"));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test69");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test70");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "jAVA(tm) se rUNTIME eNVIRONMENT                                                                  ", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test71");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATIO", 100, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test72");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test73");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10.14.3a", (java.lang.CharSequence) "TNG0000CF4NX2N2QC3_4NZ956_SREDOFRA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test74");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("javaplatformapispecification", "JavaPlatformAPISpec", 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "javaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecification" + "'", str3.equals("javaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecificationJavaPlatformAPISpecjavaplatformapispecification"));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test75");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1##################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test76");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "                 \n                 ");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.2a1.2a1.7a1.7a1.2a1.7", 3);
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        java.lang.Class[] classArray10 = new java.lang.Class[2];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray11 = (java.lang.Class<?>[]) classArray10;
        wildcardClassArray11[0] = wildcardClass3;
        wildcardClassArray11[1] = wildcardClass8;
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray11);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(classArray10);
        org.junit.Assert.assertNotNull(wildcardClassArray11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str16.equals("class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test77");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "n", 14, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test78");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("mAC os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mAC os x" + "'", str1.equals("mAC os x"));
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test79");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("043");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "043" + "'", str1.equals("043"));
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test80");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "###################################################################################################\n", "                   Virtual Machine Specification                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test81");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 14, (long) 59, (long) 217);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 14L + "'", long3 == 14L);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test82");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) 28, (float) 99);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test83");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "", (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                 \n                 ", strArray2, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "e/library/java/javavirtualmachines/", (int) (byte) 0, (int) (byte) 1);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, "sun.l...", 4, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                 \n                 " + "'", str7.equals("                 \n                 "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Mac OS X" + "'", str11.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test84");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("http:", "S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:" + "'", str2.equals("http:"));
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test85");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("ORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATIONORACLE4CORPORATION", "ARY/jAVA/eXT", 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE4COARY/jAVA/eXTPORATION" + "'", str3.equals("ORACLE4COARY/jAVA/eXTPORATION"));
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test86");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test87");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test88");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                                                         endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test89");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sophie1.6", "/Library/Java/JavaVirtualM...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie1.6" + "'", str2.equals("sophie1.6"));
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test90");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test91");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 0, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }
}

