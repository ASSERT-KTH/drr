import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", (double) 11L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("jAVA pLATFORM api sPECIFICATION", "un.lwwt...", 5);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \nsophieOracle \n");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 29, 67.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("    1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.1    " + "'", str1.equals("08_0.7.1    "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "", (int) (short) 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, 2, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Eihpos/sresU/", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Eihpos/sresU/" + "'", str3.equals("Eihpos/sresU/"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sophie1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed                                                                                                   Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   " + "'", str2.equals("                                                                                                   "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHI", "  ", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", "sun.lwun.lwawt.macx.lwctlkt                               t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", "Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/", (int) 'a', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UEihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/JavaExtensions:usrlibjava:." + "'", str4.equals("UEihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/Eihpos/sresU/JavaExtensions:usrlibjava:."));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion3.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean11 = javaVersion8.atLeast(javaVersion10);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean13 = javaVersion5.atLeast(javaVersion8);
        boolean boolean14 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str15 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean19 = javaVersion16.atLeast(javaVersion18);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean21 = javaVersion18.atLeast(javaVersion20);
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean25 = javaVersion22.atLeast(javaVersion24);
        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean27 = javaVersion24.atLeast(javaVersion26);
        boolean boolean28 = javaVersion18.atLeast(javaVersion24);
        boolean boolean29 = javaVersion0.atLeast(javaVersion18);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.6" + "'", str15.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Oracle", "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O" + "'", str2.equals("O"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("jAVA pLATFORM api sPECIFICATION", "ICATION", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixedHI!mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("ICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ".:AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/ENOITACIFICEPSENIHCAMLAUTRIV/", (java.lang.CharSequence) "JAVA PLATFa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1", "Oracle ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1UN.LWAWT.MACX.lwctLKT                               7UN.LWAWT.MACX.lwctLKT                               0_80-UN.LWAWT.MACX.lwctLKT                               15", 10, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "X86_64", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("US", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#########################", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("http:", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http:" + "'", str2.equals("http:"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("u/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u/" + "'", str1.equals("u/"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        short[] shortArray2 = new short[] { (byte) 10, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA pLATFORM api sPECIFICATION", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 12, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("    hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "SOPHIE1.", (java.lang.CharSequence) "un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                 \n                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("\n");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", (-1), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4", (java.lang.CharSequence) "                 \n           un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "cosx.CPrinterJob                        awt.masun.lw", "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JavaPlatformAPISpec");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/T/ng0000c", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/T/ng0000c" + "'", str2.equals("/T/ng0000c"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("mixedHI!mode", "sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI" + "'", str2.equals("sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophi", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", "444444444444444444444444444444444444444444444444hi!44444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("OracleCorporationOracleCorporationOracleCorporationOracltx!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"OracleCorporationOracleCorporationOracleCorporationOracltx!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hihi!hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "x.LWCTlkt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.21.21.71.71.21.7", "E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.21.21.71.71.21.7" + "'", str2.equals("1.21.21.71.71.21.7"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "X SO", (java.lang.CharSequence) "jAVA(tm) s1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "OracleCorporation", (java.lang.CharSequence) "mAC os x", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                  mixed mode                                                                  ", "                                                                 1.7.0_80-b15                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  mixed mode                                                                  " + "'", str2.equals("                                                                  mixed mode                                                                  "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                  mixed mode                                                                  ", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", "(TM)  Rl el");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str2.equals("uSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", 720, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str3.equals("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) -1, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 142, (long) 'a', 2L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 142L + "'", long3 == 142L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.2a1.2a1.7a1.7a1.2a1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2a1.2a1.7a1.7a1.2a1.7" + "'", str1.equals("1.2a1.2a1.7a1.7a1.2a1.7"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "jAVA(tm) se rUNTIME eNVIRONMENT                                                                  ", "                                  Java(TM) SE Runtime Environment                                  ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   " + "'", str1.equals("desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   "));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "uSERSSOPHIElIBRARYj", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("jv pltform api specifiction", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jv pltform api specifiction" + "'", str2.equals("jv pltform api specifiction"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("tensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:." + "'", str2.equals("tensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_EIHPOS/SRESu/560209EIHPOS/SRESu/90/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("OracleJava Virtual Machine SpecificationCorporation", "S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racleJava Virtual Machine SpecificationCorporation" + "'", str2.equals("racleJava Virtual Machine SpecificationCorporation"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.21.21.71.71.21.7", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mAC os x", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("noitacificepS enihc\nautriV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITACIFICEPs ENIHC\nAUTRIv" + "'", str1.equals("NOITACIFICEPs ENIHC\nAUTRIv"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM)SERuntimeEnvironment" + "'", str1.equals("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi", (int) (short) -1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.3", 8, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3a" + "'", str3.equals("10.14.3a"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("uSERSSOPHIElIBRARYj", "hi!", 8);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "uSERSSOPHIElIBRARYj" + "'", str4.equals("uSERSSOPHIElIBRARYj"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "uSERSSOPHIElIBRARYj" + "'", str5.equals("uSERSSOPHIElIBRARYj"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwun.lwawt.macx.lwctlkt                               t");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_156020919", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("043", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        int[] intArray2 = new int[] { 1, 8 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                   ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11" + "'", str3.equals("424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaPlatformAPISpecification", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "NOITACIFICEPs ENIHC\nAUTRIv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(59, 12, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", "UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "e", (java.lang.CharSequence) "JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("jAVA(tm) se rUNTIME eNVIRONMENT", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senhcaMlautrVavaJ/avaJ/yrarbL/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(720, 22, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 720 + "'", int3 == 720);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/", "##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/" + "'", str2.equals("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7.0_80-b15", "08_0.7.1    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "un.lwUn.lwawt.macx.LWCTlkt                              ", (int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "SUN.LWAWT.MACOSX.LWCTOO...", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!hihi!hi", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###################################################################################################\n", strArray4, strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "NOITACIFICEPs ENIHC\nAUTRIv");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str5.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "###################################################################################################\n" + "'", str10.equals("###################################################################################################\n"));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle#Corporation", "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle#Corporation" + "'", str2.equals("Oracle#Corporation"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 15, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.", "JAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VMJAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:." + "'", str2.equals("uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:."));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob                        ", (java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        char[] charArray9 = new char[] { ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.21.21.71.71.21.7", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "444444444444\n444444444444", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.l...", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle " + "'", str2.equals("Oracle "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray3 = new java.io.File[] { file0, file1, file2 };
        java.io.File file4 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file5 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file6 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray7 = new java.io.File[] { file4, file5, file6 };
        java.io.File file8 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file9 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file10 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray11 = new java.io.File[] { file8, file9, file10 };
        java.io.File file12 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file13 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file14 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray15 = new java.io.File[] { file12, file13, file14 };
        java.io.File[][] fileArray16 = new java.io.File[][] { fileArray3, fileArray7, fileArray11, fileArray15 };
        java.io.File file17 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file18 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file19 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray20 = new java.io.File[] { file17, file18, file19 };
        java.io.File file21 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file22 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file23 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray24 = new java.io.File[] { file21, file22, file23 };
        java.io.File file25 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file26 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file27 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray28 = new java.io.File[] { file25, file26, file27 };
        java.io.File file29 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file30 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file31 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray32 = new java.io.File[] { file29, file30, file31 };
        java.io.File[][] fileArray33 = new java.io.File[][] { fileArray20, fileArray24, fileArray28, fileArray32 };
        java.io.File file34 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file35 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file36 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray37 = new java.io.File[] { file34, file35, file36 };
        java.io.File file38 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file39 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file40 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray41 = new java.io.File[] { file38, file39, file40 };
        java.io.File file42 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file43 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file44 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray45 = new java.io.File[] { file42, file43, file44 };
        java.io.File file46 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file47 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file48 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray49 = new java.io.File[] { file46, file47, file48 };
        java.io.File[][] fileArray50 = new java.io.File[][] { fileArray37, fileArray41, fileArray45, fileArray49 };
        java.io.File file51 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file52 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file53 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray54 = new java.io.File[] { file51, file52, file53 };
        java.io.File file55 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file56 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file57 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray58 = new java.io.File[] { file55, file56, file57 };
        java.io.File file59 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file60 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file61 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray62 = new java.io.File[] { file59, file60, file61 };
        java.io.File file63 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file64 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file65 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray66 = new java.io.File[] { file63, file64, file65 };
        java.io.File[][] fileArray67 = new java.io.File[][] { fileArray54, fileArray58, fileArray62, fileArray66 };
        java.io.File file68 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file69 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file70 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray71 = new java.io.File[] { file68, file69, file70 };
        java.io.File file72 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file73 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file74 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray75 = new java.io.File[] { file72, file73, file74 };
        java.io.File file76 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file77 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file78 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray79 = new java.io.File[] { file76, file77, file78 };
        java.io.File file80 = org.apache.commons.lang3.SystemUtils.getUserDir();
        java.io.File file81 = org.apache.commons.lang3.SystemUtils.getUserHome();
        java.io.File file82 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.io.File[] fileArray83 = new java.io.File[] { file80, file81, file82 };
        java.io.File[][] fileArray84 = new java.io.File[][] { fileArray71, fileArray75, fileArray79, fileArray83 };
        java.io.File[][][] fileArray85 = new java.io.File[][][] { fileArray16, fileArray33, fileArray50, fileArray67, fileArray84 };
        java.lang.String str86 = org.apache.commons.lang3.StringUtils.join(fileArray85);
        org.junit.Assert.assertNotNull(file0);
        org.junit.Assert.assertNotNull(file1);
        org.junit.Assert.assertNotNull(file2);
        org.junit.Assert.assertNotNull(fileArray3);
        org.junit.Assert.assertNotNull(file4);
        org.junit.Assert.assertNotNull(file5);
        org.junit.Assert.assertNotNull(file6);
        org.junit.Assert.assertNotNull(fileArray7);
        org.junit.Assert.assertNotNull(file8);
        org.junit.Assert.assertNotNull(file9);
        org.junit.Assert.assertNotNull(file10);
        org.junit.Assert.assertNotNull(fileArray11);
        org.junit.Assert.assertNotNull(file12);
        org.junit.Assert.assertNotNull(file13);
        org.junit.Assert.assertNotNull(file14);
        org.junit.Assert.assertNotNull(fileArray15);
        org.junit.Assert.assertNotNull(fileArray16);
        org.junit.Assert.assertNotNull(file17);
        org.junit.Assert.assertNotNull(file18);
        org.junit.Assert.assertNotNull(file19);
        org.junit.Assert.assertNotNull(fileArray20);
        org.junit.Assert.assertNotNull(file21);
        org.junit.Assert.assertNotNull(file22);
        org.junit.Assert.assertNotNull(file23);
        org.junit.Assert.assertNotNull(fileArray24);
        org.junit.Assert.assertNotNull(file25);
        org.junit.Assert.assertNotNull(file26);
        org.junit.Assert.assertNotNull(file27);
        org.junit.Assert.assertNotNull(fileArray28);
        org.junit.Assert.assertNotNull(file29);
        org.junit.Assert.assertNotNull(file30);
        org.junit.Assert.assertNotNull(file31);
        org.junit.Assert.assertNotNull(fileArray32);
        org.junit.Assert.assertNotNull(fileArray33);
        org.junit.Assert.assertNotNull(file34);
        org.junit.Assert.assertNotNull(file35);
        org.junit.Assert.assertNotNull(file36);
        org.junit.Assert.assertNotNull(fileArray37);
        org.junit.Assert.assertNotNull(file38);
        org.junit.Assert.assertNotNull(file39);
        org.junit.Assert.assertNotNull(file40);
        org.junit.Assert.assertNotNull(fileArray41);
        org.junit.Assert.assertNotNull(file42);
        org.junit.Assert.assertNotNull(file43);
        org.junit.Assert.assertNotNull(file44);
        org.junit.Assert.assertNotNull(fileArray45);
        org.junit.Assert.assertNotNull(file46);
        org.junit.Assert.assertNotNull(file47);
        org.junit.Assert.assertNotNull(file48);
        org.junit.Assert.assertNotNull(fileArray49);
        org.junit.Assert.assertNotNull(fileArray50);
        org.junit.Assert.assertNotNull(file51);
        org.junit.Assert.assertNotNull(file52);
        org.junit.Assert.assertNotNull(file53);
        org.junit.Assert.assertNotNull(fileArray54);
        org.junit.Assert.assertNotNull(file55);
        org.junit.Assert.assertNotNull(file56);
        org.junit.Assert.assertNotNull(file57);
        org.junit.Assert.assertNotNull(fileArray58);
        org.junit.Assert.assertNotNull(file59);
        org.junit.Assert.assertNotNull(file60);
        org.junit.Assert.assertNotNull(file61);
        org.junit.Assert.assertNotNull(fileArray62);
        org.junit.Assert.assertNotNull(file63);
        org.junit.Assert.assertNotNull(file64);
        org.junit.Assert.assertNotNull(file65);
        org.junit.Assert.assertNotNull(fileArray66);
        org.junit.Assert.assertNotNull(fileArray67);
        org.junit.Assert.assertNotNull(file68);
        org.junit.Assert.assertNotNull(file69);
        org.junit.Assert.assertNotNull(file70);
        org.junit.Assert.assertNotNull(fileArray71);
        org.junit.Assert.assertNotNull(file72);
        org.junit.Assert.assertNotNull(file73);
        org.junit.Assert.assertNotNull(file74);
        org.junit.Assert.assertNotNull(fileArray75);
        org.junit.Assert.assertNotNull(file76);
        org.junit.Assert.assertNotNull(file77);
        org.junit.Assert.assertNotNull(file78);
        org.junit.Assert.assertNotNull(fileArray79);
        org.junit.Assert.assertNotNull(file80);
        org.junit.Assert.assertNotNull(file81);
        org.junit.Assert.assertNotNull(file82);
        org.junit.Assert.assertNotNull(fileArray83);
        org.junit.Assert.assertNotNull(fileArray84);
        org.junit.Assert.assertNotNull(fileArray85);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("tensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.6", "424.80-b11/Users/sophie/Library/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/document" + "'", str2.equals("/users/sophie/document"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), 59L, 142L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 142L + "'", long3 == 142L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("OracleCorporation", 19, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporation" + "'", str3.equals("OracleCorporation"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 142, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        int[] intArray2 = new int[] { 1, 8 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 2, (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/..." + "'", str3.equals("/..."));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi" + "'", str2.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophi"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "un.lwwt...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVAuSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/e" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/e"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Sun.lwUn.lwawt.macx.LWCTlkt                               t", (java.lang.CharSequence) "Sun.lwUn.lwawt.macx.LWCTlkt                               t");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode                                                                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                 \n                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/T/ng0000c", charSequence1, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", (int) (short) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "               eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "##4###", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/users/sophie/document");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/document" + "'", str1.equals("/users/sophie/document"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "java platform api specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15", "ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENHCAMLAUTRVAVAJ/AVAJ/YRARBL/", 14);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "################44444444444", (java.lang.CharSequence) "cosx.CPrinterJob                        awt.masun.lw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("################44444444444", (int) 'a', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:", 67, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:" + "'", str3.equals("suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8" + "'", str1.equals("utf-8"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JAVA PLATFORM API SPECIFICATION", "E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1######", "n", "x86_64");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("424.80-b11/Users/sophie/Library/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"424.80-b11/Users/sophie/Library/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("SUN.LWAWT.s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.OSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.OSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str1.equals("SUN.LWAWT.s/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.OSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKITSUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                      ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      " + "'", str2.equals("                      "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1##################################################################", (java.lang.CharSequence) "1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.600000023841858d, (double) 10, (double) 59L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.600000023841858d + "'", double3 == 1.600000023841858d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ORACLE CORPORATION", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "un.lwawt.macx.LWCTlkt                               ", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "un.lwawt.macx.LWCTlkt", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SOPHIE", "JAVAPLATFa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAPLATFa" + "'", str2.equals("JAVAPLATFa"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "jv pltform api specifictio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("e", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e" + "'", str3.equals("e"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "SUN.L...IBRARY/JAVA/JAVAVIRTUALMACHI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1##################################################################", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1##################################################################" + "'", str2.equals("1##################################################################"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Virtual/Machine/Specification", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                   Virtual Machine Specification                   ", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   Virtual Machine Specification                   " + "'", str3.equals("                   Virtual Machine Specification                   "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("java platform api specification    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specification    " + "'", str1.equals("java platform api specification    "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("424.80-b11/Users/sophie/Library/", "VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11", "http:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b/:sers/sophie/ibrary/" + "'", str3.equals("b/:sers/sophie/ibrary/"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:", 17);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("424.80-b11/Users/sophie/Library/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "424.80-b11/Users/sophie/Library/" + "'", str1.equals("424.80-b11/Users/sophie/Library/"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190", "JavaPlatformAPISpecification");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "OracleJava Virtual Machine SpecificationCorporation/Users/sop", (java.lang.CharSequence) "                      ", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                   LRb//y                                                                                                   J                                                                                                   JVR/uMJRnEM                                                                                                   dk170_80dk                                                                                                   CEnEnM                                                                                                   HEE                                                                                                   /E                                                                                                   Rb                                                                                                   EndE/MEd", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   LRb//y                                                                                                   J                                                                                                   JVR/uMJRnEM                                                                                                   dk170_80dk                                                                                                   CEnEnM                                                                                                   HEE                                                                                                   /E                                                                                                   Rb                                                                                                   EndE/MEd" + "'", str2.equals("                                                                                                   LRb//y                                                                                                   J                                                                                                   JVR/uMJRnEM                                                                                                   dk170_80dk                                                                                                   CEnEnM                                                                                                   HEE                                                                                                   /E                                                                                                   Rb                                                                                                   EndE/MEd"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Virtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/Specification", "uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:." + "'", str2.equals("uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:."));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("java platform api specification    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java platform api specification    " + "'", str1.equals("java platform api specification    "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) -1, (byte) 10, (byte) 0, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 720);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        char[] charArray9 = new char[] { ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "eihpos/sresU/", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/7/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0_80-/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", 29, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str3.equals("/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Mac OS X", charSequence1, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        int[] intArray2 = new int[] { 1, 8 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.Class<?> wildcardClass5 = intArray2.getClass();
        java.lang.Class<?> wildcardClass6 = intArray2.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("e/library/java/javavirtualmachines/", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI", "uSER############SOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI" + "'", str2.equals("sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                    SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str11.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.CPrinterJobaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("cosx.CPrinterJobawt.masun.lw", "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.CPrinterJobawt.masun.lw" + "'", str2.equals("cosx.CPrinterJobawt.masun.lw"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("#################################################", "etnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################" + "'", str2.equals("#################################################"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                 \n                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "E", (java.lang.CharSequence) "e/library/java/javavirtualmachines/", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("vAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("cosx.CPrinterJob                        awt.masun.lw");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cosx.CPrinterJob                        awt.masun.lw" + "'", str1.equals("cosx.CPrinterJob                        awt.masun.lw"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/" + "'", str1.equals("0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444SOPHIE");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.6" + "'", str4.equals("1.6"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        short[] shortArray1 = new short[] { (byte) 1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.Class<?> wildcardClass4 = shortArray1.getClass();
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray4, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "      ");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "hi!                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str8.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str13.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 6, (float) (byte) 0, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "08_0.7.1    ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ORACLE ", (java.lang.CharSequence) "OracleJava Virtual Machine SpecificationCorporation/Users/sop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hihi!hi", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "424.80-b11/Users/sophie/Library/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!hihi!hi" + "'", str6.equals("hi!hihi!hi"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 27L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 27L + "'", long3 == 27L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("###########################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", "", (int) (short) 1);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                 \n           un.lwawt.macx.LWCTlkt                               ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "        ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("          ", "                                                                  mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                                                                                    mixed mode                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0919020651_079_lp.poodnar_nur/pmt/jstcefed/stnemucoD/epos/sresU/", (java.lang.CharSequence) "1UN.LWAWT.MACX.lwctLKT                               7UN.LWAWT.MACX.lwctLKT                               0_80-UN.LWAWT.MACX.lwctLKT                               15", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444444444444444444444444444444444", "Library                                                                                                   Java                                                                                                   JavaVirtualMachines                                                                                                   jdk1.7.0_80.jdk                                                                                                   Contents                                                                                                   Home                                                                                                   jre                                                                                                   lib                                                                                                   endorsed", "JavaPlatformAPISpecification", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("4444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Users/sophie/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/Users/sophie"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaSUN.LWAWT.MACOSX.LWCTOOLKITaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("######################################################################/#######################################################################", "000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "n", 15, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java(TM)SERuntimeEnvironment", 142, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironment" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                  mixed mode                                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("mixed mode aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/" + "'", str1.equals("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444444444444444444444444444444444", "sun.lwawt.macosx.CPrinterJob                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                   Virtual Machine Specification                   ", (int) (short) 1, "1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   Virtual Machine Specification                   " + "'", str3.equals("                   Virtual Machine Specification                   "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        short[] shortArray2 = new short[] { (byte) 10, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4Corporation", "10.14.3a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "un.lwUn.lwawt.macx.LWCTlkt                               ", (java.lang.CharSequence) "oRACLE ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_156020919", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_156020919" + "'", str2.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_156020919"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####" + "'", str2.equals("####"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("jAVA pLATFORM api sPECIFICATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        char[] charArray9 = new char[] { ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!44444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA HOTSPOT(TM) 64-BIT SERVER VM", (-1), "un.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecificationJavaPlatformAPISpecification", 23);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        char[] charArray4 = new char[] { ' ' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "OracleJava Virtual Machine SpecificationC", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "/VIRTUALMACHINESPECIFICATIONE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "javaplatfa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("java platform api specification    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("###################################################################################################", "", "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################################################################" + "'", str3.equals("###################################################################################################"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Virtua\nchine Specification", "sun.l...IBRARY/JAVA/JAVAVIRTUALMACHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("OracleJava Virtual Machine SpecificationCorporation", "Sun.lwawt.macosx.LWCToolkit", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleJava Virtual Machine SpecificationCorporation" + "'", str3.equals("OracleJava Virtual Machine SpecificationCorporation"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle4Corporation", 720);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 720 + "'", int2 == 720);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("x.LWCTlkt");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                    ", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "1##################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        char[] charArray8 = new char[] { ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\n", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444444444444444444444444444444444444444444hi!44444444", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Sun.lwUn.lwawt.macx.LWCTlkt                               t", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatklTCWL.xcam.twawl.nu", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 67L, (double) 54, (double) 26);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 67.0d + "'", double3 == 67.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "1.6");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1UN.LWAWT.MACX.lwctLKT                               7UN.LWAWT.MACX.lwctLKT                               0_80-UN.LWAWT.MACX.lwctLKT                               15");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        boolean boolean6 = javaVersion1.atLeast(javaVersion4);
        boolean boolean7 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str8 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.1" + "'", str8.equals("1.1"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie", 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oRACLE ", 59, "    hi!hihi!hi     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE     hi!hihi!hi         hi!hihi!hi         hi!hihi!hi" + "'", str3.equals("oRACLE     hi!hihi!hi         hi!hihi!hi         hi!hihi!hi"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "tx!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("un.lwUn.lwawt.macx.LWCTlkt                               ", "444444444444\n444444444444", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/7/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0_80-/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/15", (java.lang.CharSequence) "1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", (int) '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "http:");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "mixed mode", 32, 3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("S/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ".:AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/ENOITACIFICEPSENIHCAMLAUTRIV/", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                 \n                 ", "Un.lwawt.macx.LWCTlkt", 19, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                 \n Un.lwawt.macx.LWCTlkt    " + "'", str4.equals("                 \n Un.lwawt.macx.LWCTlkt    "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                    ", "OracleCorporation", (-1));
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("en", (double) 217);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 217.0d + "'", double2 == 217.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################################################################################################", "4444444444444444444444444444444444444444444444444444444444444", 59);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Oracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle" + "'", str1.equals("Oracle"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/T/NG0000C");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/T/NG0000C\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##4###", (int) (byte) 100, "Virtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Virtual/Machine/SpecificationVirtual/Machine/Sp##4###Virtual/Machine/SpecificationVirtual/Machine/Sp" + "'", str3.equals("Virtual/Machine/SpecificationVirtual/Machine/Sp##4###Virtual/Machine/SpecificationVirtual/Machine/Sp"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("un.lwwt.mcx.lwctlkt", 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle#Corporation", strArray3, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str5.equals("un.lwwt.mcx.lwctlkt"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "un.lwwt.mcx.lwctlkt" + "'", str7.equals("un.lwwt.mcx.lwctlkt"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Oracle#Corporation" + "'", str11.equals("Oracle#Corporation"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                      ", "", 89);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        char[] charArray10 = new char[] { ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/7/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0_80-/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/15", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/T/NG0000C", 0, "SOPHIE1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/T/NG0000C" + "'", str3.equals("/T/NG0000C"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Virtual Machine Specification" + "'", str1.equals("Virtual Machine Specification"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu" + "'", str2.equals("NOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!                                                                                                 ", (java.lang.CharSequence) "Oracle4Corporation", 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("EIHPOS/SRESu/suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sY", 2944);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("jAVA(tm) se rUNTIME eNVIRONMENT                                                                  ", "tfa plavaj", "44444444444444444444444444444444444", 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT                                                                  " + "'", str4.equals("jAVA(tm) se rUNTIME eNVIRONMENT                                                                  "));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("ICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("UserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "userssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:." + "'", str1.equals("userssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:."));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/######################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensio", (java.lang.CharSequence) "                                                                                                   LRb//y                                                                                                   J                                                                                                   JVR/uMJRnEM                                                                                                   dk170_80dk                                                                                                   CEnEnM                                                                                                   HEE                                                                                                   /E                                                                                                   Rb                                                                                                   EndE/MEd");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################" + "'", str1.equals("#################################################"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.mOracleaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.m", "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O" + "'", str2.equals("O"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/v4r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/v4r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/v4r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) 4);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(".:AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/ENOITACIFICEPSENIHCAMLAUTRIV/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".:AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/ENOITACIFICEPSENIHCAMLAUTRIV/" + "'", str1.equals(".:AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/ENOITACIFICEPSENIHCAMLAUTRIV/"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) 2, (long) 22);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x.LWCTlkt");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosxJAVAPLATFasun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "", (int) '4');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "eihpos/sresU/");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("    1.7.0_80", strArray3, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1, (byte) 1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("i", "un.lwwt.mcx.lwctlkt", "444444444444\n444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 59, 7.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 59.0f + "'", float3 == 59.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                 \n                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ICATION" + "'", str1.equals("ICATION"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/", "snetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM) SE Runtime Environment", (java.lang.CharSequence) "hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                       bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   " + "'", str2.equals("                                                       bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   "));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                      ", "", 27, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle4Corporation", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle4Corporation" + "'", str2.equals("Oracle4Corporation"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", "racleJava Virtual Machine SpecificationCorporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        double[] doubleArray4 = new double[] { (-1L), 10, (byte) 10, (short) 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM)SERuntimeEnvironment", "hI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM)SERuntimeEnvironment" + "'", str2.equals("/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jJava(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        long[] longArray3 = new long[] { (short) -1, 97, 52L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle4Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "NOITACIFICEPs ENIHC\nAUTRIv", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/T/ng0000c", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("424.80-b11/Users/sophie/Library/", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "424.80-b11/Users/sophie/Library/" + "'", str3.equals("424.80-b11/Users/sophie/Library/"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("US", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed mode                                                                  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "", (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("un.lwwt.mcx.LWCTlkt", ":");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray5, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_970_156020919", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Mac OS X" + "'", str7.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "51.0" + "'", str11.equals("51.0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Un.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("uTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uTF-8" + "'", str1.equals("uTF-8"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/v4r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/v4r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/v4r/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/T/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, (long) (byte) 10, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi!hihi!hi", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str4.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str6.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sophie1.6", 99, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        char[] charArray8 = new char[] { ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "eihpos/sresU/", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T//var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/t/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "HI!/Users/so/Library/Java/JavaVirtualMachines/jdk1.7", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TNG0000CF4NX2N2QC3_4NZ956_SREDOFRA" + "'", str4.equals("TNG0000CF4NX2N2QC3_4NZ956_SREDOFRA"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar", "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar" + "'", str2.equals("/Users/so/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedrent.jar"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("jAVA(tm) s1.6", "    1.7.0_80", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6" + "'", str3.equals("jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "racleJava Virtual Machine SpecificationCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("          ", "/VIRTUAL MACHINE SPECIFICATION      E/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "desrodnebilerjemoHstnetnoCkdj.08_0.7.1kdjsenihcaMlautriVavaJavaJyrarbiL");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("IBRARY/JAVA/JAVAVIRTUALMACHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IBRARY/JAVA/JAVAVIRTUALMACHI" + "'", str1.equals("IBRARY/JAVA/JAVAVIRTUALMACHI"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        int[] intArray4 = new int[] { 35, 67, 97, (short) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolkit", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwwt.mcosx.LWCToolkit" + "'", str2.equals("sun.lwwt.mcosx.LWCToolkit"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "un.lwUn.lwawt.macx.LWCTlkt");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1######", (java.lang.CharSequence) " enihc\nautriV", 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        float[] floatArray3 = new float[] { '4', 1L, 10L };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 52.0f + "'", float6 == 52.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("cosx.CPrinterJob                        awt.masun.lw", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.CPrinterJob                        awt.masun.lw" + "'", str2.equals("cosx.CPrinterJob                        awt.masun.lw"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "OracleJava Virtual Machine SpecificationC", 6, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "u/", (java.lang.CharSequence) "1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/VIRTUALMACHINESPECIFaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/VIRTUALMACHINESPECIF", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VIRTUALMACHINESPECIFaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/VIRTUALMACHINESPECIF" + "'", str2.equals("/VIRTUALMACHINESPECIFaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/VIRTUALMACHINESPECIF"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("            javaplatfA             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"javaplatfA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("OracleCorporation", "ICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporation" + "'", str2.equals("OracleCorporation"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        byte[] byteArray5 = new byte[] { (byte) 10, (byte) -1, (byte) -1, (byte) -1, (byte) 1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 10 + "'", byte13 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        int[] intArray3 = new int[] { 19, (byte) 0, 26 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 26 + "'", int5 == 26);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 26 + "'", int6 == 26);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed                 ", (java.lang.CharSequence) "##SOPHIE1.##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/##########################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("  ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "javaplatfa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray12, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", strArray4, strArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "u/");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str16.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str18.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(strArray21);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HIE1.6", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HIE1.6" + "'", str2.equals("HIE1.6"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("OracleCorporation", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "444444444441##################################################################44444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 89 + "'", int1 == 89);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Virtual/Machine/SpecificationVirtual/Machine/Sp##4###Virtual/Machine/SpecificationVirtual/Machine/Sp");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "1.21.21.71.71.21.7");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("sun.lwawt.macosx.LWCToolkit", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "X86_64", 32, (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str8.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/" + "'", str1.equals("ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                  ", (java.lang.CharSequence) "VIRTUAL MACHINE SPECIFICATION      -B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mod1.6", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', (long) 23, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#######", (java.lang.CharSequence[]) strArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 35, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "#########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("O");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "o" + "'", str1.equals("o"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Lbrary/Java/JavaVrtualMachnes/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION", (java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        long[] longArray6 = new long[] { (-1), (byte) 0, (byte) -1, (-1L), ' ', (short) 100 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("un.lwwt.mcx.LWCTlkt", ":");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwwt.mcosx.LWCToolkit", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15", "1/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/7/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/0_80-/:ders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15" + "'", str2.equals("1                   Virtual Machine Specification                   7                   Virtual Machine Specification                   0_80-                   Virtual Machine Specification                   15"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1##################################################################", (java.lang.CharSequence) "JAVA PLATFORM API SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "TNG0000CF4NX2N2QC3_4NZ956_SREDOFRA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "Virtual/Machine/SpecificationVirtual/Machine/Sp##4###Virtual/Machine/SpecificationVirtual/Machine/Sp", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_64", "java platform api specification    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "###################################################################################################\n", (java.lang.CharSequence) "a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahttp:");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("###################################################################################################\n", "enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/##########################################################", (java.lang.CharSequence) "vAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JAVAPLATFa", (java.lang.CharSequence) "##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1##################################################################1", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "sophi", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("e");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean12 = javaVersion0.atLeast(javaVersion7);
        java.lang.String str13 = javaVersion7.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.2" + "'", str13.equals("1.2"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/moc.elcaro.avaj//:ptthrs/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie", "", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA PLATFa", "                 \n Un.lwawt.macx.LWCTlkt    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/", 61);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/" + "'", str2.equals("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/srhttp://java.oracle.com/"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444444444444444444444444444/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6", "suSERSSOPHIElIBRARYjAVAeXTENSIONS:lIBRARYjAVAeXTENSIONS:nETWORKlIBRARYjAVAeXTENSIONS:sYSTEMlIBRARYjAVAeXTENSIONS:USRLIBJAVA:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6" + "'", str2.equals("jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6    1.7.0_80jAVA(tm) s1.6"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) " enihc\nautriV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("4", "444444444441##################################################################44444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/", "444444444444444444444444444444444444444444444444hi!44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/" + "'", str2.equals("enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/enihpos/sresU/"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", (java.lang.CharSequence) "/Users/sope/Documents/defectsj/tmp/run_randoop.pl_970_1560209190", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 2L, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "NOITACIFICEPs ENIHC\nAUTRIv", (java.lang.CharSequence) "424.80-b11/Users/sophie/Library/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "etnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(12, 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "ARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(142L, (long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean10 = javaVersion7.atLeast(javaVersion9);
        boolean boolean11 = javaVersion0.atLeast(javaVersion7);
        java.lang.String str12 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.2" + "'", str12.equals("1.2"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "mixed mode aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("desrodne                                                                                                   bil                                                                                                   erj                                                                                                   emoH                                                                                                   stnetnoC                                                                                                   kdj.08_0.7.1kdj                                                                                                   senihcaMlautriVavaJ                                                                                                   avaJ                                                                                                   yrarbiL                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444hi!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oRACLE \n", (java.lang.CharSequence) "E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "RY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.3a", "javaplatfA", "Oracle ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3a" + "'", str3.equals("10.14.3a"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.21.21.71.71.21.7");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "################44444444444", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", 6, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("    hi!hihi!hi         hi!hihi!hi    #########################   hi!hihi!hi         hi!hihi!hi     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean9 = javaVersion6.atLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean14 = javaVersion11.atLeast(javaVersion13);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean16 = javaVersion8.atLeast(javaVersion11);
        boolean boolean17 = javaVersion3.atLeast(javaVersion8);
        java.lang.String str18 = javaVersion3.toString();
        boolean boolean19 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.6" + "'", str18.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "JavaPlatformAPISpec", 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("E/LIBRARY/JAVA/JAVAVIRTUALMACHINES/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e/library/java/javavirtualmachines/" + "'", str1.equals("e/library/java/javavirtualmachines/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                                                                                                                                                                                    SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                    SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/                                                                                                                                                                                                                                                                     " + "'", str1.equals("                                                                                                                                                                                                                                                                    SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("oRACLE ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!hihi!hi", "/T/ng0000c");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hihi!hi" + "'", str2.equals("hi!hihi!hi"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "OracleJava Virtual Machine SpecificationC", (java.lang.CharSequence) "cosx.CPrinterJob                        awt.masun.lw");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "###################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("NOITACIFICEPs ENIHC\nAUTRIv");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.0f, (float) 8, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.2", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) (short) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean5 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
        boolean boolean10 = javaVersion4.atLeast(javaVersion6);
        java.lang.String str11 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean16 = javaVersion13.atLeast(javaVersion15);
        boolean boolean17 = javaVersion12.atLeast(javaVersion15);
        boolean boolean18 = javaVersion6.atLeast(javaVersion12);
        java.lang.String str19 = javaVersion12.toString();
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean22 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean26 = javaVersion23.atLeast(javaVersion25);
        boolean boolean27 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean31 = javaVersion28.atLeast(javaVersion30);
        boolean boolean32 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
        boolean boolean33 = javaVersion25.atLeast(javaVersion28);
        boolean boolean34 = javaVersion20.atLeast(javaVersion25);
        java.lang.String str35 = javaVersion20.toString();
        boolean boolean36 = javaVersion12.atLeast(javaVersion20);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.6" + "'", str11.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.1" + "'", str19.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1.6" + "'", str35.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        long[] longArray6 = new long[] { (-1), (byte) 0, (byte) -1, (-1L), ' ', (short) 100 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#########################", (int) (short) 4, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################" + "'", str3.equals("#########################"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94470_1560209190/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/" + "'", str1.equals("erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senhcamlautrvavaj/avaj/yrarbl/"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("HI!", "08_0.7.1    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("eihpos/sresU/", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatklTCWL.xcam.twawl.nu", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("userssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:.", "hie1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("424.80-b11424.80-b11424.80-b11424.80-b11424.80-b1142");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nsophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("NOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", 142, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", "Virtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/SpecificationVirtual/Machine/Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "    hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi         hi!hihi!hi     ", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11424.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1un.lwawt.macx.LWCTlkt                               7un.lwawt.macx.LWCTlkt                               0_80-un.lwawt.macx.LWCTlkt                               15", 67);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("vAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hie1.6", (int) (short) 10, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("jAVA(tm) se rUNTIME eNVIRONMENT                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT                                                                  " + "'", str1.equals("jAVA(tm) se rUNTIME eNVIRONMENT                                                                  "));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("SNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/" + "'", str1.equals("sNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("###################################################################################################\n", (int) (short) 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################################################################\n" + "'", str2.equals("###################################################################################################\n"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4CorporationOracle4Corporation", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("SOPHIE1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: SOPHIE1.6 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defe    1.7.0_80e/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                 \n                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "SUN.L...IBRARY/JAVA/JAVAVIRTUALMACHI", (java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("un.lwwt.mcx.lwctlkt");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATIO", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JVUSERSSOPHIELIBRRYJVEXTENSIONS:LIBRRYJVEXTENSIONS:NETWORKLIBRRYJVEXTENSIONS:SYSTEMLIBRRYJVEXTENSIONS:USRLIBJV:./USERS/SOPHIE/LIBRRY/JV/EXTENSIONS:/LIBRRY/JV/JVVIRTULMCHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRRY/JV/EXTENSIONS:/NETWORK/LIBRRY/JV/EXTENSIONS:/SYSTEM/LIBRRY/JV/EXTENSIONS:/USR/LIB/JV");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "", 28, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "un.lwwt.mcx.LWCTlkt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##4###", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##4###" + "'", str3.equals("##4###"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("un.lwawt.macx.LWCTlkt                               ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaUserssophieLibraryJavaExtensions:LibraryJavaExtensions:NetworkLibraryJavaExtensions:SystemLibraryJavaExtensions:usrlibjava:./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 18, 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Oracle#Corporation", 142, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }
}

