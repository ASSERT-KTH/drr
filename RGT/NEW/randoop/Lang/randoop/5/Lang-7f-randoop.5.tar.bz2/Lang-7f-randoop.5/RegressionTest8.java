import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mixed modem\n     mixed modemi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        char[] charArray6 = new char[] { 'a', '#', '4', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', (int) (short) 100, (int) 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444a", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(".34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE10.1", "44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment", "                                         10 10 10 10");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("97 35 31 31", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("jAVA pLATFORM api sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVA pLATFORM api sPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.6                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("achine ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("3#.#41#.#01", "-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3#.#41#.#0" + "'", str2.equals("3#.#41#.#0"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "97a35a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/J######################################1.2/Library/J#######################################", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/J######################################1.2/Library/J#######################################" + "'", str2.equals("/Library/J######################################1.2/Library/J#######################################"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("-141", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141" + "'", str2.equals("-141"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978", (java.lang.CharSequence) "100a-1a100a144444444444444444...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(27L, 10L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#a a a#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a a a#" + "'", str1.equals("#a a a#"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("F-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "f-" + "'", str1.equals("f-"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("      ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cosx.LWCToolkitawt.masun.lw", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1#0#10#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("souvrilllllllllllllllllllllllllllll");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "souvrillllllllllllllllllllllllllll" + "'", str1.equals("souvrillllllllllllllllllllllllllll"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("97 35 -1 -1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97 35 -1 -1" + "'", str2.equals("97 35 -1 -1"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("SUN.AWT.CGRAPHICSENVIRONMENT                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("nenenenenenenenenenenenenene", "#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.4", "3#.#41#.#01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Oracle Corporation", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Corporation" + "'", str2.equals("Corporation"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14141004100" + "'", str12.equals("-14141004100"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        char[] charArray7 = new char[] { ' ', '4', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "3.41.01", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1#1#100#100", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specificatio", "0.0");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 21, 175);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(26.0d, (double) 31, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 26.0d + "'", double3 == 26.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-B1", (java.lang.CharSequence) "                                                100a-1a100a14444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                     sun.awt.CGraphicsEnvironment", "#########a", 29);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                     sun.awt.CGraphicsEnvironment" + "'", str4.equals("                                                                     sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                                                     sun.awt.CGraphicsEnvironment" + "'", str5.equals("                                                                     sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1 1 100 100", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444-1 1 100 1004444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444-1 1 100 1004444444444444444444444444444444444444444444"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ESCIHPARGC.TWA.NU", ".2", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.Class<?> wildcardClass9 = floatArray2.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 10.0" + "'", str8.equals("1.0 10.0"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.0410.0" + "'", str11.equals("1.0410.0"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("e");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Specifi...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specifi..." + "'", str2.equals("Specifi..."));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL", 56);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                     sun.awt.cgraphicsenvironment", 33, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                     sun.awt.cgraphicsenvironment" + "'", str3.equals("                                                                     sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 0, (byte) 0 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) ".", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 1, (double) 52L, (double) 21L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                100a-1a100a14444444444444444444444444444444444444444", (java.lang.CharSequence) "aMixed modea");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "achine ", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar.34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEM", 75);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r.34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEM" + "'", str2.equals("r.34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEM"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java(TM)4SE4Runtime4Environment", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str2.equals("Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm" + "'", str2.equals("achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "UTF-8");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-", strArray4, strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, ' ', 1004041, (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTF-" + "'", str11.equals("UTF-"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("at air", "100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("souvrillllllllllllllllllllllllllll", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "souvrillllllllllllllllllllllllllll" + "'", str2.equals("souvrillllllllllllllllllllllllllll"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", 67, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("mixed mode444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 21L, 28.0f, (float) 15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1", 33, 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaa-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1            1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaa-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1            1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 1, (byte) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10414100" + "'", str5.equals("10414100"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("         ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Library/J######################################1.2/Library/J#######################################", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1a1a100a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a1a100a10" + "'", str1.equals("-1a1a100a10"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1", "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1" + "'", str2.equals(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100#-1#100#1", (float) 21L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "a a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "a aOracleCorporationa aO100 0 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("jAVAvIRTUALmACHINEsPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"jAVAvIRTUALmACHINEsPECIFICATION\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        short[] shortArray1 = new short[] { (byte) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#   A 4  ", (java.lang.CharSequence) "#a a a#", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-141004");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java(TM)4SE4Runtime4Environment", (java.lang.CharSequence) " ", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        short[] shortArray1 = new short[] { (byte) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.Class<?> wildcardClass13 = shortArray1.getClass();
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 0, (int) (byte) -1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100 -1 100 1", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100 -1 100 1" + "'", str9.equals("100 -1 100 1"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 1, (byte) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10414100" + "'", str5.equals("10414100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10#1#100" + "'", str7.equals("10#1#100"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-141", "mnorivne emitnur es )mt(avaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141" + "'", str2.equals("-141"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100a0a10", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "cosx.LWCToolkitawt.masun.lw");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 12L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 8, 97);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Platform API Specificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specificatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0410.0Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4R", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001" + "'", str1.equals("001"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                 -1", (int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 -1" + "'", str3.equals("                                 -1"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1004-1410041", (java.lang.CharSequence) "100a-1a100a144444444444444444...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment     sun.awt.cgraphicsenvironment", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "97 35 -1 -1", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mv REVREs TIb-46 )mt(TOPsTOh AVAj");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.6                   ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("cosx.LWCTo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cosx.LWCTo" + "'", str1.equals("cosx.LWCTo"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("a#a", "souvrilllllllllllllllllllllllllllll");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#a" + "'", str2.equals("a#a"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        double[] doubleArray1 = new double[] { 1.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0414100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("041041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "140140" + "'", str1.equals("140140"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("24.80-b11", "1.3", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "974354-14-1", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-141004");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_156027697810/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769781", (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificatio" + "'", str1.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("# 4", "", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-" + "'", str1.equals("1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATION" + "'", str1.equals("jAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("-14141004100", "SPECIFICATIO API PLATFORM JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14141004100" + "'", str2.equals("-14141004100"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                                                        1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "l Machine Specification");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "97a35a-1a-1", 20, 1004041);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "-1a1a100a10", (java.lang.CharSequence) " OrcleCorportion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 97, (int) (short) 10);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        float float18 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.0 10.0" + "'", str17.equals("1.0 10.0"));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 10.0f + "'", float18 == 10.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str1.equals("XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97 35 -1 -1" + "'", str9.equals("97 35 -1 -1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "974354-14-1" + "'", str12.equals("974354-14-1"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-B11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("l Machine Specificatio", "", (int) (byte) 100);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("cosx.LWCToolkitawt.masun.lw", "Mixed mode", (int) (byte) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", strArray4, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '#');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "-141004");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, "a#a");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, '#', 49, 4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str9.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "cosx.LWCToolkitawt.masun.lw" + "'", str11.equals("cosx.LWCToolkitawt.masun.lw"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "cosx.LWCToolkitawt.masun.lw" + "'", str15.equals("cosx.LWCToolkitawt.masun.lw"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, '4', 28, 10);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray2, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA V", charArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray2, '#', 29, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (int) '#', 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OS XMac OS " + "'", str3.equals(" OS XMac OS "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT                                                                        ", "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaa-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1            1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) ".0410.0Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4R");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mv REVREs TIb-46 )mt(TOPsTOh AVAj", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "24.80-b11276978ry/Ja/", (java.lang.CharSequence) " XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#   a 4", (java.lang.CharSequence) "l Machine Specificationa a", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ESCIHPARGC.TWA.NU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ESCIHPARGC.TWA.NU" + "'", str1.equals("ESCIHPARGC.TWA.NU"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "140140");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.6                   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 22 + "'", int1 == 22);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10#10#10#1046_68x46_68x46_68x46_68x", (java.lang.CharSequence) "tnemnorivnE4emitnuR4ES4)MT(avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("46_68x", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                          ry/Ja/Libr", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Libra                                                                                          ry/J" + "'", str2.equals("/Libra                                                                                          ry/J"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(":", "10.0", "                                 -1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                             100404", "r.34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEM", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".", "ificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                           1400141-4001                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#   a 4  ", "                    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 1004041, 5);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', 20, 3);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 5, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97 35 -1 -1" + "'", str9.equals("97 35 -1 -1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("    n     ", 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n     " + "'", str2.equals("    n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n     "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 28, 10);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "JAVA V", charArray3);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "# 4", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                    ", "I44444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    " + "'", str2.equals("                    "));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ".2", (java.lang.CharSequence) " OS XMac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                i");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                i" + "'", str1.equals("                                                                                                i"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "\n/", (java.lang.CharSequence) "\n     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("97 35 31 31", "1.7so...on", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("     sun.awt.cgraphicsenvironment", "974354-14-", 300);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     sun.awt.cgraphicsenvironment" + "'", str3.equals("     sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1" + "'", str2.equals("-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                              10a1a10                                               ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) 10);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 100, 2);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long17 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 170, 170);
        long long22 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100a0a10", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 15);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                     sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1", (int) (byte) -1, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                                                                                   1a01a0                                                                                                                                                   ", (int) (short) 100, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10a1a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "mIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("35", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35" + "'", str3.equals("35"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1004041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004041" + "'", str1.equals("1004041"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        short[] shortArray1 = new short[] { (byte) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 175, (int) (byte) 10);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#   A 4  ", "lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio" + "'", str2.equals("lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/USERS/SOPHIE", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cosx.LWCToolkitawt.masun.lw", '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                     sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "cosx.LWCToolkitawt.masun.lw" + "'", str8.equals("cosx.LWCToolkitawt.masun.lw"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "cosx.LWCToolkitawt.masun.lw" + "'", str9.equals("cosx.LWCToolkitawt.masun.lw"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) (short) 10, 15L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 15L + "'", long3 == 15L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("vatform Jatio API PlaSpecific");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vatform jatio api plaspecific" + "'", str1.equals("vatform jatio api plaspecific"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!", "1.0a10.01.0a10.01.0a10.01.0", "                                                                                                i", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!" + "'", str4.equals("H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("vatform jatio api plaspecific", "974354-14-", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "-1#0#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1", "cification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1" + "'", str2.equals(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM)4SE4Runtime4Environment1004-14100411004-14100411004-14100411004-14100411004-14100411004-1410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)4SE4Runtime4Environment1004-14100411004-14100411004-14100411004-14100411004-14100411004-1410" + "'", str1.equals("Java(TM)4SE4Runtime4Environment1004-14100411004-14100411004-14100411004-14100411004-14100411004-1410"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0410.0", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.0                                ", (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "achine ", (java.lang.CharSequence) "3#.#41#.#01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n" + "'", str2.equals("\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Library/J/Library/J/Library/J/Library/J/Limixed mode/Library/J/Library/J/Library/J/Library/J/Lib", 56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/J/Library/J/Library/J/Library/J/Limixed mode/Li" + "'", str2.equals("/Library/J/Library/J/Library/J/Library/J/Limixed mode/Li"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATION" + "'", str1.equals("jAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("J#v# Virtu#l M#chine Specif", "Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J#v# Virtu#l M#chine Specif" + "'", str2.equals("J#v# Virtu#l M#chine Specif"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 100, 2);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long17 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 170, 170);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 22, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "tnemnorivnE4emitnuR4ES4)MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("java(tm) se runtime environm", "                                                                                                i");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("#aaaaa4aa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#   a 4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10L, (float) 170, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 170.0f + "'", float3 == 170.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1004041", (-1), 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004041" + "'", str3.equals("1004041"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "140140", (java.lang.CharSequence) "10#10#10#1046_68X46_68X46_68X46_68X", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                i", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "-1a0a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("achine Speci7.1Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio", (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) '4', 26);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 1, (-1));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0" + "'", str14.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) -1, "cification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 7, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        char[] charArray5 = new char[] { 'a', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0", charArray5);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#   A 4  ", charArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "a a" + "'", str7.equals("a a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a#a" + "'", str10.equals("a#a"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a a" + "'", str12.equals("a a"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a a" + "'", str16.equals("a a"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', ' ', ' ', '#' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray9);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "souvrillllllllllllllllllllllllllll", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', 3L, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 28, 10);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "al Machine Specification", charArray4);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                           -1", charArray4);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.CPrinterJob", "l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("        \n/", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        \n/" + "'", str2.equals("        \n/"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION", (java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1015 + "'", int2 == 1015);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Virtual Machine Specificatio1Java Virtual Machine Specificatio100Java Virtual Machine Specificatio10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java V\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "        \n/", (java.lang.CharSequence) "#aaaaa4aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "3#.#41#.#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("## # ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "## # ##" + "'", str1.equals("## # ##"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaa aaaaaaaaaaaaa", "##########################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1############################################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1##################", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1004-141004", (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "souvrilllllllllllllllllllllllllllll", (int) (byte) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "                                         10 10 10 10                                                                                                                                                                                                                                                        ", 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "7.1", (int) '4');
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0414100", 12.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 414100.0f + "'", float2 == 414100.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("24.80-B1", "ificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B1" + "'", str2.equals("24.80-B1"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modem\n     mixed modemi", "97a35a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1", 28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                    ", "n_", "3.41.01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                    " + "'", str3.equals("                    "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("jAVA pLATFORM api sPECIFICATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Library/", (java.lang.CharSequence) "achine Speci7.1Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Library/" + "'", charSequence2.equals("/Library/"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "    n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n         n     ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 670 + "'", int1 == 670);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("#########a #########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: #########a ######### is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "jAVAvIRTUALmACHINEsPECIFICATION", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test250");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        java.lang.String str7 = javaVersion5.toString();
//        boolean boolean8 = javaVersion3.atLeast(javaVersion5);
//        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
//        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0a10a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.7so...on");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("souvrillllllllllllllllllllllllllll", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a01a0", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) 10, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a10a10a10" + "'", str7.equals("10a10a10a10"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa1004041aaaaaaaaaa", (java.lang.CharSequence) ".0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("## # ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "## # #" + "'", str1.equals("## # #"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10a1a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1" + "'", str1.equals("10a1"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', 52, 203);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.cgraphicsenvironment ", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, 0.0f, (float) 20);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "1.7.0_80-b15");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " OrcleCorportion");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T" + "'", str1.equals("#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str4 = javaVersion3.toString();
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean7 = javaVersion3.atLeast(javaVersion6);
        boolean boolean8 = javaVersion0.atLeast(javaVersion6);
        java.lang.String str9 = javaVersion0.toString();
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.6" + "'", str9.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "US", "a ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Library/J##########################################");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0.0                                ", "al Machine Specification", "                                          1004-1410041                                           ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "   1004041", (java.lang.CharSequence) "100 0 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.0410.0Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4R", "                                                                                        1.7.0_80-b15", "0#10#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4R" + "'", str3.equals("4Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4R"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 16, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################" + "'", str3.equals("################"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("-14141004100", "Java(TM)4SE4Runtime4Environment1004-14100411004-14100411004-14100411004-14100411004-14100411004-1410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.awt.cgraphicsenvironment", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 16, 15);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 1 100 100" + "'", str12.equals("-1 1 100 100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1#1#100#100" + "'", str14.equals("-1#1#100#100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1a1a100a100" + "'", str17.equals("-1a1a100a100"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("i", strArray6, strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "Oracle Corporation");
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "1.7");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, ' ');
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", "sophie", 6);
        java.lang.String[] strArray27 = org.apache.commons.lang3.StringUtils.stripAll(strArray25, "mixed modem\n     mixed modemi");
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100", strArray17, strArray27);
        java.lang.String[] strArray30 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a1.0a100.0a-1.0");
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEach("mixed modem\n     mixed modemi", strArray17, strArray30);
        int int32 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray30);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "i" + "'", str15.equals("i"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.7.0_80-b15" + "'", str21.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "100" + "'", str28.equals("100"));
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "mixed modem\n     mixed modemi" + "'", str31.equals("mixed modem\n     mixed modemi"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10#1", "97#35#-1#-1", "## # ##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1" + "'", str3.equals("10#1"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "97 35 -1 -1", (java.lang.CharSequence) "1.0a10.01.0a10.01.0a10.01.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "97 35 -1 -1" + "'", charSequence2.equals("97 35 -1 -1"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("CLASS [FCLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [FCLASS [FCLASS [", 20, "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CLASS [FCLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [FCLASS [FCLASS [" + "'", str3.equals("CLASS [FCLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [FCLASS [FCLASS ["));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        char[] charArray7 = new char[] { '#', ' ', ' ', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/J", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "nMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 52, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { 'a', '#', '4', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java V", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Specificatio API Platform Java", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "# 4", charArray9);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 0, 2);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a #" + "'", str18.equals("a #"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!", "Java Virtual Machine Specificatio", 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!" + "'", str3.equals("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!Java Virtual Machine SpecificatioHa!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1#1#100#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1#1#100#100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(" Machi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Machi" + "'", str1.equals("Machi"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun0lwawt0macosx0lwctoolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0.0#10.0#1.0#100.0#-1.0", 29, "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4440.0#10.0#1.0#100.0#-1.0444" + "'", str3.equals("4440.0#10.0#1.0#100.0#-1.0444"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" Virtu#l M#chine Specif");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" Virt\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("# 4", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "24.80-b11276978ry/Ja/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("vatform Jatio API PlaSpecific", "   1004041####sophie####sophie####sophie####sophie####so");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vatform Jatio API PlaSpecific" + "'", str2.equals("vatform Jatio API PlaSpecific"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##########################0#10#1############################################0#10#1##################", (java.lang.CharSequence) "ai444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444aa", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 253, (long) 1004041, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1004041L + "'", long3 == 1004041L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("tmp/run_randoop.pl_50190_1560276978", "10.0/10.0L10.0i10.0b10.0r10.0a10.0r10.0y10.0/10.0J10.0a10.0v10.0a10.0/10.0J10.0a10.0v10.0a10.0V10.0i10.0r10.0t10.0u10.0a10.0l10.0M10.0a10.0c10.0h10.0i10.0n10.0e10.0s10.0/10.0j10.0d10.0k10.0110.0.10.0710.0.10.0010.0_10.0810.0010.0.10.0j10.0d10.0k10.0/10.0C10.0o10.0n10.0t10.0e10.0n10.0t10.0s10.0/10.0H10.0o10.0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0", 6);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.3");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1004-141004", "", "0.0                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004-141004" + "'", str3.equals("1004-141004"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "tnemnorivne4emitnur4es4)mt(avaj", (java.lang.CharSequence) "1Java Virtual Machine Specificatio1Java Virtual Machine Specificatio100Java Virtual Machine Specificatio10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 34, (double) 5L, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.0d + "'", double3 == 34.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("a aOracleCorporationa aO100 0 1044444444444444444444444444444444444444444444444444444444444444444", "I44444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a aOracleCorporationa aO100 0 1044444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("a aOracleCorporationa aO100 0 1044444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "Java Virtual Machine Specificatio1Java Virtual Machine Specificatio100Java Virtual Machine Specificatio10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (float) 22L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "##########################0#10#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("##########################0#10#1", "1.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#10.0" + "'", str2.equals("1.0#10.0"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "100#-1#100#1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "51.0", 175);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0" + "'", str3.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "mnorivne emitnur es )mt(avaj");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("al Machine Specification", "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "             1.0410.0              ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a1.0a100.0a-1.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100 -1 100 1", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("EN1004-1410041EN");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("souvrilllllllllllllllllllllllllllll");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Specificatio API Platform Jav", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironmen" + "'", str1.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) 100, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 -1 100 1" + "'", str8.equals("100 -1 100 1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                          ", "/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          " + "'", str2.equals("                          "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "                                                                                                                                                                               sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                               sun.awt.cgraphicsenvironment" + "'", str2.equals("                                                                                                                                                                               sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10#10#10#10", (java.lang.CharSequence) "f-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_156027697810/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769781");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_156027697810/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769781\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a1.0a100.0a-1.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "tnemnorivnE4emitnuR4ES4)MT(avaJ", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java Virtual Machine Specif");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0a10.0a1.0a100.0a-1.0" + "'", str7.equals("0.0a10.0a1.0a100.0a-1.0"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                100a-1a100a14444444444444444444444444444444444444444", 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("r.34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        float[] floatArray5 = new float[] { 0, (short) 10, 1.0f, 100L, (-1) };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', (int) (short) -1, (int) (short) -1);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (short) 0, (int) (short) 1);
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) '4', 1004041);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0a10.0a1.0a100.0a-1.0" + "'", str7.equals("0.0a10.0a1.0a100.0a-1.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0.0" + "'", str19.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + (-1.0f) + "'", float20 == (-1.0f));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "r.34MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEM", (java.lang.CharSequence) "104141004444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        char[] charArray2 = new char[] { '#' };
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification", charArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, '4', 10, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "i");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-141", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -141 + "'", short2 == (short) -141);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "#     #", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray12 = new char[] { '#', ' ', ' ', '#' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "l Machine Specificatio", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1004-1410041", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophi", charArray12);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaa aaaaaaaaaaaaaaa", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10a10a10a10", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aMixed modea", 8, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aMixed modea" + "'", str3.equals("aMixed modea"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("mnorivne emitnur es )mt(avaj", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mnorivne emitnur es )mt(avaj" + "'", str2.equals("mnorivne emitnur es )mt(avaj"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                                                           7.1", "0.15", "             1.0410.0              ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44444444444444444444444444444444Java Platform API Specification", 203);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                      44444444444444444444444444444444Java Platform API Specification                                                                      " + "'", str2.equals("                                                                      44444444444444444444444444444444Java Platform API Specification                                                                      "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode10.14.3", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.0 10.0", (java.lang.CharSequence) " OS XMac OS ", 175);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        char[] charArray7 = new char[] { '#', ' ', 'a', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        java.lang.Class<?> wildcardClass9 = charArray7.getClass();
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-B11", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "", (java.lang.CharSequence) "974354-14-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        int[] intArray5 = new int[] { (short) 0, (byte) 10, 97, 21, (byte) -1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 10 97 21 -1" + "'", str8.equals("0 10 97 21 -1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "                                                                                             1004041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 56, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Platform API Specificatio", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java V", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("CLASS [FCLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [FCLASS [FCLASS [", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLASS [FCLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [FCLASS [FCLASS [" + "'", str2.equals("CLASS [FCLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS [FCLASS [FCLASS ["));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("100#-1#100#1", 56, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("444444444444444444444444444444444444444444-1 1 100 1004444444444444444444444444444444444444444444", "EN1004-1410041EN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444-1 1 100 " + "'", str2.equals("444444444444444444444444444444444444444444-1 1 100 "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) '4', 26);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0" + "'", str14.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.0" + "'", str16.equals("10.0"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("achineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "100 0 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "97#35#-1#-1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", "sophie", 6);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("3.41.01");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + " " + "'", str6.equals(" "));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("444...", "souvrilllllllllllllllllllllllllllll");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444..." + "'", str2.equals("444..."));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("46_68x", "974354-14-1", 9);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 27, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "UTF-8");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("7.1", strArray4, strArray7);
        java.lang.Class<?> wildcardClass11 = strArray4.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7.1" + "'", str10.equals("7.1"));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!", "/Library/J/Library/J/Library/J/Library/J/Limixed mode/Li");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!" + "'", str2.equals("H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "l Machine Specificatio", (int) (byte) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie", "en1004-1410041en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi" + "'", str2.equals("/Users/sophi"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "10a1a", 670);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Mac OS X", "041041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) 100, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 26, (int) (byte) 0);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100#-1#100#1" + "'", str9.equals("100#-1#100#1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.AWT.CGRAPHICSENVIRONMENT", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATION", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-b11276978ry/Ja/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Specificatio API Platform Jav", "444444444444444444444444444444444444444444-1 1 100 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specificatio API Platform Jav" + "'", str2.equals("Specificatio API Platform Jav"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironmen", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aSpecificatio API Platform Javaa", (java.lang.CharSequence) "                                  100a-1a100a144444444444444444...                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "I44444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, ".");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        int[] intArray5 = new int[] { (short) 0, (byte) 10, 97, 21, (byte) -1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', 1, (int) (short) 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 10 97 21 -1" + "'", str8.equals("0 10 97 21 -1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/users/sophie/library/java/extensions:/library/java/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/users/sophie/library/java/extensions:/library/java/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/             1.0410.0              ", "", "so...", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/             1.0410.0              " + "'", str4.equals("#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/             1.0410.0              "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        float[] floatArray5 = new float[] { 0, (short) 10, 1.0f, 100L, (-1) };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', (int) (short) -1, (int) (short) -1);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (short) 0, (int) (short) 1);
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float21 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (short) 0, (int) (byte) 1);
        float float28 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float31 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0a10.0a1.0a100.0a-1.0" + "'", str7.equals("0.0a10.0a1.0a100.0a-1.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0.0" + "'", str19.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + (-1.0f) + "'", float20 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + (-1.0f) + "'", float21 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0.0#10.0#1.0#100.0#-1.0" + "'", str23.equals("0.0#10.0#1.0#100.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0.0" + "'", str27.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + (-1.0f) + "'", float28 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0.0 10.0 1.0 100.0 -1.0" + "'", str30.equals("0.0 10.0 1.0 100.0 -1.0"));
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + (-1.0f) + "'", float31 == (-1.0f));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" OrcleCorportion", 3, "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OrcleCorportion" + "'", str3.equals(" OrcleCorportion"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0/10.0L10.0i10.0b10.0r10.0a10.0r10.0y10.0/10.0J10.0a10.0v10.0a10.0/10.0J10.0a10.0v10.0a10.0V10.0i10.0r10.0t10.0u10.0a10.0l10.0M10.0a10.0c10.0h10.0i10.0n10.0e10.0s10.0/10.0j10.0d10.0k10.0110.0.10.0710.0.10.0010.0_10.0810.0010.0.10.0j10.0d10.0k10.0/10.0C10.0o10.0n10.0t10.0e10.0n10.0t10.0s10.0/10.0H10.0o10.0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "Specificatio API Platform Java", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str3.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aMixed modea", "sun0lwawt0macosx0lwctoolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun0lwawt0macosx0lwctoolkit" + "'", str2.equals("sun0lwawt0macosx0lwctoolkit"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Corporation", 3, "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Corporation" + "'", str3.equals("Corporation"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specificatio", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " ", 1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        short[] shortArray1 = new short[] { (byte) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 35, 10);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   1004041", "0 10 10 10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) ' ', (long) 56);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 56L + "'", long3 == 56L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 29, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97a35a-1a-1" + "'", str13.equals("97a35a-1a-1"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0a10a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("     so...     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"so...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#35#-1#-1" + "'", str10.equals("97#35#-1#-1"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "class [D", (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.cgraphicsenvironment ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.0A10.01.0A10.01.0A10.01.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                                                                                                                                                               sun.awt.cgraphicsenvironment", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machine specification" + "'", str1.equals("java virtual machine specification"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "31.7so...on.1.7so...on411.7so...on.1.7so...on01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.6", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "UTF-8");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("UTF-", strArray5, strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray18);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray19, "");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/J##########################################", strArray14, strArray21);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "class [D");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTF-" + "'", str12.equals("UTF-"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "/Library/J##########################################" + "'", str22.equals("/Library/J##########################################"));
        org.junit.Assert.assertNotNull(strArray24);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacifi", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacifi" + "'", str2.equals("oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacifi"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.reflect.Type[][] typeArray0 = new java.lang.reflect.Type[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(typeArray0);
        org.junit.Assert.assertNotNull(typeArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(170, 30, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0 10 10 10", 7, "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 10 10 10" + "'", str3.equals("0 10 10 10"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 34, (long) 75, (long) 1004041);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1004-1410041", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "1.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("souvrillllllllllllllllllllllllllll");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "souvrillllllllllllllllllllllllllll" + "'", str1.equals("souvrillllllllllllllllllllllllllll"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", ".0410.0Java(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4Runtime4EnvironmentJava(TM)4SE4R", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                  100a-1a100a144444444444444444...                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                  100a-1a100a144444444444444444...                                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aSpecificatio API Platform Javaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("3.41.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10#10#10#10", (java.lang.CharSequence) "97 35 -1 -1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n/", "aaaaaaaaaaaa aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie", "\n", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0#10#1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) '4', 26);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("00141401");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "00141401" + "'", str1.equals("00141401"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 32, 21);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 56, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 56");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0" + "'", str4.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10", "1.744444444444444444444444444444444Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10" + "'", str2.equals("100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(31, 28, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment" + "'", str2.equals("            -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("achineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio", "mixed mode", "/Users/sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "achineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio" + "'", str3.equals("achineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "97a35a-1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "46_68x", (java.lang.CharSequence) "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1015, (long) (-1), 9L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1015L + "'", long3 == 1015L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "0 10 10 10", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#10#1" + "'", str8.equals("0#10#1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978", 300, (int) (short) -141);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaMixed modeaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaMixed modeaaaaaa" + "'", str1.equals("aaMixed modeaaaaaa"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/", "UTF-");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "a # 4 a", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long19 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long20 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 1 100 100" + "'", str12.equals("-1 1 100 100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1#1#100#100" + "'", str14.equals("-1#1#100#100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1a1a100a100" + "'", str17.equals("-1a1a100a100"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0a10a1", "                                         444444444444444                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10a1" + "'", str2.equals("0a10a1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10#10#10#1046_68X46_68X46_68X46_68Xecif", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("al Machine Specification", (int) ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444al Machine Specification" + "'", str3.equals("44444444al Machine Specification"));
    }
}

