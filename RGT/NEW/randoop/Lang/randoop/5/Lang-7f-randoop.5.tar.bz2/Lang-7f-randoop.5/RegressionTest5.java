import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 7.1" + "'", str1.equals("                                                                                                 7.1"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("a ", "#44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a " + "'", str2.equals("a "));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0a10.01.0a10.01.0a10.01.0", "n     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a10.01.0a10.01.0a10.01.0" + "'", str2.equals("1.0a10.01.0a10.01.0a10.01.0"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "        \n/", (java.lang.CharSequence) "lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machine specification" + "'", str1.equals("java virtual machine specification"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "al Machine Specification", (java.lang.CharSequence) "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("JAVA V", "                                                                     sun.awt.CGraphicsEnvironment", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("achine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(29, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio" + "'", str2.equals("ificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.0a10.0", "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a10.0" + "'", str2.equals("1.0a10.0"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.2", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 20, 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("1.2/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.AWT.CGRAPHICSENVIRONMENT                                                                        ", "a aOracleCorporationa aO100 0 1044444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.CGRAPHICSENVIRONMENT                                                                        " + "'", str2.equals("SUN.AWT.CGRAPHICSENVIRONMENT                                                                        "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        char[] charArray7 = new char[] { '#', ' ', 'a', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        java.lang.Class<?> wildcardClass9 = charArray7.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a # 4 a", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#   a 4  " + "'", str11.equals("#   a 4  "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "10#1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("7 35 -1 -1", " Machi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7 35 -1 -1" + "'", str2.equals("7 35 -1 -1"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (java.lang.CharSequence) "1.8", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                             1004041", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                             100404" + "'", str2.equals("                                                                                             100404"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("               -1#1#100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#1#100#100" + "'", str1.equals("-1#1#100#100"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("## # ##", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "## # ##" + "'", str2.equals("## # ##"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                                                                                                                                               sun.awt.cgraphicsenvironment", (java.lang.CharSequence) "97a35a-1a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                           7.1", 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "enenenenenenenenenenenenenen", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "MIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100a-1a100a1", "en1004-1410041en");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "             1.0410.0              ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                i", "aaa", "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                i" + "'", str3.equals("                                                                                                i"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.0" + "'", str4.equals("10.0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10#10#10#1046_68x46_68x46_68x46_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#10#10#1046_68X46_68X46_68X46_68X" + "'", str1.equals("10#10#10#1046_68X46_68X46_68X46_68X"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0", 15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100a0a10");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i44444444444444444444444...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10.14.3", "         -1a1a100a100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        float[] floatArray5 = new float[] { 0, (short) 10, 1.0f, 100L, (-1) };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', (int) (short) -1, (int) (short) -1);
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 6, (int) (byte) 1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0a10.0a1.0a100.0a-1.0" + "'", str7.equals("0.0a10.0a1.0a100.0a-1.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 100.0f + "'", float15 == 100.0f);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1#1#100#100", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1a1a100a10", (int) 'a', 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("35", "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35" + "'", str2.equals("35"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a # 4 a", (java.lang.CharSequence) "mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode10.14.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/", (java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ria ta");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "at air" + "'", str1.equals("at air"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B1" + "'", str1.equals("24.80-B1"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/J", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        char[] charArray10 = new char[] { '#', ' ', ' ', '#' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "l Machine Specificatio", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "# 4", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "## # ##" + "'", str17.equals("## # ##"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                           1400141-4001                                          ", "Java V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                           1400141-4001                                          " + "'", str2.equals("                                           1400141-4001                                          "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Innnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.0A10.01.0A10.01.0A10.01.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sun.awt.cgraphicsenvironment", 12, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str3.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "a aOracleCorporationa aO100 0 10", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("46_68x", 16, 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("0a10a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/J", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/J" + "'", str2.equals("/Library/J"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("51.0", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1.equals(10.0d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str5 = javaVersion4.toString();
        java.lang.String str6 = javaVersion4.toString();
        boolean boolean7 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10#10#10#1046_68X46_68X46_68X46_68X", (java.lang.CharSequence) "-1a1a100a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aMixed modea");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aMixed modea" + "'", str1.equals("aMixed modea"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "##########################0#10#1", (java.lang.CharSequence) "Java V");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "   1004041", (java.lang.CharSequence) "aaa", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "24.80-b11", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("100#-1#100#1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-141", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("###########################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##########################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                          ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 ", "sun.awt.CGraphicsEnvironment", 27);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "x86_64");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100 -1 100 1", "jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 16, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "1.0a10.0", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("n     ", 29, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/J##########################################", "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 7.1" + "'", str2.equals("                                                                                                 7.1"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "## # ##");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("jAVAvIRTUALmACHINEsPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVAvIRTUALmACHINEsPECIFICATION" + "'", str1.equals("jAVAvIRTUALmACHINEsPECIFICATION"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "100a-1a100a144444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a1.0a100.0a-1.0");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0a10.0a1.0a100.0a-1.0" + "'", str5.equals("0.0a10.0a1.0a100.0a-1.0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("100", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 300);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("a aOracleCorporationa aO100 0 1044444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa", " ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "##########################0#10#1############################################0#10#1##################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("a a", "l Machine Specification", 0, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "l Machine Specificationa a" + "'", str4.equals("l Machine Specificationa a"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.8", "44444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("OracleCorporation", "100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporation" + "'", str2.equals("OracleCorporation"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1#1#100#100", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.0       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "aSpecificatio API Platform Javaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification", (int) (short) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "# 4", (java.lang.CharSequence) "                                                                                                                                                                               sun.awt.cgraphicsenvironment", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10 10 10 10", "1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 10 10 10" + "'", str2.equals("10 10 10 10"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("a a", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.9", charSequence1, 203);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                 -1", " ", 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           -1" + "'", str3.equals("                           -1"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("cification", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cification" + "'", str2.equals("cification"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specificatio", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("#44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#44" + "'", str1.equals("#44"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "1004-141004", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                                                                                                                                                                               sun.awt.cgraphicsenvironment", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                               sun.awt.cgraphicsenvironment" + "'", str2.equals("                                                                                                                                                                               sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("   1004041", "104141004444444444444444444", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("3.41.01");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7so...on");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31.7so...on.1.7so...on411.7so...on.1.7so...on01" + "'", str5.equals("31.7so...on.1.7so...on411.7so...on.1.7so...on01"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "achine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "01414001", 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "46_68x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio", "Java Platform API Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11276978", 21, "ry/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11276978ry/Ja/" + "'", str3.equals("24.80-b11276978ry/Ja/"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("7.1");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 7.1f + "'", number1.equals(7.1f));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##########################0#10#1############################################0#10#1##################", (java.lang.CharSequence) "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("   1004041", 27, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("01414001");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1414001.0f + "'", float1.equals(1414001.0f));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "souvrilllllllllllllllllllllllllllll", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("###########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!", "24.80-b11276978");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                             1004041", (java.lang.CharSequence) "100a-1a100a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "                           -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os x" + "'", str1.equals("mac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os x"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0.0a10.0a1.0a100.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cosx.LWCToolkitawt.masun.lw", '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 29, 28);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "24.80-B1", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100#0#10", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#10" + "'", str2.equals("100#0#10"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                          ", 7, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("SUN.AWT.CGRAPHICSENVIRONMENT                                                                        ", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "en");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Innnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", 21, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Innnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + "'", str3.equals("Innnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-141L), 0.0d, (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "001");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("tmp/run_randoop.pl_50190_1560276978");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tmp/run_randoop.pl_50190_1560276978" + "'", str1.equals("tmp/run_randoop.pl_50190_1560276978"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                 -1", (java.lang.CharSequence) "i4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100a-1a100a14444444444444444444444444444444444444444", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "97 35 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os xmac os x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_156027697810/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978./Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769780/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978a/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_15602769781", (java.lang.CharSequence) "35", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.8", "", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacifi" + "'", str1.equals("oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacificepSenihcaMlJ/yrarbiL/oitacifi"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("achine Speci7.1Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "achine Speci7.1Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio" + "'", str2.equals("achine Speci7.1Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        double[] doubleArray1 = new double[] { 1.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio", "-1 1 100 100", 300);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                  100a-1a100a144444444444444444...                                  ", 27, "1004-1410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  100a-1a100a144444444444444444...                                  " + "'", str3.equals("                                  100a-1a100a144444444444444444...                                  "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a1a100a100" + "'", str7.equals("-1a1a100a100"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [" + "'", str1.equals("class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass ["));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "tmp/run_r4ndoop.pl_50190_1560276978", (java.lang.CharSequence) "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.4", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4d + "'", double2 == 1.4d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-141004", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 0, (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 7, (double) 1.0f, (double) 15);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                 ", "java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("java(tm) se runtime environm", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", "sophie", 6);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "mixed modem\n     mixed modemi");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) (byte) -1, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 97, (long) 31, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "aaaaaaaaaa1004041aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa", (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("00141401");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("      ", "                                 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("             1.0410.0              ", (int) (short) 100, "#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/             1.0410.0              " + "'", str3.equals("#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/             1.0410.0              "));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("24.80-B1", 2, "7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-B1" + "'", str3.equals("24.80-B1"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("n_", "sun.lwawt.macosx.lwctoolkit", (int) (byte) 10);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                             1004041", charSequence1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100 -1 100 1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0#10.0" + "'", str1.equals("1.0#10.0"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sophie", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0 10 10 10", (java.lang.CharSequence) "0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("7.1      ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) '4', 26);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0" + "'", str13.equals("10.0"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4', 29, 9);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51.0", "01414001");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a", 203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0410.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(2.0f, (float) (short) 10, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', (int) (byte) -1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaa", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("10.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0" + "'", str2.equals("10.0"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("cosx.LWCToolkitawt.masun.lw", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                     sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 10, 203);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Specificatio API Platform Java", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vatform Jatio API PlaSpecific" + "'", str2.equals("vatform Jatio API PlaSpecific"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100a-1a100a14444444444444444444444444444444444444444", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a-1a100a14444444444444444444444444444444444444444" + "'", str2.equals("100a-1a100a14444444444444444444444444444444444444444"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        byte[] byteArray3 = new byte[] { (byte) -1, (byte) 0, (byte) 0 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a0a0" + "'", str7.equals("-1a0a0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b11", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0 10.0", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100 -1 100 1", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '#', ' ', ' ', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "l Machine Specificatio", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#a a a#" + "'", str14.equals("#a a a#"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHI" + "'", str1.equals("/USERS/SOPHI"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "-1a1a100a100", (java.lang.CharSequence) "al Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("-1", "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10#10#10#1046_68X46_68X46_68X46_68X", (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10" + "'", str2.equals("100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10   1004041100 0 10"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("31.7so...on.1.7so...on411.7so...on.1.7so...on01", "0.0a10.0a1.0a100.0a-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "31.7so...on.1.7so...on411.7so...on.1.7so...on01" + "'", str2.equals("31.7so...on.1.7so...on411.7so...on.1.7so...on01"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.0       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "974354-14-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1004-1410041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004-1410041" + "'", str1.equals("1004-1410041"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T", "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!" + "'", str2.equals("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("achineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "", (-1));
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Mixed mode", strArray2, strArray8);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.stripAll(strArray20, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("i", strArray14, strArray22);
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.stripAll(strArray22, "Oracle Corporation");
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10a1a10", strArray8, strArray25);
        java.lang.Class<?> wildcardClass27 = strArray8.getClass();
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mixed mode" + "'", str9.equals("Mixed mode"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "i" + "'", str23.equals("i"));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10a1a10" + "'", str26.equals("10a1a10"));
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment" + "'", str1.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "                                                                     sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/", "100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10" + "'", str2.equals("100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.0A10.0", "MAC OS X", 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0A10.0" + "'", str3.equals("1.0A10.0"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                           7.1", (java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 97, (int) (short) 10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 0, 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.0410.0" + "'", str20.equals("1.0410.0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4.4444444E34f, 1004041.0d, (double) 12L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/J/Library/J/Library/J/Library/J/Limixed mode/Library/J/Library/J/Library/J/Library/J/Lib", (int) (byte) 10, "                                         10 10 10 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/J/Library/J/Library/J/Library/J/Limixed mode/Library/J/Library/J/Library/J/Library/J/Lib" + "'", str3.equals("/Library/J/Library/J/Library/J/Library/J/Limixed mode/Library/J/Library/J/Library/J/Library/J/Lib"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n     ", "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0a10.0a1.0a100.0a-1.0", "\n/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aa", 16, "1.744444444444444444444444444444444Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa1.744444444444" + "'", str3.equals("aa1.744444444444"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sun0lwawt0macosx0lwctoolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "#     #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.2");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2d + "'", double1.equals(1.2d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1a1a100a10", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a1a100a10" + "'", str2.equals("1a1a100a10"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100 -1 100 1", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL", 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0a10.0" + "'", str9.equals("1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b11", 9, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaa aaaaaaaaaaaaa", "en1004-1410041en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaa aaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaa aaaaaaaaaaaaa"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("l Machine Specificatio", "1.0a10.01.0a10.01.0a10.01.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "24.80-B1", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode10.14.3", "aaaaaaaaaa1004041aaaaaaaaaa", "i44444444444444444444444...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("      ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "sun0lwawt0macosx0lwctoolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10#10#10#1046_68X46_68X46_68X46_68X", "                                           1400141-4001                                          ", "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("\n", 1004041);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { '#', ' ', ' ', '#' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "l Machine Specificatio", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1004-1410041", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                    ", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100 0 10", "", (int) (byte) -1);
        java.lang.CharSequence charSequence5 = null;
        java.lang.String[] strArray9 = new java.lang.String[] { "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "sun.awt.CGraphicsEnvironment" };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a', 21, 10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence5, (java.lang.CharSequence[]) strArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("##########################0#10#1############################################0#10#1##################", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "##########################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1############################################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1##################" + "'", str16.equals("##########################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1############################################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1##################"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("    n     ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("vatform Jatio API PlaSpecific", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vatform Jatio API PlaSpecific" + "'", str2.equals("vatform Jatio API PlaSpecific"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("3.41.01", ".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1a1a100a100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(12L, (long) 7, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100" + "'", str1.equals("100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION" + "'", str1.equals("AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION1.0410.0AL MACHINE SPECIFICATION"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 203, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 203 + "'", int3 == 203);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("               -1#1#100#100", "", "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 97, (int) (short) 10);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 0, 0);
        float float19 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float20 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float21 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 10.0f + "'", float19 == 10.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 10.0f + "'", float20 == 10.0f);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaOracleCorporationaaO100010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaOracleCorporationaaO100010" + "'", str1.equals("aaOracleCorporationaaO100010"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "UTF-8");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("7.1", strArray6, strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray18, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray24, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("i", strArray18, strArray26);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.stripAll(strArray26, "Oracle Corporation");
        java.lang.String[] strArray31 = org.apache.commons.lang3.StringUtils.stripAll(strArray29, "1.7");
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray29, ' ');
        java.lang.String[] strArray37 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", "sophie", 6);
        java.lang.String[] strArray39 = org.apache.commons.lang3.StringUtils.stripAll(strArray37, "mixed modem\n     mixed modemi");
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100", strArray29, strArray39);
        java.lang.String str41 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", strArray9, strArray39);
        int int42 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray39);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "7.1" + "'", str12.equals("7.1"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "i" + "'", str27.equals("i"));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.7.0_80-b15" + "'", str33.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "100" + "'", str40.equals("100"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str41.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("lMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio/Library/JlMachineSpecificatio", "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F");
            org.junit.Assert.fail("Expected exception of type java.util.regex.PatternSyntaxException; message: Unclosed character class near index 81\nclass [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F\n                                                                                 ^");
        } catch (java.util.regex.PatternSyntaxException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Innnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn", (long) 29);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 29L + "'", long2 == 29L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        char[] charArray8 = new char[] { '#', ' ', ' ', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                           1400141-4001                                          ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", 52, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("vatform Jatio API PlaSpecific", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vatform Jatio API PlaSpecific" + "'", str2.equals("vatform Jatio API PlaSpecific"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("## # ##", "/Library/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                                                                                               sun.awt.cgraphicsenvironment", (java.lang.CharSequence) "\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                         10 10 10 10", (java.lang.CharSequence) "31.7so...on.1.7so...on411.7so...on.1.7so...on01");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1a1a100a10", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52.0f, 32.0d, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.0410.01.0A10.01.0A10.01.0A10.01.0", (java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sophie", "1a01a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("# 4", (int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 4" + "'", str3.equals(" 4"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "      ", (java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        short[] shortArray1 = new short[] { (byte) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "#44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie/library/java/extensions:/library/java/", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14141004100" + "'", str12.equals("-14141004100"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaa", "aMixed modea", 20, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaMixed modeaaaaaa" + "'", str4.equals("aaMixed modeaaaaaa"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("7.1      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Virtual Machine Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaa aaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (java.lang.CharSequence) "ria ta", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 100, 100);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 1004041, 16);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        short[] shortArray1 = new short[] { (byte) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("i");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.0a10.0a1.0a100.0a-1.0", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "i" + "'", str5.equals("i"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library/J##########################################", "SUN.AWT.CGRAPHICSENVIRONMENT", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                          ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          " + "'", str2.equals("                          "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) -1, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("               -1#1#100#100", (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("mixed modem\n     mixed modemi", "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modem\n     mixed modemi" + "'", str2.equals("mixed modem\n     mixed modemi"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100 0 10", (java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(".34mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaa", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "vatform Jatio API PlaSpecific", (java.lang.CharSequence) "1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("JAVA V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA V" + "'", str1.equals("JAVA V"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/             1.0410.0              ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "a aOracleCorporationa aO100 0 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "104141004444444444444444444", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "97#35#-1#-1", (int) (short) 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophi", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification", (java.lang.CharSequence) "1004-141004");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("jAVA vIRTUAL mACHINE sPECIFICATION", "                                         10 10 10 10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0                                ", (java.lang.CharSequence) "aaOracleCorporationaaO100010");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a aOracleCorporationa aO100 0 1044444444444444444444444444444444444444444444444444444444444444444", "##########################0#10#1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a a", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "                                                                     sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 ", "sun.awt.CGraphicsEnvironment", 27);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "x86_64");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ', 2, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [", 4, "a aOracleCorporationa aO100 0 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [" + "'", str3.equals("class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass ["));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "0.0                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 5, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-F", "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10", "java(tm) se runtime environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10" + "'", str2.equals("100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "n_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str2.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10#10#10#1046_68X46_68X46_68X46_68X", "##########################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1############################################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#10#10#1046_68X46_68X46_68X46_68X" + "'", str2.equals("10#10#10#1046_68X46_68X46_68X46_68X"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!", "##########################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1############################################i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444#sun.awt.CGraphicsEnvironment#1##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!" + "'", str2.equals("H-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!h-!"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.2", "", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                         10 10 10 10", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "-14141004100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("n_", "1.0410.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ".", (java.lang.CharSequence) "1.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("enenenenenenenenenenenenenen", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenen" + "'", str2.equals("enenenenenenenenenenenenenen"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(203, 22, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 203 + "'", int3 == 203);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "974354-14-1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10a1a10", "               -1#1#100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a" + "'", str2.equals("10a1a"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                          1004-1410041                                           ", "n_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "7 35 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 97, (int) (short) 10);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float16 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float19 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 10.0f + "'", float16 == 10.0f);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.0410.0" + "'", str18.equals("1.0410.0"));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10a1a10", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaa1004041aaaaaaaaaa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 100, 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "souvrilllllllllllllllllllllllllllll", (java.lang.CharSequence) "Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "             1.0410.0              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.4", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1a1a100a10", "a", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1Java Virtual Machine Specificatio1Java Virtual Machine Specificatio100Java Virtual Machine Specificatio10" + "'", str3.equals("1Java Virtual Machine Specificatio1Java Virtual Machine Specificatio100Java Virtual Machine Specificatio10"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("so...", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "so..." + "'", str2.equals("so..."));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10#10#10#10", 20, "1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.61.61.610#10#10#10" + "'", str3.equals("1.61.61.610#10#10#10"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                    " + "'", str1.equals("                                                                                                    "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004041" + "'", str5.equals("1004041"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("97 35 -1 -1", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a # 4 a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a # 4 a" + "'", str1.equals("a # 4 a"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment", "24.80-B1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment" + "'", str2.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-b11", charArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "        \n/", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mIXED MODE", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("   1004041", "a # 4 a", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   1004041" + "'", str3.equals("   1004041"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0", (int) '#', 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str4.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.lwctoolkit", "tmp/run_randoop.pl_50190_1560276978");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "JAVA V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1 1 100 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "                          ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                          " + "'", charSequence2.equals("                          "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        char[] charArray8 = new char[] { '#', ' ', ' ', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0 10.0", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a-1a100a144444444444444444...", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 15L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 15.0f + "'", float3 == 15.0f);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "-1a0a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("## # ##", (int) (byte) 0, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "## # ##" + "'", str3.equals("## # ##"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("tmp/run_r4ndoop.pl_50190_1560276978", "aMixed modea");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tmp/run_r4ndoop.pl_50190_1560276978" + "'", str2.equals("tmp/run_r4ndoop.pl_50190_1560276978"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("al Machine Specification", "10.0", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100a0a10", (int) '#', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n1.2\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaMixed modeaaaaaa", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaMixed modeaaaaaa" + "'", str2.equals("aaMixed modeaaaaaa"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("MAC OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 7.1");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "tmp/run_randoop.pl_50190_1560276978", 16, 22);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978" + "'", str5.equals("tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978tmp/run_randoop.pl_50190_1560276978"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = null;
        try {
            boolean boolean5 = javaVersion0.atLeast(javaVersion4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100#0#10", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Oracle Corporation", "24.80-B11", "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment" + "'", str2.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("97 35 31 31");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("achine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio", "100#0#10M100#0#10i100#0#10x100#0#10e100#0#10d100#0#10 100#0#10m100#0#10o100#0#10d100#0#10e100#0#10", "Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm" + "'", str3.equals("achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) 100, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 52, 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 -1 100 1" + "'", str8.equals("100 -1 100 1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100#-1#100#1" + "'", str15.equals("100#-1#100#1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1004-1410041" + "'", str17.equals("1004-1410041"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("10.0", strArray3, strArray5);
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("cosx.LWCToolkitawt.masun.lw", strArray3, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0" + "'", str6.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "cosx.LWCToolkitawt.masun.lw" + "'", str8.equals("cosx.LWCToolkitawt.masun.lw"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100a0a10", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, 20L, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaa1004041aaaaaaaaaa");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("tnemnorivnE4emitnuR4ES4)MT(avaJ", "-1a1a100a10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "\n", 2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 21L, (double) 300, 1.7d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 300.0d + "'", double3 == 300.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.0", "Java Virtual Machine Specif");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.Class<?> wildcardClass6 = doubleArray1.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 32, 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", 9, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100 0 10", (float) 22L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 27);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                           7.1", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           7.1" + "'", str2.equals("                                                                                           7.1"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("a a", "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444               -1#1#100#100sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10#10#10#1046_68x46_68x46_68x46_68x", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_Va aOracleCorporationa aO100 0 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56 + "'", int2 == 56);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm/Lmbrary/Jl4achmnSpcmfmcatm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"achmnS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment", 203);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        double[] doubleArray1 = new double[] { 10L };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 56, 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.0" + "'", str5.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "F-", 12, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 33, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "Java(TM) SE Runtime Environment", (int) '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("l Machine Specificationa a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"l Machine Specificationa a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java V");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "97#35#-1#-1", 22, 203);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("             1.0410.0              ", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             1.0410.0              aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("a # 4 a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "100a0a10", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa01414001enaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.0a10.01.0a10.01.0a10.01.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("a ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a " + "'", str1.equals("a "));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.cgraphicsenvironment", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.cgraphicsenvironment " + "'", str2.equals("sun.awt.cgraphicsenvironment "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL", (java.lang.CharSequence) "tnemnorivnE4emitnuR4ES4)MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.6", 22, "                                                                                                 7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6                   " + "'", str3.equals("1.6                   "));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#" + "'", str1.equals("T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#44#"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a aOracleCorporationa aO100 0 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a aOracleCorporationa aO100 0 10" + "'", str1.equals("a aOracleCorporationa aO100 0 10"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java Platform API Specificatio");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                           -1", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                           -1" + "'", str5.equals("                           -1"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                              10a1a10                                               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "l Machine Specificatio", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100a0a10", (int) '#', (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TNEMNORIVNESCIHPARGC.TWA.NUS" + "'", str1.equals("TNEMNORIVNESCIHPARGC.TWA.NUS"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.0                                ", "Java Virtual Machine Specif", "Java Platform API Specification", (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0                                " + "'", str4.equals("0.0                                "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100a0a10", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a0a10" + "'", str3.equals("100a0a10"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "##########################0#10#1", (java.lang.CharSequence) "7.1", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1004-141004", (java.lang.CharSequence) "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 0, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("   1004041", "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "enenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "0.0                                ", "        \n/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                         10 10 10 10", (java.lang.CharSequence) "aaMixed modeaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                         10 10 10 10" + "'", charSequence2.equals("                                         10 10 10 10"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                     sun.awt.CGraphicsEnvironment", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                     sun.awt.CGraphicsEnvironment" + "'", str3.equals("                                                                     sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("vatform Jatio API PlaSpecific");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"vatform Jatio API PlaSpecific\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("01414001", "sun.lwawt.macosx.lwctoolkit", "n");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0A10.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("tmp/run_randoop.pl_50190_1560276978", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tmp/run_randoop.pl_50190_1560276978" + "'", str2.equals("tmp/run_randoop.pl_50190_1560276978"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, 32, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(".0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1a0a0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        int[] intArray4 = new int[] { 'a', '#', (byte) -1, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 100, 0);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 16, 0);
        int int18 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int20 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97#35#-1#-1" + "'", str7.equals("97#35#-1#-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 97 + "'", int19 == 97);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "97a35a-1a-1" + "'", str22.equals("97a35a-1a-1"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "24.80-b11276978ry/Ja/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100a-1a100a14444444444444444444444444444444444444444", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1a1a100a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("##########################0#10#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########################0#10#1" + "'", str1.equals("##########################0#10#1"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("100", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100a-1a100a14444444444444444444444444444444444444444", "Oracle Corporation", 56);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7 35 -1 -1", "100 0 10", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) 100, (byte) 1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 52, 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100 -1 100 1" + "'", str8.equals("100 -1 100 1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a-1a100a1" + "'", str15.equals("100a-1a100a1"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray3 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) stringUtilsArray3, "enenenenenenenenenenenenenen");
        org.junit.Assert.assertNotNull(stringUtilsArray3);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("l Machine Specificatio", "/", "sun0lwawt0macosx0lwctoolkit", 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "l Machine Specificatio" + "'", str4.equals("l Machine Specificatio"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        double[] doubleArray1 = new double[] { 1.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.Class<?> wildcardClass4 = doubleArray1.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray5 = new java.lang.reflect.AnnotatedElement[] { wildcardClass4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray5);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(annotatedElementArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "class [D" + "'", str6.equals("class [D"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100x86_64100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "#########a #########", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_Va aOracleCorporationa aO100 0 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "JAVA V");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004041", "US", 29);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-B1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T"));
    }
}

